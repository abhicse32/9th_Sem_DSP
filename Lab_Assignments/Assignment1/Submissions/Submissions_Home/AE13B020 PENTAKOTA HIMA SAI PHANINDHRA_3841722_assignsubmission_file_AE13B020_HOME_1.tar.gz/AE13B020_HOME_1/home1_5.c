#include <stdio.h>

double sqrt(double );

void main() {
    double number;
    scanf("%lf", &number);
    printf("%.15lf", sqrt(number));

}

double sqrt(double number) {
    double guessed_root = number / 2, better_root;
    better_root = 0.5 * (guessed_root + number / guessed_root);
    while (guessed_root != better_root) {
        guessed_root = better_root;
        better_root = 0.5 * (guessed_root + number / guessed_root);
    }
    return better_root;
}