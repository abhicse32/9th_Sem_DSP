#include<stdio.h>
int main(){
long double x;
x=3.123456789123456789123;
printf("%.19Lf",x);
}
