#include<stdio.h>

int main()
{
	long n;
	scanf("%ld",&n);
	printf("0x%.8x",n); 	//0x is identification flag
	return 0;
}