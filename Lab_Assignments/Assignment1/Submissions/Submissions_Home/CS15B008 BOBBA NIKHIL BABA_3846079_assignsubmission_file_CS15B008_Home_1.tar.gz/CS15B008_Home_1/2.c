//A program to find Hexadecimal form of a number.
//Program is written by Nikhil Baba.B CS15B008 on 9th August,2016

#include<stdio.h>

int main()
{
 unsigned int n;                    //Declaring an unsigned integer
 scanf("%u",&n);                    //Reading that integer
 printf("0x%08x",n);                //Printing it in hexadecimal format
 return 0;                          //Returning that integer
} 

 
