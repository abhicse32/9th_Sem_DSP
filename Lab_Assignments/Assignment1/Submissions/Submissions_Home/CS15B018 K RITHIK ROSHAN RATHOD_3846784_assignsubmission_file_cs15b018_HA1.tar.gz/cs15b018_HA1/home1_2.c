 #include<stdio.h>
//CONVERSION TO HEXADECIMAL
int main(){

  long unsigned int a;

  
  scanf("%u",&a);

  printf("0x%0.8X",a);

  return 0;
}

