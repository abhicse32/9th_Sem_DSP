#include<stdio.h>
#include<math.h>
#include<stdlib.h>
#include<string.h>



int maxcmp(int a, int b)
{
 if(a>b) return a;
 else return b;
}

int mincmp(int a, int b)
{
 if(a<b) return a;
 else return b;
}
 
int maxf(int *a,int b)
{
 int i,j,k;
 int *maxarray;
 if(b%2!=0){j=b/2+1;k=b-3;}
 else {j=b/2;k=b-2;}
 maxarray=(int*)malloc(j*sizeof(int));     
 
for(i=0;i<=k;i=i+2)
  {
   maxarray[i/2]=maxcmp(a[i],a[i+1]);
 if(b%2!=0){maxarray[j-1]=a[b-1];}
  }
 if(j!=1) maxf(maxarray,j);
 else return maxarray[0];
}
 
int minf(int *a,int b)
{
 int i,j,k;
 int *minarray;
  if(b%2!=0){j=b/2+1;k=b-3;}
 else {j=b/2;k=b-2;}
 minarray=(int*)malloc(j*sizeof(int));     
 
for(i=0;i<=k;i=i+2)
  {
   minarray[i/2]=mincmp(a[i],a[i+1]);
 if(b%2!=0){minarray[j-1]=a[b-1];}
  }
  if(j!=1) minf(minarray,j);
 else return minarray[0];
}
 


int main()
{
 int i,j,max,min;
 scanf("%d",&j);

 int *array;
 array=(int*)malloc(j*sizeof(int));
 for(i=0;i<j;i++)
 {
  scanf("%d",&array[i]);
  }
 max=maxf(array,j);
 min=minf(array,j);
 for(i=0;i<j;i++)
	{  
		if(array[i]==max) array[i]=min-1;
	}
printf("%d %d\n",max,maxf(array,j));
}

