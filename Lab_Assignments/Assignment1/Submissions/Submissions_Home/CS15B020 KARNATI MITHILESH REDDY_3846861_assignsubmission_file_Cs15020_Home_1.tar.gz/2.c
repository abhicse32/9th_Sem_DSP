#include<stdio.h>
#include<math.h>



int main()
{
	int n,i,q,m;
	scanf("%d",&n);
	printf("0x");
        for(i=7;i>=0;i=i-1)
	   {
		q=n/(int)pow(16,i);	      
		n=n%(int)pow(16,i);
		if(q<10) { printf("%c",q+48);}
		else {printf("%c",q+87);}
	   }
	printf("\n");
			     
}
