#include<stdio.h>
#include<math.h>
int primecheck(int x)
{
 int r,i;
r=(int)sqrt(x);

for(i=2;i<=r;i++)
{
 if(x%i==0) return 0;
}
return 1;
}



int main()
{
int n1,n2,i,a;
int sum=0;
if(n1>n2){a=n1;
n1=n2;n2=a;}
scanf("%d %d",&n1,&n2);
for(i=2;i<=n1;i++)
{
 if((n1%i==0)&&(n2%i==0)){if(primecheck(i)) {printf("%d\n",i);sum=1;}}
}
if(sum==0) printf("no common divisors\n");
}
