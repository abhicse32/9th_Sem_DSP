#include<stdio.h>
#include<string.h>

int main()
{
	int i,j,temp;
	char string1[100],string2[100];
	scanf("%s %s",string1,string2);

	for(i=0;;i++)
	{
	  for(j=0;;j++)
		{
		    if((int)string1[j]<(int)string1[j+1]) { temp=string1[j]; string1[j]=string1[j+1];string1[j+1]=temp;}
			 if(string1[j+1]=='\0') break;
		}
	if(string1[i+1]=='\0') break;
	}

	for(i=0;;i++)
	{
	  for(j=0;;j++)
		{
		    if((int)string2[j]<(int)string2[j+1]) { temp=string2[j]; string2[j]=string2[j+1];string2[j+1]=temp;}
			 if(string2[j+1]=='\0') break;
		}
	if(string2[i+1]=='\0') break;
	}
	
	
	
	
	if(strcmp(string1,string2)==0) printf("1\n");
	else printf("0\n");
}
