#include<stdio.h>
#include<math.h>

int main()
{
	int i;
	double n,j;
	scanf("%lf",&n);
	j=n*500;

	for(i=0;i<50;i++)
	{
		j=(j+n/j)/2;
	}	
	printf("%0.15lf\n",j);
		
}
