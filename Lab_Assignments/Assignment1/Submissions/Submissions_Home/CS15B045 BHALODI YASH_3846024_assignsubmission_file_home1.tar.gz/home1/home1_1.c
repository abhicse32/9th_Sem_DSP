/*this program is to find maximum and next-to-maximum elements in the given array of integers*/

#include<stdio.h>

void swap(int *a, int *b)
{
   int temp;
 
   temp = *b;
   *b   = *a;
   *a   = temp;   
}

int main()
{
	int max,next_max;
	long int size_array;
	long int i;

	//printf("enter the size of array:\n");
	scanf("%ld",&size_array);

	int arr[size_array];

	//taking the values from users for comparisons
	for(i=0;i<size_array;i++)
		{
			scanf("%d",&arr[i]);
		}

	//initialization of values of max,next_max
	arr[0]=max;
	arr[1]=next_max;

	if (max<next_max)
		{
			swap(&max,&next_max);		//function calling swap
		}

	//calculation of max and next_max
	for(i=2;i<size_array;i++)
		{
			if(arr[i]>max)
				{
					next_max = max;
					max = arr[i];
				}
			else if(arr[i]>next_max)
				{
					next_max = arr[i];
				}
		}
	printf("%d %d\n",max,next_max);
	return 0;
}
