/*this program will take an input as decimal number and give output of its equivalent to hexadecimal numbersystem*/

#include<stdio.h>

int main()
{
	long int decNumber,r,q;		//r==remainder;q=quotient

	int i=1,j,temp;

	char hexadecimalNumber[100];

	//printf("Enter any decimal number: ");
	scanf("%ld",&decNumber);

	q = decNumber;

	while(q!=0) 
	{
		temp = q % 16;
		//To convert integer into character
		if(temp < 10)
	       temp = temp + 48; 
		else
		   temp = temp + 55;

		hexadecimalNumber[i++]= temp;

		q = q / 16;
	}

	//printf("Equivalent hexadecimal value of decimal number %d: ",decimalNumber);

	for (j = i -1 ;j> 0;j--)
	      printf("%c",hexadecimalNumber[j]);

	return 0;
}


