/*this program will print the common prime factors of given two integers.
method is as below.
1.calculate greatest common diviser
2.facorization of gcd.
3.filtering the prime factors of gcd.*/
 
#include<stdio.h>

int gcd (int n,int m)		//to calculate greatest common divisor.
{
	int i,result;
	for (i=1;i<=n && i<=m;i++)
		{if (n%i == 0 && m%i == 0)
			{ result = i;}
		}
	return result;
}

int iprime(int i)		//to check whether the number is prime or not
{

	int j,flag;
	flag = 0;

	if (i != 1)
	{	
		for (j=2;j<=i/2;j++)
		{
			if (i%j == 0)
				{
					flag = 1;
					break;
				}
		}
		return flag;
	}
	else
	{
		flag = 1;
	}
	return flag;		//flag==0 => number is prime ;flag==1 => number is non prime.
}

int factor(int l)		//function to factorize the input number;filter to check prime is included.
{
	int k;
	for(k=1;k<=l;k++)
		{
			if (l%k == 0 && iprime(k) == 0)
				{printf("%d ",k);}
		}
	return 0;
}

int main()
{
	int gcd(int ,int );
	int factor(int );
	int iprime(int );
	int j,k;
	//printf("enter two numbers:");
	scanf("%d %d",&j,&k);
	factor(gcd(j,k));	
	return 0;
}
