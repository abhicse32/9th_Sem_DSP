#include <stdio.h>
 
int check_anagram(char [], char []);
 
int main()
{
   char a[100], b[100];
   int flag;
 
   //printf("Enter first string\n");
   scanf("%s",a);
 
   //printf("Enter second string\n");
   scanf("%s",b);
 
   flag = check_anagram(a, b);
 
   printf("%d",flag);
 
   return 0;
}
 
int check_anagram(char a[], char b[])
{
   int first[26] = {0}, second[26] = {0}, c = 0;
 
   while (a[c] != '\0')
   {
      first[a[c]-'a']++;
      c++;
   }
 
   c = 0;
 
   while (b[c] != '\0')
   {
      second[b[c]-'a']++;
      c++;
   }
 
   for (c = 0; c < 26; c++)
   {
      if (first[c] != second[c])
         return 0;
   }
 
   return 1;		//flag == 1 => anagrams;flag == 0 => not anagrams
}
