#include<stdio.h>
#include<math.h>

int main()
{
	int num;
	scanf("%d",&num);

	long double x = (long double)(num/2);	//initial guess root is num/2

	while(fabs((x*x)-num) > pow(10,-16))
	{
		x = x - ((x*x)-num)/(long double)(2*x);
	}
	
	printf("%.15Lf",x);		
	return 0;
}
