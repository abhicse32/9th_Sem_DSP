#include<stdio.h>
#include<math.h>
struct complexnum 
      {
        float real;
        float imag;
      };

float add (float num1 , float num2)
        {
          float sum ;
          sum = num1+num2 ;
          return sum ;
        };

float subtract (float num1 , float num2)
        {
          float sub ;
          sub = num1-num2 ;
          return sub ;
        };
 
float multiplyreal (float num1 , float num2,float num3 , float num4)
        {
          float mulreal ;
         mulreal = ((num1*num3)-(num2*num4));
	 return mulreal;
        };

float multiplyimag (float num1 , float num2,float num3 , float num4)
        {
          float mulimag ;
         mulimag = ((num1*num4)+(num2*num3));
	 return mulimag;
        };

float divisionreal (float num1 , float num2,float num3 , float num4)
        {
          float divreal ;
         divreal = (((num1*num3)+(num2*num4))/((num3*num3)+(num4*num4)));
	 return divreal;
        };

float divisionimag (float num1 , float num2,float num3 , float num4)
        {
          float divimag ;
         divimag = (((num2*num3)-(num1*num4))/((num3*num3)+(num4*num4)));
	 return divimag;
        };

float modulus (float num1 , float num2,float num3 , float num4)
        {
          float a , b,abs ;
          a = num1-num3 ;
          b = num2-num4 ;
          abs = sqrt((a*a) +(b*b));
          return abs;
        };


int  main() 
   {
        
        while(1)
      {
         struct complexnum num1 ,num2 ;
        int oprtn ;
        float addreal,addimag,subreal,subimag,mulreal,mulimag,divreal,divimag,mod;
        scanf("%f %f", &num1.real,&num1.imag);
  	scanf("%f %f", &num2.real,&num2.imag);
  	scanf("%d", &oprtn);
        if (oprtn>=0 && oprtn<=5)
          {
  	switch (oprtn)
          {
         case 1 : addreal = add (num1.real,num2.real);
                  addimag = add (num1.imag,num2.imag);
 		  printf("%f + i%f \n",addreal,addimag);
                  break;
         case 2 : subreal = subtract (num1.real,num2.real);
                  subimag = subtract (num1.imag,num2.imag);
 		  printf("%f + i%f \n",subreal,subimag);
                  break;
   	 case 3 : mulreal = multiplyreal(num1.real,num1.imag,num2.real,num2.imag);
		  mulimag = multiplyimag(num1.real,num1.imag,num2.real,num2.imag);
                  printf("%f + i%f \n",mulreal,mulimag);
                  break;
         case 4 : divreal = divisionreal(num1.real,num1.imag,num2.real,num2.imag);
		  divimag = divisionimag(num1.real,num1.imag,num2.real,num2.imag);
                  printf("%0.6f + i%0.6f \n",divreal,divimag);
                  break;
         case 5 : mod= modulus(num1.real,num1.imag,num2.real,num2.imag);
                  printf("%0.6f \n",mod);
                  break;
         case 0: return 0;
         
           }
           }
      }
    }
