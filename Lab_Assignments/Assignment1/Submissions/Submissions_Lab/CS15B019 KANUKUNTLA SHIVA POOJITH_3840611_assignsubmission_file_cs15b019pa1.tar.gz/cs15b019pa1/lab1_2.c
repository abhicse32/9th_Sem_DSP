#include<stdio.h>
#include<math.h>
int main ()
  {
     int a[100];
     int count,i,max,min,b;
     scanf("%d",&count);

    for (i=0;i<count;++i)
      {
      scanf("%d",&a[i]);
      }

    if (a[0]>a[1])
      {
      max = a[0];  
      min = a[1];   
      }
    else 
      {
       max = a[1];
       min = a[0];      
      }

    for (b=2;b<=count;b+=2)
      {
       if (a[b]>a[b+1])
          {
           if (a[b]>max)
               {
               max =a[b];
               }
               if (a[b+1]<min)
               {
               min = a[b+1];
                }
          }

        if (a[b+1]>a[b])
          {
           if (a[b+1]>max)
               {
               max =a[b+1];
               }
               if (a[b]<min)
                {
               min = a[b];
                }
          }
     printf("%d  %d \n",min, max);
	

}






























}
