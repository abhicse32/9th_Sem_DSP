/*
This program was done by R.Gokulan, Roll Num. CS15B033 on 8-8-2016.
This program manipulates complex numbers according to the user's input.
*/
#include <stdio.h>
#include <math.h>
struct Complex//Structure definition
{
	float r;
	float i;
};
struct Complex add(struct Complex a, struct Complex b)
{
	struct Complex c;
	c.r = a.r + b.r;
	c.i = a.i + b.i;
	return c;
}
struct Complex sub(struct Complex a, struct Complex b)
{
	struct Complex c;
	c.r = a.r - b.r;
	c.i = a.i - b.i;
	return c;
}
struct Complex mul(struct Complex a, struct Complex b)
{
	struct Complex c;
	c.r = a.r * b.r - a.i * b.i;
	c.i = a.i * b.r + a.r * b.i;
	return c;
}
struct Complex div(struct Complex a, struct Complex b)
{
	struct Complex c;
	b.i = 0-b.i;
	c = mul (a,b);
	c.r = c.r/(b.r * b.r + b.i * b.i);
	c.i = c.i/(b.r * b.r + b.i * b.i);
	return c;
}
float mod(struct Complex a, struct Complex b)
{
	float x = (a.r - b.r)*(a.r - b.r);
	float y = (a.i - b.i)*(a.i - b.i);
	float val = x+y;
	float d = sqrt(val);
	return d;
}

int main()
{
	int flag = 0; // for termination of loop
	while ( flag == 0)
	{
		int choice;
		struct Complex a;
		struct Complex b;
		struct Complex c;
		scanf("%f %f", &a.r, &a.i);
		scanf("%f %f", &b.r, &b.i);

		scanf("%d", &choice);

		switch(choice)
		{
			case 1:{
					c = add(a,b);
					printf("%f+%fi\n", c.r, c.i);
					break;
					}
			case 2:{
					 
					c = sub(a,b);
					printf("%f+%fi\n", c.r, c.i);
					break;
					}
			case 3:{
					 
					c = mul(a,b);
					printf("%f+%fi\n", c.r, c.i);
					break;
					}
			case 4:{
					 
					c = div(a,b);
					printf("%f+%fi\n", c.r, c.i);
					break;
					}
			case 5:{
					 
					float d = mod(a,b);
					printf("%f\n", d);
					break;
					}
			case 0:
			case -1:
					{
					flag = -1;// ensures loop exit condition
					break;
					}
		}
	}
	return 0;
}
