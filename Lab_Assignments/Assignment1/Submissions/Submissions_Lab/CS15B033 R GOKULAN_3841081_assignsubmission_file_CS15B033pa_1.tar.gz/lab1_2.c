/*
This program was done by R.Gokulan, Roll Num. CS15B033 on 8-8-2016.
This program finds the min and max of array of integers in best possible way.
*/
#include <stdio.h>
#include <stdlib.h>

int main()
{
	int n;
	int a[100];
	int a1[50];
	int a2[50];
	int i;
	int j;
	int k;

	scanf("%d", &n);

	for (i = 0; i<n; i++)
	{
		scanf("%d", &a[i]);//Reading input
	}


	for( i =0, j =0 ; i<n-1; i+=2, j++ )
	{
		if( a[i]>a[i+1])
		{
			a1[j] = a[i];
			a2[j] = a[i+1];
		}
		else
		{
			a1[j] = a[i+1];
			a2[j] = a[i];
		}
	}//Splitting input into two arrays

	
	if ( n%2 == 0)
		k = n/2;
	else
		{
			k = n/2;
			a[j+1] = a[n-1];
		}

	int max = a1[0];//Finding max
	for( j = 1; j< k; j++)
	{
		if( a1[j] > max)
			max = a1[j];
	}
	int min = a2[0];//Finding min
	for( j = 1; j< k; j++)
	{
		if( a2[j] < min)
			min = a2[j];
	}
	printf("%d %d\n", min, max);
	return 0;
}
