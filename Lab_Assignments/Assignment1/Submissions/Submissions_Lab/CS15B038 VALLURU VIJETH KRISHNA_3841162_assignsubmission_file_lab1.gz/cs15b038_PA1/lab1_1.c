#include<stdio.h>
#include<math.h>

struct comp
  {
   float r;
   float i;
  };

struct comp Add(struct comp comp1 , struct comp comp2);
struct comp Sub(struct comp comp1 , struct comp comp2);
struct comp Mult(struct comp comp1 , struct comp comp2);
struct comp Div(struct comp comp1 , struct comp comp2);
struct comp Dis(struct comp comp1 , struct comp comp2);

int main()
 {
  struct comp c1;
  struct comp c2;
  struct comp c3;
  scanf("%f",&c1.r);
  scanf("%f",&c1.i);
  scanf("%f",&c2.r);
  scanf("%f",&c2.i); 
  
  int z;
  scanf("%d",&z);
 
  while( z != 0 )
  
    {
     if(z==1) c3 = Add(c1, c2);
      
     if(z==2) c3 = Sub(c1, c2);
     
     if(z==3) c3 = Mult(c1, c2);
   
     if(z==4) c3 = Div(c1, c2);

     if(z==5) c3 = Dis(c1, c2);
     
       printf("(%f)+(%f)i",c3.r,c3.i);
       scanf("%d",&z);
    }

 }

    

  struct comp Add(struct comp c1, struct comp c2)
    {
	struct comp c3;
     c3.r = c1.r + c2.r;
     c3.i = c2.i + c1.i;
     return c3;
    }

  struct comp Sub(struct comp c1, struct comp c2)
    {   
        struct comp c3;
     c3.r = c1.r - c2.r;
     c3.i = c1.i - c2.i;
      return c3;
    }
  struct comp Mult(struct comp c1, struct comp c2)
    {
         struct comp c3;
     c3.r = (c1.r)*(c2.r) - (c1.i)*(c2.i);
     c3.i = (c1.r)*(c2.i) + (c1.i)*(c2.r);
       return c3;
    }
  struct comp Div(struct comp c1, struct comp c2)
    {
      if(c2.r==0 && c2.i==0) printf("error");
     else
         {struct comp c3;
     c3.r = ((c1.r)*(c2.r) + (c1.i)*(c2.i))/(c2.r)*(c2.r)+(c2.i)*(c2.i);
     c3.i = ((c1.i)*(c2.r) - (c1.r)*(c2.i))/(c2.r)*(c2.r)+(c2.i)*(c2.i);
         return c3;}
     }
  struct  comp Dis(struct comp c1, struct comp c2)
    {
        struct comp c3;
     c3.i = 0;
     c3.r = sqrt ((c1.r - c2.r)*(c1.r - c2.r) + (c1.i - c2.i)*(c1.i - c2.i));
          return c3;   
     }
