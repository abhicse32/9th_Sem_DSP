#include<stdio.h>

int main()
 {
  int n;
  scanf("%d",&n);

  int A[n];
  int i;
  for(i=0;i<n;i++)
    {
     scanf("%d",&A[i]);
    }

  int max, min;
  int B[n/2], C[n/2];
  int j=0;
  
  for(i=0;i<n-1;i=i+2)
    {
     if(A[i]>A[i+1]) { B[j]=A[i]; C[j]=A[i+1];}
     else {B[j]=A[i+1]; C[j]=A[i];}
     j=j+1;
    }
  
  int x, y;
  max=B[0];
  min=C[0];
  
  for(x=0;x<n/2;x++)
    {
     if (B[x]>max) max=B[x];
    }
    
   for(y=0;y<n/2;y++)
     {
      if (C[y]<min) min=C[y];
     }
     
   if(n%2!=0) 
    {
     if(A[n-1]>max) max=A[n-1];
     if(A[n-1]<min) min=A[n-1];
    }
    
     printf("%d\n",max);
     printf("%d",min);
 }
