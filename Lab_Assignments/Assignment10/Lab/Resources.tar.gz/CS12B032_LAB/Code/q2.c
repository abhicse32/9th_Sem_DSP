#include <stdio.h>
#include "stack.h"
#include "List.h"

int main(){
	
}