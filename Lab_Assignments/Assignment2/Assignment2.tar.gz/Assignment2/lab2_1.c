#include <stdio.h>
#include <time.h>
#include <sys/time.h>
#include <stdlib.h>
long long iterativeFib(int n){
	long long temp,fib1=1, fib2=1;
	int i;
	for(i=3;i<=n;i++){
		temp=fib2;
		fib2+=fib1;
		fib1=temp;
	}
	return fib2;
}

long long recursiveFib(int n){
	if(n==1 || n==2)
		return 1;
	return recursiveFib(n-1)+recursiveFib(n-2);
}

int main(int argc, char **argv){
	int n,i,t;
	struct timeval tv1,tv2,tv3,tv4;
	FILE* fp;
	fp=fopen(argv[1],"a+");
	if(fp==NULL){
		printf("failed to open file\n");
		exit(1);
	}
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		gettimeofday(&tv3,NULL);
		long long iter_val= iterativeFib(n);
		gettimeofday(&tv4,NULL);
		printf("%.10lf\n",((double)(tv4.tv_usec - tv3.tv_usec))/1000000+
						  (double)(tv4.tv_sec - tv3.tv_sec));
		gettimeofday(&tv1,NULL);
		long long rec_val= recursiveFib(n);
		gettimeofday(&tv2,NULL);
		printf("%.10lf\n",((double)(tv2.tv_usec - tv1.tv_usec))/1000000+
						  (double)(tv2.tv_sec - tv1.tv_sec));
	}
	return 0;
}