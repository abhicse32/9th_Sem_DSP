
/*

Author Name: Gudur Phani Karan Reddy (EE13B077)
Time: Sun Aug 21 22:32:34 IST 2016

Description:
This program takes the number of queens/rows as input and outputs as many lines as the number of possible non-attacking configurations 
with each line containing N integers where i th integer represents the non-attacking cell of the i th row followed by a line
containing single integer representing the number of such configurations

*/

# include <stdio.h>

