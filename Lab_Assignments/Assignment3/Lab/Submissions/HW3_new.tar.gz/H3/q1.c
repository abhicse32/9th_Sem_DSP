#include<stdio.h>
#include<stdlib.h>

void countsort(int *a,int n,int max)  //countsort computation using extra array
{int l=max;

 
// int b[15000000];  //extra array used
 int* b=(int*)malloc((max)*sizeof(int));

 int i,j,k;

 for(i=0;i<=l;i++)
   b[i]=0;
   for(i=n-1;i>=0;i--)
    b[a[i]]++;
    int sum=0;
     for(i=0;i<=l;i++)
 {    sum+=b[i];
       b[i]=sum;
 }
    // int c[15000000];//extra array used
   int * c=(int*)malloc((n)*sizeof(int));
  
   for(i=n-1;i>=0;i--)
     { c[b[a[i]]--]=a[i];
     //printf("%d ",c[i]);
     }

   for(i=1;i<=n;i++)
      printf("%d ",c[i]);
        

 }


 void main()   //begining of main fn
{int *a,n,i,max,m,ii;
  //scanf("%d",&m);ii=1;
 
   scanf("%d",&n);
   scanf("%d",&max);
 a=(int*)malloc((n)*sizeof(int));  //dynamic allocation
for(i=0;i<n;i++)
 scanf("%d",&a[i]);

 countsort(a,n,max);
//printf("\n");
  //free(a);
 //ii++;
// }
 }

 
    
