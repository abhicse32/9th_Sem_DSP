#include<stdlib.h>
#include "q2_sort.h" //sort.h contains all necessary fn defns
#include<stdio.h>

#include<sys/time.h>  //for time computation

void main()
{int n,k,j,*a,*aa,i,*b,*c,*d,ii=1;
 struct timeval t1,t2;
  FILE *fp;
  fp=fopen("out2.txt","w");   //opening file in write mode
  scanf("%d",&k);
  while(ii<=k)
  { scanf("%d",&n);
fprintf(fp,"%d ",n);
    a=(int *)malloc(n*sizeof(int));   //dynamic memory allocation
     b=(int *)malloc(n*sizeof(int));
      c=(int *)malloc(n*sizeof(int));
      d=(int *)malloc(n*sizeof(int));
   
    for(j=0;j<n;j++)
   { scanf("%d",&a[j]);b[j]=c[j]=d[j]=a[j];}    //accepting values
      gettimeofday(&t1,NULL); 
      seln(a,n);
     gettimeofday(&t2,NULL);
       double time=(double)((t2.tv_usec-t1.tv_usec) +(t2.tv_sec-t1.tv_sec)*1000000);  //calculating time in micro secs
        fprintf(fp,"%lf ",time);  
      for(i=0;i<n;i++)                                                            //repeating same using other sortings
         printf("%d ",a[i]);
    printf("\n");
   gettimeofday(&t1,NULL);
    bub(b,n);
   gettimeofday(&t2,NULL);
        time=(double)((t2.tv_usec-t1.tv_usec) +(t2.tv_sec-t1.tv_sec)*1000000);
       fprintf(fp,"%lf ",time);
         for(i=0;i<n;i++)
           printf("%d ",b[i]);
    printf("\n");
   gettimeofday(&t1,NULL);
    ins(c,n);
  gettimeofday(&t2,NULL);
    time=(double)((t2.tv_usec-t1.tv_usec) +(t2.tv_sec-t1.tv_sec)*1000000);
    fprintf(fp,"%lf ",time);
  for(i=0;i<n;i++)
   printf("%d ",c[i]);
     printf("\n");
    gettimeofday(&t1,NULL);
    aa=mergesort(a,n);
  gettimeofday(&t2,NULL);
   time=(double)((t2.tv_usec-t1.tv_usec) +(t2.tv_sec-t1.tv_sec)*1000000);
    fprintf(fp,"%lf ",time);
   for(i=0;i<n;i++)
   printf("%d ",*(aa+i));
     printf("\n");
   gettimeofday(&t1,NULL);
    quick(d,n);
gettimeofday(&t2,NULL);
    time=(double)((t2.tv_usec-t1.tv_usec) +(t2.tv_sec-t1.tv_sec)*1000000);
    fprintf(fp,"%lf ",time);
   for(i=0;i<n;i++)
   printf("%d ",d[i]);
    printf("\n");ii++;
   fprintf(fp,"\n");
  }
 

  }
