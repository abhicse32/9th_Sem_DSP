#include<stdlib.h>
#include "q2_sort.h" //sort.h contains all necessary fn defns
#include<stdio.h>

#include<sys/time.h>  //for time computation


void seln(int* a,int n)       //function for selection sort
{int i,j,min,flag;

  for(i=0;i<n-1;i++)
  {min=a[i];flag=i;
   for(j=i+1;j<n;j++)
    if(min>a[j])
     {min=a[j];
      flag=j;
      }
     if(flag!=i)
     {a[flag]=a[i];
      a[i]=min;
    }
}
}


void bub(int* a,int n)        //function for bubble sort
{int i,j,t;

  for(i=0;i<n-1;i++)
  {for(j=0;j<n-1-i;j++)
    if(a[j]>a[j+1])
     {t=a[j];
      a[j]=a[j+1];
       a[j+1]=t;
      }
    }
}

void ins(int* a,int n)   //function for insertion sort
{int i,j,t;

  for(i=1;i<n;i++)
  {t=a[i];
  for(j=i-1; j>=0 && t<a[j];j--)
  a[j+1]=a[j]; 
  a[j+1]=t;
      
    }
}

void quick(int *a,int n)   //quic sort fn
{int i,j,t,temp,ll,ul;
if(n<=1)
 return;
ll=0;ul=n-1;
 t=a[rand()%(n)];
   


 
  while(ll<=ul)
  {
   while(a[ll]<t)ll++;
    while(a[ul]>t)
      ul--;

   
     if(ll<=ul)
      {temp=a[ll];
        a[ll]=a[ul];
        a[ul]=temp;
     ll++;ul--;
       }          

    } 


 quick(a,ul+1);
 quick(&a[ll],n-ll);
 }

int* merge(int *a,int*b,int m,int n)  //mergesorting function
{int i,j,k,*c;k=0;i=j=0;

c=(int*)malloc((m+n)*sizeof(int));


 while(i<m &&j<n)
{ if(a[i]<b[j])
  {c[k]=a[i];
    k++;i++;
  }
  else
  {c[k]=b[j];
    k++;j++;
   }
 }
 
 while(i<m)
{c[k]=a[i];
    k++;i++;
 }

 while(j<n)
{c[k]=b[j];
    k++;j++;
 }



 return c;
}


int *mergesort(int *a,int n)
{ 

 if(n==1)
 return a;

 else
{int mid;
 mid=n/2;

 int *c,*d;
  c=mergesort(a,n/2);
  d=mergesort(a+n/2,n-n/2);
  return merge(c,d,n/2,n-n/2);
 }
 

 }
