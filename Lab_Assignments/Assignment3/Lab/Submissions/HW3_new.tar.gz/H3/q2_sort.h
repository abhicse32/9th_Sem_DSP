#ifndef SORTING_H
#define SORTING_H
void bub(int*, int);
void seln(int*, int);
void ins(int*,int);
void quick(int*,int);
int* mergesort(int*,int);
#endif 



