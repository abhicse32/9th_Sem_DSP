/*note:in this program i have used prev defns of sorting algorithm...
       also the matgraph module is not woring in my system i have attached my output files only*/

#include"q2_sort.h"  //file which includes all function definitions
#include<stdio.h>
#include<stdlib.h>
#include<sys/time.h>  //for calculating time taken



void main()     
{   int k,n,i,ii,j,*a,*b,*c,*d,*e,l;double time;
     struct timeval t1,t2;
     scanf("%d",&k);i=1;
      FILE *fp;  FILE *fp1;
        fp=fopen("out3_insertion.txt","w");     /*opening the respective files  
       
                                                  in write mode*/
        fp1=fopen("out3_bubble.txt","w");
        FILE *fp2;
          fp2=fopen("out3_merge.txt","w");
          FILE *fp3;
         fp3=fopen("out3_quick.txt","w");
        FILE *fp4;
        fp4=fopen("out3_selection.txt","w");
    while(i<=k)
{    scanf("%d",&n);
  
  //int a[100],b[100],c[100],d[100],e[100],a1[100],b1[100],c1[100],d1[100],e1[100],a2[100],b2[100],c2[100],d2[100],e2[100];
   int *a,*b,*c,*d,*e,*a1,*b1,*c1,*d1,*e1,*a2,*b2,*c2,*d2,*e2;
   a=(int *)malloc(n*sizeof(int));   //dynamic memory allocation
     b=(int *)malloc(n*sizeof(int));
      c=(int *)malloc(n*sizeof(int));
      d=(int *)malloc(n*sizeof(int));
       a1=(int *)malloc(n*sizeof(int));   //dynamic memory allocation
     b1=(int *)malloc(n*sizeof(int));
      c1=(int *)malloc(n*sizeof(int));
      d1=(int *)malloc(n*sizeof(int));
       a2=(int *)malloc(n*sizeof(int));   //dynamic memory allocation
     b2=(int *)malloc(n*sizeof(int));
      c2=(int *)malloc(n*sizeof(int));
      d2=(int *)malloc(n*sizeof(int));
       e=(int *)malloc(n*sizeof(int));   //dynamic memory allocation
     e2=(int *)malloc(n*sizeof(int));
      e1=(int *)malloc(n*sizeof(int));
      //d=(int *)malloc(n*sizeof(int));
  
  
  
  
  
 
  ii=0;

  for(j=0;j<n;j++)                                     /*accepting values from user*/
    {scanf("%d",&a[j]);
      e[j]=d[j]=c[j]=b[j]=a[j];}
   for(j=0;j<n;j++)
    {scanf("%d",&a1[j]);
       e1[j]=d1[j]=c1[j]=b1[j]=a1[j];}
  for(j=0;j<n;j++)
    {scanf("%d",&a2[j]);
      e2[j]=d2[j]=c2[j]=b2[j]=a2[j];}
  
  
       if(ii==0)
        fprintf(fp,"%d ",n);
     gettimeofday(&t1,NULL);          //calculating time taken
       ins(a,n);
      gettimeofday(&t2,NULL);
    time=(double)((t2.tv_usec-t1.tv_usec) +(t2.tv_sec-t1.tv_sec)*1000000);
    for(l=0;l<n;l++)
    printf("%d ",a[l]);
    printf("\n");
  
     fprintf(fp,"%lf ",time);       //outputting time as per format in file
 
  //i++;
//printf("thnx");

 if(ii==0)
 fprintf(fp1,"%d ",n);

 gettimeofday(&t1,NULL);             //calculating time taken
   bub(b,n);
   gettimeofday(&t2,NULL);
   time=(double)((t2.tv_usec-t1.tv_usec) +(t2.tv_sec-t1.tv_sec)*1000000);
    fprintf(fp1,"%lf ",time); 
  for(l=0;l<n;l++)
    printf("%d ",b[l]);
    printf("\n");
 


if(ii==0)                         //outputting time as per format in file
 
fprintf(fp2,"%d ",n);

 gettimeofday(&t1,NULL); 
   int *f=mergesort(c,n);
   gettimeofday(&t2,NULL);
   time=(double)((t2.tv_usec-t1.tv_usec) +(t2.tv_sec-t1.tv_sec)*1000000);
    fprintf(fp2,"%lf ",time); 
   for(l=0;l<n;l++)
    printf("%d ",f[l]);
    printf("\n");
 
 

   if(ii==0)
    fprintf(fp3,"%d ",n);

       gettimeofday(&t1,NULL); 
        quick(d,n);
       gettimeofday(&t2,NULL);
      time=(double)((t2.tv_usec-t1.tv_usec) +(t2.tv_sec-t1.tv_sec)*1000000);
        fprintf(fp3,"%lf ",time); 
      for(l=0;l<n;l++)
       printf("%d ",d[l]);
        printf("\n");
  
 


 
if(ii==0)
 fprintf(fp4,"%d ",n);
 gettimeofday(&t1,NULL); 
   seln(e,n);
   gettimeofday(&t2,NULL);
   time=(double)((t2.tv_usec-t1.tv_usec) +(t2.tv_sec-t1.tv_sec)*1000000);
    fprintf(fp4,"%lf ",time); 
    for(l=0;l<n;l++)
    printf("%d ",e[l]);
   
    printf("\n");
   
 

    ii++;

  
  
  
  if(ii==0)
 fprintf(fp,"%d ",n);
 gettimeofday(&t1,NULL); 
   ins(a1,n);
   gettimeofday(&t2,NULL);
    time=(double)((t2.tv_usec-t1.tv_usec) +(t2.tv_sec-t1.tv_sec)*1000000);
    for(l=0;l<n;l++)
    printf("%d ",a1[l]);
    printf("\n");
  
 fprintf(fp,"%lf ",time); 
 
 

 if(ii==0)
 fprintf(fp1,"%d ",n);

 gettimeofday(&t1,NULL); 
   bub(b1,n);
   gettimeofday(&t2,NULL);
   time=(double)((t2.tv_usec-t1.tv_usec) +(t2.tv_sec-t1.tv_sec)*1000000);
    fprintf(fp1,"%lf ",time); 
  for(l=0;l<n;l++)
    printf("%d ",b1[l]);
    printf("\n");
 


if(ii==0)
 fprintf(fp2,"%d ",n);

 gettimeofday(&t1,NULL); 
   f=mergesort(c1,n);
   gettimeofday(&t2,NULL);
   time=(double)((t2.tv_usec-t1.tv_usec) +(t2.tv_sec-t1.tv_sec)*1000000);
    fprintf(fp2,"%lf ",time); 
   for(l=0;l<n;l++)
    printf("%d ",f[l]);
    printf("\n");
 
  

if(ii==0)
 fprintf(fp3,"%d ",n);

 gettimeofday(&t1,NULL); 
   quick(d1,n);
   gettimeofday(&t2,NULL);
   time=(double)((t2.tv_usec-t1.tv_usec) +(t2.tv_sec-t1.tv_sec)*1000000);
    fprintf(fp3,"%lf ",time); 
   for(l=0;l<n;l++)
    printf("%d ",d1[l]);
    printf("\n");
  
 


 
if(ii==0)
 fprintf(fp4,"%d ",n);
 gettimeofday(&t1,NULL); 
   seln(e1,n);
   gettimeofday(&t2,NULL);
   time=(double)((t2.tv_usec-t1.tv_usec) +(t2.tv_sec-t1.tv_sec)*1000000);
    fprintf(fp4,"%lf ",time); 
    for(l=0;l<n;l++)
    printf("%d ",e1[l]);
   
    printf("\n");
    
 
 

  

  
  if(ii==0)
 fprintf(fp,"%d ",n);
 gettimeofday(&t1,NULL); 
   ins(a2,n);
   gettimeofday(&t2,NULL);
    time=(double)((t2.tv_usec-t1.tv_usec) +(t2.tv_sec-t1.tv_sec)*1000000);
    for(l=0;l<n;l++)
    printf("%d ",a2[l]);
    printf("\n");
  
 fprintf(fp,"%lf ",time); 
 
  

 if(ii==0)
 fprintf(fp1,"%d ",n);

 gettimeofday(&t1,NULL); 
   bub(b2,n);
   gettimeofday(&t2,NULL);
   time=(double)((t2.tv_usec-t1.tv_usec) +(t2.tv_sec-t1.tv_sec)*1000000);
    fprintf(fp1,"%lf ",time); 
  for(l=0;l<n;l++)
    printf("%d ",b2[l]);
    printf("\n");
 


if(ii==0)
 fprintf(fp2,"%d ",n);

 gettimeofday(&t1,NULL); 
   f=mergesort(c2,n);
   gettimeofday(&t2,NULL);
   time=(double)((t2.tv_usec-t1.tv_usec) +(t2.tv_sec-t1.tv_sec)*1000000);
    fprintf(fp2,"%lf ",time); 
   for(l=0;l<n;l++)
    printf("%d ",f[l]);
    printf("\n");
 
 

if(ii==0)
 fprintf(fp3,"%d ",n);

 gettimeofday(&t1,NULL); 
   quick(d2,n);
   gettimeofday(&t2,NULL);
   time=(double)((t2.tv_usec-t1.tv_usec) +(t2.tv_sec-t1.tv_sec)*1000000);
    fprintf(fp3,"%lf ",time); 
   for(l=0;l<n;l++)
    printf("%d ",d2[l]);
    printf("\n");
 
 


 
if(ii==0)
 fprintf(fp4,"%d ",n);
 gettimeofday(&t1,NULL); 
   seln(e2,n);
   gettimeofday(&t2,NULL);
   time=(double)((t2.tv_usec-t1.tv_usec) +(t2.tv_sec-t1.tv_sec)*1000000);
    fprintf(fp4,"%lf ",time); 
    for(l=0;l<n;l++)
    printf("%d ",e2[l]);
  
    printf("\n");
   
    i++;

 
  fprintf(fp4,"\n");
  fprintf(fp2,"\n");
   
    fprintf(fp3,"\n");
    fprintf(fp1,"\n");
    fprintf(fp,"\n");

}
}
   
  



 

