#include<stdio.h>
#include<stdlib.h>
 int c1,c2,c3;  //global variables to keep track of no of countings
 
 int bin1(int*a,int n,int k)   //function to compute binary search using n/2 algorithm
{
  int ll,ul,mid;
   ll=0;ul=n-1;                      //ll-lower limit ul-upper limit
     while(ul>=ll)                    // loop condition      
  {    
         mid=(ll+ul)/2;
       if(a[mid]==k)                    //comparing with middle element
          {c1++;
          return mid;
           }
   else if(a[mid]<k)                    //assigning new ul or ll
        {
         c1+=2;
        ll=mid+1;
        }
   else
    {c1+=2;ul=mid-1;}
    }
    
    return -1;
  }
    
   int bin2(int*a,int n,int k)           //computing binary search using 1/3,2/3 div

{

  int ll,ul,mid2;
   ll=0;ul=n-1;
  while(ul>=ll)                         
  {   mid2=(2*ll+ul)/3;
         if(a[mid2]==k)
           {c2++;
            return mid2;
            }
           else if(a[mid2]<k)
           {c2+=2;
           ll=mid2+1;
           }
            else
          {       
         c2+=2;
          ul=mid2-1;
          }
  }
    
    return -1;
}
    
    int bin3(int*a,int n,int k)    //computing binary search using 1/3 *3 division
    { 
      int mid1,mid2,ll,ul;
     ll=0;
     ul=n-1;
        while(ll<=ul)
      { 
        mid1=(2*ll+ul)/3;        //2 mids needed as we split array into 3 parts
        mid2=(ll+2*ul)/3;
           if(a[mid1]==k)
       {   c3++;
       return mid1;
       }
       else if(a[mid2]==k)
        {c3+=2;
        return mid2;
        }
        else if(k<a[mid1])
        {c3+=3;
        ul=mid1-1;
        }
        else if(k<a[mid2])
        {c3+=4;
        ll=mid1+1;
        ul=mid2-1;
        }
        else 
        {c3+=4;
        ll=mid2+1;
        }
        
      }
        return -1;
        
    }
        
        
        void main()   //begining of main function
        {
       // int a[10000],n,i,k;
          int *a,n,i,k;
         scanf("%d",&n);
                 a=(int*)malloc(n*sizeof(int));                  //accepting input as per format
         for(i=0;i<n;i++)
         scanf("%d",&a[i]);
         scanf("%d",&k);
         
         printf("%d ",bin1(a,n,k));  //printing outputs as per format
         printf("%d ",bin2(a,n,k));
         printf("%d \n",bin3(a,n,k));
         printf("%d ",c1);
         printf("%d ",c2);
         printf("%d \n ",c3);
    
    }
