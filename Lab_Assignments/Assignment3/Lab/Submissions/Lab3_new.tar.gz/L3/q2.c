#include<stdio.h>
#include<stdlib.h>
void swap(int *a,int*b)   //function top swap two elements
{  int t;
   t=*a;
   *a=*b;
   *b=t;
}
void sort1(int *a,int n)   //function for sorting an array of integers using insertion sort
{   int t,i,j;
     int min=a[0];
     int indx=0;
     for(i=0;i<n;i++)
       if(a[i]<min)
         {min=a[i];
           indx=i;
           }
         a[indx]=a[0];
         a[0]=min;    
   
   
   }

void merge(int *a,int *b,int m,int n)   /* function to merge two arrays of lengths m and n respectively...
                                            here we swap elements if an element in 1st array is smaller than least element of 2nd and sort second array */
{ int i,j,k,l;
 j=0;i=0;
  while(i<m )                                 //loop condition
  {  if(a[i]>b[j])
    {
      swap(&a[i],&b[j]);
       sort1(b,n);
      i++;
     }
    else
    i++;
   }
   
    for(i=0;i<m;i++)
    printf("%d ",a[i]);
    printf("\n");
    for(i=0;i<n;i++)
    printf("%d ",b[i]);
     printf("\n");
 }
    
    void main()              //begining of main function
    {  //int a[100],b[100],m,n,i;
         int *a,*b,m,n,i;
         
       scanf("%d",&m);
         a=(int*)malloc(m*sizeof(int));
    
         for(i=0;i<m;i++)
         scanf("%d",&a[i]);   //input and output printed as expected
         scanf("%d",&n);
         b=(int*)malloc(n*sizeof(int));
        for(i=0;i<n;i++)
          scanf("%d",&b[i]);
       merge(a,b,m,n);
    
 
    }
    
     
     
