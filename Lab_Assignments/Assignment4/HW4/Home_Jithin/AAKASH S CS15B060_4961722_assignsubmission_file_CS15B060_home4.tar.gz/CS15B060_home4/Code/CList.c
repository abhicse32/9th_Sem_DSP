#include "CList.h"   //including clist.h
#include<stdio.h>
#include<stdlib.h>
#include<math.h>
CNode* cnode_new( int data)                //fn for creating new node in circular list
{CNode *cur=(CNode*)malloc(sizeof(CNode));
 cur->data=data;
 cur->next=cur;
 return cur;
 }
 
 CList* clist_new()                       //new list creation
 {CList *lst=(CList*)malloc(sizeof(CList));
 lst->head=NULL;
  return lst;}
 
 int clist_size( CList* lst )          //returns size of list
  { int i=0;
     if(lst->head==NULL) //
      return 0;
      else{
      CNode *cur;
       for(cur=lst->head;cur->next!=lst->head;cur=cur->next)
         i++;
         
         return i+1;
         }
         
      }
      
      void clist_print( CList* lst )        //printing the list completely
      { if(lst->head!=NULL)
        { CNode *cur;
       for(cur=lst->head;cur->next!=lst->head;cur=cur->next)
        printf("%d ",cur->data);
         printf("%d ",cur->data);
         printf("\n");
         }
         }
         
         
         int clist_get( CList* lst, int idx )   //getting value for particular index of list
         {if(lst->head==NULL || idx>=clist_size(lst))
           return -1;
           else
           {int i;CNode *cur=lst->head;
           for(i=0;i<idx;i++)
           cur=cur->next;
           return cur->data;
           }
           }
           
           
           void clist_append( CList* lst, int data )   //adding elements at the end
           {   CNode *cur=cnode_new(data);
               
           
            if(lst->head==NULL)
             { lst->head=cur;}
             else
             {CNode *curr;
              for(curr=lst->head;curr->next!=lst->head;curr=curr->next);
               cur->next=lst->head;
               curr->next=cur;
               }
               }
               
               
               void clist_prepend( CList* lst, int data )      //adding elements in front
               { CNode *cur=cnode_new(data);
               
           
                if(lst->head==NULL)
                { lst->head=cur;}
                else
                {CNode *curr;
                  cur->next=lst->head;
                   for(curr=lst->head;curr->next!=lst->head;curr=curr->next);
                   curr->next=cur;
                   lst->head=cur;
                   }
                   
                   }
                   
                   void clist_insert( CList* lst, int idx, int data )   //inserting at index posn
                   {   CNode *cur=cnode_new(data);
                       CNode *curr=lst->head;
                      int i,n;
                      n=clist_size(  lst );
                      // printf("h");
                       if(idx<=n)
                       {
                       if(lst->head==NULL ||idx==n) 
                        clist_append( lst,data );
                        else if(idx==0)
                        clist_prepend(  lst,  data );
                        else
                        {for(i=0;i<idx-1;i++)
                           curr=curr->next;
                           cur->next=curr->next;
                           curr->next=cur;
                           }
                           }
                           
                           }
                           
                      void  clist_remove_last( CList* lst )   //removing last element
                           {CNode *cur,curr;
                           
                            if(lst->head==NULL)
                             return;
                             else if(clist_size(  lst )==1)
                                lst->head=NULL;
                                else
                                {CNode *curr;
                                   for(curr=lst->head;curr->next->next!=lst->head;curr=curr->next);
                                    curr->next=lst->head;
                                    
                                  }
                                  
                                  }
                                  
                         void clist_remove_first( CList* lst )
                         { CNode *cur,*curr; 
                           if(lst->head==NULL)
                             return;
                             else if(clist_size(  lst )==1)
                                lst->head=NULL;
                                else
                                 {cur=lst->head; 
                                  lst->head=lst->head->next;
                                   CNode *curr;
                                   for(curr=lst->head;curr->next!=cur;curr=curr->next);
                                    curr->next=lst->head;
                                  }
                   
                           }
                           
                           void clist_remove( CList* lst, int idx )
                           {CNode *cur,*curr;int i;curr=lst->head; 
                           if(lst->head==NULL)
                             return;
                             else if(idx<clist_size( lst ))
                             {if(idx==0)
                             clist_remove_first( lst );
                             else if(idx==clist_size(  lst )-1)
                             clist_remove_last( lst );
                             else
                             {for(i=0;i<idx-1;i++)
                               curr=curr->next;
                               curr->next=curr->next->next;
                               }
                               }
               
                             }
                             
                             
                        
                                 
                                   void clist_reverse(CList* lst)    //reversing circular list
                             {  CNode *curr,*tail,*curr1,*curr2;
                                 for(curr=lst->head;curr->next!=lst->head;curr=curr->next);
                                 tail=curr;
                                 curr1=tail;
                                 //printf("\n %d",tail->data);
                                 while(tail!=lst->head->next)
                                 { 
                                   for(curr=lst->head;curr->next!=tail;curr=curr->next);
                                   tail->next=curr;
                                   curr->next=NULL;
                                   tail=curr;
                                   }//printf("hi");
                                   tail->next=lst->head;
                                   lst->head->next=NULL;
                                   curr2=lst->head;
                                   lst->head=curr1;
                                   tail=curr2;
                                   
                                   tail->next=lst->head;
                                 }
                                 
                                 
                                 
                                 
                                 
                                 
                                 
           
           
