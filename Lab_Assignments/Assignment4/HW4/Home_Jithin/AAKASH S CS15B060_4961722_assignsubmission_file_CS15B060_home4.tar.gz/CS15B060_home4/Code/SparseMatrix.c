#include "SparseMatrix.h"
#include<stdio.h>
#include<stdlib.h>

Matrix add(Matrix a, Matrix b)      //function for adding two sparse matrices
{ Matrix c;Node *curr;
   int i;
   c.row_lst=(LList**)malloc(a.n_rows*sizeof(LList*));
   for(i=0;i<a.n_rows;i++)
   c.row_lst[i]=llist_new();
   for(i=0;i<a.n_rows;i++)
   {Node *cur1=a.row_lst[i]->head;
     Node *cur2=b.row_lst[i]->head;
     Node *cur=c.row_lst[i]->head;
      while(cur2!=NULL &&cur1!=NULL)
      {
        
        if(cur1->col_ind <cur2->col_ind)
        { llist_append( c.row_lst[i], cur1->col_ind,cur1->val ); cur1=cur1->next;}
         
        else if(cur2->col_ind <cur1->col_ind)
        { llist_append( c.row_lst[i], cur2->col_ind,cur2->val ); cur2=cur2->next;}
         else
        {curr=(Node *)malloc(sizeof(Node));
        curr->val=cur1->val+cur2->val;
        curr->col_ind=cur1->col_ind;
        llist_append( c.row_lst[i], curr->col_ind,curr->val );
          cur1=cur1->next;
        cur2=cur2->next;
        }
        
       }
       
        while(cur1!=NULL)
        { llist_append( c.row_lst[i], cur1->col_ind,cur1->val ); cur1=cur1->next;}
        
        while(cur2!=NULL)
        { llist_append( c.row_lst[i], cur2->col_ind,cur2->val ); cur2=cur2->next;}
       
       
       
        
       
       }return c;
       
       }
       
 
       
       
       Matrix subtract(Matrix a, Matrix b)   //fn for subtracting two sparse matrices
{ Matrix c;Node *curr;
   int i;
   c.row_lst=(LList**)malloc(a.n_rows*sizeof(LList*));
   for(i=0;i<a.n_rows;i++)
   c.row_lst[i]=llist_new();
   for(i=0;i<a.n_rows;i++)
   {Node *cur1=a.row_lst[i]->head;
     Node *cur2=b.row_lst[i]->head;
     Node *cur=c.row_lst[i]->head;
      while(cur2!=NULL &&cur1!=NULL)
      { //curr=node_new(data);
        /*curr->data=cur1->data+cur2->data;
        cur1=cur1->next;
        cur2=cur2->next;
        llist_append( c.row_lst[i], curr->data );*/
        
        if(cur1->col_ind <cur2->col_ind)
        { llist_append( c.row_lst[i], cur1->col_ind,cur1->val ); cur1=cur1->next;}
         
        else if(cur2->col_ind <cur1->col_ind)
        { llist_append( c.row_lst[i], cur2->col_ind,-1*cur2->val ); cur2=cur2->next;}
         else
        {curr=(Node *)malloc(sizeof(Node));
        curr->val=cur1->val-cur2->val;
        curr->col_ind=cur1->col_ind;
        llist_append( c.row_lst[i], curr->col_ind,curr->val );
          cur1=cur1->next;
        cur2=cur2->next;
        }
        
       }
       
        while(cur1!=NULL)
        { llist_append( c.row_lst[i], cur1->col_ind,cur1->val ); cur1=cur1->next;}
        
        while(cur2!=NULL)
        { llist_append( c.row_lst[i], cur2->col_ind,-1*cur2->val ); cur2=cur2->next;}
       
       
       
        
       
       }return c;
       
       }
       
       
       
       Matrix matrix_vect_multiply(Matrix mat, Matrix vect)  //fn for multiplying matrix and vector
       {Matrix c;Node *curr;
   int i; int t,s,sum;sum=0;
   c.row_lst=(LList**)malloc(mat.n_rows*sizeof(LList*));
   for(i=0;i<mat.n_rows;i++)
   c.row_lst[i]=llist_new();
   
      for(i=0;i<mat.n_rows;i++)
      { curr=mat.row_lst[i]->head;
        while(curr!=NULL)
         { t=curr->col_ind;
           s=curr->val;
            if(vect.row_lst[t]->head!=NULL)
             {s=s*vect.row_lst[t]->head->val;
                sum+=s;
                }
                curr=curr->next;
                }
                if(sum!=0)
            llist_append(c.row_lst[i],0,sum);
             sum=0;
            }
            
            return c;
            }
       
       
       
       
       
       
       
       
       
       
       
      
