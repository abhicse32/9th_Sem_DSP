#include "List.h"
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>

// Create a new node with next set to NULL
Node* node_new( int data1, int data2)
{
	Node *temp;
    temp=(Node*) malloc(sizeof(Node));

    temp->col_ind=data1;
    temp->val=data2;

    temp->next=NULL;
    return temp;	//Setting next pointer to NULL	
}


// Create an empty list (head shall be NULL)
LList* llist_new()
{
	LList *start;
    start=(LList *) malloc(sizeof(LList));
    start->head=NULL;
    return start;
}



// Traverse the linked list and return its size
int llist_size( LList* lst )
{
	int count=0;
    Node *temp;
    temp=lst->head;

    while(temp!=NULL)
    {
        temp=temp->next;
        count++;
    }

    return count;
}



// Traverse the linked list and print each element
void llist_print( LList* lst)
{
	Node *temp;
    temp=lst->head;

    if(temp==NULL)
    {
        return;
    }

    while(temp!=NULL)
    {
        printf("%d ",temp->val);
        temp=temp->next;
    }

    printf("\n");	//Inserting new line in the end
}





//get the element at position @idx
Node* llist_get( LList* lst, int idx )
{
	Node *temp;
    int index=0;
    temp=lst->head;


    while(temp!=NULL)
    {
        if(index==idx)
        {
            return temp;
        }
        index++;
        temp=temp->next;
    }

    return temp;

}




// Add a new element at the end of the list
void llist_append( LList* lst, int data1, int data2)
{

    Node *temp,*new1;

    new1=node_new(data1,data2);

    if(lst->head==NULL)
    {
        lst->head=new1;
        return;
    }

    temp=lst->head;

    while(temp->next!=NULL)
    {
        temp=temp->next;
    }

    temp->next=new1;
    (temp->next)->next=NULL;	//Setting last pointer as null


}





// Add a new element at the beginning of the list
void llist_prepend( LList* lst, int data1, int data2)
{
	Node *temp,*new1;
    new1=node_new(data1,data2);

    temp=lst->head;

    lst->head=new1;
    (lst->head)->next=temp;	//Connecting the link back
}




// Add a new element at the @idx index
void llist_insert( LList* lst, int idx, int data1, int data2)
{
	int index=0;
    Node *temp,*temp1,*new1;
    temp=lst->head;

    if(idx==0)
    {
        llist_prepend(lst,data1,data2);
        return;
    }

    new1=node_new(data1,data2);

    while(temp->next!=NULL)
    {
        index++;
        if(index==idx)
        {
            break;
        }
        temp=temp->next;
    }

    temp1=temp->next;
    temp->next=new1;
    (temp->next)->next=temp1;
}