#include "SparseMatrix.h"
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>


/*Add two matrices*/
Matrix add(Matrix a, Matrix b)
{
	struct Matrix c;
	Node *temp_a,*temp_b;
	int i,row;	//Loop variables
	c.n_rows=a.n_rows;

	c.row_lst= (LList**) malloc(sizeof(LList*)*c.n_rows);

	for(i=0;i<a.n_rows;++i)
	{
		c.row_lst[i]=llist_new();
	}

	temp_a= (a.row_lst[0])->head;
	temp_b= (b.row_lst[0])->head;

	row=0;

	while(row<=(a.n_rows)-1)
	{	
		if((temp_a!=NULL)&&(temp_b!=NULL))
		{

			if(temp_a->col_ind==temp_b->col_ind)	//If the column indices are equal
			{
				llist_append(c.row_lst[row],temp_a->col_ind,temp_a->val+temp_b->val);
				temp_a=temp_a->next;
				temp_b=temp_b->next;
			}
			else if(temp_a->col_ind < temp_b->col_ind)
			{
				llist_append(c.row_lst[row],temp_a->col_ind,temp_a->val);
				temp_a=temp_a->next;
			}
			else
			{
				llist_append(c.row_lst[row],temp_b->col_ind,temp_b->val);
				temp_b=temp_b->next;
			}	
		}

		else if((temp_a!=NULL)&&(temp_b==NULL))
		{
			llist_append(c.row_lst[row],temp_a->col_ind,temp_a->val);
			temp_a=temp_a->next;
		}

		else if((temp_a==NULL)&&(temp_b!=NULL))
		{
			llist_append(c.row_lst[row],temp_b->col_ind,temp_b->val);
			temp_b=temp_b->next;
		}

		else
		{	
			row++;
			if(row<=a.n_rows-1)
			{
				temp_a=(a.row_lst[row])->head;
				temp_b=(b.row_lst[row])->head;	
			}
			
		}

		
	}

	return c;

}





/*Subtract Matrix b from a*/
Matrix subtract(Matrix a, Matrix b)
{
	struct Matrix c;
	Node *temp_a,*temp_b;
	int i,row;	//Loop variables
	c.n_rows=a.n_rows;

	c.row_lst= (LList**) malloc(sizeof(LList*)*c.n_rows);

	for(i=0;i<a.n_rows;++i)
	{
		c.row_lst[i]=llist_new();
	}

	temp_a= (a.row_lst[0])->head;
	temp_b= (b.row_lst[0])->head;

	row=0;

	while(row<=(a.n_rows)-1)
	{	
		if((temp_a!=NULL)&&(temp_b!=NULL))
		{

			if(temp_a->col_ind==temp_b->col_ind)	//If the column indices are equal
			{
				llist_append(c.row_lst[row],temp_a->col_ind,temp_a->val-temp_b->val);
				temp_a=temp_a->next;
				temp_b=temp_b->next;
			}
			else if(temp_a->col_ind < temp_b->col_ind)
			{
				llist_append(c.row_lst[row],temp_a->col_ind,temp_a->val);
				temp_a=temp_a->next;
			}
			else
			{
				llist_append(c.row_lst[row],temp_b->col_ind, -temp_b->val);
				temp_b=temp_b->next;
			}	
		}

		else if((temp_a!=NULL)&&(temp_b==NULL))
		{
			llist_append(c.row_lst[row],temp_a->col_ind,temp_a->val);
			temp_a=temp_a->next;
		}

		else if((temp_a==NULL)&&(temp_b!=NULL))
		{
			llist_append(c.row_lst[row],temp_b->col_ind,-temp_b->val);
			temp_b=temp_b->next;
		}

		else
		{	
			row++;
			if(row<=a.n_rows-1)
			{
				temp_a=(a.row_lst[row])->head;
				temp_b=(b.row_lst[row])->head;	
			}
			
		}

		
	}

	return c;
}





/*Multiply an M x N matrix with N X 1 vector*/
Matrix matrix_vect_multiply(Matrix mat, Matrix vect)
{
	struct Matrix c;
	int i,row=0;	//Loop variables
	int ans=0,hold;
	Node *temp;

	c.n_rows=mat.n_rows;

	c.row_lst= (LList**) malloc(sizeof(LList*)*c.n_rows);


	for(i=0;i<mat.n_rows;++i)
	{
		c.row_lst[i]=llist_new();
	}

	temp=(mat.row_lst[row])->head;


	while(row<mat.n_rows)
	{
		while(temp!=NULL)
		{	
			if( ((vect.row_lst[ (temp->col_ind) ])->head)!=NULL )
			{
				hold = ((vect.row_lst[ (temp->col_ind) ])->head)->val;
			}
			else
			{
				hold = 0;
			}
			//hold=((vect.row_lst[ (temp->col_ind) ])->head)->val
			//ans=ans+temp->val*((vect.row_lst[ (temp->col_ind) ])->head)->val;
			ans=ans+temp->val*hold;
			temp=temp->next;
		}

		llist_append(c.row_lst[row],row,ans);
		ans=0;
		row++;
		if(row!=mat.n_rows)
		{
			temp=(mat.row_lst[row])->head;
		}
	}

	return c;

}