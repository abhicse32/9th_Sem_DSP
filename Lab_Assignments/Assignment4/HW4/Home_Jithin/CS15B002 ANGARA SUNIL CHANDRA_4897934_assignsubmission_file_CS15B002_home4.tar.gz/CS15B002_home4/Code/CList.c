#include "CList.h"
#include<stdio.h>
#include<stdlib.h>
#include<limits.h>
CNode* node_new( int data)
{
	CNode* new;
	new = (CNode*)malloc(sizeof(CNode)); 
	new->data = data;
	new->next = NULL;
	return new;
}
CList* clist_new()
{
	CList* new;
	new = (CList*)malloc(sizeof(CList)); 
	new->head = NULL ;
	return new;
}
int clist_size( CList* lst)
{
	if(lst->head==NULL) return 0;
	int c=1;
	CNode* b;
	b = (lst->head)->next;
	while(b != lst->head)
	{
		c++;
		b = b->next;
	}
	return c;
}
void clist_print( CList* lst )
{
	CNode* c;
	c = lst->head;
	printf("%d ",c->data);
	c=c->next;
	while(c != lst->head)
	{
		printf("%d ",c->data);
		c = c->next;
	}
	printf("\n");
	fflush(stdout);
}
int clist_get( CList* lst, int idx )
{
	int c=0;
	CNode* b;
	b = lst->head;
	while(b != NULL)
	{
		if(c==idx)
		return b->data;
		c++;
		b = b->next;
		if(b == lst->head) break;
	}
	return -1 ;
}
void clist_append( CList* lst, int data )
{
	CNode* b;
	CNode* c;
	b = (CNode*)malloc(sizeof(CNode));  
	b->data = data;
	b->next = lst->head;
	c = lst->head;
	if(c == NULL) 
	{	
		lst->head = b;
		b->next = lst->head;
	}
	else
	{
		while(c->next != lst->head)
		{
			c = c->next;
		}
		c->next = b;
	}
}
void clist_prepend( CList* lst, int data )
{
	CNode* b;
	CNode* c;
	c = lst->head;
	if(c==NULL) clist_append(lst,data);
	else
	{
		b = (CNode*)malloc(sizeof(CNode)); 
		b->data = data;
		b->next = lst->head;
		while(c->next != lst->head)
		{
			c = c->next;
		}
		c->next = b;
		lst->head = b;
	}
}
void clist_insert( CList* lst, int idx, int data )
{	
	CNode* b;
	CNode* c;
	if(idx>clist_size(lst)) return;
	b = (CNode*)malloc(sizeof(CNode));  
	int i;
	b->data = data;
	c = lst->head;
	if(idx==0)
	{
		clist_prepend(lst,data);		
	}
	else
	{
		for(i=0;c->next != lst->head;i++)
		{ 
			if(i==idx-1) break;
			else c = c->next;
		}		
		b->next = c->next;
		c->next = b;
		if(c->next==lst->head) return;
	}
}
void clist_remove_last( CList* lst )
{
	CNode* c; 
	c = lst->head;
	while((c->next)->next != lst->head)
	{
		c = c->next;
	}
	c->next = lst->head;
}
void clist_remove_first( CList* lst )
{
	CNode* c;
	c=lst->head;
	while(c->next != lst->head)
	{
		c = c->next;
	}
	lst->head = (lst->head)->next ;
	c->next = lst->head;
}
void clist_remove( CList* lst, int idx )
{
	CNode* c;
	CNode* b;
	c = lst->head;
	if(idx>=clist_size(lst)) return;
	int i;
	if(idx==0)
	{
		clist_remove_first(lst) ;
	}
	else
	{
		c=c->next;
		b=lst->head;
		for(i=0;c!= lst->head;i++)
		{
			if(i==idx-1) break;
			else 
			{
				c = c->next;
				b=b->next;
			}
		}
		b->next = (b->next)->next ;
	}
}
void clist_reverse(CList* lst)
{
	CNode* c;
	c = lst->head;
	int t=clist_size(lst);
	int a[t],i,n,x;
	for(i=0;c->next != lst->head;i++)
	{
		a[i]=c->data;
		c=c->next;
	}
	n=i;
	x = c->data;
	c = (lst->head);
	for(i=n-1;i>=0;i--)
	{
		(c->next)->data=a[i];
		c=c->next;
	}
	(lst->head)->data = x;
	
}
