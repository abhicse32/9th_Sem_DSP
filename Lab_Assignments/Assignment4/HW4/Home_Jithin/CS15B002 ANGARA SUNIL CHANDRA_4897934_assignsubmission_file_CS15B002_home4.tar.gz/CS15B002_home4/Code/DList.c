#include "DList.h"
#include<stdio.h>
#include<stdlib.h>
#include<limits.h>
DNode* node_new( int data)
{
	DNode* new;
	new = (DNode*)malloc(sizeof(DNode)); 
	new->data = data;
	new->next = NULL;
	new->prev = NULL;
	return new;
}
DList* dlist_new()
{
	DList* new;
	new = (DList*)malloc(sizeof(DList)); 
	new->head = NULL ;
	return new;
}
int dlist_size( DList* lst)
{
	int c=0;
	DNode* b;
	b = lst->head;
	while(b != NULL)
	{
		c++;
		b = b->next;
	}
	return c;
}
void dlist_print( DList* lst )
{
	DNode* c;
	c = lst->head;
	while(c != NULL)
	{
		printf("%d ",c->data);
		c = c->next;
	}
	printf("\n");
}
int dlist_get( DList* lst, int idx )
{
	int c=0;
	DNode* b;
	b = lst->head;
	while(b != NULL)
	{
		if(c==idx)
		return b->data;
		c++;
		b = b->next;
	}
	return -1;
}
void dlist_append( DList* lst, int data )
{
	DNode* b;
	DNode* c;
	b = (DNode*)malloc(sizeof(DNode));  
	b->data = data;
	b->next = NULL;
	c = lst->head;
	if(c == NULL) 
	{	
		lst->head = b;
		b->next = NULL;
		b->prev = NULL;
	}
	else
	{
		while(c->next != NULL)
		{
			c = c->next;
		}
		c->next = b;
		b->prev = c;
	}
}
void dlist_prepend( DList* lst, int data )
{
	DNode* b;
	DNode* c;
	c = lst->head;
	b = (DNode*)malloc(sizeof(DNode)); 
	b->data = data;
	if(lst->head == NULL)
	{
		lst->head = b;
	}
	else
	{
		b->next = lst->head;
		b->prev = NULL;
		c->prev = b;
		lst->head = b;
	}
}
void dlist_insert( DList* lst, int idx, int data )
{	
	DNode* b;
	DNode* c;
	b = (DNode*)malloc(sizeof(DNode));  
	int i;
	b->data = data;
	c = lst->head;
	if(idx==0)
	{
		dlist_prepend(lst,data);		
	}
	else if( idx > dlist_size(lst));
	else
	{
		for(i=0;c != NULL;i++)
		{ 
			if(i==idx-1) break;
			else c = c->next;
		}
		if(c==NULL) return;
		b->next = c->next;
		c->next = b;
		b->prev = c;
	}
}
void dlist_remove_last( DList* lst )
{
	DNode* c; 
	c = lst->head;
	while((c->next)->next != NULL)
	{
		c = c->next;
	}
	(c->next)->prev = NULL;
	c->next = NULL;
}
void dlist_remove_first( DList* lst )
{
	DNode* c;
	c=lst->head;
	lst->head = (lst->head)->next ;
	((lst->head)->next)->prev = NULL;
}
void dlist_remove( DList* lst, int idx )
{
	DNode* c;
	DNode* b;
	c = lst->head;
	if(idx>=dlist_size(lst)) return;
	int i;
	if(idx==0)
	{
		dlist_remove_first(lst) ;
	}
	else
	{
		c=c->next;
		b=lst->head;
		for(i=0;c!= NULL;i++)
		{
			if(i==idx-1) break;
			else 
			{
				c = c->next;
				b=b->next;
			}
		}
		(b->next)->prev = NULL;
		b->next = c->next ;
		c = c->next;
		c->prev = b;
	}
}
void dlist_reverse(DList* lst)
{
	DNode* c;
	c = lst->head;
	int t=dlist_size(lst);
	int a[t],i,n,x;
	for(i=0;c->next != NULL;i++)
	{
		a[i]=c->data;
		c=c->next;
	}
	n=i;
	x = c->data;
	c = (lst->head);
	for(i=n-1;i>=0;i--)
	{
		(c->next)->data=a[i];
		c=c->next;
	}
	(lst->head)->data = x;
	
}
