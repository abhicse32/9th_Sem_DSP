#include "List.h"
#include<stdio.h>
#include<stdlib.h>
#include<limits.h>
Node* node_new( int data1,int data2)
{
	Node* new;
	new = (Node*)malloc(sizeof(Node)); 
	new->col_ind = data1;
	new->val = data2;
	new->next = NULL;
	return new;
}
LList* llist_new()
{
	LList* new;
	new = (LList*)malloc(sizeof(LList)); 
	new->head = NULL ;
	return new;
}
int llist_size( LList* lst)
{
	int c=0;
	Node* b;
	b = lst->head;
	while(b != NULL)
	{
		c++;
		b = b->next;
	}
	return c;
}
void llist_print( LList* lst )
{
	Node* c;
	c = lst->head;
	if(c==NULL) return;
	while(c != NULL)
	{
		printf("%d ",c->val);
		c = c->next;
	}
	printf("\n");
		fflush(stdout);
}
Node* llist_get( LList* lst, int idx )
{
	int c=0;
	Node* b;
	b = lst->head;
	while(b != NULL)
	{
		if(c==idx)
		return b;
		c++;
		b = b->next;
	}
}
void llist_append( LList* lst, int data1,int data2 )
{
	Node* b;
	Node* c;
	b = (Node*)malloc(sizeof(Node));  
	b->col_ind = data1;
	b->val = data2;
	b->next = NULL;
	c = lst->head;
	if(c == NULL) lst->head=b;
	else
	{
		while(c->next != NULL)
		{
			c = c->next;
		}
		c->next = b;
	}
}
void llist_prepend( LList* lst, int data1, int data2 )
{
	Node* b;
	b = (Node*)malloc(sizeof(Node)); 
	b->col_ind = data1;
	b->val = data2;
	b->next = (lst->head);
	(lst->head) = b;
}
void llist_insert( LList* lst, int idx, int data1, int data2 )
{	
	Node* b;
	Node* c;
	b = (Node*)malloc(sizeof(Node));  
	int i;
	b->col_ind = data1;
	b->val = data2;
	c = lst->head;
	if(idx==0)
	{
		b->next = c;
		(lst->head) = b;
	}
	else
	{
		for(i=0;c != NULL;i++)
		{ 
			if(i==idx-1) break;
			else c = c->next;
		}
		b->next = c->next;
		c->next = b;
	}
}
