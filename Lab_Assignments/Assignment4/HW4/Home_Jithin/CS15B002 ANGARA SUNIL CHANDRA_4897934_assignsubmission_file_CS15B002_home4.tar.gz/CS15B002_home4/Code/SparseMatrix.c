#include "SparseMatrix.h"
#include<stdio.h>
#include <stdlib.h> 
Matrix add(Matrix a, Matrix b)										//Adding matrices a,b and saving the result in a
{
	int i;
	for(i=0;i<a.n_rows;i++)	
	{
		Node* a1; Node* b1;
		int c1,d1,c2,d2,x=0;
		a1=(a.row_lst[i])->head;
		b1=(b.row_lst[i])->head; 
		while (a1!=NULL && b1!=NULL)
		{
			d1=a1->col_ind;
			c1=a1->val;
			d2=b1->col_ind;
			c2=b1->val;
			if(d2<d1) 
			{			
				llist_insert((a.row_lst[i]),x, d2,c2); 
				b1=b1->next;
				x++;
				continue ;
			}		
			else if(d2==d1) 
			{		
				a1->val=c1+c2;
				b1=b1->next;
			}
			a1=a1->next;
			x++;
		}
		while (b1!=NULL)
		{
			d2=b1->col_ind;
			c2=b1->val;
			llist_append((a.row_lst[i]),d2,c2);
			b1=b1->next;
		}
	}
	return a;
}
Matrix subtract(Matrix a,Matrix b)									//Adding matrices a , (-b)
{
	int i,m,k;
	m=b.n_rows;
	for(i=0;i<m;i++)
	{
		Node* c;
		c= (b.row_lst[i])->head;
		while(c!=NULL)	
		{
			k = c->val;
			c->val= -k;
			c=c->next;
		}
	}
	return add(a,b);
}
Matrix matrix_vect_multiply(Matrix a, Matrix b)						//Multiplying matrix a and vector b
{
	Matrix c;int i,j;
	int m = a.n_rows;
	int n = b.n_rows;
	c.row_lst = (LList**)malloc(sizeof(LList*)*m);
	for(i=0;i<m;i++)
	{
		Node* a1;
		a1=a.row_lst[i]->head;
		int sum=0;
		while (a1!=NULL)
		{
			int x = a1->col_ind;
			if(b.row_lst[x]->head != NULL)
			{
				sum+=(a1->val) * ((b.row_lst[x]->head)->val);
			}
			a1=a1->next;
		}
		c.row_lst[i]=llist_new();
		llist_append(c.row_lst[i],0,sum);
	}
	c.n_rows = m;
	return c;
}
