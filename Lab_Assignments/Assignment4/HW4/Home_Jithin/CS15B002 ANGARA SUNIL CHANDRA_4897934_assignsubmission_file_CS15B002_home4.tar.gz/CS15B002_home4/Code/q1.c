#include "SparseMatrix.h"
#include<stdio.h>
#include<stdlib.h>
void print(Matrix m);
int main()
{
	int i,j,o,m,n,p;
	Matrix a,b;
	while (1){
	scanf("%d",&o);
	scanf("%d%d",&m,&n);											//Scanning option and getting the order of matrices
	if(o==-1) return 1;
	else if((o==1)||(o==2))
	{
		Matrix a,b;
		a.n_rows = m;
		b.n_rows = m;
		a.row_lst = (LList**)malloc(sizeof(LList*) * m);
		for(i=0;i<m;i++)
		{
			a.row_lst[i] = llist_new();								//Saving the non zero elements of a row in matrix a in a linked list
			for(j=0;j<n;j++)
			{
				scanf("%d",&p);
				if(p!=0) 
				{
					llist_append(a.row_lst[i],j,p);
				}
			}
		}
		b.row_lst = (LList**)malloc(sizeof(LList*) * m);
		for(i=0;i<m;i++)
		{
			b.row_lst[i] = llist_new();								//Saving the non zero elements of a row in matrix b in a linked list
			for(j=0;j<n;j++)
			{
				scanf("%d",&p);
				if(p!=0) 
				{
					llist_append(b.row_lst[i],j,p);
				}
			}
		}
		if(o==1) 
		{
			a=add(a,b);
			print(a);
		}
		else 
		{
			a=subtract(a,b);
			print(a);
		}
	}
	else if(o==3)
	{
		Matrix a,b;
		a.n_rows = m;
		b.n_rows = m;
		a.row_lst = (LList**)malloc(sizeof(LList*) * m);
		for(i=0;i<m;i++)
		{
			a.row_lst[i] = llist_new();								//Saving the non zero elements of a row in matrix a in a linked list
			for(j=0;j<n;j++)
			{
				scanf("%d",&p);
				if(p!=0) 
				{
					llist_append(a.row_lst[i],j,p);
				}
			}
		}
		b.row_lst = (LList**)malloc(sizeof(LList*)*n);
		for(i=0;i<n;i++)											//Saving elements of vector in matrix b
		{
			b.row_lst[i] = llist_new();
			scanf("%d",&p);
			if(p!=0) 
			{		
				llist_append(b.row_lst[i],0,p);
			}
		}
		Matrix c;
		c = matrix_vect_multiply(a,b);
		print(c);
	}
	}
	return 0;
}
void print(Matrix m)												//Printing matrix 
{
	int i;
	int c= m.n_rows;
	for(i=0;i<c;i++)
	{
		llist_print(m.row_lst[i]);
	}
	fflush(stdout);
}
