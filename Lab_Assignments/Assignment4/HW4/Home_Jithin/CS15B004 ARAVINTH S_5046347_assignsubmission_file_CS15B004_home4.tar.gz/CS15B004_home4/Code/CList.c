#include "CList.h"
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

// Create a new CNode with next set to NULL
CNode* cnode_new( int data)
{
	CNode* new;
	new = (CNode*) malloc (sizeof(CNode));
	new -> data = data;
	new -> next = new;
	return new;
}

// Create an empty list (head shall be NULL)
CList* clist_new()
{
	CList* lst= ( CList*) malloc (sizeof(CList));
	lst -> head = NULL; 									// head is a pointer that points to first element of list. here NULL
	return lst;
}

// Traverse the linked list and return its size
int clist_size( CList* lst )
{
	int ctr = 1;
	CNode* cur;
	cur = lst-> head -> next;
	while( cur!= lst -> head)
		{ 
			ctr++;
			cur = cur -> next;
		}
	
	return ctr;
	
}

// Traverse the linked list and print each element
void clist_print( CList* lst )
{
	CNode* cur;
	cur = lst-> head;

	if(cur == NULL)
		return;

	printf("%d ", cur -> data);
	cur = cur -> next;

	while( cur != lst -> head)
		{ 
			printf("%d ", cur -> data);
			cur = cur -> next;
		}
	printf("\n");
}

//get the element at position @idx
int clist_get( CList* lst, int idx )
{

	if(clist_size(lst) <= idx )
		return -1;
	CNode* cur;
	cur = lst-> head ;

	int pos = 0, temp;
	while(1)	
		{
			if(pos == idx )
			{ 
				temp = cur -> data;
				
				return temp;
				
			}
			pos++; 
			cur = cur -> next;
		}
	return -1;	
}

// Add a new element at the end of the list
void clist_append( CList* lst, int data )
{
	CNode* cur;
	cur = lst-> head;

	CNode *new = cnode_new(data);


	if(cur == NULL)
		{
			lst -> head = new;
			new -> next = lst->head ;			
			return;
		}

	while ( cur -> next != lst -> head)
		cur = cur -> next;

	new -> next = lst -> head;       				    
	cur -> next = new;  
}

// Add a new element at the beginning of the list
void clist_prepend( CList* lst, int data )
{
	CNode* new = cnode_new(data);
	if( lst -> head == NULL)
	{
		lst -> head = new;		
		return;
	}

	CNode* cur = lst -> head;
	while ( cur -> next != lst -> head)
		cur = cur -> next;



	cur -> next = new;
	new->next=lst->head;
	lst -> head = new;

}

// Add a new element at the @idx index
void clist_insert( CList* lst, int idx, int data )
{
	if(idx == 0)
		clist_prepend( lst, data );

	else if(idx > clist_size(lst))
		return;

	else
	{	
		CNode* cur ;
		cur = lst-> head;
		CNode* new ;
		new = cnode_new(data);

		int pos = 0;
		while(1)	
			{
				if(pos+1 == idx )
				{ 
					new -> next = cur -> next;
					cur -> next = new;
					return;
				}
				pos++; 
				cur = cur -> next;
			}
	}
}


// Remove an element from the end of the list
void clist_remove_last( CList* lst )
{
	CNode* cur ;
	cur = lst-> head;

	if( cur == NULL)
		return;

	if(cur -> next == cur)
		{
			lst -> head = NULL;
			return;
		}


	if(cur != NULL)
	{	
		while ( cur -> next -> next != lst -> head)
			cur = cur -> next;

		CNode* p = cur -> next;
		cur -> next = lst -> head;
		p -> next = lst -> head;
		free(p);
		
	}        
}

// Remove an element from the beginning of the list
void clist_remove_first( CList* lst )
{	

	CNode *temp;
	if( lst -> head == NULL)
		return;

	temp=lst->head;

	if( lst -> head -> next == lst -> head)
		{
			lst -> head = NULL;
			free(temp);
			return;
		}


	CNode* cur ;
	cur = lst ->head;
	while ( cur -> next != lst -> head)
		cur = cur -> next;

	
	
	cur -> next = lst -> head -> next;
	lst -> head = lst -> head -> next;
	//free(n);

}

// Remove an element from an arbitrary @idx position in the list
void clist_remove( CList* lst, int idx )
{
	if(idx == 0)
		clist_remove_first(lst);

	else
	{
		CNode* cur;
		cur = lst-> head;
	
		int pos = 0;
		while(1)	
			{
				if(pos+1 == idx )
				{ 
					CNode* p = cur -> next;
					cur -> next = cur -> next -> next;
					p -> next = NULL;
					free(p);
					return;
				}
				pos++; 
				cur = cur -> next;
			}	
	}
}

// reverse the list
void clist_reverse(CList* lst)
{
	CList* newLst = clist_new();

	CNode* cur = lst -> head;

	if( (lst->head==NULL) || ((lst->head)->next) == lst->head )
	{
		return;
	}
	clist_prepend( newLst, cur -> data);
	cur = cur -> next;

	while(cur != lst -> head)
	{
		clist_prepend( newLst, cur -> data);
		cur = cur -> next;
	}

	lst-> head = newLst -> head;
	free(newLst);
}












