#include "DList.h"
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>


// Create a new node with next set to NULL
DNode* dnode_new(int data)
{
	DNode* new = (DNode*) malloc (sizeof(DNode));
	new -> data = data;
	new -> prev = NULL;
	new -> next = NULL;

	return new;
}

// Create an empty list (head shall be NULL)
DList* dlist_new()
{
	DList* lst = (DList*) malloc (sizeof(DList));	
	lst -> head = NULL;
	return lst;
}

// Traverse the linked list and return its size
int dlist_size( DList* lst )
{
	DNode* cur;
	cur = lst -> head;
	int size =0;
	while(cur != NULL)
	{
		cur = cur -> next;
		size ++;
	}
	return size;
}

// Traverse the linked list and print each element
void dlist_print( DList* lst )
{
	DNode* cur;
	cur = lst-> head;
	while( cur!= NULL)
		{ 
			printf("%d ", cur -> data);
			cur = cur -> next;
		}
	printf("\n");
														
}

//get the element at position @idx
int dlist_get( DList* lst, int idx )
{
	DNode* cur;
	cur = lst-> head ;

	int pos = 0, temp;
	while(cur!= NULL)	
		{
			if(pos == idx )
			{ 
				temp = cur -> data;
				
				return temp;
			}
			pos++; 
			cur = cur -> next;
		}
	return -1;	
}

// Add a new element at the end of the list
void dlist_append( DList* lst, int data )
{
	DNode* cur;
	cur = lst-> head;

	DNode* new = dnode_new(data);

	if(cur == NULL)
		{
			lst -> head = new;
			return;
		}

	while ( cur -> next != NULL)
		cur = cur -> next;
	cur -> next = new; 
	new -> prev = cur;        				    
}

// Add a new element at the beginning of the list
void dlist_prepend( DList* lst, int data )
{
	DNode* new = dnode_new(data);

	if(dlist_size == 0) 
	{  lst -> head = new; return; }
	DNode* cur = lst -> head;

	if(cur == NULL)
		{
			lst -> head = new;
			return;
		}

	new -> next = cur ;
	cur -> prev = new;
	lst -> head = new;
}

// Add a new element at the @idx index
void dlist_insert( DList* lst, int idx, int data )
{
	if(idx == 0)
		dlist_prepend( lst, data );

	else if(idx == dlist_size(lst))
		dlist_append( lst, data );

	else
	{	
		DNode* cur ; //= (Node*) malloc (sizeof(Node));
		cur = lst-> head;
		DNode* new = dnode_new(data);

		int pos = 0;
		while(cur!= NULL && cur -> next != NULL)	
			{
				if(pos+1 == idx )
				{ 
					new -> next = cur -> next;      /////  consider cur being last element
					cur -> next = new;

					new -> prev = cur;
					new -> next -> prev = new;

					return;
				}
				pos++; 
				cur = cur -> next;
			}

		// (cur -> next == NULL) case
		if( pos == idx)
			dlist_append(lst, data);
	}
}

// Remove an element from the end of the list
void dlist_remove_last( DList* lst )
{
	DNode* cur ;
	cur = lst-> head;

	if( cur == NULL)
		return;

	if(cur -> next == NULL)
		{
			lst -> head = NULL;
			return;
		}


	if(cur != NULL)
	{	
		while ( cur -> next -> next != NULL)
			cur = cur -> next;

		DNode* p = cur -> next;
		cur -> next = NULL;
		free(p);
		
	}  
}


// Remove an element from the beginning of the list
void dlist_remove_first( DList* lst )
{
	DNode* cur = lst -> head;
	if(cur -> next == NULL)
		lst -> head = NULL;

	if(cur -> next != NULL)
		{
			DNode* p = cur -> next ;
			p -> prev = NULL;
			//cur -> next = NULL;
			lst -> head = p ;
			free(cur);                         	///// check
		}

}

// Remove an element from an arbitrary @idx position in the list
void dlist_remove( DList* lst, int idx )
{
	if(idx == 0)
		dlist_remove_first(lst);

	else
	{
		DNode* cur;
		cur = lst-> head;
	
		int pos = 0;
		while(cur -> next != NULL)	
			{
				if(pos+1 == idx )
				{ 
					DNode* p = cur -> next;
					cur -> next = cur -> next -> next;
					cur -> next -> prev =cur;
					p -> next = NULL;
					// p -> prev = NULL;
					free(p);
				}
				pos++; 
				cur = cur -> next;
			}	
		// ( cur -> next -= NULL) CASE
		if( pos == idx)
		{
			cur -> prev -> next = NULL ;
			cur -> prev = NULL;
			free( cur );
		}
	}
}

void dlist_reverse(DList* lst)
{
	DNode* cur = lst -> head;
	DNode* temp;

	while( cur -> next != NULL)
	{
		temp = cur -> next;
		cur -> next = cur -> prev;
		cur -> prev = temp;
		cur = cur -> prev;
	}

	cur -> next = cur -> prev;
	cur -> prev = NULL;

	lst -> head = cur;
}





