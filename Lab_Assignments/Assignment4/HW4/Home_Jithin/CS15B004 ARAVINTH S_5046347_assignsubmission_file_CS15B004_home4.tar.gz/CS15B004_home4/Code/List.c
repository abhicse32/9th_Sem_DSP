#include "List.h"
#include <stdlib.h>
#include <stdio.h>

// Create a new node with next set to NULL
Node* node_new( int data1, int data2)
{
	Node* new;
	new = (Node*) malloc (sizeof(Node));
	new -> col_ind = data1 ;
	new -> val = data2 ;
	new -> next = NULL;
	return new;
}

// Create an empty list (head shall be NULL)
LList* llist_new()
{
	LList* lst= ( LList*) malloc (sizeof(LList));
	lst -> head = NULL;    							// head is a pointer that points to first element of list. here NULL
	return lst;
}

// Traverse the linked list and return its size
int llist_size( LList* lst )
{
	if(lst->head == NULL)
	return 0;

	int ctr = 1;
	Node* cur;
	cur = lst-> head -> next;
	while( cur!= NULL)
		{ 
			ctr++;
			cur = cur -> next;
		}
	
	return ctr;
}

// Traverse the linked list and print each element
void llist_print( LList* lst);

//get the element at position @idx
Node* llist_get( LList* lst, int idx )
{
	Node* cur;
	cur = lst-> head ;

	int pos = 0, temp;
	while(cur!= NULL)	
		{
			if(pos == idx )
				return cur;

			pos++; 
			cur = cur -> next;
		}
	return NULL;	
}

// Add a new element at the end of the list
void llist_append( LList* lst, int data1, int data2 )
{
	//printf("got in append\n");
	Node* cur;
	cur = lst-> head;

	Node* new = node_new(data1 , data2);
	

	if(cur == NULL)
		{	
			lst -> head = new;
			return;
		}
	while ( cur -> next != NULL)
		cur = cur -> next;
	cur -> next = new;
}

// Add a new element at the beginning of the list
void llist_prepend( LList* lst, int data1 , int data2)
{
	Node* new = node_new(data1, data2);
	new -> next = lst -> head ;
	lst -> head = new;
}

// Add a new element at the @idx index
void llist_insert( LList* lst, int idx, int data1, int data2)
{
	if(idx == 0)
		llist_prepend( lst, data1, data2);

	else
	{	
		Node* cur = (Node*) malloc (sizeof(Node));
		cur = lst-> head;
		Node* new = node_new(data1, data2);

		int pos = 0;
		while(cur!= NULL)	
			{
				if(pos+1 == idx )
				{ 
					new -> next = cur -> next;
					cur -> next = new;
				}
				pos++; 
				cur = cur -> next;
			}
	}
}






