#include <stdio.h>
#include <stdlib.h>
#include "SparseMatrix.h"


/*Add two matrices*/
Matrix add(Matrix mat1, Matrix mat2)
{
	LList** rows = (LList**) malloc (mat1.n_rows * sizeof(LList*));
	int value, i=0;

	int col_ind1, col_ind2, val1, val2;

	while(i < mat1.n_rows)
	{
		int idx1 = 0, idx2 = 0, idx3 = 0;
		int size1 = llist_size( mat1.row_lst[i] );
		int size2 = llist_size( mat2.row_lst[i] );

		rows[i] = llist_new();
														// exp is col_ind    val is coeffs
		while (idx1 < size1 && idx2 < size2)		//  MOVING two pointers idx1 and idx2 over the two sorted arrays
	    {
	        col_ind1 = ( llist_get( mat1.row_lst[i], idx1 )  ->  col_ind );
	        col_ind2 = ( llist_get( mat2.row_lst[i], idx2 )  ->  col_ind );

	        val1 = ( llist_get( mat1.row_lst[i], idx1 )  ->  val );
	        val2 = ( llist_get( mat2.row_lst[i], idx2 )  ->  val );


	        if( col_ind1 == col_ind2 )
	        {
	        	llist_append( rows[i], col_ind1, val1 + val2 );
	     
	        	idx1++;
	        	idx2++;
	        }

	        if(col_ind1 < col_ind2)       				
	        {
	        	llist_append( rows[i], col_ind1, val1 );
	            idx1++;
	        }


	        if(col_ind1 > col_ind2)
	        {
	           llist_append( rows[i], col_ind2, val2 );
	            idx2++;   		 
	        }
	        idx3++;
	    }


	    if (idx1 >= size1)						// after exhausting one list completely 
	    {
	        while (idx2 < size2)  					
	        {
	        	col_ind2 = ( llist_get( mat2.row_lst[i], idx2 )  ->  col_ind );
				val2 = ( llist_get( mat2.row_lst[i], idx2 )  -> val );

	            llist_append( rows[i], col_ind2, val2 );
	            idx2++;
	            idx3++;
	        }
	    }


	    else if (idx2 >= size2)
	    {
	        while (idx1 < size1)
	        {
	            col_ind1 = (llist_get( mat1.row_lst[i], idx1 )  -> col_ind );
				val1 = (llist_get( mat1.row_lst[i], idx1 )  -> val );

				llist_append( rows[i], col_ind1, val1 );
	            idx1++;
	            idx3++;
	        }
	    }

	    i++;
		
	}

	Matrix mat;
	mat.n_rows = mat1.n_rows;
	mat.row_lst = rows;
	return mat;
}

/*Add two matrices*/
Matrix subtract(Matrix mat1, Matrix mat2)
{
	LList** rows = (LList**) malloc (mat1.n_rows * sizeof(LList*));
	int value, i=0;

	int col_ind1, col_ind2, val1, val2;

	while(i < mat1.n_rows)
	{
		int idx1 = 0, idx2 = 0, idx3 = 0;
		int size1 = llist_size( mat1.row_lst[i] );
		int size2 = llist_size( mat2.row_lst[i] );

		rows[i] = llist_new();
														// exp is col_ind    val is coeffs
		while (idx1 < size1 && idx2 < size2)		//  MOVING two pointers idx1 and idx2 over the two sorted arrays
	    {
	        col_ind1 = ( llist_get( mat1.row_lst[i], idx1 )  ->  col_ind );
	        col_ind2 = ( llist_get( mat2.row_lst[i], idx2 )  ->  col_ind );

	        val1 = ( llist_get( mat1.row_lst[i], idx1 )  ->  val );
	        val2 = ( llist_get( mat2.row_lst[i], idx2 )  ->  val );


	        if( col_ind1 == col_ind2 )
	        {
	        	llist_append( rows[i], col_ind1, val1 - val2 );
	     
	        	idx1++;
	        	idx2++;
	        }

	        if(col_ind1 < col_ind2)       				
	        {
	        	llist_append( rows[i], col_ind1, val1 );
	            idx1++;
	        }


	        if(col_ind1 > col_ind2)
	        {
	           llist_append( rows[i], col_ind2, -val2 );
	            idx2++;   		 
	        }
	        idx3++;
	    }


	    if (idx1 >= size1)						// after exhausting one list completely 
	    {
	        while (idx2 < size2)  					
	        {
	        	col_ind2 = ( llist_get( mat2.row_lst[i], idx2 )  ->  col_ind );
				val2 = ( llist_get( mat2.row_lst[i], idx2 )  -> val );

	            llist_append( rows[i], col_ind2, -val2 );
	            idx2++;
	            idx3++;
	        }
	    }


	    else if (idx2 >= size2)
	    {
	        while (idx1 < size1)
	        {
	            col_ind1 = (llist_get( mat1.row_lst[i], idx1 )  -> col_ind );
				val1 = (llist_get( mat1.row_lst[i], idx1 )  -> val );

				llist_append( rows[i], col_ind1, val1 );
	            idx1++;
	            idx3++;
	        }
	    }

	    i++;
		
	}

	Matrix mat;
	mat.n_rows = mat1.n_rows;
	mat.row_lst = rows;
	return mat;
}

/*Multiply an M x N matrix with N X 1 vector*/
Matrix matrix_vect_multiply(Matrix mat, Matrix vect)
{
	Matrix matr;
	int n = vect.n_rows,m = mat.n_rows, sum;
	matr.n_rows = m;
	Node* cur1, *cur2;
	matr.row_lst= (LList**) malloc((sizeof(LList*))*m);

	for(int i=0 ; i < m ; i++)
	{
		int j;
		matr.row_lst[i] = llist_new();
		sum=0;
		
		cur1 = mat.row_lst[i]->head;
		if(cur1==NULL)
		{
			llist_append(matr.row_lst[i],0,sum);
			continue;
		}
				
		for(j=0 ; j < n ; j++)
		{
			cur2 = vect.row_lst[j]->head;
			
			if((cur1->col_ind)==j)
			{
				if(cur2 != NULL)
					sum=sum+(cur1->val)*(cur2->val);
				cur1 = cur1->next;
				if(cur1==NULL)	break;		
			}
		}
		llist_append(matr.row_lst[i],0,sum);
	}

	return matr;
}	


