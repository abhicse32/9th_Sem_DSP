
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "SparseMatrix.h"

Matrix getmatrix(int m, int n)
{
	LList** rows = (LList**) malloc (m * sizeof(LList*));
	int value, i=0, j=0;

	while(i < m)
	{
		j = 0;
		rows[i] = llist_new();

		while(j < n)
		{
			scanf("%d", &value);
			if(value != 0)
				llist_append(rows[i], j, value);
			j++;
		}

		//if(rows[i] -> head == NULL)
			//llist_append(rows[i], 0, 0);

		i++;
	}
	Matrix mat;
	mat.n_rows = m;
	mat.row_lst = rows;
	return mat;

}

void printMatrix(Matrix mat)
{
	int i = 0, j = 0;
	while( i < mat.n_rows)
	{
		int size = llist_size( mat.row_lst[i] );

		if(size	!=0)	
		{
		j=0;
		
		while( j < size)
		{
			printf("%d ", llist_get( mat.row_lst[i], j) -> val);
			j++;
		}
		printf("\n");
		
		}
		i++;
	}
}


int main()
{
	//printf("starting \n");
	int choice, m, n;
	scanf("%d", &choice);
	//printf("%d\n", choice);

	Matrix mat1, mat2, vec, mat3;

	while( choice != -1)
	{
		scanf("%d %d", &m, &n);
		switch(choice)
		{

			case 1:	//printf("getting mat1 \n");
					mat1 = getmatrix(m,n);
			//printMatrix(mat1);
					//printf("getting mat2 \n");
					mat2 = getmatrix(m,n);
			//printMatrix(mat2);
					mat3 = add(mat1, mat2);
					printMatrix(mat3);
					break;

			case 2:	//printf("getting mat1 \n");
					mat1 = getmatrix(m,n);
					//printf("getting mat2 \n");
					mat2 = getmatrix(m,n);
					mat3 = subtract(mat1, mat2);
					printMatrix(mat3);
					break;

			case 3: //printf("getting mat1 \n");
					mat1 = getmatrix(m,n);
					//printf("getting mat2 \n");
					vec = getmatrix(n,1);
					//printf("mat1 \n");
					//printMatrix(mat1);
					//printf("vec \n");
					//printMatrix(vec);
					//printf("prod \n");
					mat3 = matrix_vect_multiply(mat1, vec);
					printMatrix(mat3);
					break;
			default:
			break;
		}
		scanf("%d", &choice);
	}

	return 0;

}
