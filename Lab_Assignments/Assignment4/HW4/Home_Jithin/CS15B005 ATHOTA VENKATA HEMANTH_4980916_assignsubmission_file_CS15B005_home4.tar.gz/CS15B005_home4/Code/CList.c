#include "CList.h"
#include <stdio.h>
#include <stdlib.h>

// Create a new node with next set to NULL
CNode* cnode_new( int data)
{
	CNode *new;
    new = (CNode*)malloc(sizeof(CNode));
	new->data = data;
	new->next = NULL;
	return new;
}

// Create an empty list (head shall be NULL)
CList* clist_new()
{
	CList *clist;
    clist = (CList*)malloc(sizeof(CList));
	clist->head = NULL;
	return clist;
}

// Traverse the linked list and return its size
int clist_size( CList* lst )
{
	int size=0;
	CNode* current = lst->head;
	
	if(current==NULL)	return 0;
	
	do
	{
		size++;
		current=current->next;
	}
	while(current!=(lst->head));
	return size;
}

// Traverse the linked list and print each element
void clist_print( CList* lst )
{
	CNode* current;
	current=lst->head;
	do
	{
		printf("%d ",current->data);
		current = current->next;
	}
	while(current!=(lst->head));
	printf("\n");
	return;
}

//get the element at position @idx
int clist_get( CList* lst, int idx )
{
	int i=0;
	if(idx>=clist_size(lst))	return -1;
	CNode* current;
	current = lst->head;
	while(i!=idx)
	{
		i++;
		current=current->next;
		if(current == lst->head)	return -1;
	}
	return (current->data);
}

// Add a new element at the end of the list
void clist_append( CList* lst, int data )
{
	CNode* current = lst->head;
	CNode* new = cnode_new(data);
	if(current==NULL)
	{
		lst->head = new;
		new->next = new;
		return ;
	}
	current = current->next;
	while((current->next)!=(lst->head))
	{
		current = current->next;
	}
	current->next = new;
	new->next = lst->head;
	return;
}

// Add a new element at the beginning of the list
void clist_prepend( CList* lst, int data )
{
	if(lst->head == NULL )
	{
		clist_append( lst , data);
		return ;
	}
	CNode* current = lst->head;
	CNode* new = cnode_new(data);
	new->next = current;
	while((current->next)!=(lst->head))
	{
		current = current->next;
	}
	current->next = new;	
	lst->head = new;
	return;
}

// Add a new element at the @idx index
void clist_insert( CList* lst, int idx, int data )
{
	if(idx > clist_size ( lst ) )
	{
		return ;
	}
	CNode* current1;
	CNode* current2;
	CNode* new = cnode_new(data);
	if(idx==0)
	{
		clist_prepend( lst, data );
		return ;
	}
	if(idx==clist_size(lst))
	{
		clist_append(lst,data);
		return;
	}
	int i;
	current1 = lst->head;
	for(i=0 ; i<idx ; i++)
	{
		current2 = current1;
		current1 = current1->next;
	}
	new->next = current1;
	current2->next = new;	
	return;	
}


// Remove an element from the end of the list
void clist_remove_last( CList* lst )
{
	CNode* current;
	CNode* previous;
	current = lst->head;
	if( current==NULL )		return;
	if( clist_size(lst)==1) 
	{
		lst->head=NULL;
		return;
	}
	while( (current->next)!=(lst->head) )
	{
		previous=current;
		current=current->next;
	}
	previous->next = lst->head;
	return;
}

// Remove an element from the beginning of the list
void clist_remove_first( CList* lst )
{
	CNode* current = lst->head;
	while((current->next)!=(lst->head))
	{
		current = current->next;
	}
	current->next = lst->head->next;
	lst->head = lst->head->next;
	return ;	
}

// Remove an element from an arbitrary @idx position in the list
void clist_remove( CList* lst, int idx )
{
	CNode* current;
	CNode* previous;
	int i;
	current=lst->head;
	if(idx>=clist_size(lst))	return ;
	if(idx==0)
	{
		clist_remove_first( lst );
		return;
	}
	if(idx==clist_size(lst))
	{
		clist_remove_last(lst);
		return;
	}
	for(i=0;i<idx;i++)
	{
		previous = current;
		current = current->next;	
	}
	if((current->next)==(lst->head))
	{
		clist_remove_last( lst );
		return;
	}
	previous->next = current->next;

	return;
}

// reverse the list
void clist_reverse(CList* lst)
{
	int l = clist_size(lst);
	if(l==0 || l==1) return;
	
	CNode* current1 = lst->head->next->next;
	CNode* current2 = lst->head->next;
	CNode* current3 = lst->head;
	do
	{	
		current2->next = current3;
		current3 = current2;
		current2 = current1;
		current1 = current1->next;
	}
	while(current2!=lst->head);
	lst->head->next = current3;
	lst->head = current3;
	return ;
}
