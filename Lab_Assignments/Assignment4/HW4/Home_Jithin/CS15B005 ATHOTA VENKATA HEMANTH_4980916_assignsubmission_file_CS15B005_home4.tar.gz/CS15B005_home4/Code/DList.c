#include "DList.h"
#include <stdlib.h>
#include <stdio.h>
#include <limits.h>

// Create a new node with next set to NULL
DNode* dnode_new(int data)
{
	DNode *new;
    new = (DNode*)malloc(sizeof(DNode));
	new->data = data;
	new->next = NULL;
	new->prev = NULL;
	return new;
}

// Create an empty list (head shall be NULL)
DList* dlist_new()
{
	DList *list;
    list = (DList*)malloc(sizeof(DList));
	list->head = NULL;
	return list;
}

// Traverse the linked list and return its size
int dlist_size( DList* lst )
{
	int length=0;
	DNode* current;
	current = lst->head;
	while(current!=NULL)
	{
		length++;
		current = current->next;
	}
	return length;
}

// Traverse the linked list and print each element
void dlist_print( DList* lst )
{
	DNode* current;
	current = lst->head;
	while(current!=NULL)
	{
		printf("%d ", current->data);
		current = current->next;
	}
	printf("\n");
	return;
}

//get the element at position @idx
int dlist_get( DList* lst, int idx )
{
     if(idx>=dlist_size(lst)) return -1;
	int i=0;
	DNode* current;
	current = lst->head;
	while(i!=idx)
	{
		current=current->next;
		i++;
	}
	return (current->data);
}

// Add a new element at the end of the list
void dlist_append( DList* lst, int data )
{
	DNode* current = lst->head;
	DNode* new = dnode_new(data);
	if(current==NULL)
	{
		lst->head = new;
		new->prev = NULL;
		return ;
	}
	//current = current->next;
	while((current->next)!=(NULL))
	{
		current = current->next;
	}
	current->next = new;
	new->prev = current;
	new->next = NULL;
	return;
}

// Add a new element at the beginning of the list
void dlist_prepend( DList* lst, int data )
{
	DNode* new;
	new = dnode_new(data);
	if((lst->head) == NULL)
	{
		lst->head = new;
		return;
	}
	new->next = lst->head;
	lst->head->prev = new;
	new->prev = NULL;
	lst->head = new;
	return;
}

// Add a new element at the @idx index
void dlist_insert( DList* lst, int idx, int data )
{
	if(idx==0)
	{
		dlist_prepend(lst, data);
		return ;
	}
	if(idx==dlist_size(lst))
	{
		dlist_append(lst, data);
		return;
	}
     if(idx>dlist_size(lst)) return ;
     
	DNode* current1;
	DNode* current2;
	DNode* new = dnode_new(data);
	int i;
	current1 = lst->head;
	for(i=0 ; i<idx ; i++)
	{
		current2 = current1;
		current1 = current1->next;
	}
	new->next = current1;
	new->prev = current2;
	
	current2->next = new;
	
	current1->prev = new;
	
	return;	
}

// Remove an element from the end of the list
void dlist_remove_last( DList* lst )
{
	DNode* current;
	current = lst->head;
	if(current==NULL)	return;
	if(dlist_size(lst)==1)
	{
		lst->head = NULL;
		return;
	}
	while((current->next->next)!=NULL)
	{
		current = current->next;
	}
	current->next = NULL;
	return;
}

// Remove an element from the beginning of the list
void dlist_remove_first( DList* lst )
{
	if(lst->head==NULL)	return;
	if(dlist_size(lst)==1)
	{
		lst->head = NULL;
		return;
	}
	lst->head=(lst->head)->next;
	(lst->head)->prev = NULL;
	return;
}

// Remove an element from an arbitrary @idx position in the list
void dlist_remove( DList* lst, int idx )
{
	if(idx>dlist_size(lst)) return ;
	DNode* current = lst->head;
	int i;
	if(idx==0)
	{
		dlist_remove_first( lst );
		return;
	}
	if(idx==(dlist_size(lst)-1))
	{
		dlist_remove_last(lst);
		return;
	}
	
	for(i=0 ; i!=(idx-1) ; i++)
	{
		current = current->next;	
	}
	
	current->next = current->next->next;
	current->next->prev = current;
	return;
}

void dlist_reverse(DList* lst)
{
	if(dlist_size(lst)==0 || dlist_size(lst)==1)	return;
	DNode* current;
	current = lst->head;
	while((current->next)!=NULL)
	{
		DNode* temp;
		temp = current->prev;
		current->prev = current->next;
		current->next = temp;
		
		current = current->prev;
	}
	DNode* temp;
	temp = current->prev;
	current->prev = current->next;
	current->next = temp;
	lst->head = current;
	return ;
}

