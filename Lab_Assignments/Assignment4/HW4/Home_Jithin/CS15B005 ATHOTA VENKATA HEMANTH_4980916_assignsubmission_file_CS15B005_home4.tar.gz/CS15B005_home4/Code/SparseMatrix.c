#include "SparseMatrix.h"
#include <stdio.h>
#include <stdlib.h>

/*Multiply an M x N matrix with N X 1 vector*/
Matrix matrix_vect_multiply(Matrix mat, Matrix vect)
{
	int i , j;
	Matrix matr;
	int n = vect.n_rows;
	int m = mat.n_rows;
	int sum;
	matr.n_rows = m;
	Node* cur1;
	Node* cur2;
	matr.row_lst= (LList**) malloc((sizeof(LList*))*m);
	for(i=0 ; i < m ; i++)
	{
		matr.row_lst[i] = llist_new();
		sum=0;
		
		cur1 = mat.row_lst[i]->head;
		if(cur1==NULL)
		{
			llist_append(matr.row_lst[i],0,sum);
			continue;
		}
				
		for(j=0 ; j < n ; j++)
		{
			cur2 = vect.row_lst[j]->head;
			
			if((cur1->col_ind)==j)
			{
				if(cur2 != NULL)
					sum=sum+(cur1->val)*(cur2->val);
				cur1 = cur1->next;
				if(cur1==NULL)	break;		
			}
		}
		llist_append(matr.row_lst[i],0,sum);
	}

	return matr;
}

/*Add two matrices*/
Matrix add(Matrix mat1, Matrix mat2)
{
	int i;
	Matrix matr;
	
	int m = mat1.n_rows;
	matr.n_rows = m;

	matr.row_lst = (LList**) malloc((sizeof(LList*))*m);

	Node* cur1;
	Node* cur2;

	for(i=0 ; i < (mat1.n_rows) ; i++)
	{

		matr.row_lst[i] = llist_new();
		cur1 = mat1.row_lst[i]->head;
		cur2 = mat2.row_lst[i]->head;


		while((cur1!=NULL)&&(cur2!=NULL))
		{
			if((cur1->col_ind)==(cur2->col_ind))
			{
				llist_append( matr.row_lst[i], cur1->col_ind , (cur1->val)+(cur2->val));
				cur1 = cur1->next;
				cur2 = cur2->next;
			}
			else if((cur1->col_ind) > (cur2->col_ind))
			{
				llist_append( matr.row_lst[i], cur2->col_ind , cur2->val);
				cur2 = cur2->next;
			}
			else if((cur1->col_ind) < (cur2->col_ind))
			{
				llist_append( matr.row_lst[i], cur1->col_ind , cur1->val);
				cur1 = cur1->next;
			}
		}
		while(cur2!=NULL)
		{
			llist_append( matr.row_lst[i], cur2->col_ind , cur2->val);
			cur2 = cur2->next;
		}
		while(cur1!=NULL)
		{
			llist_append( matr.row_lst[i], cur1->col_ind , cur1->val);
			cur1 = cur1->next;
		}
	}
	return matr;
}

/*Subtract Matrix b from a*/
Matrix subtract(Matrix mat1, Matrix mat2)
{
	int i;
	Matrix matr;
	matr.n_rows = mat1.n_rows;

	int m = mat1.n_rows;

	matr.row_lst = (LList**) malloc((sizeof(LList*))*m);

	Node* cur1;
	Node* cur2;

	for(i=0 ; i < (mat1.n_rows) ; i++)
	{

		matr.row_lst[i] = llist_new();
		cur1 = mat1.row_lst[i]->head;
		cur2 = mat2.row_lst[i]->head;


		while((cur1!=NULL)&&(cur2!=NULL))
		{
			if((cur1->col_ind)==(cur2->col_ind))
			{
				llist_append( matr.row_lst[i], cur1->col_ind , (cur1->val)-(cur2->val));

				cur1 = cur1->next;
				cur2 = cur2->next;
			}
			else if((cur1->col_ind) > (cur2->col_ind))
			{
				llist_append( matr.row_lst[i], cur2->col_ind , -(cur2->val));
				cur2 = cur2->next;
			}
			else if((cur1->col_ind) < (cur2->col_ind))
			{
				llist_append( matr.row_lst[i], cur1->col_ind , cur1->val);
				cur1 = cur1->next;
			}
		}
		if(cur1==NULL)
		{
			while(cur2!=NULL)
			{
				llist_append( matr.row_lst[i], cur2->col_ind , -(cur2->val));
				cur2 = cur2->next;
			}
		}
		else if(cur2==NULL)
		{
			while(cur1!=NULL)
			{
				llist_append( matr.row_lst[i], cur1->col_ind , cur1->val);
				cur1 = cur1->next;
			}
		}
	}
	return matr;
}

