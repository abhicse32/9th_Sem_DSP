#include <stdio.h>
#include <stdlib.h>
#include "SparseMatrix.h"
#include "List.h"

void main()
{
	int opt;
	scanf("%d",&opt);
	while(opt!=-1)
	{
		if((opt==1) || (opt==2))
		{
			int m, n, i, x, j;
			scanf("%d", &m);
			scanf("%d", &n);
			Matrix mat1, mat2, matr;

			mat1.n_rows = m;
			mat2.n_rows = m;

			mat1.row_lst = (LList**) malloc(m*sizeof(LList*));

			mat2.row_lst = (LList**) malloc(m*sizeof(LList*));
			LList** p;
			LList** q;
			p=mat1.row_lst;
			for(i=0;i<m;i++)
			{
				
				p[i]=llist_new();
				for(j=0;j<n;j++)
				{
					scanf("%d", &x);
					if(x!=0)
					{
						llist_append(p[i], j, x);
					}
				}
			}

			for(i=0;i<m;i++)
			{
				mat2.row_lst[i] = llist_new();
				for(j=0;j<n;j++)
				{
					scanf("%d",&x);
					if(x!=0)
					{
						llist_append(mat2.row_lst[i], j, x);
					}
				}
			}

			if(opt==1)
			{
				matr = add( mat1, mat2);
			}
			else if(opt==2)
			{
				matr = subtract( mat1, mat2);
			}

			for(i=0;i<m;i++)
			{
				llist_print( matr.row_lst[i]);
			}
			
			free(mat1.row_lst);
			free(mat2.row_lst);
		}

		else if(opt==3)
		{
			int m, n, i, x, j;
			scanf("%d", &m);
			scanf("%d", &n);
			Matrix mat, vet, matr;

			mat.row_lst = (LList**) malloc((sizeof(LList*))*m);

			vet.row_lst = (LList**) malloc((sizeof(LList*))*n);

			mat.n_rows = m;
			vet.n_rows = n;

			for(i=0;i<m;i++)
			{
				mat.row_lst[i] = llist_new();
				for(j=0;j<n;j++)
				{
					scanf("%d",&x);
					if(x!=0)
					{
						llist_append(mat.row_lst[i], j, x);
					}
				}
			}

			for(i=0;i<n;i++)
			{
				vet.row_lst[i] = llist_new();
				scanf("%d", &x);
				if(x!=0)
				{
					llist_append(vet.row_lst[i], 0, x);
				}
			}
			matr = matrix_vect_multiply(mat, vet);
			LList** ad;
			ad=matr.row_lst;
			for(i=0;i<m;i++)
			{
				llist_print( ad[i]);
			}
			free(mat.row_lst);
			free(vet.row_lst);
		}
		scanf("%d",&opt);
	}
	return ;
}
