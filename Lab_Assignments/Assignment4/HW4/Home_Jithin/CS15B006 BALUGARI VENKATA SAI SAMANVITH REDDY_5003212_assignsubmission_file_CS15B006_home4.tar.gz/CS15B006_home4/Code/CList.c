#include "CList.h"
#include <stdio.h>
#include <stdlib.h>

CNode* cnode_new (int data){
    CNode* new = malloc(sizeof(CNode));
    new->next = NULL;
    new->data = data;
    return new;
}

CList* clist_new(){
    CList* new = malloc(sizeof(CList));
    return new;
}

int clist_size( CList* lst){

    int i = 1;
    CNode* p = lst->head;
    if(p == NULL) return 0;

    while( p -> next != lst->head){
        p = p->next;														    // Last term has next pointing to null
        i++;
    }
    return i;
}

void clist_print( CList* lst ){

    if(lst->head == NULL) return ;
    CNode* p = lst->head;

    do{															// Printing upto last variable
        printf("%d ", p->data);
        p = p->next;
    }while(p != lst->head);
    printf("\n");
    return;
}

int clist_get( CList* lst, int idx){

    if(lst->head == NULL) return -1;
    CNode* p = lst->head;
    int k = clist_size(lst);

    if( idx >= k ) return -1;											// When index is more than available terms

    int j = 0;

    while(j < idx){
        p = p->next;														//Normal cases with lower index
        j++;
    }

    return (p->data);
}

void clist_append( CList* lst, int data ){

    CNode* p;
    p = lst->head;
    if( p == NULL ){													// When there is pointer is to NULL or list is empty
     	p = cnode_new(data);
     	lst->head = p;
        p->next = lst->head;
     	return;
     }

    while( p->next != lst->head ){											// when non-empty
        p = p->next;
    }
    CNode* new = cnode_new(data);
    p->next = new;
    new->next = lst->head;														// Assigning new one's next to NULL and old last one to NEW
    return;
}

void clist_prepend( CList* lst, int data){

    if( lst->head == NULL){ 											// Adding an element at the frnt of list when it is empty
    	CNode* new = cnode_new(data);
    	lst->head = new;
        new->next = lst->head;
    	return;
    }
    CNode* p = lst->head;
    CNode* new = cnode_new(data);									// When Not empty
    new->next = lst->head;
    while( p->next != lst->head ){											// when non-empty
        p = p->next;
    }
    p->next = new;
    lst->head = new;
    return;
}

void clist_insert( CList* lst, int idx, int data){									// Inserting at given index

    if( lst->head == NULL) {
        clist_prepend(lst, data);
        return;
    }
    CNode* p = lst->head;
    int j = clist_size(lst);

    if( idx > j ) return;							// Index greater than length of list = ERROR
    if(idx == 0){
        clist_prepend(lst, data);					// Index at first one
        return;
    }
	if( idx == j){
        clist_append(lst, data);					// WHen index is last one's index
        return;
    }
    j = 1;
    while(j < idx){
        p = p->next;								// Normal case
        j++;
    }
    CNode* new = cnode_new(data);
    new->next = p->next;
    p->next = new;

    return;
}

void clist_remove_last(CList* lst){

    if( lst->head == NULL ) return;					//  When it is empty

    CNode* p = lst->head->next;
	CNode* p1 = lst->head;
	while( p->next != lst->head ){
        p1 = p1->next;								// Normal cases when not empty
        p = p->next;								// Assigning last but one's next to NULL
    }
    free(p);
    p1->next = lst->head;

	return;
}

void clist_remove_first(CList* lst){

    if( lst->head == NULL ) return;					// Removing inital one's element
    CNode* p;

    p = lst->head;
    while( p->next != lst->head ){											// when non-empty
        p = p->next;
    }
    p->next = lst->head->next;
    p = lst->head;
    lst->head = p->next;
    free(p);
    return;
}

void clist_remove(CList* lst, int idx){				// Removing at given index's position

    if( lst->head == NULL ) return;
	CNode* p;
    CNode* p1;
    int j = clist_size(lst);
	p = lst->head;
	if( idx >= j ) return;
	if( idx == 0 ){								// At first position
        clist_remove_first(lst);
        return;
    }
    if(idx == j-1){
        clist_remove_last(lst);
        return;
    }
    j = 1;
    while(j < idx){								// Changing previous one's next from index term to next one's address
        p = p->next;
        j++;
    }
    p1 = p->next;
    p->next = p1->next;
    free(p1);
    return;
}

void clist_reverse(CList* lst){
    CNode *p, *q, *r;
    p = lst->head;
    if( p == NULL) return;
    r = NULL;

    do{
        q = p->next;
        p->next = r;
        r = p;
        p = q;
    }while(p != lst->head);

    p->next = r;
    lst->head = r;
    return;

}
