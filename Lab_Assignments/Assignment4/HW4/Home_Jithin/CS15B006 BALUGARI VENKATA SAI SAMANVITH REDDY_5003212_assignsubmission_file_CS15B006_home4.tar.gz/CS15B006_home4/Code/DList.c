#include "DList.h"

#include <stdlib.h>
#include <limits.h>
#include <stdio.h>
#include <assert.h>

DNode* dnode_new(int data){
    DNode* new = malloc( sizeof(DNode));												// Memory for new node
    new->data = data;
    new->next = NULL;
    new->prev = NULL;
    return new;
}

DList* dlist_new(){
    DList* new = malloc(sizeof(DList));
    new->head = NULL;																// memory for new list
    return new;
}

int dlist_size( DList* lst){

    int i = 1;
    DNode* p = lst->head;
    if(p == NULL) return 0;

    while( p -> next != NULL){
        p = p->next;															// Last term has next pointing to null
        i++;
    }
    return i;
}

void dlist_print( DList* lst ){

    if(lst->head == NULL) return ;

    DNode* p = lst->head;

    while(p != NULL){															// Printing upto last variable

        printf("%d ", p->data);
        p = p->next;
    }
    printf("\n");

    return;
}

int dlist_get( DList* lst, int idx){

    if(lst->head == NULL) return -1;
    DNode* p = lst->head;

   int k = dlist_size(lst);
   if( idx >= k ) return -1;											// When index is more than available terms

    int j = 0;

    while(j < idx ){
        p = p->next;														//Normal cases with lower index
        j++;
    }

    return (p->data);
}

void dlist_append( DList* lst, int data ){

    DNode* p;
    p = lst->head;
    if( p == NULL ){													// When there is pointer is to NULL or list is empty
     	p = dnode_new(data);
     	lst->head = p;
     	return;
     }

    while( p->next != NULL ){											// when non-empty
        p = p->next;
    }
    DNode* new = dnode_new(data);
    p->next = new;
    new->prev = p;														// Assigning new one's next to NULL and old last one to NEW
    return;
}

void dlist_prepend( DList* lst, int data){

    if( lst->head == NULL){ 											// Adding an element at the frnt of list when it is empty
    	DNode* new = dnode_new(data);
    	lst->head = new;
    	return;
    }

    DNode* new = dnode_new(data);									// When Not empty
    lst->head->prev = new;
    new->next = lst->head;
    lst->head = new;
    return;
}
void dlist_insert( DList* lst, int idx, int data){									// Inserting at given index

    if( lst->head == NULL){
      dlist_prepend(lst, data);
      return;
    }
    DNode* p = lst->head;
    int j = dlist_size(lst);

    if( idx > j ) return;							// Index greater than length of list = ERROR

    if(idx == 0){
        dlist_prepend(lst, data);					// Index at first one
        return;
    }
	if( idx == j){
        dlist_append(lst, data);					// WHen index is last one's index
        return;
    }
    j = 1;
    while(j < idx){
        p = p->next;								// Normal case
        j++;
    }
    DNode* new = dnode_new(data);
    new->next = p->next;
    (p->next)->prev = new;
    p->next = new;
    new->prev = p;

    return;
}

void dlist_remove_last(DList* lst){

    if( lst->head == NULL ) return;					//  When it is empty

    DNode* p = lst->head;
	//DNode* p1 = lst->head;
	while( p->next != NULL ){
        //p1 = p1->next;								// Normal cases when not empty
        p = p->next;								// Assigning last but one's next to NULL
    }
    p = p->prev;
	free(p->next);
    p->next = NULL;
  //p1->next = NULL;

	return;
}

void dlist_remove_first(DList* lst){

    if( lst->head == NULL ) return;					// Removing inital one's element
    DNode* p;

    p = lst->head;
    lst->head = lst->head->next;
    lst->head->prev = NULL;
    free(p);
    return;
}

void dlist_remove(DList* lst, int idx){				// Removing at given index's position

    if( lst->head == NULL ) return;
	DNode* p;
    DNode* p1;
    int j = dlist_size(lst);
	p = lst->head;
	if( idx >= j ) return;
	if( idx == 0 ){								// At first position
        dlist_remove_first(lst);
        return;
    }
    j = 1;
    while(j < idx){								// Changing previous one's next from index term to next one's address
        p = p->next;
        j++;
    }
    p1 = p->next;
    p->next = p1->next;
    (p->next)->prev = p;
    free(p1);
    return;
}

void dlist_reverse(DList* lst){

	DNode *p, *q;
	p = lst->head;

	if( p == NULL ) return;
	p->prev = NULL;
	//printf("sjit\n");

	while(p->next != NULL){
		q = p->next;
		//swap( &(p->next), &(p->prev) );
		p->next = p->prev;
		p->prev = q;
		p = q;
	}

	lst->head = p;
	q = p->next;
	p->next = p->prev;
	p->prev = q;
	//swap( &(p->next), &(p->prev));

	return;
}

void swap( DNode** a, DNode** b ){

	DNode* temp;
	temp = *a;
	*a = *b;
	*b = *a;
	return;
}
