#include "List.h"
#include <stdlib.h>
#include <limits.h>
#include <stdio.h>
#include <assert.h>

Node* node_new(int col_ind, int val){
    Node* new = malloc( sizeof(Node));												// Memory for new node
    new->col_ind = col_ind;
    new->val = val;
    new->next = NULL;
    return new;
}

LList* llist_new(){
    LList* new = malloc(sizeof(LList));
    new->head = NULL;																// memory for new list
    return new;
}

int llist_size( LList* lst){

    int i = 1;
    Node* p = lst->head;
    if(p == NULL) return 0;

    while( p -> next != NULL){
        p = p->next;															// Last term has next pointing to null
        i++;
    }
    return i;
}

void llist_print( LList* lst, int n ){

    if(lst->head == NULL) return ;
   
    Node* p = lst->head;
    int j = 0, i = 0;
    
    while(p != NULL){															// Printing upto last variable
        for(; i < p->col_ind - 1; i++ ){
          //  printf("0 ");
            
        }
        printf("%d ", p->val); i++;
        p = p->next;
    }
    
    while( i < n){
        //printf("0 ");
        i++;
    }
    
    printf("\n");
    return;
}

Node* llist_get( LList* lst, int idx){

    if(lst->head == NULL) return NULL;
    Node* p = lst->head;
    int k = llist_size(lst);

    if( idx >= k ) return NULL;											// When index is more than available terms

    int j = 0;

    while(j < idx){
        p = p->next;														//Normal cases with lower index
        j++;
    }

    return (p);
}

void llist_append( LList* lst, int col_ind, int val ){

    Node* p;
    p = lst->head;
    if( p == NULL ){													// When there is pointer is to NULL or list is empty
     	p=node_new(col_ind, val);
     	lst->head = p;
     	return;
     }

    while( p->next != NULL ){											// when non-empty
        p = p->next;
    }
    Node* new = node_new(col_ind, val);
    p->next = new;														// Assigning new one's next to NULL and old last one to NEW
    return;
}

void llist_prepend( LList* lst, int col_ind, int val){

    if( lst->head == NULL){ 											// Adding an element at the frnt of list when it is empty
    	Node* new = node_new(col_ind, val);
    	lst->head = new;
    	return;
    }

    Node* new = node_new(col_ind, val);									// When Not empty
    new->next = lst->head;

    lst->head = new;
    return;
}
void llist_insert( LList* lst, int idx, int col_ind, int val){									// Inserting at given index

    if( lst->head == NULL) return;
    Node* p = lst->head;
    int j = llist_size(lst);

    if( idx > j ) return;							// Index greater than length of list = ERROR
    if(idx == 0){
        llist_prepend(lst, col_ind, val);					// Index at first one
        return;
    }
	if( idx == j){
        llist_append(lst, col_ind, val);					// WHen index is last one's index
        return;
    }
    j = 1;
    while(j < idx){
        p = p->next;								// Normal case
        j++;
    }
    Node* new = node_new(col_ind, val);
    new->next = p->next;
    p->next = new;

    return;
}

