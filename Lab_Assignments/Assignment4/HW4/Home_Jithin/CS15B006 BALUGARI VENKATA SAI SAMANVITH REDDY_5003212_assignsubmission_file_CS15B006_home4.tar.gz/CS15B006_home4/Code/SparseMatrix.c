#include "SparseMatrix.h"
#include "List.h"
#include <stdio.h>
#include <stdlib.h>

Matrix add(Matrix a, Matrix b){
    int i = 0;
    Matrix new;
    
    new.row_lst = (LList**)malloc( a.n_rows * sizeof(LList*));
    for( i = 0; i < a.n_rows ; i++){
        new.row_lst[i] = llist_new();
    }
    i = 0;
	Node *p, *q;

    while(i < a.n_rows){

        p = (a.row_lst[i])->head;
        q = (b.row_lst[i])->head;
         
        while( p != NULL && q != NULL ){
   
                if(p->col_ind < q->col_ind){
                    llist_append(new.row_lst[i], p->col_ind, p->val);
                    p = p->next;
                }
                else if(p->col_ind > q->col_ind){
                    llist_append(new.row_lst[i], p->col_ind, q->val);
                    q = q->next;
                } 
                else if(p->col_ind == q->col_ind){
                    llist_append(new.row_lst[i], p->col_ind, (q->val + p->val));
                    q = q->next;
                    p = p->next;
                }
        }	

                if( p == NULL){
                    while (q != NULL) {
                        llist_append(new.row_lst[i], q->col_ind, q->val);
                    	q = q->next;
                    }
                }
                else if( q == NULL){
                    while (p != NULL) {
                        llist_append(new.row_lst[i], p->col_ind, p->val);
                    	p = p->next;
                    }
                }
        
    	i++;
    }
    return new;
}

Matrix subtract(Matrix a, Matrix b){
     int i = 0;
    Matrix new;
    
    new.row_lst = (LList**)malloc( a.n_rows * sizeof(LList*));
    for( i = 0; i < a.n_rows ; i++){
        new.row_lst[i] = llist_new();
    }
    i = 0;
	Node *p, *q;

    while(i < a.n_rows){

        p = (a.row_lst[i])->head;
        q = (b.row_lst[i])->head;
        
        while( p != NULL && q != NULL ){
         
                if(p->col_ind < q->col_ind){
                    llist_append(new.row_lst[i], p->col_ind, p->val);
                    p = p->next;
                }
                else if(p->col_ind > q->col_ind){
                    llist_append(new.row_lst[i], p->col_ind, -1*q->val);
                    q = q->next;
                }
                else if(p->col_ind == q->col_ind){
                    llist_append(new.row_lst[i], p->col_ind, (-1*q->val + p->val));
                    q = q->next;
                    p = p->next;
                }
        }	

                if( p == NULL){
                    while (q != NULL) {
                        llist_append(new.row_lst[i], q->col_ind, -1*q->val);
                    	q = q->next;
                    }
                }
                else if( q == NULL){
                    while (p != NULL) {
                        llist_append(new.row_lst[i], p->col_ind, p->val);
                    	p = p->next;
                    }
                }
        
    	i++;
    }
    return new;
}


Matrix matrix_vect_multiply(Matrix a, Matrix b){
	
	int i = 0;
	int sum;
    Matrix new;
    new.n_rows = a.n_rows;
    
    new.row_lst = (LList**)malloc( a.n_rows * sizeof(LList*));
    
    for( i = 0; i < a.n_rows ; i++){
        new.row_lst[i] = llist_new();
    }

    Node *p;
    int count = 0;
    while( count < a.n_rows ){
    	p = (a.row_lst[count])->head;
    	sum = 0;
    	   
        while( p != NULL ){
    		
            if( (b.row_lst[p->col_ind])->head != NULL ){
    		    sum = sum + (p->val) * ((b.row_lst[p->col_ind])->head)->val;
    		}
    		p = p->next;
    	}
    	
        llist_append((new.row_lst[count]), 0, sum);
    	count++;
    }
    return new;
}
