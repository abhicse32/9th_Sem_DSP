#include <stdio.h>
#include "SparseMatrix.h"
#include "List.h"
#include <stdlib.h>

int main () {

	int option, m, n;
	int temp;
	int i, j;
	scanf("%d", &option);

	while(option != -1){

		Matrix a, b, c;
					scanf("%d%d", &m, &n);
					a.n_rows = m;
					b.n_rows = m;

					a.row_lst = (LList**) malloc(m*sizeof(LList*));			// Allocating space to each pointer in matrix according to number
																			// of rows		
					c.row_lst = (LList**) malloc(m*sizeof(LList*));		
					
					for(i = 0; i < m; i++){
						a.row_lst[i] = llist_new();
						
						c.row_lst[i] = llist_new();
					}														// Scanning input of A		

					for(i = 0; i < m; i++){
						for(j = 0; j < n; j++){
							scanf("%d", &temp);
							if(temp != 0){
								llist_append(a.row_lst[i], j, temp);
								continue;
							} 
						}
					}

		switch(option){
			case 1:
			case 2:
				b.row_lst = (LList**) malloc(m*sizeof(LList*));
				for(i = 0; i < m; i++){
						b.row_lst[i] = llist_new();
					}	

				for(i = 0; i < m; i++){										//scanning input of B			
					for(j = 0; j < n; j++){
						scanf("%d", &temp);
						if(temp != 0){
							llist_append(b.row_lst[i], j, temp);
						}
					}
				}
				break;
			case 3:
				b.n_rows = n;
				b.row_lst = (LList**) malloc(n*sizeof(LList*));
				for(i = 0; i < n; i++){
						b.row_lst[i] = llist_new();
					}
				for(i = 0; i < n; i++){
				
					scanf("%d", &temp);
						if(temp != 0){
							llist_append(b.row_lst[i], j, temp);
						}
				}
				break;
		}
		
		switch(option){
			case 1: 
				c = add( a, b);											// Calling the add function
			
			for( i = 0; i < m; i++){
				llist_print(c.row_lst[i], n); fflush(stdout);			// Printing each rows
			}
			break;

			case 2:
				c = subtract(a, b);											// Calling the subtract function
			for( i = 0; i < m; i++){
				llist_print(c.row_lst[i], n); fflush(stdout);			// Printing each rows
			}
			break;
			
			case 3:
				c = matrix_vect_multiply(a, b);							// Calling multiply function				
				for( i = 0; i < m; i++){
					if(c.row_lst[i]->head == NULL) {
						//printf("0\n"); 									// Printing each rows
						continue;
					}
				printf("%d \n", c.row_lst[i]->head->val);
				}
				break;
		}
		free(a.row_lst);
		free(b.row_lst);
		free(c.row_lst);
		scanf("%d", &option);
	}
	return 0;
}
