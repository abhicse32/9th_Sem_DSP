#include "CList.h"
#include <stdlib.h>
#include <stdio.h>
#include <limits.h>

CNode* cnode_new( int dat){
	CNode *new;
	new=(CNode *)malloc(sizeof(CNode));
	new->data=dat;
	new->next=NULL;
	
	return new;
}

CList* clist_new(){
	CList *new;
	new=(CList *)malloc(sizeof(CList));
	new->head=NULL;
	
	return new;
}

int clist_size( CList* lst ){
	if (lst->head==NULL){
		return 0;	
	}
	int cnt=1;
	CNode* pin=lst->head;
	for(; pin->next != lst->head ;){
		cnt++;
		pin=pin->next;
	}
	return cnt;
}

void clist_print( CList* lst ){
	if (lst->head==NULL){
		return;	
	}
	CNode* pin=lst->head;
	for(; pin->next != lst->head ;){
		printf("%d ",pin->data);
		pin=pin->next;
	}
	printf("%d ",pin->data);
	printf("\n");
	fflush(stdout);
	return;
}

int clist_get( CList* lst, int idx ){
	if (lst->head==NULL){
		return -1;	
	}
	int cnt=0;
	CNode* pin=lst->head;
	for(; pin->next != lst->head ;){
		if(idx==cnt){
			return pin->data; 
		}		
		cnt++;
		pin=pin->next;
	}
	if(idx==cnt){return pin->data;}
	return -1;	
}

void clist_append( CList* lst, int dat ){
	if(lst->head==NULL){
		CNode* new=(CNode *)malloc(sizeof(CNode));
		lst->head=new;
		new->data=dat;
		new->next=new;	
		return;
	}
	
	CNode* pin=lst->head;
	for(; pin->next!=lst->head ;){
		pin=pin->next;
	}
	
	CNode* new=(CNode *)malloc(sizeof(CNode));
	pin->next=new;
	new->data=dat;
	new->next=lst->head;	
	return;	
}

void clist_prepend( CList* lst, int dat ){
	if(lst->head==NULL){
		CNode* new=(CNode *)malloc(sizeof(CNode));
		lst->head=new;
		new->data=dat;
		new->next=new;	
		return;
	}
	CNode* pin=lst->head;

	CNode* new=(CNode *)malloc(sizeof(CNode));
	new->data=dat;
	new->next=pin;
	for (; pin->next != lst->head ; ){
		pin=pin->next;
	}
	pin->next=new;
	lst->head=new;
	return;
}

void clist_insert( CList* lst, int idx, int dat ){
	if(idx==0){
		clist_prepend( lst, dat );
		return;
	}
	
	int pre = clist_size(lst);
	if(idx>pre){return;}
	
	pre=1;
	CNode* pin=lst->head;
	
	for( ; pin->next !=lst->head ; ){
		if(pre==idx){
			CNode* new=(CNode *)malloc(sizeof(CNode));
			new->data=dat;
			new->next=pin->next;
			pin->next=new;
			return;				
		}
		pre++;
		pin=pin->next;
	}
	clist_append(lst,dat);
	return;
}

void clist_remove_last( CList* lst ){

	if(lst->head==NULL) 
		return;

	CNode* pin=lst->head;
	CNode* prev=lst->head;

	for(;pin->next!=lst->head;){
		prev=pin;
		pin=pin->next;
	}
	prev->next=lst->head;
	return;
}

void clist_remove_first( CList* lst ){

	if(lst->head==NULL) return;
	
	CNode* pin=lst->head;
	if(pin->next == lst->head){
		lst->head=NULL;
		return;
	}

	CNode* new=	pin->next;

	for ( ;pin->next!=lst->head ; ){
		pin=pin->next;
	}
	pin->next=new;
	lst->head=new;
	
	return;
}

void clist_remove( CList* lst, int idx ){

	if(idx==0){
		clist_remove_first( lst );
		return;
	}
	
	int pre = clist_size(lst);
	if(idx>=pre){return;}
	
	pre=0;
	CNode* pin=lst->head;
	CNode* prev=lst->head;	

	for( ; pin->next!=lst->head ; ){
		if(pre==idx){
			prev->next=pin->next;
			return;				
		}
		pre++;
		prev=pin;
		pin=pin->next;
	}
	prev->next=lst->head;
	return;
}

void clist_reverse(CList* lst){
	
	
	if(lst->head==NULL)  return;
	CNode *curr,*next,*prev;
	CNode *pin;
	pin=lst->head;

	if(pin->next==pin) return;


	curr=lst->head;
	prev=NULL;
	for( ; curr->next!= lst->head ; ){
		next = curr->next;
		curr->next=prev;
		prev=curr;
		curr=next;
	}
	curr->next=prev;
	pin->next=curr;
	lst->head=curr;
    
}
