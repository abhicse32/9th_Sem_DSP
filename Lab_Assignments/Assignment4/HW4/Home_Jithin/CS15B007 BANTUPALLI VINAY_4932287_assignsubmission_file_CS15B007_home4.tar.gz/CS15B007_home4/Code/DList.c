#include "DList.h"
#include <stdlib.h>
#include <stdio.h>
#include <limits.h>

DNode* dnode_new( int dat){
	DNode *new;
	new=(DNode *)malloc(sizeof(DNode));
	new->data=dat;
	new->next=NULL;

	return new; 
}

DList* dlist_new(){
	DList *new;
	new=(DList *)malloc(sizeof(DList));
	new->head=NULL;
	
	return new;
}

int dlist_size( DList* lst ){
	if (lst->head==NULL){
		return 0;	
	}
	int cnt=1;
	DNode* pin=lst->head;
	for(; pin->next != NULL ;){
		cnt++;
		pin=pin->next;
	}
	return cnt;
}

void dlist_print( DList* lst ){
	if (lst->head==NULL){
		return;	
	}
	DNode* pin=lst->head;
	for(; pin != NULL ;){
		printf("%d ",pin->data);
		pin=pin->next;
	}
	printf("\n");
	return;
}

int dlist_get( DList* lst, int idx ){
	if (lst->head==NULL){
		return -1;	
	}
	int cnt=0;
	DNode* pin=lst->head;
	for(; pin != NULL ;){
		if(idx==cnt){
			return pin->data; 
		}		
		cnt++;
		pin=pin->next;
	}
	return -1;
}

void dlist_append( DList* lst, int dat ){

	if(lst->head==NULL){
		DNode* new=(DNode *)malloc(sizeof(DNode));
		lst->head=new;
		new->data=dat;
		new->prev=NULL;
		new->next=NULL;	
		return;
	}
	
	DNode* pin=lst->head;
	for(; pin->next!=NULL ;){
		pin=pin->next;
	}
	
	DNode* new=(DNode *)malloc(sizeof(DNode));
	pin->next=new;
	new->data=dat;
	new->prev=pin;
	new->next=NULL;	
	return;	
}

void dlist_prepend( DList* lst, int dat ){

	if(lst->head==NULL){
		DNode* new=(DNode *)malloc(sizeof(DNode));
		lst->head=new;
		new->data=dat;
		new->next=NULL;
		new->next=NULL;	
		return;
	}
	DNode* pin=lst->head;

	DNode* new=(DNode *)malloc(sizeof(DNode));
	lst->head=new;
	new->data=dat;
	new->next=pin;
	new->prev=NULL;
	pin->prev=new;
	return;
}

void dlist_insert( DList* lst, int idx, int dat ){
	if(idx==0){
		dlist_prepend( lst, dat );
		return;
	}
	
	int pre = dlist_size(lst);
	if(idx>pre){return;}
	
	pre=1;
	DNode* pin=lst->head;
	
	for( ; pin->next !=NULL ; ){
		if(pre==idx){
			DNode* new=(DNode *)malloc(sizeof(DNode));
			new->data=dat;
			new->prev=pin;
			new->next=pin->next;
			(pin->next)->prev=new;
			pin->next=new;
			return;				
		}
		pre++;
		pin=pin->next;
	}
	dlist_append(lst,dat);
	return;
}

void dlist_remove_last( DList* lst ){
	if(lst->head==NULL) return;

	DNode* pin=lst->head;
	DNode* prev=lst->head;

	for(;pin->next!=NULL;){
		prev=pin;
		pin=pin->next;
	}
	prev->next=NULL;
	return;
}

void dlist_remove_first( DList* lst ){
	if(lst->head==NULL) return;
	
	DNode* pin=lst->head;

	lst->head=pin->next;
	(pin->next)->prev=NULL;
	return;
}

void dlist_remove( DList* lst, int idx ){
	if(idx==0){
		dlist_remove_first( lst );
		return;
	}
	
	int pre = dlist_size(lst);
	if(idx>=pre){return;}
	
	pre=0;
	DNode* pin=lst->head;
	DNode* prev=lst->head;	

	for( ; pin->next!=NULL ; ){
		if(pre==idx){
			prev->next=pin->next;
			(pin->next)->prev=prev;
			return;				
		}
		pre++;
		prev=pin;
		pin=pin->next;
	}
	prev->next=NULL;
}

void dlist_reverse(DList* lst){

	if(lst->head == NULL) return;
	DNode *temp;
	DNode *pin;

	temp=NULL;
	pin=lst->head;

	if(pin->next == NULL) return;

	for(; pin!=NULL;){
		temp=pin->prev;
		pin->prev=pin->next;
		pin->next=temp;
		pin=pin->prev;
	}
	lst->head=temp->prev;
}