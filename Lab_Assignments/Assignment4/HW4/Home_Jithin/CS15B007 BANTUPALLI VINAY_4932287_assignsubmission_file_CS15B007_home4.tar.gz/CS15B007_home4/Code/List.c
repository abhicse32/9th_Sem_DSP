#include "List.h"
#include <stdlib.h>
#include <stdio.h>
#include <limits.h>

Node* node_new( int data1, int data2){
	Node *new;
	new=(Node *)malloc(sizeof(Node));
	new->col_ind=data1;
	new->val=data2;
	new->next=NULL;
	
	return new;
}

LList* llist_new(){
	LList *new;
	new=(LList *)malloc(sizeof(LList));
	new->head=NULL;
	
	return new;
}

int llist_size( LList* lst ){
	if (lst->head==NULL){
		return 0;	
	}
	int cnt=1;
	Node* pin=lst->head;
	for(; pin->next != NULL ;){
		cnt++;
		pin=pin->next;
	}
	return cnt;
}

void llist_print( LList* lst){
	if (lst->head==NULL){
		//printf("0");
	}
else{	Node* pin=lst->head;
	for(; pin != NULL ;){
		printf("%d ",pin->val);
		pin=pin->next;
	}
	printf("\n");
	fflush(stdout);}
	//return;
}

Node* llist_get( LList* lst, int idx ){
	if (lst->head==NULL){
		return NULL;	
	}
	int cnt=0;
	Node* pin=lst->head;
	for(; pin != NULL ;){
		if(idx==cnt){
			return pin; 
		}		
		cnt++;
		pin=pin->next;
	}
	return NULL;
}

void llist_append( LList* lst, int data1, int data2){
	if(lst->head==NULL){
		Node* new=(Node *)malloc(sizeof(Node));
		lst->head=new;
		new->col_ind=data1;
		new->val=data2;
		new->next=NULL;	
		return;
	}
	
	Node* pin=lst->head;
	for(; pin->next!=NULL ;){
		pin=pin->next;
	}
	
	Node* new=(Node *)malloc(sizeof(Node));
	pin->next=new;
	new->col_ind=data1;
	new->val=data2;
	new->next=NULL;	
	return;	
}

void llist_prepend( LList* lst, int data1 , int data2){
	if(lst->head==NULL){
		Node* new=(Node *)malloc(sizeof(Node));
		lst->head=new;
		new->col_ind=data1;
		new->val=data2;
		new->next=NULL;	
		return;
	}
	Node* pin=lst->head;

	Node* new=(Node *)malloc(sizeof(Node));
	lst->head=new;
	new->col_ind=data1;
	new->val=data2;
	new->next=pin;
	return;
}

void llist_insert( LList* lst, int idx, int data1, int data2){
	if(idx==0){
		llist_prepend( lst, data1, data2);
		return;
	}
	
	int pre = llist_size(lst);
	if(idx>pre){return;}
	
	pre=1;
	Node* pin=lst->head;
	
	for( ; pin->next !=NULL ; ){
		if(pre==idx){
			Node* new=(Node *)malloc(sizeof(Node));
			new->col_ind=data1;
			new->val=data2;
			new->next=pin->next;
			pin->next=new;
			return;				
		}
		pre++;
		pin=pin->next;
	}
	llist_append(lst,data1,data2);
	return;
}
