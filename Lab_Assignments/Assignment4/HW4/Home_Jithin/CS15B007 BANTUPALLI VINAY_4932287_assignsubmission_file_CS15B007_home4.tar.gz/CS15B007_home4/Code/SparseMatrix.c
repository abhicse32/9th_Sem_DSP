#include "SparseMatrix.h"
#include <stdio.h>
#include <stdlib.h>

Matrix add(Matrix a, Matrix b){
	 Matrix add;
	 add.row_lst=(LList **)malloc(sizeof(LList *)*(a.n_rows));
	 add.n_rows=a.n_rows;
	 LList *row;
	 Node *noa,*nob;

	 int i;
	 for(i=0 ; i< a.n_rows ; i++){
	 	noa=(a.row_lst[i])->head;
		nob=(b.row_lst[i])->head;
		add.row_lst[i]=llist_new();
	 	row=add.row_lst[i];
	 	for(; noa!=NULL && nob!=NULL;){
	 		if(noa->col_ind > nob->col_ind){
	 			llist_append( row , nob->col_ind , nob->val);
	 			nob=nob->next;
	 		}
	 		else if(noa->col_ind < nob->col_ind){
	 			llist_append(row , noa->col_ind ,noa->val);
	 			noa=noa->next;
	 		}
	 		else if(noa->col_ind == nob->col_ind){
	 			int sum = noa->val+nob->val;
	 			/*if(sum!=0)*/ llist_append(row , noa->col_ind , sum);
	 			noa=noa->next;
	 			nob=nob->next;
	 		}
	 	}

	 	if(noa!=NULL){
	 		for( ; noa!=NULL ;){
	 			llist_append(row , noa->col_ind ,noa->val);
	 			noa=noa->next;
	 		}
	 	}
	 	else if(nob!=NULL){
	 		for( ; nob!=NULL ; ){
	 			llist_append( row , nob->col_ind , nob->val);
	 			nob=nob->next;
	 		}
	 	}
	 }

	 return add;
}


Matrix subtract(Matrix a, Matrix b){
	 Matrix sub;
	 sub.row_lst=(LList **)malloc(sizeof(LList *)*(a.n_rows));
	 sub.n_rows=a.n_rows;
	 LList *row;
	 Node *noa,*nob;

	 int i;
	 for(i=0 ; i< a.n_rows ; i++){
	 	noa=(a.row_lst[i])->head;
		nob=(b.row_lst[i])->head;
		sub.row_lst[i]=llist_new();
	 	row=sub.row_lst[i];
	 	for(; noa!=NULL && nob!=NULL;){
	 		if(noa->col_ind > nob->col_ind){
	 			llist_append( row , nob->col_ind , (-1)*nob->val);
	 			nob=nob->next;
	 		}
	 		else if(noa->col_ind < nob->col_ind){
	 			llist_append(row , noa->col_ind ,noa->val);
	 			noa=noa->next;
	 		}
	 		else if(noa->col_ind == nob->col_ind){
	 			int sum = noa->val - nob->val;
	 			/*if(sum!=0)*/ llist_append(row , noa->col_ind , sum);
	 			noa=noa->next;
	 			nob=nob->next;
	 		}
	 	}

	 	if(noa!=NULL){
	 		for( ; noa!=NULL ;){
	 			llist_append(row , noa->col_ind ,noa->val);
	 			noa=noa->next;
	 		}
	 	}
	 	else if(nob!=NULL){
	 		for( ; nob!=NULL ; ){
	 			llist_append( row , nob->col_ind , (-1)*nob->val);
	 			nob=nob->next;
	 		}
	 	}
	 }

	 return sub;
}


Matrix matrix_vect_multiply(Matrix a, Matrix b){

	 Matrix mult;
	 mult.row_lst=(LList **)malloc(sizeof(LList *)*(a.n_rows));
	 mult.n_rows=a.n_rows;
	 LList *row;
	 Node *noa,*nob;
	 int sum;
	 int i,j;

	for(i=0 ; i< a.n_rows ; i++){
	 	noa=(a.row_lst[i])->head;
		mult.row_lst[i]=llist_new();
	 	row=mult.row_lst[i];
	 	sum=0;
	 	for( ; noa!=NULL ; ){
	 		nob=(b.row_lst[noa->col_ind])->head;
	 		if(nob!=NULL) sum=sum+(noa->val) * (nob->val);
	 		noa=noa->next;
	 	}

	 	row->head=node_new(0,sum);
	}
	return mult;
}