#include <stdio.h>
#include <stdlib.h>
#include "SparseMatrix.h"
#include "List.h"

void print(Matrix x);

int main(){

	int i,j;
	int k,no;
	int m,n;
	Matrix a,b;
	Matrix ans;

	for( ; ; ){
		scanf("%d",&k);
		if(k==-1){break;}

		switch(k){
			case 1 :{
				scanf("%d%d",&m,&n);
				a.n_rows=m;
				b.n_rows=m;
				a.row_lst=(LList **)malloc(sizeof(LList *)*(a.n_rows));
				b.row_lst=(LList **)malloc(sizeof(LList *)*(a.n_rows));
				
				for(i=0 ; i<m ; i++){
					a.row_lst[i]=llist_new();
					//LList *row=a.row_lst[i];
					for(j=0 ; j< n ; j++){
						scanf("%d",&no);
						if(no!=0){
							llist_append(a.row_lst[i],j,no);
						}
					}
				}

				for(i=0 ; i<m ; i++){
					b.row_lst[i]=llist_new();
					//LList *row=b.row_lst[i];
					for(j=0 ; j< n ; j++){
						scanf("%d",&no);
						if(no!=0){
							llist_append(b.row_lst[i],j,no);
						}
					}
				}
				ans=add(a,b);
				print(ans);
				break;
			}

			case 2 :{
				scanf("%d%d",&m,&n);
				a.n_rows=m;
				b.n_rows=m;
				a.row_lst=(LList **)malloc(sizeof(LList *)*(a.n_rows));
				b.row_lst=(LList **)malloc(sizeof(LList *)*(a.n_rows));
				
				for(i=0 ; i<m ; i++){
					a.row_lst[i]=llist_new();
					LList *row=a.row_lst[i];
					for(j=0 ; j< n ; j++){
						scanf("%d",&no);
						if(no!=0){
							llist_append(row,j,no);
						}
					}
				}

				for(i=0 ; i<m ; i++){
					b.row_lst[i]=llist_new();
					LList *row=b.row_lst[i];
					for(j=0 ; j< n ; j++){
						scanf("%d",&no);
						if(no!=0){
							llist_append(row,j,no);
						}
					}
				}
				ans=subtract(a,b);
				print(ans);
				break;
			}

			case 3 :{
				scanf("%d%d",&m,&n);
				a.n_rows=m;
				b.n_rows=n;
				a.row_lst=(LList **)malloc(sizeof(LList *)*(a.n_rows));
				b.row_lst=(LList **)malloc(sizeof(LList *)*(b.n_rows));
				
				for(i=0 ; i<m ; i++){
					a.row_lst[i]=llist_new();
					LList *row=a.row_lst[i];
					for(j=0 ; j< n ; j++){
						scanf("%d",&no);
						if(no!=0){
							llist_append(row,j,no);
						}
					}
				}

				for(i=0 ; i<n ; i++){
					b.row_lst[i]=llist_new();
					LList *row=b.row_lst[i];
					for(j=0 ; j< 1 ; j++){
						scanf("%d",&no);
						llist_append(row,j,no);
					}
				}
				ans=matrix_vect_multiply(a,b);
				print(ans);
				break;
			}			

		}
	}
	return 0;
}	

void print(Matrix x){
	int rows=x.n_rows;
	int i;
	for(i=0 ; i<rows ;i++ ){
		llist_print(x.row_lst[i]);
		fflush(stdout);
	}
	//return;
}