//Program written by B.Nikhil Baba -CS15B008 on Sept 3rd,2016.
//Circular linked list.
#include "CList.h"
#include<stdio.h>
#include<limits.h>
#include<stdlib.h>
 //Creating a single new node. 
 CNode* cnode_new( int data)
 {
  CNode *node;
  node = (CNode *)malloc(sizeof(CNode));
  node->data = data;
  node->next = NULL;
  return node;
 }
 //Creating an empty linked list.
 CList* clist_new()
 {
  CList *list;
  list = (CList *)malloc(sizeof(CList));
  list->head = NULL;
  return list;
 }
 //Finding the size of linked list using recursion.
 int clist_size( CList* lst )
 {
  
  if(lst->head == NULL)
  {
   return 0;
  }
  int count = 1;
  CNode* exam = lst->head;
   while(exam->next != NULL)
  {
   exam = exam->next;
   count++;
  }
  return count;
 }
 //Printing all the elements using recursion.
 void clist_print( CList* lst )
 {
  if(lst->head == NULL)
  {
   return;
  } 
  CNode* exam = lst->head;
  while(exam != NULL) 
  {
   printf("%d ",exam->data);
   exam = exam->next;
  }
  printf("\n");
  return;
 }
 //Getting an element at a particular index.
 int clist_get( CList* lst, int idx )
 {
  if(lst->head == NULL)
  {
   return INT_MIN;
  }
  CNode* exam = lst->head; 
  int count=0;
  while(exam != NULL)
  {
   if(count == idx)
   {
    return exam->data;
   }
    exam = exam->next;
    count++;
  }
  
  return INT_MIN ;
 }
 //Adding an element at the end of the list.
 void clist_append( CList* lst, int data )
 {
  if(lst->head == NULL)
  {
   CNode* new = (CNode *)malloc(sizeof(CNode));
   lst->head = new;
   new->data = data;
   new->next=NULL;
   return;
  }
  
  CNode* exam = lst->head;
  while(exam->next != NULL)
  {
   exam = exam->next;
  }
  CNode* new=(CNode *)malloc(sizeof(CNode));
  exam->next=new;
  new->data=data;
  new->next=NULL;
  return;
 }
 //Adding an element at the beginning of the list.
 void clist_prepend( CList* lst, int data )
 {
  if(lst->head==NULL)
  {
   CNode* new=(CNode *)malloc(sizeof(CNode));
   lst->head=new;
   new->data=data;
   new->next=NULL;	
   return;
  }
   CNode* exam = lst->head;
   CNode* new = (CNode *)malloc(sizeof(CNode));
   lst->head = new; 
   new->data = data;
   new->next = exam;
   return;
  
 }
 // Adding a new element at a particular index.
 void clist_insert( CList* lst, int idx, int data )  
 {
  if(idx == 0)
  {
   clist_prepend(lst,data);
   return;
  }
  int count =clist_size(lst);
  if(idx>count)
  {
   return;
  }
  count=1;
  CNode* exam = lst->head;
  while(exam->next != NULL)
  {
    if(count == idx)
    {
     CNode* new = (CNode *)malloc(sizeof(CNode));
     new->data = data; 
     new->next = exam->next; 
     exam->next=new;
     return;
    }
   count++;
   exam = exam->next;
  }
  clist_append(lst,data);
  return;
 }
  
 // Removing an element from the end of the list.
 void clist_remove_last( CList* lst )
 {
  if(lst->head == NULL)
  { 
   return;
  }
  CNode* exam = lst->head;
  CNode* current = lst->head;
  while(exam->next != NULL)
  {
     current = exam;
     exam = exam->next;
  }
   current->next = NULL;
   return;
 }
 
 // Remove an element from the beginning of the list.
 void clist_remove_first( CList* lst )
 {
  if(lst->head == NULL)
  {
   return;
  }
  CNode* exam = lst->head;
  lst->head = exam->next;
  return;
 }
 // Removing an element from a particular position in the list.
 void clist_remove( CList* lst, int idx )
 {
  if(idx == 0)
  {
   clist_remove_first(lst);
   return;
  }
  CNode* exam = lst->head;
  
  int count = clist_size(lst);
  if(idx>=count)
  {
   return;
  }
  count = 0;
  CNode* prev=lst->head;	
  while(exam!=NULL)
  {
   if(count==idx)
   {
    prev->next=exam->next;
    return;
   }
			   
   count++;
   prev=exam;
   exam=exam->next;
  }
} 
void clist_reverse(CList* lst)
{
 CNode* exam = lst->head;
 CNode* land = lst->head;
 int i = 0;
 int n = clist_size(lst);
 int array[n];
 for(i= 0;i<n;i++)
 {
  array[i] = exam->data;
  exam = exam->next;
 }
 for(i=0;i<n;i++)
 {
  land->data = array[n-1-i];
  land = land->next;
 }
 return;
}
