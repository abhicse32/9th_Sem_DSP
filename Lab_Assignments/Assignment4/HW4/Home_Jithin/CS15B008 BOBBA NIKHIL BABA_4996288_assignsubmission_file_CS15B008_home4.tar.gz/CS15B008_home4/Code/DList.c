//Program wriiten to define standard functions involved in any doubly linked list operation.
//Program written by B.Nikhil Baba on September 5th,2016.




#include "DList.h"
#include<stdlib.h>
#include<limits.h>
#include<math.h>
#include<stdio.h>

//Creating a new Double linked list with data.

DNode* dnode_new( int data)
{
 DNode* new = (DNode *)malloc(sizeof(DNode));
 new->prev = NULL;
 new->next = NULL;
 new->data = data;
 return new;
}

//Creating an empty Double linked list.

DList* dlist_new()
{
 DList *new;
 new = (DList *)malloc(sizeof(DList));
 new->head = NULL;
 return new;
}

//Finding the size of a Double linked list.

int dlist_size( DList* lst )
{
 
 if(lst->head == NULL)
 {
  return 0;
 }
 
 int i=0;
 
 DNode *iter = lst->head;
 while(iter->next != NULL)
 {
  i++;
  iter = iter->next;
 }
 return (i+1);
}

//Printing the given Double linked list.

void dlist_print( DList* lst )
{
 if(dlist_size(lst) == 0)
 {
  return;
 }
 else
 {
  DNode *iter = lst->head;
  while(iter!= NULL)
  {
   printf("%d ",iter->data);
   iter = iter->next;
  }
 }
  printf("\n");
 return;
} 

//Returning an element of particular index.

int dlist_get( DList* lst, int idx )
{
 if(idx < 0 || idx >= dlist_size(lst))
 {
  return -1 ;
 }
 if(lst->head == NULL)
 {
  return -1;
 }
 DNode *iter = lst->head;
 int i = 0;
 while(i!=idx )
 {
  i++;
  iter = iter->next;
 }
 return (iter->data);
}

//Adding a new node at the end of the linked list.

void dlist_append( DList* lst, int data )
{
 if(lst->head == NULL)
 {
  DNode *new = (DNode *)malloc(sizeof(DNode));
  new->prev = NULL;
  lst->head = new;
  new->data = data;
  new->next = NULL;
 }
 else 
 { 
  DNode *sur = lst->head;
   while(sur->next != NULL)
  {
   sur = sur->next;
  }
  DNode *new = (DNode *)malloc(sizeof(DNode));
  sur->next = new;
  new->prev = sur;
  new->data = data;
  new->next = NULL;   
 }
 return;
}

//Adding a new node at the beginning of the linked list.

void dlist_prepend( DList* lst, int data )
{
 if(lst->head == NULL)
 {
	
  dlist_append(lst,data);
 }
 else
 {
  //DNode *first = lst->head;
  DNode *new = (DNode *)malloc(sizeof(DNode));
  (lst->head)->prev = new;
  new->next = lst->head;
  new->data = data;
  new->prev = NULL;
  lst->head = new;
 }
 return;
}

//Inserting an element at a particular position in Double linked list.

void dlist_insert( DList* lst, int idx, int data )
{

 if((lst->head) == NULL)
 {
  dlist_prepend(lst,data);
  return;
 }
 else if(idx == 0)
 {
  dlist_prepend(lst,data);
  return;
 }
 else if(idx == dlist_size(lst))
 {
  dlist_append(lst,data);
  return;
 }
 else if(idx > dlist_size(lst))
 {
  return;
 }
 else
 {
  DNode *sur = lst->head;
  int  i = 0;
  while(i!=(idx-1))
  {
    sur = sur->next;
	i++;
  }
     DNode *new = (DNode *)malloc(sizeof(DNode));
     new->data = data;
     new->next = sur->next;
     new->prev = sur;
     (sur->next)->prev = new;
     sur->next = new;
     return;
 }
  //dlist_append(lst,data);
  return;
}

//Removing the last element in the doubly linked list.

void dlist_remove_last( DList* lst )
{
 if(lst->head == NULL)
 {
  return;
 }

else if (lst->head->next == NULL){ lst->head = NULL;return;}

 DNode *sur = lst->head;
 while((sur->next)->next != NULL)
 {
  sur = sur->next;
 }
 sur->next = NULL;
 return; 
}

//Removing the first element in a doubly linked list.

void dlist_remove_first( DList* lst )
{
 if(lst->head == NULL)
 {
  return;
 }

else if (lst->head->next == NULL){ lst->head = NULL;return;}
 DNode *sur = lst->head;
 (sur->next)->prev = NULL; 
 lst->head = sur->next;
  return;
}

//Removing a particular element in a doubly linked list.

void dlist_remove( DList* lst, int idx )
{
 if(idx == 0)
 {
  dlist_remove_first(lst);
  return;
 }
 if(idx>=dlist_size(lst))
 {
  return;
 }
 DNode *per = lst->head;
 DNode *sur = lst->head;
 int i = 0;
 while(per != NULL)
  {
   if(i == idx)
   {
     sur->next = per->next;
     (per->next)->prev = sur;
     return;
   } 
   sur = per;
   per = per->next;
   i++;
  }
}

//Reverse the give doubly linked list.

void dlist_reverse(DList* lst)
{
  DNode *link = lst->head;
  DNode *sink = lst->head;
  int i=0;
  int n =dlist_size(lst);
  int array[n];
  for(i=0;i<n;i++)
  {
    array[i] = link->data;
    link = link->next;
  }
  for(i=0;i<n;i++)
  { 
     sink->data = array[n-1-i];
     sink = sink->next;
  }  
  return;
}  
    
  
