#include "List.h"
#include<stdio.h>
#include<stdlib.h>
#include<limits.h>
#include<math.h>

Node* node_new( int data1,int data2)
{
 Node *new = (Node *)malloc(sizeof(Node));
 new->col_ind = data1;
 new->val     = data2;
 new->next    = NULL;
 return new;
}

LList* llist_new()
{
 LList *newlist;
 newlist  = (LList *)malloc(sizeof(LList));
 newlist->head  = NULL;
 return newlist;
}

int llist_size( LList* lst )
{
 Node *iter = lst->head;
 int size =0;
 while(iter != NULL)
 {
  size = size + 1;
  iter = iter->next;
 }
 return size;
}

void llist_print( LList* lst)
{
 if(lst->head == NULL)
 {
  return;
 }
 Node *iter = lst->head;
 while(iter != NULL)
 {
  printf("%d ",iter->val);
  fflush(stdout);
  iter = iter->next;
 }
 printf("\n");
 return;
}

Node* llist_get( LList* lst, int idx )
{
 if(lst->head ==NULL)
 {
  return NULL;
 }
 if(idx < 0 || idx >= llist_size(lst))
 {
  return NULL;
 }
 Node *iter = lst->head;
 int i= 0;
 while(iter != NULL)
 {
  if(i == idx)
  {
   return iter;
  }
  iter = iter->next;
  i++;
 }
}

void llist_append( LList* lst, int a, int b)
{
 if(lst->head == NULL)
 {
  Node *new = (Node *)malloc(sizeof(Node));
  new->col_ind = a;
  new->val     = b;
  lst->head    = new;
  new->next    = NULL;
  return;
 }
 Node *new = (Node *)malloc(sizeof(Node));
 Node *now  = lst->head;
 while(now->next != NULL)
 {
  now = now->next;
 }
 new->col_ind = a;
 new->val     = b;
 now->next    = new;
 new->next    = NULL;
 return;
}

void llist_prepend( LList* lst, int a, int b)
{
 if(lst->head == NULL)
 {
   Node *new = (Node *)malloc(sizeof(Node));
   new->col_ind = a;
   new->val     = b;
   lst->head    = new;
   new->next    = NULL;
   return;
 }
 Node *new = (Node *)malloc(sizeof(Node));
 Node *now = lst->head;
 new->col_ind = a;
 new->val     = b;
 new->next    = now;
 lst->head    = new;
 return;
}

void llist_insert( LList* lst, int idx, int a, int b)
{  
 int count =llist_size(lst);
 if(idx == 0)
  {
   llist_prepend(lst,a,b);
   return;
  }
  
  else if(idx == count)
  {
   llist_append(lst,a,b);
  }
  else if(idx>count)
  {
   return;
  }
  else
 {
  count=1;
  Node* exam = lst->head;
  while(exam->next != NULL)
  {
    if(count == idx)
    {
     Node* new = (Node *)malloc(sizeof(Node));
     new->col_ind = a;
     new->val     = b; 
     new->next = exam->next; 
     exam->next=new;
     return;
    }
   count++;
   exam = exam->next;
  }
  llist_append(lst,a,b);
  return;
  }
 }

 
   
 
