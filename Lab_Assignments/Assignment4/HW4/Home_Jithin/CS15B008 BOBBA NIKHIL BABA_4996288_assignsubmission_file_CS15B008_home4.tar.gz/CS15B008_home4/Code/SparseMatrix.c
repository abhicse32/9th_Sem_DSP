//Program written by B.Nikhil Baba on 4th Sept to Add,Subtract,Multiply matrices using linked list.
//New libraries taken from SparseMatrix.h ,List.h .
#include "SparseMatrix.h"
#include<stdlib.h>
#include<stdio.h>
#include<limits.h>

//Addition of two matrices
Matrix add(Matrix a , Matrix b)
{
 Matrix final;
 int rows_a = a.n_rows;
 LList **pointer_a = a.row_lst;
 int rows_b = b.n_rows;
 LList **pointer_b = b.row_lst;
 final.n_rows = rows_a;
 LList** pointer_final = malloc(sizeof(LList *) * rows_a);     
 for(int i=0; i<rows_a ; i++)
 {
  pointer_final[i] = llist_new();
 }
 final.row_lst = pointer_final;                   //Assigning the final pointer to the operated one.
 
 for(int i=0 ; i<rows_a ; i++)
 {
  Node *now_a  =  pointer_a[i]->head; 
  Node *now_b  =  pointer_b[i]->head;
  while((now_a != NULL) && (now_b != NULL))
  {
   int cola = now_a->col_ind;
   int colb = now_b->col_ind;
   int vala = now_a->val;
   int valb = now_b->val;
   if(cola<colb)
   { 
    llist_append(pointer_final[i],cola,vala);
    now_a = now_a->next;
   }
    else if(cola>colb)
   { 
    llist_append(pointer_final[i],colb,valb);
    now_b = now_b->next;
   }
   else 
   { 
    llist_append(pointer_final[i],cola,vala+valb);
    now_a = now_a->next;
    now_b = now_b->next;
   }
  } 
  while(now_a != NULL)
  {
   int cola = now_a->col_ind;
   int vala = now_a->val;
   llist_append(pointer_final[i],cola,vala);
   now_a = now_a->next;
  }
  while(now_b != NULL)
  {
   int colb = now_b->col_ind;
   int valb = now_b->val;
   llist_append(pointer_final[i],colb,valb); 
   now_b = now_b->next;
  }
 }
 
   return final;
}

Matrix subtract(Matrix a, Matrix b)
{
  Matrix final;
 
 int rows_a = a.n_rows;
 LList **pointer_a = a.row_lst;
 LList **pointer_b = b.row_lst;
 final.n_rows = rows_a;
 
 LList **pointer_final = malloc(sizeof(LList *)*rows_a);
 for(int i=0; i<rows_a ; i++)
 {
  pointer_final[i] = malloc(sizeof(LList));
 }
 final.row_lst = pointer_final;                              //Assigining the final pointer to the operated one.
 
 for(int i=0 ; i<rows_a ; i++)
 {
  Node *now_a  =  pointer_a[i]->head; 
  Node *now_b  =  pointer_b[i]->head;
  while(now_a != NULL && now_b != NULL)
  {
   int cola = now_a->col_ind;
   int vala = now_a->val;
   int colb = now_b->col_ind;
   int valb = now_b->val;
   if(cola<colb)
   { 
    llist_append(pointer_final[i],cola,vala);
    now_a = now_a->next;
   }
    else if(cola>colb)
   { 
    llist_append(pointer_final[i],colb,(-1)*valb);
    now_b = now_b->next;
   }
   else 
   { 
    llist_append(pointer_final[i],cola,vala-valb);
    now_a = now_a->next;
    now_b = now_b->next;
   }
  } 
  while(now_a != NULL)
  {
   int cola = now_a->col_ind;
   int vala = now_a->val;
   llist_append(pointer_final[i],cola,vala);
   now_a = now_a->next;
  }
  while(now_b != NULL)
  {
   int colb = now_b->col_ind;
   int valb = now_b->val;
   llist_append(pointer_final[i],colb,(-1)*valb); 
   now_b = now_b->next;
  }
 }
 return final;
}
  
Matrix matrix_vect_multiply(Matrix mat, Matrix vect)
{
 Matrix final;
 
 int rows_mat = mat.n_rows;
 LList **pointer_mat  = mat.row_lst;
 LList **pointer_vect = vect.row_lst;
 
 final.n_rows = mat.n_rows;
 
 LList **pointer_final = malloc(sizeof(LList *)*rows_mat);
 
 for(int i=0 ; i<rows_mat ; i++)
 {
  pointer_final[i] = malloc(sizeof(LList));
 }
 
 final.row_lst = pointer_final;                                  //Assigning the final pointer to the operated one.
 
 for(int i=0 ; i<rows_mat ; i++)
 {
  int sum = 0;
  Node *now = pointer_mat[i]->head;
  while(now != NULL)
  {
   int col = now->col_ind;
   int num = now->val;
   Node *vet = pointer_vect[col]->head;
   if(vet != NULL)
   {
    int num1 = vet->val;
    sum = sum+(num*num1);
   }
   now = now->next;
 }

  llist_append(pointer_final[i],0,sum);
 }
 return final;
} 
     
    
   
 
