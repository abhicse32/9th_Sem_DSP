//Program written by B.Nikhil Baba on Sept 4th.
//Writing driver function for Sparse matrix operations.
#include<stdio.h>
#include"List.h"
#include"SparseMatrix.h"
#include<stdlib.h>
int main()
{
 int p,m,n;
 Matrix a,b,c,M;
 scanf("%d",&p);
 while( p!=-1)
 {
    switch(p)                                                       //P is the choice here.
    {
      case 1://Input function for addition
       scanf("%d%d",&m,&n);
       a.n_rows =m;
       b.n_rows =m;
       LList **pointer_a = (LList **)malloc(sizeof(LList *)*m);
       LList **pointer_b = (LList **)malloc(sizeof(LList *)*m);
      
       for(int i=0;i<m;i++)
       {
        pointer_a[i] =(LList *)malloc(sizeof(LList));
       }
       a.row_lst = pointer_a;
       for(int i=0;i<m;i++)
       { 
        for(int j=0;j<n;j++)
        {
         int ele;
         scanf("%d",&ele);
	 if(ele!=0)                                                      //Not appending zero elements.(No wastage of memory)
         {
          llist_append(pointer_a[i],j,ele);
         }
        }
       }
       for(int i=0;i<m;i++)
       {
        pointer_b[i] = malloc(sizeof(LList));
       }
       b.row_lst = pointer_b;
       for(int i=0;i<m;i++)
       {
        for(int j=0;j<n;j++)
        {
         int ele;
         scanf("%d",&ele);
	 if(ele !=0)
         {
          llist_append(pointer_b[i],j,ele);
         }
        }
       }
       Matrix M1 = add(a,b);
       printMatrix(M1);      
       break;
    
      case 2://Input function for subtraction.
         scanf("%d%d",&m,&n);
       a.n_rows =m;
       b.n_rows =m;
       LList **pointer_a1 = (LList **)malloc(sizeof(LList *)*m);
       LList **pointer_b1 = (LList **)malloc(sizeof(LList *)*m);
      
       for(int i=0;i<m;i++)
       {
        pointer_a1[i] = llist_new();
       }
       a.row_lst = pointer_a1;
       for(int i=0;i<m;i++)
       { 
        for(int j=0;j<n;j++)
        {
         int ele;
         scanf("%d",&ele);
	 if(ele!=0)                                                             //No wastage of memory
         {
          llist_append(pointer_a1[i],j,ele);
         }
        }
       }
      
       for(int i=0;i<m;i++)
       {
        pointer_b1[i] = llist_new();
       }
        b.row_lst = pointer_b1;
       for(int i=0;i<m;i++)
       {
        for(int j=0;j<n;j++)
        {
         int ele;
         scanf("%d",&ele);
	 if(ele !=0)
         {
          llist_append(pointer_b1[i],j,ele);
         }
        }
       }
       Matrix M2 = subtract(a,b);
       printMatrix(M2);

       
       break;
        
       case 3://Multiplcation of matrices
       
       
       scanf("%d %d",&m,&n);
       a.n_rows = m;
       b.n_rows = m;
       LList **pointer_a2 = (LList **)malloc(sizeof(LList *)*m);
       LList **pointer_c2 = (LList **)malloc(sizeof(LList *)*n);     
       
       for(int i=0;i<m;i++)
       {
        pointer_a2[i] = llist_new();
       }
       a.row_lst = pointer_a2;
       for(int i=0;i<m;i++)
       { 
       for(int j=0;j<n;j++)
        {
         int ele;
         scanf("%d",&ele);
         llist_append(pointer_a2[i],j,ele);
        }
       }  
       
       for(int i=0;i<n;i++)
       {
        pointer_c2[i] = llist_new();
       }
       c.row_lst=pointer_c2;
       for(int i=0;i<n;i++)
       {
        int ele; 
        scanf("%d",&ele);
        llist_append(pointer_c2[i],0,ele);
       }
       Matrix M3= matrix_vect_multiply(a,c); 
       printMatrix(M3);        
       break;
    
       
   }
  scanf("%d",&p);   //Again reading the choice to check termination.
  }
 
 return 0;
}
       
void printMatrix(Matrix A)                                        //Writing a function to print array.Tedious to write 3 times.
{
  LList **listptr = A.row_lst;
  int row = A.n_rows;
  int i;
  for(i=0;i<row;i++)
  {
   Node *now =listptr[i]->head;
   Node *now2 = listptr[i]->head;
   while(now != NULL)  //Modified code
   {
    printf("%d ",now->val);
    now = now->next;
   }
   if(now2 != NULL)
   printf("\n");
  }
}
