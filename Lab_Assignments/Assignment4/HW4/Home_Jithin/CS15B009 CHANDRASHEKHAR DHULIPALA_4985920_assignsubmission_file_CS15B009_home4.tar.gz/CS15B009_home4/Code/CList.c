/*  Program to implement a circularly - linked list data structure and basic functions on it

	By  Chandrashekhar D --- Roll no.CS15B009 --- 3 Sept 2016 --- CS2710 Home Assignment 4  */

#include "CList.h"
#include <stdio.h>
#include <stdlib.h>

/*  Function to create a new node and initialize it with data :
	Input parameters : the data to be stored
	Returns : pointer to the node  */
CNode* cnode_new( int data)
{
	CNode* node = (CNode*)malloc(sizeof(CNode));
	node->data = data;
	node->next = NULL;
	return node;
}

/*  Function to create a new circularly linked list and initialize its head to NULL :
	Input parameters : nothing
	Returns : pointer to the list  */
CList* clist_new()
{
	CList* lst = (CList*)malloc(sizeof(CList));
	lst->head = NULL;
	return lst;
}

/*  Function to find the size of a given linked list :
	Input parameters : pointer to the list
	Returns : size of the list, an integer  */
int clist_size( CList* lst )
{
	int size = 0;
	CNode* cur;
	CNode* head = lst->head;
	if(lst->head != NULL)
	{
		size = 1;
		for(cur = lst->head; cur->next != head; cur = cur->next)
			size++;
	}
	return size;
}

/*  Function to print a list in a sequence from head to end :
	Input parameters : pointer to the list
	Returns : nothing  */
void clist_print( CList* lst )
{
	CNode* cur;
	cur = lst->head;
	//CNode* head = lst->head;
	if (lst->head != NULL)
	{
		do
		{
			printf("%d ",cur->data);
			cur = cur->next;
		} 
		while (cur != lst->head);
	}
	printf("\n");
}

/*  Function to retrieve an element at a given index in a linked list :
	Input parameters : pointer to the list, index 
	Returns : element at index idx  */
int clist_get( CList* lst, int idx )
{
	int i = 0;
	CNode* node = lst->head;
	if(idx > clist_size(lst)-1) // If index is out of bounds
		i = -1;
	else
	{
		for(i = 0; i < idx; i++)
			node = node->next;
		i = node->data;
	}
	return i;
}

/*  Function to append an element at the end of a linked list :
	Input parameters : pointer to the list, integer to be appended
	Returns : nothing  */ 
void clist_append( CList* lst, int data )
{
	CNode* node;
	CNode* cur;
	CNode* head;

	node = lst->head;
	head = lst->head;
	cur = cnode_new(data);
	if(node == NULL)       // If list is empty
	{
		lst->head = cur;
		cur->next = cur;
		return;
	}
	while(node->next != head)
		node = node->next;
	node->next = cur;
	cur->next = head;	
}

/*  Function to prepend(add at beginning) an element to the linked list :
	Input parameters : pointer to the list, integer to be prepended
	Returns : nothing  */
void clist_prepend( CList* lst, int data )
{
	clist_append(lst,data);
	CNode* head = lst->head;
	CNode* node = lst->head;
	while(node->next != head)
		node = node->next;
	lst->head = node;
}

/*  Function to insert an element at a particular index :
	Input parameters : pointer to the list, index and integer to be inserted
	Returns : nothing  */
void clist_insert( CList* lst, int idx, int data )
{
	if (idx == 0)
	{
		clist_prepend(lst,data);
		return;
	}
	else if (idx == (clist_size(lst)))
	{
		clist_append(lst,data);
		return;
	}
	else if(idx > (clist_size(lst)) )  // If index is out of bounds
		return;

	CNode* node = lst->head;
	CNode* cur = cnode_new(data);
	int i;
	for(i = 0; i < idx-1; i++)
		node = node->next;
	cur->next = node->next;
	node->next = cur;
}

/*  Function to remove the last element in a linked list :
	Input parameters : pointer to the list
	Returns : nothing  */
void clist_remove_last( CList* lst )
{
	CNode* node = lst->head;
	CNode* remove;
	CNode* head = lst->head;
	if (node->next == head) // If the list has only one element
	{
		lst->head = NULL;
		return;
	}
	while((node->next)->next != head)
		node = node->next;
	remove = node->next;
	node->next = head;
	free(remove);
}

/*  Function to remove the first element in a linked list :
	Input parameters : pointer to the list
	Returns : nothing  */
void clist_remove_first( CList* lst )
{
	CNode* node = lst->head;
	CNode* remove;
	CNode* head = lst->head;
	if (node->next == head) // If the list has only one element
	{
		lst->head = NULL;
		return;
	}
	while((node->next) != head)
		node = node->next;
	remove = node->next;
	lst->head = (lst->head)->next;
	node->next = head->next; 
	free(remove);
}

/*  Function to remove the element at an index idx in a linked list :
	Input parameters : pointer to the list, index idx
	Returns : nothing  */
void clist_remove( CList* lst, int idx )
{
	if(idx == 0)
	{
		clist_remove_first(lst);
		return;
	}
	int i;
	CNode* node = lst->head;
	CNode* remove;
	CNode* head = lst->head;
	for(i = 0; i < idx-1; i++)
		node = node->next;
	remove = node->next;
	node->next = (node->next)->next;
	free(remove);
}

/*  Function to reverse a double linked list :
	Input parameters : pointer to the list
	Returns : nothing  */
void clist_reverse(CList* lst)
{
	CNode* n1 = lst->head;
	CNode* n2 = lst->head;
	while (n1->next != lst->head)
	{
		clist_prepend(lst,n1->next->data);
		n1 = n1->next;
	} 
	n2->next = lst->head;
	return;
}












































