/*  Program to implement a linked list data structure and basic functions on it

	By  Chandrashekhar D --- Roll no.CS15B009 --- 29 Aug 2016 --- CS2710 Lab Assignment 4  */

#include "List.h" // Importing function prototypes and structures from List.c
#include <stdio.h>
#include <stdlib.h>
#include <limits.h> 

/*  Function to create a new node and initialize it with data :
	Input parameters : the data to be stored, two integers
	Returns : pointer to the node  */
Node* node_new( int data1, int data2)
{
	Node* node;
	node = (Node* )malloc(sizeof(Node));
	if(node == NULL)
		printf("Memory Allocation Error!!\n");
	else
	{
		node->col_ind = data1;
		node->val = data2;
		node->next = NULL;
	}
	return node;
}

/*  Function to create a new linked list and initialize its head to NULL :
	Input parameters : nothing
	Returns : pointer to the list  */
LList* llist_new()
{
	LList* list;
	list = (LList* )malloc(sizeof(LList));
	if(list == NULL)
		printf("Memory Allocation Error!!\n");
	list->head = NULL;
	return list;
}

/*  Function to find the size of a given linked list :
	Input parameters : pointer to the list
	Returns : size of the list, an integer  */
int llist_size( LList* lst )
{
	int size = 0;
	Node* cur;
	if(lst->head != NULL)
	{
		for(cur = lst->head; cur != NULL; cur = cur->next)
			size++;
	}
	return size;
}

/*  Function to print a list in a seequence from head to end :
	Input parameters : pointer to the list
	Returns : nothing  */
void llist_print( LList* lst )
{
	Node* cur;
	cur = lst->head;
	while(cur != NULL)
	{
		printf("%d ",cur->val);
		fflush(stdout);
		cur = cur->next;
	}
	printf("\n");
}

/*  Function to retrieve an element at a given index in a linked list :
	Input parameters : pointer to the list, index 
	Returns : element at index idx  */
Node* llist_get( LList* lst, int idx )
{
	int i = 0;
	Node* node = lst->head;
	if(idx > llist_size(lst)-1) // If index is out of bounds
		i = INT_MIN;
	else
	{
		for(i = 0; i < idx; i++)
			node = node->next;
		i = node->val;
	}
	return node;
}

/*  Function to append an element at the end of a linked list :
	Input parameters : pointer to the list, integers to be appended
	Returns : nothing  */ 
void llist_append( LList* lst, int data1, int data2 )
{
	Node* node;
	Node* cur;
	node = lst->head;
	cur = node_new(data1,data2);
	if(node == NULL)       // If list is empty
	{
		lst->head = cur;
		return;
	}
	while(node->next != NULL)
		node = node->next;
	node->next = cur;	
}

/*  Function to prepend(add at beginning) an element to the linked list :
	Input parameters : pointer to the list, integers to be prepended
	Returns : nothing  */
void llist_prepend( LList* lst, int data1, int data2 )
{
	Node** phead;
	Node* cur;
	phead = &(lst->head);
	cur = node_new(data1,data2);
	
	cur->next = (*phead);
	(*phead) = cur;
}

/*  Function to insert an element at a particular index :
	Input parameters : pointer to the list, index and integers to be inserted
	Returns : nothing  */
void llist_insert( LList* lst, int idx, int data1, int data2 )
{
	int i;
	if(idx == 0)
	{
		llist_prepend(lst,data1,data2);
		return;
	}
	else if(idx == llist_size(lst))
	{
		llist_append(lst,data1,data2);
		return;
	}
	else if(idx > (llist_size(lst)) )  // If index is out of bounds
		return;

	Node* node = lst->head;
	Node* cur = node_new(data1,data2);
	
	for(i = 0; i < idx-1; i++)
		node = node->next;
	cur->next = node->next;
	node->next = cur;
}

























































