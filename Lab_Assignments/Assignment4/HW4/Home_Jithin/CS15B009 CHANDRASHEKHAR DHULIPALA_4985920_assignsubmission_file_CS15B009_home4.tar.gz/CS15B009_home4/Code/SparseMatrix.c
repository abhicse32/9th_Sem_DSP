/*  Program to implement a Sparse Matrix data structure and simple mathematical functions on it using linked lists

	By  Chandrashekhar D --- Roll no.CS15B009 --- 4 Sept 2016 --- CS2710 Home Assignment 4  */

#include "SparseMatrix.h"
#include <stdlib.h>

/*  Function to add two sparse matrices :
	Input parameters : Two Matrix ADTs a,b
	Returns : the ans matrix (a+b)  */
Matrix add(Matrix a, Matrix b)
{
	int i;
	int n = a.n_rows;
	Matrix ans;
	ans.row_lst=(LList**)malloc(sizeof(LList*)*n);
	ans.n_rows = n;
	for(i = 0;i < n;i++)
	{
		(ans.row_lst)[i] = llist_new();
		LList* l = (ans.row_lst)[i];
		LList* l1 = (a.row_lst)[i];
		LList* l2 = (b.row_lst)[i];
		Node* n1 = l1->head;
		Node* n2 = l2->head;
		while (n1 != NULL && n2 != NULL)
		{
			if (n1->col_ind == n2->col_ind)
			{
				llist_append(l,n1->col_ind,n1->val+n2->val);
				n1 = n1->next;
				n2 = n2->next;
			}
			else if (n1->col_ind < n2->col_ind)
			{
				llist_append(l,n1->col_ind,n1->val);
				n1 = n1->next;
			}
			else if (n1->col_ind > n2->col_ind)
			{
				llist_append(l,n2->col_ind,n2->val);
				n2 = n2->next;
			}
		}
		while (n1 != NULL)
		{
			llist_append(l,n1->col_ind,n1->val);
			n1 = n1->next;
		}
		while (n2 != NULL)
		{
			llist_append(l,n2->col_ind,n2->val);
			n2 = n2->next;
		}
	}
	return ans;
}

/*  Function to multiply a sparse matrix by -1 :
	Input parameters : Matrix ADT a
	Returns : Matrix -(a)  */
void invert(Matrix a)
{
	int i;
	int n = a.n_rows;
	for(i = 0;i < n;i++)
	{
		LList* l = (a.row_lst)[i];
		Node* nd = l->head;
		while(nd != NULL)
		{
			nd->val = nd->val * (-1);
			nd = nd->next;
		}
	}
}

/*  Function to subtract two sparse matrices :
	Input parameters : Two Matrix ADTs a,b
	Returns : the ans matrix (a-b)  */
Matrix subtract(Matrix a, Matrix b)
{
	
	invert(b);
	Matrix ans = add(a,b);
	return ans;
}

/*  Function to multiply two sparse matrices :
	Input parameters : Two Matrix ADTs a,b
	Returns : the ans matrix (a*b)  */
Matrix matrix_vect_multiply(Matrix mat, Matrix vect)
{
	int i,j;
	int m = mat.n_rows;
	int n = 0;
	Matrix ans;
	ans.row_lst=(LList**)malloc(sizeof(LList*)*m);
	ans.n_rows = m;
	for (i = 0;i < m;i++)
	{

		LList* l1 = (mat.row_lst)[i];
		(ans.row_lst)[i] = llist_new();
		LList* l = (ans.row_lst)[i];
		Node* n1 = l1->head;
		int sum = 0;
		while(n1 != NULL)
		{	int x = 0;
			if (((vect.row_lst)[n1->col_ind])->head != NULL)
				x = ((vect.row_lst)[n1->col_ind])->head->val;
			sum = sum + x*(n1->val);
			n1 = n1->next;
		}
		llist_append(l,0,sum);
	}
	return ans;
}
















