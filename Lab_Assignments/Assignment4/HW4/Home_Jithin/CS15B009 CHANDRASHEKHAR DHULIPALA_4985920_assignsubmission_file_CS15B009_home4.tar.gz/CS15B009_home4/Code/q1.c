/*  Program to perform mathematical operations on user input sparse matrices 

	By  Chandrashekhar D --- Roll no.CS15B009 --- 4 Sept 2016 --- CS2710 Home Assignment 4  */

#include <stdio.h>
#include <stdlib.h>
#include "SparseMatrix.h"

/*  Main function */
int main()
{
	int choice;
	while(1)
	{
		scanf("%d",&choice);  // User choice
		if (choice == -1)
			break;
		Matrix a,b,ans;

		int m,n;
		int i,j;
		LList* l;
		int inp;
		switch(choice)
		{
			case 1:                      // Addition
				scanf("%d %d",&m,&n);
				a.row_lst=(LList**)malloc(sizeof(LList*)*m);
				b.row_lst=(LList**)malloc(sizeof(LList*)*m);
				a.n_rows = m;
				b.n_rows = m;
				for(i = 0;i < m;i++)     // Matrix a input
				{

					(a.row_lst)[i] = llist_new();
					l = (a.row_lst)[i];
					for(j = 0;j < n;j++)
					{
						scanf("%d",&inp);
						if (inp == 0)
							continue;
						llist_append(l,j,inp);
					}
				}
				for(i = 0;i < m;i++)     // Matrix b input
				{
					(b.row_lst)[i] = llist_new();
					l = (b.row_lst)[i];
					for(j = 0;j < n;j++)
					{
						scanf("%d",&inp);
						if (inp == 0)
							continue;
						llist_append(l,j,inp);
					}
				}
				ans = add(a,b);
				for(i = 0;i < m;i++)
				{
					if (llist_size((ans.row_lst)[i]) != 0)
						llist_print((ans.row_lst)[i]);
				}
				break;

			case 2:                           // Subtraction
				scanf("%d %d",&m,&n);
				a.row_lst=(LList**)malloc(sizeof(LList*)*m);
				b.row_lst=(LList**)malloc(sizeof(LList*)*m);
				a.n_rows = m;
				b.n_rows = m;
				for(i = 0;i < m;i++)          // Matrix a input
				{
					(a.row_lst)[i] = llist_new();
					l = (a.row_lst)[i];
					for(j = 0;j < n;j++)
					{
						scanf("%d",&inp);
						if (inp == 0)
							continue;
						llist_append(l,j,inp);
					}
				}
				for(i = 0;i < m;i++)          // Matrix b input
				{
					(b.row_lst)[i] = llist_new();
					l = (b.row_lst)[i];
					for(j = 0;j < n;j++)
					{
						scanf("%d",&inp);
						if (inp == 0)
							continue;
						llist_append(l,j,inp);
					}
				}
				ans = subtract(a,b);
				for(i = 0;i < m;i++)
				{
					if (llist_size((ans.row_lst)[i]) != 0)
						llist_print((ans.row_lst)[i]);
				}
				break;

			case 3:                           // Multiplication
				scanf("%d %d",&m,&n);
				a.row_lst=(LList**)malloc(sizeof(LList*)*m);
				b.row_lst=(LList**)malloc(sizeof(LList*)*n);
				a.n_rows = m;
				b.n_rows = n;
				for(i = 0;i < m;i++)          // Matrix a input
				{
					(a.row_lst)[i] = llist_new();
					l = (a.row_lst)[i];
					for(j = 0;j < n;j++)
					{
						scanf("%d",&inp);
						if (inp == 0)
							continue;
						llist_append(l,j,inp);
					}
				}
				for(i = 0;i < n;i++)          // Vector b input
				{
					(b.row_lst)[i] = llist_new();
					l = (b.row_lst)[i];
					scanf("%d",&inp);
					if (inp == 0)
						continue;
					llist_append(l,0,inp);
				}
				ans = matrix_vect_multiply(a,b);
				for(i = 0;i < m;i++)
				{
					if (llist_size((ans.row_lst)[i]) != 0)
						llist_print((ans.row_lst)[i]);
				}
				break;

			default:
				printf("Invalid choice!\n");
		
		}   // End switch case
	
	}   // End while loop
	return 0;
}