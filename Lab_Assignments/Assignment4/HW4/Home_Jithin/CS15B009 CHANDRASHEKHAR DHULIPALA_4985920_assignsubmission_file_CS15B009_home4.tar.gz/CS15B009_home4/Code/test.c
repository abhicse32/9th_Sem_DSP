#include "CList.h"
#include <stdio.h>
#include <stdlib.h>

int main()
{
	CNode* n = cnode_new(0);
	CList* l = clist_new();
	clist_prepend(l,0);
	clist_print(l);
	clist_prepend(l,1);
	clist_print(l);
	clist_prepend(l,2);
	clist_print(l);
	clist_prepend(l,3);
	clist_print(l);
	clist_prepend(l,5);
	clist_print(l);
	clist_insert(l,4,4);
	clist_print(l);
	printf("%d %d\n",clist_size(l),clist_get(l,5));
	clist_reverse(l);
	clist_print(l);
	clist_remove_last(l);
	clist_print(l);
	
	clist_remove(l,2);
	clist_print(l);
	clist_remove_first(l);
	clist_print(l);
	clist_remove_first(l);
	clist_print(l);
	clist_remove_first(l);
	clist_print(l);
	clist_remove_first(l);
	clist_print(l);
	//printf("%d\n",l->head->next->next->next->next->next->next->next->data);
	return 0;
}