#include "CList.h"
#include<stdio.h>
#include<stdlib.h>
#include<limits.h>

CNode* cnode_new(int data){
	CNode *newnode;
	newnode=(CNode *)malloc(sizeof(CNode));
	if(newnode==NULL)
		printf("Malloc Error!");	//creating a node
	else{
		newnode->data = data;
		newnode->next = NULL;
	}
	return(newnode);
}

CList* clist_new(){
	CList* sll;
	sll=(CList *)malloc(sizeof(CList));	//allocating space for the new list
	sll->head = NULL;
	return sll;
}

int clist_size( CList* lst ){
	int count=0;
	CNode *curr;
	if(lst->head!=NULL){ 
	    count++;
		for(curr=lst->head;curr->next!=lst->head;curr=curr->next){	//inc counter till the last element
			count++;
		}
	}
	return count;
}

void clist_print( CList* lst ){
	CNode *curr;
	curr = lst->head ;
	if(lst->head==NULL) return;
	while( curr)
	{
		printf( "%d " , curr->data);
		if(curr->next==lst->head ) break;	//printing current data and going for the next one till null
		curr = curr ->next ;
	} 
	printf("\n");
	
	return;
}

int clist_get( CList* lst, int idx ){
	int count=0;
	CNode *curr;
	if(lst->head!=NULL){ 
		curr=lst->head;
		for(count=0;count<idx;count ++){
			if(curr->next==NULL){
				return INT_MIN; }	//using the counter for the no of steps
			else{
				curr=curr->next;
			}
		}
		return curr->data;
	}
	return INT_MIN;
}

void clist_append( CList* lst, int data ){
	CNode *curr=lst->head;
	if(lst->head!=NULL){ 
		if(lst->head->next == lst->head){
			CNode *newnode = cnode_new(data);
			newnode->next = lst->head;
			lst->head->next = newnode;
			return;
		}
		for(curr=lst->head;curr->next!=lst->head;curr=curr->next){
		}
		CNode *newnode = cnode_new(data);
		newnode->next = lst->head;
		curr->next = newnode;	
	}
	else{
		CNode *newnode = cnode_new(data);		//check for no node list
		lst->head=newnode;
		newnode->next=lst->head;		
	}
	return;
}

void clist_prepend( CList* lst, int data ){
	if(lst->head==NULL) clist_append(lst,data);
	CNode *curr;
	curr = lst->head;
	while(curr->next != lst->head){ curr = curr->next; }
	CNode *newnode = cnode_new(data);
	newnode->next = lst -> head;
	lst->head = newnode;
	curr->next = lst->head;
	return;
}

void clist_insert( CList* lst, int idx, int data ){
	CNode *curr;
	int count;
	if(lst->head!=NULL){ 
		if(idx==0){ clist_prepend(lst,data); return; }		//using the pointer to keep the no of steps
		curr=lst->head;
		for(count=0;count<idx-1;count ++){
			if(curr->next==lst->head){
				return; }
			else{
				curr=curr->next;
			}
		}
		CNode *newnode=cnode_new(data);
		newnode->next=curr->next;
		curr->next=newnode;
	}
}

void clist_remove_last( CList* lst ){
	CNode *curr;
	if(lst->head!=NULL){ 
		if(lst->head->next==lst->head) {  lst->head = NULL; return;} 	//for single node list
		for(curr=lst->head;curr->next!=lst->head;curr=curr->next){
			if(curr->next->next==lst->head){
				curr->next=lst->head;
				break;
			}
		}
				
	}
	return;
}

void clist_remove_first( CList* lst ){
	if(lst->head == NULL) return;
	CNode *curr;
	curr = lst->head;
	while(curr->next != lst->head ){
		curr = curr->next;
	}
	if(lst->head!=NULL)
		lst->head=lst->head->next;
	curr->next = lst->head;
	return;
}

void clist_remove( CList* lst, int idx ){
	CNode *curr;
	int count;
	if(lst->head!=NULL){ 
		if(idx==0){ clist_remove_first(lst);  return; }
		curr=lst->head;		//using a counter to check the no of steps
		for(count=0;count<idx-1;count ++){
			if(curr->next==lst->head){
				return; }
			else{
				curr=curr->next;
			}
		}
		curr->next=curr->next->next;
	}
	return;
}

void clist_reverse(CList* lst){
	CNode* q = lst->head;
	CNode* r = NULL;
	CNode* s;
	while (q != NULL)
	{
		s = r;
		r = q;
		q = q->next;
		r->next = s;
	}
	lst->head = s;
	return;
}
