#include "DList.h"
#include<stdio.h>
#include<stdlib.h>
#include<limits.h>

DNode* dnode_new(int data){
	DNode *node;
	node=(DNode *)malloc(sizeof(DNode));
	if(node==NULL)
		printf("Malloc Error!");	//creating a node
	else{
		node->data = data;
		node->next = NULL;
		node->prev = NULL;
	}
	return(node);
}

DList* dlist_new(){
	DList* dll;
	dll=(DList *)malloc(sizeof(DList));	//allocating space for the new list
	dll->head = NULL;
	return dll;
}

int dlist_size( DList* lst ){
	int count=0;
	DNode *curr;
	if(lst->head!=NULL){ 
	    count++;
		for(curr=lst->head;curr->next!=NULL;curr=curr->next){	//inc counter till the last element
			count++;
		}
	}
	return count;
}

void dlist_print( DList* lst ){
	DNode *curr;
	curr = lst->head ;
	
	while( curr )
	{
		printf( "%d " , curr->data);	//printing current data and going for the next one till null
		curr = curr ->next ;
	} 
	printf("\n");
	
	return;
}

int dlist_get( DList* lst, int idx ){
	int count=0;
	DNode *curr;
	if(lst->head!=NULL){ 
		curr=lst->head;
		for(count=0;count<idx;count ++){
			if(curr->next==NULL){
				return -1; }	//using the counter for the no of steps
			else{
				curr=curr->next;
			}
		}
		return curr->data;
	}
	return -1;
}

void dlist_append( DList* lst, int data ){
	if(lst->head == NULL){
		DNode *node = dnode_new(data);
		lst->head = node;
		return;
	}
	else{
		DNode *curr;
		for(curr=lst->head;curr->next!=NULL;curr=curr->next){
		}
		DNode *node = dnode_new(data);
		curr->next = node;
		node->prev = curr;
	}
	return;
}

void dlist_prepend( DList* lst, int data ){
	if(lst->head==NULL){
		DNode *node = dnode_new(data);
		lst->head = node;
		return;
	}
	DNode *node = dnode_new(data);
	lst->head->prev = node;
	node->next = lst->head;
	lst->head = node;
	return;
}

void dlist_insert( DList* lst, int idx, int data ){
	if(idx==0){ dlist_prepend(lst,data); return; }
	DNode *curr;
	int count;
	if(lst->head!=NULL){ 		//using the pointer to keep the no of steps
		curr=lst->head;
		for(count=0;count<idx-1;count ++){
			if(curr->next==NULL){
				return; }
			else{
				curr=curr->next;
			}
		}
		DNode *node = dnode_new(data);	
		node->next=curr->next;
		curr->next=node;
		node->prev = curr;
		node->next->prev = node;
	}
}

void dlist_remove_last( DList* lst ){
	DNode *curr;
	if(lst->head!=NULL){ 
		if(lst->head->next==NULL) {  lst->head = NULL; return;} 	//for single node list
		for(curr=lst->head;curr->next!=NULL;curr=curr->next){
			if(curr->next->next==NULL){
				curr->next=NULL;
				break;
			}
		}
				
	}
	return;
}

void dlist_remove_first( DList* lst ){
	if(lst->head!=NULL)
		if(lst->head->next==NULL){
			lst->head=NULL;
			return;}
		lst->head=lst->head->next;
		lst->head->prev = NULL;
	return;
}

void dlist_remove( DList* lst, int idx ){
	DNode *curr;
	int count;
	if(lst->head!=NULL){ 
		if(idx==0){ dlist_remove_first(lst);  return; }
		curr=lst->head;		//using a counter to check the no of steps
		if(idx==1){
			if(curr->next==NULL){
				return;
			}
		}
		for(count=0;count<idx-1;count ++){
			if(curr->next==NULL){
				return; }
			else{
				curr=curr->next;
			}
		}
		curr->next=curr->next->next;
		curr->next->prev = curr;
	}
}

void dlist_reverse(DList * lst){
	if(lst->head == NULL) return;
	DNode *temp;
	DNode *curr;
	curr = lst->head;
	while(curr!=NULL){
		temp = curr->next;
		curr->next = curr->prev;
		curr->prev = temp;
		if(curr->prev == NULL) 
			lst->head = curr;
		curr = curr->prev;
	}
}
