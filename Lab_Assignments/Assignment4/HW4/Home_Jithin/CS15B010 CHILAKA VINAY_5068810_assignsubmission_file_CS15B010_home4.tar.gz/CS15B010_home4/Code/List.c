#include "List.h"
#include<stdio.h>
#include<stdlib.h>

Node* node_new( int data1, int data2){
	Node *node;
	node=(Node *)malloc(sizeof(Node));
	if(node==NULL)
		printf("Malloc Error!");	//creating a node
	else{
		node->col_ind = data1;
		node->val = data2;
		node->next = NULL;
	}
	return(node);
}

LList* llist_new(){
	LList* sll;
	sll=(LList *)malloc(sizeof(LList));	//allocating space for the new list
	sll->head = NULL;
	return sll;
}

int llist_size( LList* lst ){
	int count=0;
	Node *curr;
	if(lst->head!=NULL){ 
	    count++;
		for(curr=lst->head;curr->next!=NULL;curr=curr->next){	//inc counter till the last element
			count++;
		}
	}
	return count;
}

void llist_print( LList* lst ){
	Node *curr;
	curr = lst->head ;
	
	while( curr )
	{
		printf( "%d " ,curr->val);	//printing current data and going for the next one till null
		curr = curr ->next ;
	} 
	printf("\n");
	
	return;
}

Node* llist_get( LList* lst, int idx ){
	int count=0;
	Node *curr;
	if(lst->head!=NULL){ 
		curr=lst->head;
		for(count=0;count<idx;count ++){
			if(curr->next==NULL){
				return NULL; }	//using the counter for the no of steps
			else{
				curr=curr->next;
			}
		}
		return curr;
	}
	return NULL;
}

void llist_append( LList* lst, int data1 ,int data2){
	Node *curr;
	if(lst->head!=NULL){ 
		for(curr=lst->head;curr->next!=NULL;curr=curr->next){
		}
		Node *node = node_new(data1,data2);
		curr->next = node;		
	}
	else{
		Node *node=node_new(data1,data2);
		lst->head=node;		
	}
	return;
}

void llist_prepend( LList* lst, int data1, int data2){
	Node *node = node_new(data1,data2);
	node->next = lst->head;
	lst->head = node;
	return;
}

void llist_insert( LList* lst, int idx, int data1, int data2){
	Node *node = node_new(data1,data2);
	Node *curr;
	int count;
	if(lst->head!=NULL){ 
		if(idx==0){ llist_prepend(lst,data1,data2); return; }		//using the pointer to keep the no of steps
		curr=lst->head;
		for(count=0;count<idx-1;count ++){
			if(curr->next==NULL){
				return; }
			else{
				curr=curr->next;
			}
		}
		node->col_ind =data1;
		node->val =data2;
		node->next=curr->next;
		curr->next=node;
	}
}

