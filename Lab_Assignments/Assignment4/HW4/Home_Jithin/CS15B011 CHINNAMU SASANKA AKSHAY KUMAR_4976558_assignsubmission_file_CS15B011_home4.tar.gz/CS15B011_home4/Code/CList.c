#include "CList.h"
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>


// Create a new node with next set to NULL
CNode* cnode_new( int data)
{
	CNode *p;
	p = (CNode*) malloc(sizeof(CNode));
	p->data = data;
	p->next = NULL;
	return p;
}

// Create an empty list (head shall be NULL)
CList* clist_new()
{
	CList* l;
	l = (CList*) malloc(sizeof(CList));
	l->head = NULL;
	return l;
}

// Traverse the linked list and return its size
int clist_size( CList* lst )
{
	int k = 0;
	CNode *n;
	n = (lst->head)->next;

	while(n != lst->head)
	{
		k++;
		n = n->next;
	}
	return k+1;
}

// Traverse the linked list and print each element
void clist_print( CList* lst )
{
	CNode *n;
	n = lst->head;
	if(n==NULL) return;
	if(n->next == lst->head) 
	{
		printf("%d \n",n->data);
		return;
	}
	printf("%d ",n->data);
	n = n->next;
	while(1)
	{
		printf("%d ",n->data);
		n = n->next;
		if(n == lst->head) break;
	}
	printf("\n");
}

//get the element at position @idx
int clist_get( CList* lst, int idx )
{
	int k = 0;
	CNode *n;
	n = lst->head;
	if(idx >= clist_size(lst)) return -1;
	while(k != idx)
	{
		n = n->next;
		k++;
	}
	return n->data;
}

// Add a new element at the end of the list
void clist_append( CList* lst, int data )
{
	CNode * n=(CNode *)malloc(sizeof(CNode));
    n->data=data;
    n->next=lst->head;

    if(lst->head==NULL)
    {
      	lst->head = n;
 		n->next = lst->head;
    }
    else
    {
      	CNode * t=lst->head;

      	while(t->next != lst->head)
      	{
      		t=t->next;         
      	}

      	t->next=n; 
    } 
}

// Add a new element at the beginning of the list
void clist_prepend( CList* lst, int data )
{ 
 	CNode * n=lst->head; 
 	CNode * m=cnode_new(data);
	if(lst->head==NULL)           
    {
    	m->next=m;
   		lst->head=m;return;
    }
   
    while(n->next!=lst->head)  
    n=n->next; 
  
 	m->next=lst->head;   
	lst->head=m;
    n->next=m;
}

// Add a new element at the @idx index
void clist_insert( CList* lst, int idx, int data )
{
	int k = 1;
	CNode *n;
	CNode *x = cnode_new(data);
	if(lst->head == NULL)
	{
		clist_prepend(lst,data);
		return;
	}
	n = lst->head;
	if(idx > clist_size( lst )) return;
	if(!lst->head) 
	{
		lst->head = x;
		x->next=x;
	}
	else if(idx == 0)
	{
		clist_prepend(lst, data );
		
	}
	else
	{
		while(k != idx)
		{
			n = n->next;
			k++;
		}
		x->next = n->next;
		n->next = x;
	}

}

// Remove an element from the end of the list
void clist_remove_last( CList* lst )
{
	CNode *n;
	n = lst->head;
	while((n->next)->next != lst->head)
	{
		n = n->next;
	}
	n->next = lst->head;
}

// Remove an element from the beginning of the list
void clist_remove_first( CList* lst )
{
	CNode* n = lst->head;
	if(lst->head == NULL) return;
	if(n->next == lst->head) 
	{
		lst->head = NULL;
		return;
	}
	while(n->next!=lst->head)  
    n=n->next; 
	lst->head = (lst->head)->next;
	n->next=lst->head;
	
}

// Remove an element from an arbitrary @idx position in the list
void clist_remove( CList* lst, int idx )
{
	CNode* n=lst->head;
	CNode* m=lst->head;
	if(idx==0)
	{
		clist_remove_first( lst );
		return;
	}
	
	int k = clist_size(lst);
	if(idx>=k) return;
	
	k=0;
	

	while(n!=NULL)
	{
		if(k==idx)
		{
			m->next=n->next;
			return;				
		}
		k++;
		m=n;
		n=n->next;
	}
}

// reverse the list
void clist_reverse(CList* lst)
{
	int i;
	CList* l = clist_new();
	CNode* n = lst->head;
	clist_prepend(l,n->data);
	n = n->next;
	while(n != lst->head)
	{
		clist_prepend(l,n->data);
		n = n->next;
	}
	int k = clist_size(lst);
	for(i = 0; i < k; i++)
	{
		clist_remove_first( lst );
	}
	clist_remove_first( lst );
	CNode* m = l->head;
	for(i = 0; i < k; i++)
	{
		clist_append(lst,m->data);
		m = m->next;
	}
}
