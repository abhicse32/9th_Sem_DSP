#include "DList.h"
#include <stdlib.h>
#include <limits.h>
#include <stdio.h>


// Create a new node with next set to NULL
DNode* dnode_new( int data)
{
	DNode *p;
	p = (DNode*) malloc(sizeof(DNode));
	p->data = data;
	p->next = NULL;
	p->next = NULL;
	return p;
}

// Create an empty list (head shall be NULL)
DList* dlist_new()
{
	DList* l;
	l = (DList*) malloc(sizeof(DList));
	l->head = NULL;
	return l;
}

// Traverse the linked list and return its size
int dlist_size( DList* lst )
{
	int k = 0;
	DNode *n;
	n = lst->head;
	while(n != NULL)
	{
		k++;
		n = n->next;
	}
	return k;
}

// Traverse the linked list and print each element
void dlist_print( DList* lst )
{
	DNode *n;
	n = lst->head;
	if(n==NULL) return;
	while(1)
	{
		printf("%d ",n->data);
		n = n->next;
		if(!n) break;
	}
	printf("\n");
}

//get the element at position @idx
int dlist_get( DList* lst, int idx )
{
	int k = 0;
	DNode *n;
	n = lst->head;
	if(idx >= dlist_size(lst)) return -1;
	while(k != idx)
	{
		n = n->next;
		k++;
	}
	return n->data;
}

// Add a new element at the end of the list
void dlist_append( DList* lst, int data )
{
	DNode* n = dnode_new( data);

    if(lst->head==NULL)
    lst->head=n;
    else
    {
   		DNode * t=lst->head;
    	while(t->next!=NULL)
   		{
      		t=t->next;         
  		}
  		t->next = n; 
  		n->prev = t;
    } 
}

// Add a new element at the beginning of the list
void dlist_prepend( DList* lst, int data )
{
	DNode *n = dnode_new(data);
	if(lst->head == NULL) lst->head = n;
	else
	{
		(lst->head)->prev = n;
		n->next = lst->head;
		lst->head = n;
	}
}

// Add a new element at the @idx index
void dlist_insert( DList* lst, int idx, int data )
{
	int k = 1;
	DNode *n;
	DNode *x = dnode_new(data);
	n = lst->head;
	if(idx > dlist_size( lst )) return;
	if(!lst->head) 
	{
		lst->head = x;
		x->next=NULL;
	}
	else if(idx == 0)
	{
		dlist_prepend(lst, data );
		
	}
	else if(idx == dlist_size( lst )) dlist_append(lst, data );
	else
	{
		while(k != idx)
		{
			n = n->next;
			k++;
		}
		x->next = n->next;
		(n->next)->prev = x;
		n->next = x;
		x->prev = n;
	}
}

// Remove an element from the end of the list
void dlist_remove_last( DList* lst )
{
	DNode *n;
	n = lst->head;
	while((n->next)->next != NULL)
	{
		n = n->next;
	}
	n->next = NULL;
}

// Remove an element from the beginning of the list
void dlist_remove_first( DList* lst )
{
	if(lst->head == NULL) return;
	lst->head = (lst->head)->next;
	(lst->head)->prev = NULL;
}

// Remove an element from an arbitrary @idx position in the list
void dlist_remove( DList* lst, int idx )
{
	DNode* n=lst->head;
	DNode* m=lst->head;
	if(idx==0)
	{
		dlist_remove_first( lst );
		return;
	}
	
	int k = dlist_size(lst);
	if(idx>=k) return;
	
	k=0;
	
	while(n!=NULL)
	{
		if(k==idx)
		{
			m->next=n->next;
			(n->next)->prev = m;
			return;				
		}
		k++;
		m=n;
		n=n->next;
	}
}

// reverse the list
void dlist_reverse(DList* lst)
{
	DNode* n = lst->head;
	if(!n) return;
	if(dlist_size( lst ) == 1) return;
	else
	{
		n->prev = n->next;
		n->next = NULL;
		
		while(n->prev)
		{
			(n->prev)->prev = (n->prev)->next;
			(n->prev)->next = n;
			n = n->prev;
		}
	}
	lst->head = n;
}
