/* Program to implement basic operations on a linked list Akshay Kumar*/
#include "List.h"
#include <stdlib.h>
#include <stdio.h>
#include <limits.h>

// Create a new node with next set to NULL
Node* node_new( int data1, int data2)
{
	Node *p = (Node*) malloc(sizeof(Node));
	p->col_ind = data1;
	p->val = data2;
	p->next = NULL;
	return p;
}

// Create an empty list (head shall be NULL)
LList* llist_new()
{
	LList* l = (LList*) malloc(sizeof(LList));
	l->head = NULL;
	return l;
}

// Traverse the linked list and return its size
int llist_size( LList* lst )
{
	int k = 0;
	Node *n;
	n = lst->head;
	while(n != NULL)
	{
		k++;
		n = n->next;
	}
	return k;
}

// Traverse the linked list and print each element
void llist_print( LList* lst )
{
	Node *n;
	n = lst->head;
	if(n == NULL) return;
	while(1)
	{
		printf("%d ",n->val);
		n = n->next;
		if(!n) break;
	}
	printf("\n");
}

//get the element at position @idx
Node* llist_get( LList* lst, int idx )
{
	int k = 0;
	Node *n;
	n = lst->head;
	if(idx >= llist_size(lst)) return NULL;
	while(k != idx)
	{
		n = n->next;
		k++;
	}
	return n;
}

// Add a new element at the end of the list
void llist_append( LList* lst, int data1, int data2)
{
         
    Node * n = node_new( data1, data2);
 
    if(lst->head == NULL)
    lst->head = n;
    else
    {
   		Node * t=lst->head;

    	while(t->next!=NULL)
   		{
      		t=t->next;         
  		}

  		t->next=n; 
    } 
}

// Add a new element at the beginning of the list
void llist_prepend( LList* lst, int data1, int data2 )
{
	Node *n = node_new(data1,data2);
	if(lst->head == NULL) lst->head = n;
	else
	{
		n->next = lst->head;
		lst->head = n;
	}
}

// Add a new element at the @idx index
void llist_insert( LList* lst, int idx, int data1, int data2)
{
	int k = 1;
	Node *n = lst->head;
	Node *x = node_new(data1,data2);
	
	if(idx > llist_size( lst )) return;
	if(!lst->head) 
	{
		lst->head = x;
		x->next=NULL;
	}
	else if(idx == 0)
	{
		llist_prepend(lst, data1, data2);
		
	}
	else
	{
		while(k != idx)
		{
			n = n->next;
			k++;
		}
		x->next = n->next;
		n->next = x;
	}

}

