#include "SparseMatrix.h"
#include <stdio.h>
#include <stdlib.h>


/*Multiply an M x N matrix with N X 1 vector*/
Matrix matrix_vect_multiply(Matrix mat, Matrix vect)
{
	Matrix result;
	result.n_rows = mat.n_rows;
	result.row_lst=(LList **)malloc(sizeof(LList *)*mat.n_rows);
	int i,j,x,f;
	for(i = 0; i < mat.n_rows; i++)
	{
		result.row_lst[i]=(LList *)malloc(sizeof(LList *));
		LList* mrl = mat.row_lst[i];																	// row lists of mat
		LList* l = result.row_lst[i];
		l->head = NULL;
		x = 0;
		Node* n = mrl->head;
		while(n != NULL)
		{	
			f = n->col_ind;
			x = x + n->val * ((vect.row_lst[f])->head)->val;											// x repeatedly adds and stores multiplied value
			n = n->next;
		}
		llist_append( l, 0, x);																			// stores value in result matrix
	}	
	return result;																						// returns result matrix
}


/*Add two matrices*/
Matrix add(Matrix a, Matrix b)
{
	int i,j,x;
	Matrix result;
	result.n_rows=a.n_rows;
	result.row_lst=(LList **)malloc(sizeof(LList *)*a.n_rows);
	for(i = 0; i < a.n_rows; i++)
	{
		LList* arl = a.row_lst[i];
		LList* brl = b.row_lst[i];
		result.row_lst[i]=(LList *)malloc(sizeof(LList *));

		Node* n = arl->head;
		Node* m = brl->head;
		j = 0;
		while(n != NULL && m != NULL)																	// if col is same adds and saves
		{
			if(n->col_ind == j && m->col_ind == j)
			{
				x = n->val + m->val;
				llist_append(result.row_lst[i], j , x);
				n = n->next;
				m = m->next;
			}
			if(n == NULL || m == NULL) break;
			if(n->col_ind != j && m->col_ind == j)
			{
				llist_append(result.row_lst[i], j , m->val);
				m = m->next;	
			}
			if( m == NULL) break;
			if(n->col_ind == j && m->col_ind != j)
			{
				llist_append(result.row_lst[i], j , n->val);
				n = n->next;
			}
			if(n == NULL) break;
			j++;
		}
		while(n != NULL)																				// if anything in remains appends
		{
			llist_append(result.row_lst[i], a.n_rows , n->val);
			n = n->next;
		}
		while(m != NULL)
		{
			llist_append(result.row_lst[i], a.n_rows , m->val);
			m = m->next;
		}
	}
	return result;																						// returns result matrix
} 


/*Subtract Matrix b from a*/
Matrix subtract(Matrix a, Matrix b)
{
	int i,j,x;
	Matrix result;
	result.n_rows=a.n_rows;
	result.row_lst=(LList **)malloc(sizeof(LList *)*a.n_rows);
	for(i = 0; i < a.n_rows; i++)
	{
		LList* arl = a.row_lst[i];
		LList* brl = b.row_lst[i];
		result.row_lst[i]=(LList *)malloc(sizeof(LList *));

		Node* n = arl->head;
		Node* m = brl->head;
		j = 0;
		while(n != NULL && m != NULL)																	// if col is same subtracts and saves
		{
			if(n->col_ind == j && m->col_ind == j)
			{
				x = n->val - m->val;
				llist_append(result.row_lst[i], j , x);
				n = n->next;
				m = m->next;
			}
			if(n == NULL || m == NULL) break;
			if(n->col_ind != j && m->col_ind == j)
			{
				llist_append(result.row_lst[i], j , -m->val);
				m = m->next;	
			}
			if( m == NULL) break;
			if(n->col_ind == j && m->col_ind != j)
			{
				llist_append(result.row_lst[i], j , n->val);
				n = n->next;
			}
			if(n == NULL) break;
			j++;
		}
		while(n != NULL)																				// if anything in remains appends
		{
			llist_append(result.row_lst[i], n->col_ind , n->val);
			n = n->next;
		}
		while(m != NULL)
		{
			llist_append(result.row_lst[i], m->col_ind , -m->val);
			m = m->next;
		}
	}

	return result;																						// returns result matrix
}