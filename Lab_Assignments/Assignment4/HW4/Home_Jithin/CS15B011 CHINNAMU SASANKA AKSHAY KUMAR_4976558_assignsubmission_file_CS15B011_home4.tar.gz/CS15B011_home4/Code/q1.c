															/*driver program for sparse matrix operations by Akshay Kumar*/

#include "SparseMatrix.h"
#include <stdio.h>
#include <stdlib.h>


void main()
{
	

 	Matrix result;
 
	int option,m,n,x,i,j;																			// declaration of variables
	scanf("%d",&option);																			// intake of option
	while(option != -1)
	{
		scanf("%d %d",&m,&n);
		Matrix a;
		a.row_lst = (LList**) malloc(sizeof(LList*)*m);
		a.n_rows = m;
		for(i = 0; i < m; i++)																		// creation of a matrix
		{
			LList* l = llist_new();
			 *(a.row_lst + i) = l;
			for(j = 0; j < n; j++)																	// printing of result matrix
			{
				scanf("%d",&x);
				if(x != 0) llist_append( l, j, x);
			}
		}

		switch(option)
		{
			case 1:
			{
				
				Matrix b ;
				b.row_lst=(LList **)malloc(sizeof(LList *)*m);
				b.n_rows = m;
				for(i = 0; i < m; i++)																// creation of b matrix
				{
					LList* k = llist_new();
					*(b.row_lst + i) = k;
					for(j = 0; j < n; j++)
					{
						scanf("%d",&x);
						if(x != 0) llist_append( k, j, x);
					}
				}
				
				Matrix result = add(a, b);															// adds two matrices

				for(i = 0; i < m; i++)
				{
					LList* p = *(result.row_lst + i);
					llist_print( p );
				}
				scanf("%d",&option);
				break;
			}

			case 2:
			{
				
				Matrix b ;
				b.row_lst=(LList **)malloc(sizeof(LList *)*m);
				b.n_rows = m;
				for(i = 0; i < m; i++)
				{
					LList* k = llist_new();
					*(b.row_lst + i) = k;
					for(j = 0; j < n; j++)
					{
						scanf("%d",&x);
						if(x != 0) llist_append( k, j, x);
					}
				}

				Matrix result = subtract(a, b);													// subtracts two matrices

				for(i = 0; i < m; i++)
				{
					LList* p = *(result.row_lst + i);
					llist_print( p );
				}
				scanf("%d",&option);
				break;
			}

			case 3:
			{
				    
				
				Matrix b ;
				b.row_lst=(LList **)malloc(sizeof(LList *)*n);
				b.n_rows = n;
				for(i = 0; i < n; i++)
				{
					b.row_lst[i]=(LList *)malloc(sizeof(LList *));
					LList * l;
             		l=b.row_lst[i];
              		l->head=NULL;
					for(j = 0; j < 1; j++)
					{
						scanf("%d",&x);
						llist_append( l, j, x);
					}
				}
				
				Matrix result = matrix_vect_multiply(a, b);										// multiplies a matrix and a vector


				for(i = 0; i < m; i++)
				{
					LList* p = *(result.row_lst + i);
					llist_print( p );
				}

				scanf("%d",&option);
				break;

			}
		}
	}
}



