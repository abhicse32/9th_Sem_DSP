#include "CList.h"
#include <stdlib.h>
#include <stdio.h>
#include <limits.h>

CNode* cnode_new( int data)
{
	CNode* cur;
	cur=(CNode*)malloc(sizeof(CNode));
/* just creating a node with a NULL and update it later*/	
	cur->data=data;
	cur->next=NULL;
	return cur;
} 

CList* clist_new()
{
	CList* new;
	new=(CList*)malloc(sizeof(CList));
	/* creating a circular node which has a NULL as it is empty*/
	new->head=NULL;
	return new;
}

int clist_size( CList* lst )
{

    int count=0;
    CNode* cur;
    cur = (CNode*)malloc(sizeof(CNode));
    /*As it returns to intial the stoping condition is lst->head pointer*/
    if(lst->head==NULL)
    return 0;
    if(lst->head->next==lst->head)
    return 1;    
	 if(lst->head != NULL && lst->head->next!=lst->head)
    {  cur=lst->head;
        do
        {         
         count++; 
         cur=cur->next;
        }while(cur!=lst->head);
    }
    return count;

}

void clist_print( CList* lst )
{
    CNode* cur=(CNode*)malloc(sizeof(CNode)*1);   
     
 
  cur=lst->head;
        do
        {
                printf("%d ",cur->data);    
         cur=cur->next;
      
        }while(cur!=lst->head);
     printf("\n");
     
 
}

int clist_get( CList* lst, int idx )
{
	if(idx>clist_size(lst))
	return -1;
   CNode* cur;
   cur = (CNode*)malloc(sizeof(CNode));
    /* same as idx in linked list no difference*/
  cur=lst->head;
   int count=0;
        do
      {
                           
         
         if(count==idx)
         return cur->data;
         cur=cur->next; 
         count++;                      
      }while(cur!=lst->head);
      
      
      return -1;
        
        
}

void clist_append( CList* lst, int data )
{
    CNode* cur;
    cur = (CNode*)malloc(sizeof(CNode));
    cur->data=data;
/* we append it and point the pointer to the first one*/
     CNode* temp=lst->head;
     if (temp==NULL)
     {lst->head=cur;
      cur->next=cur;
      return;
      }
      
    do
    {
             temp=temp->next;
    }
    while(temp->next!=lst->head);
    temp->next=cur;
    cur->next=lst->head;

    
}

void clist_prepend( CList* lst, int data )
{
    CNode* temp;    
    temp = (CNode*)malloc(sizeof(CNode));
    CNode* new;
      new = (CNode*)malloc(sizeof(CNode));
      /* in prepend we point the prepended element with the last one*/ 
     new->data=data;
     temp=lst->head;
     if(temp==NULL)
     {lst->head=new;
     new->next=new;
     return;
     }
     while(temp->next!=lst->head)
     {temp=temp->next;}
     
     temp->next=new;
     new->next=lst->head;
     lst->head=new;
}

void clist_insert( CList* lst, int idx, int data )
{
  	if(idx>clist_size(lst))
	return;
      CNode* cur;
      cur = (CNode*)malloc(sizeof(CNode));
      CNode* temp;
      int count;
   /*insert is simple unless it is the first or the last one we use prepend and append*/
   cur->data=data;
   
   if(idx==0)
   {
    clist_prepend( lst, data );
   }
   else
   { CNode* temp;
     temp=(CNode*)malloc(sizeof(CNode));
    
     temp=lst->head;
     for(count=0;count<idx-1;  ) 
      {     
       temp=temp->next;
             count++;
      }       
               cur->next=temp->next;
               temp->next=cur;
                                     
   }
    
}

void clist_remove_last( CList* lst )
{
    CNode* cur;
    cur = (CNode*)malloc(sizeof(CNode));
    /*here we remove last and point the before pointer to the first one*/
     if (lst->head->next!=lst->head)
   { cur=lst->head;
    while(cur->next->next!=lst->head)
    {
         cur=cur->next;
    }
    if(cur->next->next==lst->head)
   {
     cur->next=lst->head;      
   }
   }
}

void clist_remove_first( CList* lst )
{/* we need to point the last one to the refreshed first one*/
 if(lst->head->next!=lst->head)
 	{
 	CNode* cur;
 	CNode* temp;
 	temp=lst->head;
 	cur=lst->head;
 	while(cur->next!=lst->head)
 	{
 		cur=cur->next;
 	}
 	cur->next=temp->next;
    lst->head=(lst->head)->next;
    }
}

void clist_remove( CList* lst, int idx )
{
	if(idx>=clist_size(lst))
	return;

    CNode* cur;
    cur = (CNode*)malloc(sizeof(CNode));
    /* It is same as single linked list unless it is remove first or last*/
    cur=lst->head;
    if(idx==0)
    {
    clist_remove_first(lst );
    return;
    }
    int count=0;
        if(idx==1)
    {
    cur->next=cur->next->next;
    return;}
      do  
      {  
       cur=cur->next;
       count++;
      }  while(count<idx-1&&cur!=lst->head);
    cur->next=cur->next->next;     
       
    
  }

void clist_reverse(CList* lst)  
{
	CNode* temp;
	CNode* prev=NULL;
	CNode* cur=lst->head;
	/* While reversing the list we check the pointers*/
do
	{
	  temp=cur->next;
	  cur->next=prev;
	  prev=cur;
	  cur=temp;
	  
	}while(cur->next!=lst->head);
	temp=cur->next;
	temp->next=cur;
	cur->next=prev;
	prev=cur;
	cur=temp;
	
	lst->head=prev;
	
}       
