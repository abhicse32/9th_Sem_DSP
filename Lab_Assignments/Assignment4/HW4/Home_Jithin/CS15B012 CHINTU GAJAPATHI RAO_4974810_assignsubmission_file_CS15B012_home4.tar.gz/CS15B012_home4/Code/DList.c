#include "DList.h"
#include <stdio.h>
#include <limits.h>
#include <stdlib.h>

DNode* dnode_new( int data)
{
	DNode* new;
	new=(DNode*)malloc(sizeof(DNode));
	/*we have 2 pointers to point to NULL*/
	new->data=data;
	new->prev=NULL;
	new->next=NULL;
	return new;
}

DList* dlist_new()
{
	DList* new;
	/*empty double linked list is made */
	new=(DList*)malloc(sizeof(DList));
	new->head=NULL;
	return new;

}

int dlist_size( DList* lst )
{
    int count=0;
    DNode* cur;
    cur = (DNode*)malloc(sizeof(DNode));
    /* the termination conditon and every thing iss same as linked list*/
  if(lst->head!=NULL)
    {  cur=lst->head;
        while(cur!=NULL)
        {         
         count++; 
         cur=cur->next;
        }
    }
    return count;
}

void dlist_print( DList* lst )
{
    DNode* cur=(DNode*)malloc(sizeof(DNode)*1);   
     
 
  cur=lst->head;
        while(cur!=NULL)
        {
                printf("%d ",cur->data);    
         cur=cur->next;
      
        }
     printf("\n");
 
}

int dlist_get( DList* lst, int idx )
{
   DNode* cur;
   cur = (DNode*)malloc(sizeof(DNode));
    if(dlist_size(lst)<idx)
    return -1;    
  cur=lst->head;
   int count=0;
   /* Same as that of normal single linked list*/
        for(count=0;cur!=NULL;count++)
      {
                           
         
         if(count==idx)
         return cur->data;
         cur=cur->next;                       
      }
      
      
      return -1;
        
        
}

void dlist_append( DList* lst, int data )
{
    DNode* cur;
    cur = (DNode*)malloc(sizeof(DNode));
    cur->data=data;
    cur->next=NULL;
    /* The pointer of the appended variable should be done checked carefully*/
    if(lst->head==NULL)
    {lst->head=cur;
     cur->prev==NULL;
    }
else
    { DNode * temp=lst->head;
    while(temp->next!=NULL)
    {
             temp=temp->next;
    }
    temp->next=cur;
    cur->prev=temp;
    cur->next=NULL;
    
    
    }
}

void dlist_prepend( DList* lst, int data )
{
    DNode* temp;    
    temp = (DNode*)malloc(sizeof(DNode));
    /*just NULL the prevv pointer of the prepended element*/
     temp->data=data;
     temp->next=lst->head;
     lst->head=temp;
 	 temp->prev=NULL;    
}

void dlist_insert( DList* lst, int idx, int data )
{
    if(dlist_size(lst)<idx)
    return ;
      DNode* cur;
      cur = (DNode*)malloc(sizeof(DNode));
      DNode* temp;
      int count;
   /*the pointer prev should be done as temp->net->prev and insert the new element*/
   cur->data=data;
   
   if(idx==0)
   {
    cur->next=lst->head;
    lst->head=cur;
    cur->prev=NULL;
    return;
   }
   else if (idx<=dlist_size(lst ))
   { DNode* temp;
     temp=(DNode*)malloc(sizeof(DNode));
    
     temp=lst->head;
     for(count=0;count<idx-1;  ) 
      {     
       temp=temp->next;
             count++;
      }       
               cur->next=temp->next;
               temp->next=cur;
               if(cur->next!=NULL)// only one change               
               cur->next->prev=cur;
               cur->prev=temp;
                                     
   }
   else{}
    
}

void dlist_remove_last( DList* lst )
{
    DNode* cur;
    cur = (DNode*)malloc(sizeof(DNode));
     if (lst->head!=NULL)
   { cur=lst->head;
   /* This is simple as LInked list single one just makig cur->next->prev as NULL*/
    while(cur->next->next!=NULL)
    {
         cur=cur->next;
    }
    if(cur->next->next==NULL)
   { cur->next->prev=NULL;
     cur->next=NULL;
           
   }
   }
}

void dlist_remove_first( DList* lst )
{/*Basic pointing the prev to NULL*/
 if(lst->head!=NULL)
    lst->head=(lst->head)->next;
    lst->head->prev=NULL;
}

void dlist_remove( DList* lst, int idx )
{
    if(dlist_size(lst)<=idx)
    return ;
    DNode* cur;
    cur = (DNode*)malloc(sizeof(DNode));
    /* adjust the pointer of the before & the after pointers of the deleting element*/ 
    cur=lst->head;
    if(idx==0)
    {
    lst->head=lst->head->next;
    lst->head->prev=NULL;
    return;
    }
    else {
    int count=0;
    for(count=0;count<idx-1&&cur!=NULL;count++)
        
      {  
       cur=cur->next;
      }
    cur->next=cur->next->next;     
    cur->next->prev=cur;    
    
  }
  }
  
void dlist_reverse(DList* lst)
{
    DNode* temp;
	DNode* prev=NULL;
    DNode* cur=lst->head;
 /* just change the prev and next pointers of every node*/
    while(cur!=NULL)
    {
      temp=cur->next;
      cur->next=prev;
      cur->prev=temp;
      prev=cur;
      cur=temp;
	
	}
	lst->head=prev;
}
