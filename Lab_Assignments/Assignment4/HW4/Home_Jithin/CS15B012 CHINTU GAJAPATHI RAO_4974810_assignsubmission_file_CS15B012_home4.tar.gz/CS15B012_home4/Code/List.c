#include "List.h"
#include <stdio.h>
#include <stdlib.h>

Node* node_new( int data1, int data2)
{
	Node* new;
	new=(Node*)malloc(sizeof(Node));

	new->col_ind=data1;
	new->val=data2;
	new->next=NULL;
	
	return new;
}

LList* llist_new()
{
	LList* lst;
	lst=(LList*)malloc(sizeof(LList));

	lst->head=NULL;
	return lst;	
}

int llist_size( LList* lst )
{
    int count=0;
    Node* cur;
    cur = (Node*)malloc(sizeof(Node));
  if(lst->head!=NULL)
    {  cur=lst->head;
        while(cur!=NULL)
        {         
         count++; 
         cur=cur->next;
        }
    }
    return count;
}

void llist_print( LList* lst )
{
    Node* cur=(Node*)malloc(sizeof(Node)*1);    
  cur=lst->head;
  if(cur==NULL)
  return;
        while(cur!=NULL)
        {  
            
		     printf("%d ",cur->val);     
		     cur=cur->next;		    
        }
     printf("\n");
 
}

Node* llist_get( LList* lst, int idx )
{
   Node* cur;
   cur = (Node*)malloc(sizeof(Node));  
   cur=lst->head;
   int count=0;
        for(count=0;cur!=NULL;count++)
      {
                           
         
         if(count==idx)
         return cur;
         cur=cur->next;                       
      }
      
      
      return NULL;
               
}

void llist_append( LList* lst, int data1,int data2)
{
    Node* cur;
    cur = (Node*)malloc(sizeof(Node));
    cur->col_ind=data1;
    cur->val=data2;
    cur->next=NULL;
    if(lst->head==NULL)
    {lst->head=cur;
    }
else
    { Node * temp=lst->head;
    while(temp->next!=NULL)
    {
             temp=temp->next;
    }
    temp->next=cur;

    }
}

void llist_prepend( LList* lst, int data1, int data2 )
{
    Node* temp;    
    temp = (Node*)malloc(sizeof(Node));
     temp->col_ind=data1;
     temp->val=data2;
     temp->next=lst->head;
     lst->head=temp;
}

void llist_insert( LList* lst, int idx, int data1,int data2 )
{
      Node* cur;
      cur = (Node*)malloc(sizeof(Node));
      Node* temp;
      int count;
   
   cur->col_ind=data1;
   cur->val=data2;
   
   if(idx==0)
   {
    cur->next=lst->head;
    lst->head=cur;
   }
   else
   { Node* temp;
     temp=(Node*)malloc(sizeof(Node));
    
     temp=lst->head;
     for(count=0;count<idx-1;  ) 
      {     
       temp=temp->next;
             count++;
      }       
               cur->next=temp->next;
               temp->next=cur;
                                     
   }
    
}

