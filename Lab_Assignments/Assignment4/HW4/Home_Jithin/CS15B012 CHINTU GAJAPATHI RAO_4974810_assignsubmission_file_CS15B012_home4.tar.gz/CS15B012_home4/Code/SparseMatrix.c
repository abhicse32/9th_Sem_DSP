#include "SparseMatrix.h"
#include <stdlib.h>
#include <stdio.h>
#include <limits.h>
Matrix add(Matrix m1, Matrix m2)
{
	
	int rows=m1.n_rows;
 	Matrix m3;
/* This creates a array of row lists*/
    m3.row_lst=(LList**)malloc(sizeof(LList)*rows);
		  
	int i;
	for(i=1;i<=rows;i++)
		 
	{
		
		m3.row_lst[i]=llist_new();
		
		Node* cur1;
		Node* cur2;
		cur1=(Node*)malloc(sizeof(Node));
		cur2=(Node*)malloc(sizeof(Node));
		cur1=m1.row_lst[i]->head;
		cur2=m2.row_lst[i]->head;	
			
		while(cur1!=NULL&&cur2!=NULL)
		{ /* making rows in each i'th row*/
		  if(cur1->col_ind==cur2->col_ind)
		  {
 	        llist_append(m3.row_lst[i],cur2->col_ind,cur1->val+cur2->val);
	        cur1=cur1->next;
	        cur2=cur2->next;   
		  }
		 else if (cur1->col_ind<cur2->col_ind)
		 {
		 
	        llist_append(m3.row_lst[i],cur1->col_ind,cur1->val);
	        cur1=cur1->next;
	        
		 }	else
		 {
		 
	        llist_append(m3.row_lst[i],cur2->col_ind,cur2->val);
	        cur2=cur2->next;
		 }
		 

		}
 		 while(cur1!=NULL)
		 {
		 
	        llist_append(m3.row_lst[i],cur1->col_ind,cur1->val);
			cur1=cur1->next;
	        
		 }
 		 while(cur2!=NULL)
		 {
		 
	        llist_append(m3.row_lst[i],cur2->col_ind,cur2->val);
			cur2=cur2->next;
	        
		 }		
  	}
  	
 return m3; 	

}


Matrix subtract(Matrix m1, Matrix m2)
{
	
	int rows=m1.n_rows;
 	Matrix m3;
    m3.row_lst=(LList**)malloc(sizeof(LList)*rows);
		  
	int i;
	for(i=1;i<=rows;i++)
		 
	{
		
		m3.row_lst[i]=llist_new();
		
		Node* cur1;
		Node* cur2;
		cur1=(Node*)malloc(sizeof(Node));
		cur2=(Node*)malloc(sizeof(Node));
		cur1=m1.row_lst[i]->head;
		cur2=m2.row_lst[i]->head;	
			
		while(cur1!=NULL&&cur2!=NULL)
		{
		  if(cur1->col_ind==cur2->col_ind)
		  {
 	        llist_append(m3.row_lst[i],cur2->col_ind,cur1->val-cur2->val);
	        cur1=cur1->next;
	        cur2=cur2->next;   
		  }
		 else if (cur1->col_ind<cur2->col_ind)
		 {
		 
	        llist_append(m3.row_lst[i],cur1->col_ind,cur1->val);
	        cur1=cur1->next;
	        
		 }	else
		 {
		 
	        llist_append(m3.row_lst[i],cur2->col_ind,-cur2->val);
	        cur2=cur2->next;
		 }
		 

		}
 		 while(cur1!=NULL)
		 {
		 
	        llist_append(m3.row_lst[i],cur1->col_ind,cur1->val);
			cur1=cur1->next;
	        
		 }
 		 while(cur2!=NULL)
		 {
		 
	        llist_append(m3.row_lst[i],cur2->col_ind,-cur2->val);
			cur2=cur2->next;
	        
		 }		
  	}
  	
 return m3; 	

}

Matrix matrix_vect_multiply(Matrix mat, Matrix vect)
{
	int rows=mat.n_rows;
 	Matrix m3;
    m3.row_lst=(LList**)malloc(sizeof(LList)*rows);
/* we should first caluclate the sum and append it to the result list*/
	int i;
	for(i=1;i<=rows;i++)
		{
	   	  m3.row_lst[i]=llist_new();
	   	  Node* cur1;
	   	  cur1=(Node*)malloc(sizeof(Node));
		  cur1=mat.row_lst[i]->head;
		  int sum=0;int j=1;
		  while(cur1!=NULL)
		  {
		  	int lines=vect.n_rows;
		  	sum=sum+(cur1->val*(vect.row_lst[cur1->col_ind]->head->val));
			cur1=cur1->next;
			
		  }  
		  llist_append(m3.row_lst[i],1,sum);
		  
		}
		
return m3;
}
