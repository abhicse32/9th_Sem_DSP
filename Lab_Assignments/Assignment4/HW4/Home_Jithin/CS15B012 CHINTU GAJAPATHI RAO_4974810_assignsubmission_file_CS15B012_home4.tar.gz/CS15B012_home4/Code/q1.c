#include "List.h"
#include "SparseMatrix.h"
#include <stdlib.h>
#include <stdio.h>

int main()
{	

	
	int opn;
	
	scanf("%d",&opn);
while(opn!=-1)
{	
	switch(opn)
	{
		case 1:
		case 2:
				{
				Matrix m1;
				Matrix m2;
				Matrix m3;
				int hor;
				int col;
				scanf("%d %d",&hor,&col);
				
				m1.row_lst=(LList**)malloc(sizeof(LList)*hor);
				m2.row_lst=(LList**)malloc(sizeof(LList)*hor);
				m3.row_lst=(LList**)malloc(sizeof(LList)*hor);
				
				int i;
				/*reading first list of Sparse matrix elements*/
				for(i=1;i<=hor;i++)
				{
					m1.row_lst[i]=llist_new();
					m1.n_rows=hor;
					int j;
					
					for(j=1;j<=col;j++)
					{
					int x;
					scanf("%d",&x);
					if(x!=0)
				      { 
					    llist_append(m1.row_lst[i],j,x);
					    
					  }
					  
					}
					
				}
				/* reading the secound list of SparseMatrix elements*/
				for(i=1;i<=hor;i++)
				{
					m2.row_lst[i]=llist_new();
					m2.n_rows=hor;
					int j;
					
					for(j=1;j<=col;j++)
					{
					int x;
					scanf("%d",&x);
					if(x!=0)
				      {
					    llist_append(m2.row_lst[i],j,x);
					  }
					 
					}
					
				}	
			   if (opn==1)
				{
				 m3=add(m1,m2);
				for(i=1;i<=hor;i++)
				 {
				 llist_print(m3.row_lst[i]);
				 }
				 break;
		    	}
			   if (opn==2)
				{
				 m3=subtract(m1,m2);
				 for(i=1;i<=hor;i++)
				 {
				 llist_print(m3.row_lst[i]);
				 }
				 
				 break;
		    	}
		   }
	case 3:
	 		{	Matrix m1;
				Matrix m2;
				Matrix m3;
				int hor;
				int col;
				scanf("%d %d",&hor,&col);
				
				m1.row_lst=(LList**)malloc(sizeof(LList)*hor);
				m2.row_lst=(LList**)malloc(sizeof(LList)*col);
				m3.row_lst=(LList**)malloc(sizeof(LList)*col);
				
				int i;
				/*reading first list of Sparse matrix elements*/
				for(i=1;i<=hor;i++)
				{
					m1.row_lst[i]=llist_new();
					m1.n_rows=hor;
					int j;
					
					for(j=1;j<=col;j++)
					{
					int x;
					scanf("%d",&x);
					if(x!=0)
				      { 
					    llist_append(m1.row_lst[i],j,x);
					    
					  }
					  
					}
			    }
			    for(i=1;i<=col;i++)
			    {
			    	m2.row_lst[i]=llist_new();
					m2.n_rows=hor;
					int x;
					scanf("%d",&x);
					llist_append(m2.row_lst[i],1,x);
			    }
			    m3=matrix_vect_multiply(m1,m2);
			     for(i=1;i<=hor;i++)
				 {
				 llist_print(m3.row_lst[i]);
				 
				 }
				 break;
			 }   			
	}
	scanf("%d",&opn);
	
} 	
}
