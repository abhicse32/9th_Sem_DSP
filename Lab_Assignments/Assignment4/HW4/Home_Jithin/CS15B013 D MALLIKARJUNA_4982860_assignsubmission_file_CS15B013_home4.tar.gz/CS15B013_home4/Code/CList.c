//CS15B013

#include "CList.h"
#include<limits.h>
#include<stdlib.h>
#include<stdio.h>

CNode* cnode_new( int data)
 {
  CNode * new =(CNode *)malloc(sizeof(CNode*));
  new->data=data;
  new->next=NULL;
 
  return new;
 }
 
CList* clist_new()
 {
  CList * new=(CList *)malloc(sizeof(CList*));
  new->head=NULL;
  return new; 
 } 
 
 
int clist_size( CList* lst )
 {
  CNode * new=lst->head;
  if(new==NULL)
    return 0;
  int size=1;  
  while(new->next!=lst->head)   //condition for last node
    {
     size++;
     new=new->next;
    }
  return size;    
  
 } 
 
void clist_print( CList* lst )
 {
  CNode * new=lst->head;
  if(lst->head==NULL)
    return;
  printf("%d ",new->data);
    
  while(new->next!=lst->head)
   {
    new=new->next;
    printf("%d ",new->data); 
   
   }
  printf("\n");
 }

int clist_get( CList* lst, int idx )
 {
  CNode * new=lst->head;
  int i=0;  
  for(;i<idx && new->next!=lst->head;i++)
   {
    new=new->next;
   }
   
  if(i==idx && lst->head!=NULL)  //checking if index is out of bound
    return new->data;
  else
    return -1;  
 }

void clist_append( CList* lst, int data )
 {
  CNode * new=lst->head;
  CNode * elem=cnode_new(data);
  
  if(lst->head==NULL)           //base case
    {
     lst->head=elem;
     elem->next=elem;
     return;
    }
    
  while(new->next!=lst->head)
   {
    new=new->next; 
   }
  
  elem->next=new->next;  
  new->next=elem;  
 }


void clist_prepend( CList* lst, int data )
 {  CNode * new=lst->head; 
  CNode * elem=cnode_new(data);
  if(lst->head==NULL)           
   {
    elem->next=elem;
    lst->head=elem;return;
   }
   
  while(new->next!=lst->head)  
     new=new->next; 
  
  elem->next=lst->head;    //changing the next value of last node
  lst->head=elem;
  new->next=elem;
 }
 
void clist_insert( CList* lst, int idx, int data )
 {
  int i=0;
  CNode * elem=cnode_new(data);
  CNode * new=lst->head;
  
  if(idx==0)
   {
    clist_prepend(lst,data);return;
   }
  
  for(;i<idx-1 && new->next!=lst->head;i++)
    new=new->next;
  if(i==idx-1)                     //index of new=idx-1
  {elem->next=new->next;
  new->next=elem;}  
 } 

void clist_remove_last( CList* lst )
 {
    CNode * new=lst->head;
   if(lst->head==NULL)
     return;
   if(new->next==lst->head)
     {lst->head=NULL;return;  
     }
     
   while(new->next->next!=lst->head)
     new=new->next;
     
   new->next=lst->head;     
 
 }

void clist_remove_first( CList* lst )
 {    CNode * new=lst->head;
  if(lst->head==NULL)
    return;
  if(new->next==lst->head)
    {lst->head=NULL;return;  
    }
    
  while(new->next!=lst->head)
    new=new->next;    
    
  lst->head=lst->head->next;
  
  new->next=lst->head;
 }

void clist_remove( CList* lst, int idx )
 {
  CNode * new=lst->head;
  if(lst->head==NULL)
    return;
  int i=0;
  if(idx==0)
    clist_remove_first(lst);
    
  for(;i<idx-1 && new->next!=lst->head;i++)
    {
     new=new->next;
    }
  if(i==idx-1 && new->next!=lst->head)
  new->next=new->next->next;
    
 }

void clist_reverse(CList* lst)
{
   CNode * front=lst->head->next;
   CNode * cur=lst->head;
   CNode * prev=lst->head;

   if(lst->head==NULL)
     return;
   if(front==lst->head)
     {
      return;
     }  
     
   while(front->next!=lst->head)
    {
     prev=cur;
     cur=front;
     front=cur->next;
     cur->next=prev;
    }
   front->next=cur;
   lst->head->next=front;
   lst->head=front;
}

