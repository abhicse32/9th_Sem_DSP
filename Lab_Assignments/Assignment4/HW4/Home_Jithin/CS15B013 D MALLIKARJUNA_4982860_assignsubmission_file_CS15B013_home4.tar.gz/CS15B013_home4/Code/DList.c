//CS15B013

#include "DList.h"
#include<stdio.h>
#include<stdlib.h>
#include<limits.h>

DNode* dnode_new( int data)
 {
  DNode * new=(DNode *)malloc(sizeof(DNode *));
  new->data=data;
  new->next=NULL;                               //assign to a pointer
  new->prev=NULL;
  return new; 
 
 }

DList* dlist_new()
 {
   DList * new=(DList *)malloc(sizeof(DList *)); //assigning address
   new->head=NULL;
   return new;
 
 }

int dlist_size( DList* lst )
 {
   int size=0;

   DNode * new=lst->head;
   
   while(new!=NULL)
    {
     size++;
     new=new->next;
    }
    return size; 
 }

void dlist_print( DList* lst )
 {
    DNode * new=lst->head;  
    while(new!=NULL)             //base case
     {
      printf("%d ",new->data);
      new=new->next;
     } 
     if(lst->head!=NULL)
      printf("\n");  
 
 }
 
int dlist_get( DList* lst, int idx )
 {
   DNode * new=lst->head;
   int i=0;
   
   for(;i<idx && new!=NULL;i++)
    {
     new=new->next;
    }
   
  if(i==idx && lst->head!=NULL)  //condition for index
     return new->data;
  else
     return -1;
 }

void dlist_append( DList* lst, int data )
 {  DNode * elem=dnode_new(data);
    DNode * new=lst->head;
 
    if(new==NULL)               //appending to empty list
      {
       lst->head=elem;
       elem->prev=NULL;return;
      }
    
    while(new->next!=NULL)      //exits at last node
     {
      new=new->next;
     }  
 
    new->next=elem;
    elem->prev=new;
 }

void dlist_prepend( DList* lst, int data )
 {
      DNode * elem=dnode_new(data);
    DNode * new=lst->head;
 
    if(new==NULL)
      {
       lst->head=elem;
       elem->prev=NULL;return;
      }
 
    elem->next=lst->head;      
    elem->prev=NULL;
    lst->head->prev=elem;
    lst->head=elem;
    
 }

void dlist_insert( DList* lst, int idx, int data )
 {  
    DNode * elem=dnode_new(data);
    DNode * new=lst->head;
  
    if(idx==0)
      {dlist_prepend(lst,data);return;}
    if(new==NULL)
     {
      if(idx!=0)
        return;
     }
      
    int i=0;  
    for(i=0;i<idx && new->next!=NULL;i++)//new is the pointer of idx index after looping
    {
     new=new->next;
    }
      
   if(i==idx)
    {
     elem->next=new;
     elem->prev=new->prev;
     new->prev->next=elem;
     new->prev=elem;
    }
   if(i==idx-1)
   {
    new->next=elem;
    elem->prev=new;
   } 
 }

void dlist_remove_last( DList* lst )
 {
  
    DNode * new=lst->head; 
 
    if(new==NULL)
      return;
    if(new->next==NULL)
      {
       lst->head=NULL;
       return;
      }  
      
    while(new->next!=NULL)  
         new=new->next;
 
    new->prev->next=NULL;     //removing last element
 } 

void dlist_remove_first( DList* lst )
 {
 
    DNode * new=lst->head; 
 
    if(new==NULL)
      return;
      
    if(new->next==NULL)
    {  lst->head=NULL;
      return; 
    }
    
    lst->head->next->prev=NULL;   //removing the element
    lst->head=lst->head->next;    
 }

void dlist_remove( DList* lst, int idx )
 {
 
    DNode * new=lst->head;   
    int i=0;
    if(idx==0)
    {  dlist_remove_first(lst);
     return; 
    }
    if(new==NULL)
      return;
      
    for(;i<idx-1 && new->next!=NULL;i++)
     {
      new=new->next;
     }  
    if(new->next==NULL) 
     return; 

    if(i==idx-1 && new->next->next!=NULL)
     {
      new->next->next->prev=new;
      new->next=new->next->next;
     }
    if(i==idx-1 && new->next->next==NULL)
     {
      new->next=NULL;

     } 
 }


void dlist_reverse(DList* lst)
 {
  
    DNode * new=lst->head;   
    DNode * temp;
    if(new==NULL || new->next==NULL)
      return;
   while(new!=NULL)
   {
    temp=new->prev;
    new->prev=new->next;     //swapping next and prev pointers
    new->next=temp;
    new=new->prev;
   }
   
   lst->head=temp->prev;
 }
















