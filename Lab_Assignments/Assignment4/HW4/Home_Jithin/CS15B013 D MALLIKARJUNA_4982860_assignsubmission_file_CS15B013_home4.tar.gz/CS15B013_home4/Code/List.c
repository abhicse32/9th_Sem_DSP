//CS15B013

#include "List.h"
#include<stdio.h>
#include<stdlib.h>
#include<limits.h>



Node* node_new( int data1, int data2)
 {
  Node * new=(Node *)malloc(sizeof(Node *));
  new->col_ind=data1;
  new->val=data2;
  return new;
 }
 
 LList* llist_new()
  {
   LList * new=(LList *)malloc(sizeof(LList *));  //memory allocation
   new->head=NULL;
   return new;
  }
  
 int llist_size( LList* lst ) 
  {
   int size=0;

   Node * new=lst->head;
   
   while(new!=NULL)                    //stops at last node
    {
     size++;
     new=new->next;
    }
    return size;
  }
  
  void llist_print( LList* lst)
   {
    Node * new=lst->head;  
    while(new!=NULL)
     {
      printf("%d",new->val);
      new=new->next;
     }
    if(lst->head!=NULL)
      printf("\n"); 
   }
   
   
  Node* llist_get( LList* lst, int idx ) 
   {
    Node* new=lst->head;
    int i=0;
    while(new!=NULL & i<idx)  //stop after idx iterations
      {
       new=new->next;
       i++;
      }
    if(new!=NULL)
      return new;
    else
      return NULL;    
   
   }
   
   void llist_append( LList* lst, int a, int b)
    {     Node * elem=node_new(a,b);
     Node * new=lst->head;
     if(new==NULL)              //base case
       {
        lst->head=elem;
        return;
       } 
       
     while(new->next!=NULL)
         new=new->next;
         

     
     new->next=elem;    
    }
    
   void llist_prepend( LList* lst, int a, int b)
    {Node * new=lst->head;
    
     Node * elem=node_new(a,b);
     
     elem->next=lst->head;
     lst->head=elem;  
      
    }
   
   void llist_insert( LList* lst, int idx, int a, int b)   
    {
     Node* elem=node_new(a,b);
     Node * new=lst->head;
     int i=0;
     if(idx==0)                   //base case
       {
        elem->next=new;
        lst->head=elem;
        return;
       }
       
     while(i<idx-1 && new!=NULL)
      {
       new=new->next;
       i++;
      }   
    
     if(new!=NULL)
       {
        elem->next=new->next;   //inserting element
        new->next=elem;
       }
    
    }
   
   
   
 
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
  
