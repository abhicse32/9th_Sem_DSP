//cs15b013

#include "SparseMatrix.h"
#include"List.h"
#include<stdlib.h>
#include<stdio.h>

Matrix add(Matrix mata, Matrix matb)
 {int i;
  Matrix result;
  int rows=mata.n_rows;
  result.n_rows=rows;
  result.row_lst=(LList **)malloc(sizeof(LList **)*rows);  //memory allocation
  LList * currowa;LList * currowb;
  Node * curnodea;Node * curnodeb;
  LList * resrow;
  
  for(i=0;i<rows;i++)
  {
   currowa=mata.row_lst[i];
   currowb=matb.row_lst[i];
   curnodea=currowa->head;
   curnodeb=currowb->head;
   result.row_lst[i]=(LList *)malloc(sizeof(LList *));  //allocating address
   resrow=result.row_lst[i];
   resrow->head=NULL;
  
   while(curnodea!=NULL && curnodeb!=NULL)
    {
     if(curnodea->col_ind < curnodeb->col_ind)              //condition for lesser exponent value
      {
       llist_append(resrow,curnodea->col_ind,curnodea->val); //appending the value 
       curnodea=curnodea->next;
      }
     else
      if(curnodea->col_ind > curnodeb->col_ind) 
        {
       llist_append(resrow,curnodeb->col_ind,curnodeb->val);
       curnodeb=curnodeb->next;
        }
      else
       {
       
       llist_append(resrow,curnodea->col_ind,(curnodea->val+curnodeb->val));
       curnodea=curnodea->next;
       curnodeb=curnodeb->next;
       }  
    }
    
   while(curnodea!=NULL)
    {
       llist_append(resrow,curnodea->col_ind,curnodea->val);
       curnodea=curnodea->next;     
    } 
    while(curnodeb!=NULL)
    {
       llist_append(resrow,curnodeb->col_ind,curnodeb->val);
       curnodeb=curnodeb->next;     
    }  
  

   } 
  return result;
 
 }
 
 
 
Matrix subtract(Matrix mata, Matrix matb)
 {int i;
  Matrix result;
  int rows=mata.n_rows;
  result.row_lst=(LList **)malloc(sizeof(LList **)*rows);      //memory allocation
  result.n_rows=rows;
  LList * currowa;LList * currowb;
  Node * curnodea;Node * curnodeb;
  LList * resrow;
  
  for(i=0;i<rows;i++)
  {
   currowa=mata.row_lst[i];
   currowb=matb.row_lst[i];
   curnodea=currowa->head;
   curnodeb=currowb->head;
   result.row_lst[i]=(LList *)malloc(sizeof(LList *));        //allocating address
   resrow=result.row_lst[i];
   resrow->head=NULL;
   while(curnodea!=NULL && curnodeb!=NULL)
    {
     if(curnodea->col_ind < curnodeb->col_ind)                //condition for lesser exponent value
      {
       llist_append(resrow,curnodea->col_ind,curnodea->val);
       curnodea=curnodea->next;
      }
     else
      if(curnodea->col_ind > curnodeb->col_ind) 
        {
       llist_append(resrow,curnodeb->col_ind,-curnodeb->val);
       curnodeb=curnodeb->next;
        }
      else
       {
        
       llist_append(resrow,curnodea->col_ind,curnodea->val-curnodeb->val);
       curnodea=curnodea->next;
       curnodeb=curnodeb->next;
       }  
    }
    
   while(curnodea!=NULL)
    {
       llist_append(resrow,curnodea->col_ind,curnodea->val);
       curnodea=curnodea->next;     
    } 
    while(curnodeb!=NULL)
    {
       llist_append(resrow,curnodeb->col_ind,-curnodeb->val);
       curnodeb=curnodeb->next;     
    }  
  

   } 
  return result;
 
 } 
 
 
 
 
 
 Matrix matrix_vect_multiply(Matrix mat,Matrix vect)
  {int i,j,sum;
   Matrix result;
  int rows=mat.n_rows;
  result.row_lst=(LList **)malloc(sizeof(LList **)*rows);   //memory allocation
  result.n_rows=rows;
  LList * currow;LList * vectl;
  Node * curnode;Node * vectnode; 
  LList * resrow;
  for(i=0;i<rows;i++)
  {
   result.row_lst[i]=(LList *)malloc(sizeof(LList *));      //allocating address
   resrow=result.row_lst[i];
   resrow->head=NULL;
   currow=mat.row_lst[i];
   curnode=currow->head;
   sum=0;
   for(j=0;vect.row_lst[j]!=NULL;j++)
    {
     vectl=vect.row_lst[j];
     vectnode=vectl->head;curnode=currow->head;
     if(vectnode!=NULL)
      {
       while(curnode!=NULL && curnode->col_ind <= j  )
          {
           if(curnode->col_ind==j)
             {
              sum=sum+vectnode->val * curnode->val;
              curnode=curnode->next;
             }
           else
             curnode=curnode->next;  
          }
      }
    }
  
   llist_append(resrow,0,sum);
   }
   return result;
  
  }
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 





