#include "SparseMatrix.h"
#include"List.h"
#include<stdio.h>
#include<stdlib.h>
void printmat(Matrix * result,int col);


int main()
{int m,n,opt,i,j,num;
 Matrix mata,matb;
 Matrix result;
 LList * currow;
 int *p;
 scanf("%d",&opt);
 
 while(opt!=-1)
 {switch(opt)
   {
     case 1:scanf("%d %d",&m,&n);
            p=(int*)malloc(sizeof(int*));
     
            mata.n_rows=m;
            mata.row_lst=(LList **)malloc(sizeof(LList **)*m);
            
            for(i=0;i<m;i++)
             {
              mata.row_lst[i]=(LList *)malloc(sizeof(LList *));   
               currow=mata.row_lst[i];
               currow->head=NULL;
             
             for(j=0;j<n;j++)
              {
               
               scanf("%d",&num);
               if(num!=0)
                 {
                  llist_append(currow,j,num);       //initialising 1st matrix
                  
                 }
              } 
             }
             
             matb.row_lst=(LList **)malloc(sizeof(LList **)*m);
             
              matb.n_rows=m;            
            for(i=0;i<m;i++)
             {
              matb.row_lst[i]=(LList *)malloc(sizeof(LList *));

               currow=matb.row_lst[i];
               currow->head=NULL;
             
             for(j=0;j<n;j++)
              {
               
               scanf("%d",&num);
               if(num!=0)
                 {
                  llist_append(currow,j,num);  //initialising 2st matrix
                 
                 }
              }   

             }   
             
                      
            result =add(mata,matb);            //function call
            printmat(&result,n);
            scanf("%d",&opt);
           
            break; 
            
            
     case 2:scanf("%d %d",&m,&n);
            
            mata.n_rows=m;
            mata.row_lst=(LList **)malloc(sizeof(LList **)*m);
            
            for(i=0;i<m;i++)
             {
              mata.row_lst[i]=(LList *)malloc(sizeof(LList *));
               currow=mata.row_lst[i];
               currow->head=NULL;
             
             for(j=0;j<n;j++)
              {
               
               scanf("%d",&num);
               if(num!=0)
                 {
                  llist_append(currow,j,num);
                 
                 }
              }   

             }
             
             matb.row_lst=(LList **)malloc(sizeof(LList **)*m);
              
              matb.n_rows=m;            
            for(i=0;i<m;i++)
             {
              matb.row_lst[i]=(LList *)malloc(sizeof(LList *));

               currow=matb.row_lst[i];
               currow->head=NULL;
             
             for(j=0;j<n;j++)
              {
               
               scanf("%d",&num);
               if(num!=0)
                 {
                  llist_append(currow,j,num);
                 
                 }
              }   

             }            
            result =subtract(mata,matb); 
            printmat(&result,n);
            scanf("%d",&opt);
            break;             
            
     case 3:scanf("%d %d",&m,&n);
            
            mata.n_rows=m;
            mata.row_lst=(LList **)malloc(sizeof(LList **)*m);
           
            for(i=0;i<m;i++)
             {
              mata.row_lst[i]=(LList *)malloc(sizeof(LList *));
               currow=mata.row_lst[i];
               currow->head=NULL;
             
             for(j=0;j<n;j++)
              {
               
               scanf("%d",&num);
               if(num!=0)
                 {
                  llist_append(currow,j,num);
                 
                 }
              }   

             }
             matb.row_lst=(LList **)malloc(sizeof(LList **)*(n+1));
            
              matb.n_rows=n;            
           for(i=0;i<n;i++)
             {
              matb.row_lst[i]=(LList *)malloc(sizeof(LList *));

               currow=matb.row_lst[i];
               currow->head=NULL;
             
             for(j=0;j<1;j++)
              {
               
               scanf("%d",&num);
               if(num!=0)
                 {
                  llist_append(currow,j,num);   //initialising a column
                 
                 }
              }   

             }  
           matb.row_lst[i]=NULL;               
           result=matrix_vect_multiply(mata,matb);     
                    
           printmat(&result,1);
           scanf("%d",&opt);
           break;
           
           
   }
 }return 0; 
}


void printmat(Matrix * result,int col)
 {int i,j;
  int rows=result->n_rows;
  LList * currow;
  Node * elem;
  for(i=0;i<rows;i++)
   {
    currow=result->row_lst[i];
    elem=currow->head;
    for(j=0;j<col;j++)
     {
      if(elem!=NULL && elem->col_ind==j)
        {printf("%d ",elem->val);
         elem=elem->next;
        }
      //else
        //printf("0 ");
     
     }
    if(currow->head!=NULL)
    printf("\n");
   }

 
 
 
 }
















