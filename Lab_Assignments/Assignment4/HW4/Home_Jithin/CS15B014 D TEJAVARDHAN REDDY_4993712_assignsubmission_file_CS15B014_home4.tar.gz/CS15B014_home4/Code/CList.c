/*D Teja vardhan  CS15B014   5/9/16 */
/*FUNCTIONS WHICH HELP IN  IMPLEMENTATIONS INVOLVING CIRCULAR LINKED LISTS*/
#include "CList.h"
#include<stdio.h>
#include<stdlib.h>



// creates new node
CNode* cnode_new( int data){
	CNode *start;
	start=(CNode*)malloc(sizeof(CNode));
	start->data=data;
	start->next=NULL;
	return start;

}


// to create new list
CList* clist_new(){
	CList*lst=(CList*)malloc(sizeof(CList));
	lst->head=NULL;
	return lst;
}


// to find size of list
int clist_size( CList* lst ){
	int i=1;
	CNode*next=lst->head;
	if(next==NULL)
		return 0;
	next=next->next;
	while(next!=(lst->head)){
		i++;
		next=next->next;
	}
	return i;
}



//to print elements of list
void clist_print( CList* lst ){
	CNode*next=lst->head;
	if(next==NULL)
		return;
	printf("%d ",next->data);
	next=next->next;
	while(next!=lst->head){
		printf("%d ",next->data);
		next=next->next;
	}
	printf("\n");
}



//to get element at idx in list
int clist_get( CList* lst, int idx ){
	CNode*next=lst->head;
	if(next==NULL)
		return -1;
	if(idx==0)
		return next->data;
	int i=1;
	next=next->next;
	while(i!=idx && next!=lst->head){
		
		i++;
		next=next->next;
	}
	if(i==idx && next!=NULL)
		return next->data;
	else
		return -1;
}



//to append element to the list

void clist_append( CList* lst, int data ){
	CNode*node= cnode_new( data);
	CNode*next=lst->head;
	CNode*next1;
	next1=lst->head;
	node->next=lst->head;
	if(next==NULL){
		lst->head=node;
		node->next=node;
		return ;
	}
	next=next->next;
	while(next!=lst->head){
		next1=next;
		next=next->next;
	}
	
	next1->next=node;
}

// to prepend element to the list
void clist_prepend( CList* lst, int data ){
	
	CNode*node= cnode_new( data);
	node->next=lst->head;
	lst->head=node;
	if(node->next==NULL)
	{
		node->next=node;
		return;
	}
	CNode*next=lst->head;
	next=next->next;
	CNode*next1=next;
	next=next->next;
	while(next!=node->next){
		next1=next;
		next=next->next;
	}
	next1->next=lst->head;
}



// to insert element at idx in list
void clist_insert( CList* lst, int idx, int data ){
	if(idx==0){
		clist_prepend(  lst, data );
		return;
	}

	CNode*node= cnode_new( data);
	CNode*next1;
	CNode*next=lst->head;
	int i=1;
	next1=next;
	next=next->next;
	while(i!=idx && next!=lst->head ){
		
		i++;
		next1=next;
		next=next->next;
		
	}
	node->next=next;
	
	
	 if(idx==i)
		next1->next=node;
}



//to remove last element of the list
void clist_remove_last( CList* lst ){
	CNode*next=lst->head;
	CNode*next1,*next2;

	if(lst->head!=NULL){
		next2=lst->head;
		next=next->next;
		next1=next;
		if(next==lst->head)
			{
				lst->head=NULL;
				return ;
			}
		
		while(next!=lst->head){
			next2=next1;
			next1=next;
			next=next->next;
			
		}
		next2->next=lst->head;
	}
}



//to remove first element of the list 
void clist_remove_first( CList* lst ){
	if(lst->head==NULL)
		return;
	CNode*next=lst->head;
	if(lst->head==next->next)
	{
		lst->head=NULL;
		return;
	}
	lst->head=next->next;
	CNode*next1=lst->head,*next2;
	while(next1!=next){
		next2=next1;
		next1=next1->next;
	}
	next2->next=lst->head;
}



//to remove element at idx from list
void clist_remove( CList* lst, int idx ){
	if(lst->head==NULL)
		return;
	if(idx==0){
		clist_remove_first(  lst );
		return;
	}
	int i=0;

	CNode*next=lst->head;
	CNode*next1,*next2;
	next2=lst->head;
	if(lst->head!=NULL){
		
		next=next->next;
		next1=next;
		
		next=next->next;
		//next2=next;
		i++;
		while(i!=idx && next!=lst->head){
			next2=next1;
			next1=next;
			next=next->next;
			i++;
			
		}
		if(i==idx)
			next2->next=next;
		
	}
}



// to reverse elements in the list
void clist_reverse(CList*lst){
	CNode*next=lst->head;
	if(next==NULL)
		return;
	int data=(lst->head)->data;
	clist_remove_first(lst);
	clist_reverse(lst);
	clist_append(lst,data);
	return ;
}