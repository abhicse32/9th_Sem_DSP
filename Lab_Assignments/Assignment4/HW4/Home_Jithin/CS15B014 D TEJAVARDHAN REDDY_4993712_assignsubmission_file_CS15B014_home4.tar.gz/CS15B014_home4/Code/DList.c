/*D Teja vardhan  CS15B014   5/9/16 */
/*FUNCTIONS WHICH HELP IN  IMPLEMENTATIONS INVOLVING DOUBLY LINKED LISTS*/
#include "DList.h"
#include<stdio.h>
#include<stdlib.h>
#include<limits.h>
// creates new node
DNode* dnode_new( int data){
	DNode *start;
	start=(DNode*)malloc(sizeof(DNode));
	start->data=data;
	start->next=NULL;
	start->prev=NULL;
	return start;
}
// to create new list
DList* dlist_new(){
	DList*lst=(DList*)malloc(sizeof(DList));
	lst->head=NULL;
	return lst;
}
// to find size of list
int dlist_size( DList* lst ){
	int i=0;
	DNode*next=lst->head;
	while(next!=NULL){
		i++;
		next=next->next;
	}
	return i;
}
//to print elements of list
void dlist_print( DList* lst ){
	DNode*next=lst->head;
	while(next!=NULL){
		printf("%d ",next->data);
		next=next->next;
	}
	printf("\n");
	fflush(stdout);
}


//to get element at idx in list
int dlist_get( DList* lst, int idx ){
	DNode*next=lst->head;
	int i=0;
	while(i!=idx && next!=NULL){
		
		i++;
		next=next->next;
	}
	if(i==idx && next!=NULL)
		return next->data;
	else
		return -1;
}


//to append element to the list

void dlist_append( DList* lst, int data ){
	DNode*node= dnode_new( data);
	DNode*next=lst->head;
	DNode*next1;
	next1=lst->head;
	if(next==NULL){
		lst->head=node;
		return ;
	}
	while(next!=NULL){
		next1=next;
		next=next->next;
	}
	
	next1->next=node;

	node->prev=next1;
}


// to prepend element to the list
void dlist_prepend( DList* lst, int data ){
	DNode*node= dnode_new( data);

	node->next=lst->head;
	lst->head=node;
	//node->prev=NULL;
	if(node->next!=NULL)
	(node->next)->prev=node;
}


// to insert element at idx in list
void dlist_insert( DList* lst, int idx, int data )
{
	DNode*node= dnode_new( data);
	DNode*next1=NULL;
	DNode*next=lst->head;
	int i=0;
	while(i!=idx && next!=NULL ){
		
		i++;
		next1=next;
		next=next->next;
		
	}
	node->next=next;
	node->prev=next1;
	
	if(idx==0){
		lst->head=node;
		
	}
	else if(idx==i)
		next1->next=node;
	if(node->next!=NULL)
		(node->next)->prev=node;
}


//to remove last element of the list
void dlist_remove_last( DList* lst ){
	DNode*next=lst->head;
	DNode*next1=NULL;
	if(lst->head!=NULL){
		next1=next;
		next=next->next;
		
		if(next==NULL)
			{
				lst->head=NULL;
				return ;
			}
		
		while(next!=NULL){
			
			next1=next;
			next=next->next;
			
		}
		(next1->prev)->next=NULL;
	}
}

//to remove first element of the list 
void dlist_remove_first( DList* lst ){
	DNode*node=lst->head;
	if(node==NULL)
		return;

	lst->head=node->next;
	if(lst->head!=NULL)
		(lst->head)->prev=NULL;
}


//to remove element at idx from list
void dlist_remove( DList* lst, int idx ){
	DNode*next=lst->head,*next1=NULL;
	int i=0;
	if(next==NULL)
		return;
	if(idx==0){
		dlist_remove_first( lst );
		return;
	}
	while(i!=idx && next!=NULL){
		i++;
		next1=next;
		next=next->next;
	}
	if(i==idx && next!=NULL){
		next1->next=next->next;
		(next->next)->prev=next1;
	}
	return;
}


// to reverse elements in the list
void dlist_reverse(DList*lst){
	DNode*next=lst->head;
	if(next==NULL)
		return;
	int data=next->data;
	dlist_remove_first(lst);
	dlist_reverse(lst);
	dlist_append(lst,data);
	return ;
}


