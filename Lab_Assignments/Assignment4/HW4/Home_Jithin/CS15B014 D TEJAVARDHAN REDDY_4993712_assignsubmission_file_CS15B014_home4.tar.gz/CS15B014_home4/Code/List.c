/*D Teja vardhan  CS15B014   5/9/16 */
/*FUNCTIONS TO HELP IMPLEMENTATION OF SPARSE MATRIX USING LINKED LISTS*/

#include "List.h"
#include<stdio.h>
#include<stdlib.h>

//to create new node
Node* node_new( int data1, int data2){
	Node *start;
	start=(Node*)malloc(sizeof(Node));
	start->col_ind=data1;
	start->val=data2;
	start->next=NULL;
	return start;
}

//to create new list
LList* llist_new(){
	LList *list;
	list=(LList*)malloc(sizeof(LList));
	list->head=NULL;
	return list;
}


//to get list size
int llist_size( LList* lst ){
	int i=0;
	Node*next=lst->head;
	while(next!=NULL){
		i++;
		next=next->next;
	}
	return i;
}


//to print list
void llist_print( LList* lst ){
	
	Node*next=lst->head;
	while(next!=NULL){
		printf("%d ",next->val);
		next=next->next;
	}
	if(llist_size(lst)!=0)
		printf("\n");
	
}

//to get element at index ind
Node*llist_get( LList* lst, int idx ){
	Node*next=lst->head;
	int i=0;
	while(i!=idx && next!=NULL){
		
		i++;
		next=next->next;
	}
	if(i==idx)
		return next;
	else
		return NULL;
	
}	


//to append element to last of list
void llist_append( LList* lst, int data1,int data2 ){
	Node*node= node_new( data1,data2);
	Node*next=lst->head;
	Node*next1;
	next1=lst->head;
	if(next==NULL){
		lst->head=node;
		return ;
	}
	while(next!=NULL){
		next1=next;
		next=next->next;
	}
	
	next1->next=node;
}


// to  prepend element to start of list 
void llist_prepend( LList* lst, int data1, int data2){
	Node*node= node_new( data1,data2);
	node->next=lst->head;
	lst->head=node;

}

// to insert element at idx in list
void llist_insert( LList* lst, int idx, int data1, int data2){
	if(idx==0){
		llist_prepend(  lst, data1,data2 );
		return;
	}

	Node*node= node_new( data1,data2);
	Node*next1;
	Node*next=lst->head;
	int i=0;
	while(i!=idx && next!=NULL ){
		
		i++;
		next1=next;
		next=next->next;
		
	}
	node->next=next;
	if(lst->head!=NULL)
	if(idx==0)
		lst->head=node;
	else if(idx==i)
		next1->next=node;
}