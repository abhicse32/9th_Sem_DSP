/*D Teja vardhan  CS15B014   5/9/16 */
/*FUNCTIONS TO IMPLEMENT DIFFERENT OPERATIONS ON SPARSE MATRIX*/
#include "SparseMatrix.h"
#include<stdio.h>
#include<stdlib.h>



/*Add two matrices*/
Matrix add(Matrix a, Matrix b){
	int m=a.n_rows;
	Matrix c;
	c.row_lst=(LList**)malloc(sizeof(LList*)*(m+1));
	int i=0;
	while(i<m){
		*((c.row_lst)+i)=llist_new();
		LList*lst=*((c.row_lst)+i);

		LList*la=*((a.row_lst)+i);
		LList*lb=*((b.row_lst)+i);
	    Node*next1=la->head;
	    Node*next2=lb->head;
	    
		while(next1!=NULL && next2!=NULL){
			
			if((next1->col_ind)== next2->col_ind){
				llist_append(  lst, next1->col_ind,next1->val + next2->val);
				next1=next1->next;
				next2=next2->next;
			}
			else if(next1->col_ind < next2->col_ind){
				llist_append(  lst, next1->col_ind,next1->val);
				next1=next1->next;
			}
			else if(next1->col_ind > next2->col_ind){
				llist_append(  lst, next2->col_ind,next2->val);
				next2=next2->next;
			}

		}
		if(next1==NULL){
			while(next2!=NULL){
				llist_append(  lst, next2->col_ind,next2->val);
				next2=next2->next;
			}
		}
		if(next2==NULL){
			while(next1!=NULL){
				llist_append(  lst, next1->col_ind,next1->val);
				next1=next1->next;
			}
		}
		i++;
	}
	return c;
}


//multiply matrix with a vector
Matrix matrix_vect_multiply(Matrix a, Matrix b){
	Matrix c;
	int m=a.n_rows;
	c.row_lst=(LList**)malloc(sizeof(LList*)*(m+1));
	int i=0;
	while(i<m){
		int s=0;
		*((c.row_lst)+i)=llist_new();
		LList*lst=(c.row_lst)[i];
		LList*la=*((a.row_lst)+i);
		Node*next1=la->head;
		while(next1!=NULL){
			int num=next1->val;
			int col = next1->col_ind;

			Node*next2=((b.row_lst)[col])->head;
			if(next2!=NULL){
				s+=num*(next2->val);
			
			}
			
				next1=next1->next;
				

		}
		llist_append(  lst,0,s);
		i++;
	}
	return c;
}



// to subtract matrix b from matrix a
Matrix subtract(Matrix a, Matrix b){
	int m=a.n_rows;
	Matrix c;
	c.row_lst=(LList**)malloc(sizeof(LList*)*(m+1));
	int i=0;
	while(i<m){
		*((c.row_lst)+i)=llist_new();
		LList*lst=*((c.row_lst)+i);

		LList*la=*((a.row_lst)+i);
		LList*lb=*((b.row_lst)+i);
	    Node*next1=la->head;
	    Node*next2=lb->head;
	    
		while(next1!=NULL && next2!=NULL){
			
			if((next1->col_ind)== next2->col_ind){
				llist_append(  lst, next1->col_ind,next1->val - next2->val);
				next1=next1->next;
				next2=next2->next;
			}
			else if(next1->col_ind < next2->col_ind){
				llist_append(  lst, next1->col_ind,next1->val);
				next1=next1->next;
			}
			else if(next1->col_ind > next2->col_ind){
				llist_append(  lst, next2->col_ind,-1 * next2->val);
				next2=next2->next;
			}

		}
		if(next1==NULL){
			while(next2!=NULL){
				llist_append(  lst, next2->col_ind,-1 * next2->val);
				next2=next2->next;
			}
		}
		if(next2==NULL){
			while(next1!=NULL){
				llist_append(  lst, next1->col_ind,next1->val);
				next1=next1->next;
			}
		}
		i++;
	}
	return c;
}