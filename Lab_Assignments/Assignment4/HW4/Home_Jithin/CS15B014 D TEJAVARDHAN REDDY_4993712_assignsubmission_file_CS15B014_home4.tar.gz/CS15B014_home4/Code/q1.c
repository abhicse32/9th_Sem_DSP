/*D Teja vardhan  CS15B014   5/9/16 */
/*DRIVER PROGRAM FOR SPARSE MATRIX IMPLEMENATION*/
#include "List.h"
#include"SparseMatrix.h"
#include<stdlib.h>
#include<stdio.h>
int main(){
	int i,n,m,inp;
	scanf("%d",&i);
	while(i!=-1){
		switch(i){
			case 3:{					//MULTIPLICATION
				   Matrix *a=(Matrix*)malloc(sizeof(Matrix));
				  scanf("%d%d",&m,&n);
				  a->n_rows=m;
    			a->row_lst=(LList**)malloc(sizeof(LList*)*(m+1));
    		//	*((a->row_lst)+m)=NULL;
				for (int i = 0; i < m; ++i)
				{
					*((a->row_lst)+i)=llist_new();	
					for (int j = 0; j < n; ++j)
					{
						scanf("%d",&inp);
						if(inp==0)
							continue;
						llist_append(*((a->row_lst)+i),j,inp);
						
					}
				}


				 Matrix *b=(Matrix*)malloc(sizeof(Matrix));
				  

    			b->row_lst=(LList**)malloc(sizeof(LList*)*(n+1));
    			//*((b->row_lst)+m)=NULL;
				for (int i = 0; i < n; ++i)
				{
					*((b->row_lst)+i)=llist_new();	
					for (int j = 0; j < 1; ++j)
					{
						scanf("%d",&inp);
						if(inp==0)
							continue;
						llist_append(*((b->row_lst)+i),j,inp);
						
					}
				}
				Matrix c =	matrix_vect_multiply(*a,*b);
				for (int i = 0; i < m; ++i)
				{
					llist_print( *((c.row_lst)+i));
				}
				break;

			}
			case 1:{								//ADDITION
				 Matrix *a=(Matrix*)malloc(sizeof(Matrix));
				  scanf("%d%d",&m,&n);
				  a->n_rows=m;
    			a->row_lst=(LList**)malloc(sizeof(LList*)*(m+1));
    		//	*((a->row_lst)+m)=NULL;
				for (int i = 0; i < m; ++i)
				{
					*((a->row_lst)+i)=llist_new();	
					for (int j = 0; j < n; ++j)
					{
						scanf("%d",&inp);
						if(inp==0)
							continue;
						llist_append(*((a->row_lst)+i),j,inp);
						
					}
				}


				 Matrix *b=(Matrix*)malloc(sizeof(Matrix));
				  

    			b->row_lst=(LList**)malloc(sizeof(LList*)*(m+1));
    			*((b->row_lst)+m)=NULL;
				for (int i = 0; i < m; ++i)
				{
					*((b->row_lst)+i)=llist_new();	
					for (int j = 0; j < n; ++j)
					{
						scanf("%d",&inp);
						if(inp==0)
							continue;
						llist_append(*((b->row_lst)+i),j,inp);
						
					}
				}
				Matrix c =	add(*a,*b);
				for (int i = 0; i < m; ++i)
				{
					llist_print( *((c.row_lst)+i));
				}
				break;
			}
			case 2:{						//SUBTRACTION
				 Matrix *a=(Matrix*)malloc(sizeof(Matrix));
				  scanf("%d%d",&m,&n);
				  a->n_rows=m;
    			a->row_lst=(LList**)malloc(sizeof(LList*)*(m+1));
    		//	*((a->row_lst)+m)=NULL;
				for (int i = 0; i < m; ++i)
				{
					*((a->row_lst)+i)=llist_new();	
					for (int j = 0; j < n; ++j)
					{
						scanf("%d",&inp);
						if(inp==0)
							continue;
						llist_append(*((a->row_lst)+i),j,inp);
						
					}
				}


				 Matrix *b=(Matrix*)malloc(sizeof(Matrix));
				  

    			b->row_lst=(LList**)malloc(sizeof(LList*)*(m+1));
    			*((b->row_lst)+m)=NULL;
				for (int i = 0; i < m; ++i)
				{
					*((b->row_lst)+i)=llist_new();	
					for (int j = 0; j < n; ++j)
					{
						scanf("%d",&inp);
						if(inp==0)
							continue;
						llist_append(*((b->row_lst)+i),j,inp);
						
					}
				}
				Matrix c =	subtract(*a,*b);
				for (int i = 0; i < m; ++i)
				{
					
					llist_print( *((c.row_lst)+i));
				}
				break;
			}
		}
		scanf("%d",&i);
	}
}