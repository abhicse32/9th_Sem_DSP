/*      Program to implement basic operations on circular linked lists
            G.Pranav        CS15B015        3-9-2016*/

#include "CList.h"
#include<stdio.h>
#include<stdlib.h>


// Create a new node with next set to NULL
CNode* cnode_new( int data){
	CNode *newnodeptr=malloc(sizeof(CNode));
    newnodeptr->data=data;
    newnodeptr->next=NULL;
    return newnodeptr;
}

// Create an empty list (head shall be NULL)
CList* clist_new(){
	CList *listptr=malloc(sizeof(CList));
    listptr->head=NULL;
    return listptr;
}

// Traverse the linked list and return its size
int clist_size( CList* lst ){
	CNode *startptr=lst->head;
	if(startptr==NULL){
		return 0;
	}
	else{
		int size=1;
		CNode *nextptr;
		nextptr=startptr->next;
		while(nextptr!=startptr){
			nextptr=nextptr->next;
			size++;
		}
		return size;
	}
}

// Traverse the linked list and print each element
void clist_print( CList* lst ){
	int size=clist_size(lst);
	int i;
	CNode *currptr=lst->head;
	for(i=0;i<size;i++){
		printf("%d ",currptr->data);
		currptr=currptr->next;
	}
	printf("\n");
}

//get the element at position @idx
int clist_get( CList* lst, int idx ){
	int num;
	int size=clist_size(lst);
	if(idx>=size){		//checking whether the given index is present in the linked list
		num=-1;
	}
	else{
		int i;
		CNode *currptr=lst->head;
	    for(i=0;(i<idx);i++){
	        currptr=currptr->next;
	    }
    	num=currptr->data;
	}
	return num;
}

// Add a new element at the end of the list
void clist_append( CList* lst, int data ){
	int size=clist_size(lst);
	CNode *tempptr=lst->head;
	int i;
	for(i=0;i<size-1;i++){
		tempptr=tempptr->next;
	}
	CNode *newptr=cnode_new(data);
	newptr->next=lst->head;
	if(tempptr!=NULL) tempptr->next=newptr;
	else{
		lst->head=newptr;
		newptr->next=lst->head;
	}
}

// Add a new element at the beginning of the list
void clist_prepend( CList* lst, int data ){
	int size=clist_size(lst);
	CNode *newptr=cnode_new(data);
    newptr->next=lst->head;
    lst->head=newptr;
    CNode *tempptr=lst->head;
    int i;
    for(i=0;i<size;i++){
    	tempptr=tempptr->next;
    }
    tempptr->next=lst->head;
}

// Add a new element at the @idx index
void clist_insert( CList* lst, int idx, int data ){
	int a=clist_size(lst);
    int i;
    if(a>idx){			//checking whether the given idx is in the ranges
        if(idx==0){
            clist_prepend(lst,data);
            return;
        }
        CNode *newptr=cnode_new(data);
        CNode *currptr=lst->head;
        CNode *nextptr;
        for(i=0;i<idx-1;i++){
            nextptr=currptr->next;
            currptr=nextptr;
        }
        nextptr=currptr->next;
        newptr->next=nextptr;
        currptr->next=newptr;
    }
    else if(a==idx){		//adding the at the end when idx=size-1
        clist_append(lst,data);
    }
    if(lst->head==NULL) clist_prepend(lst,data);
}

// Remove an element from the end of the list
void clist_remove_last( CList* lst ){
	CNode *currptr=lst->head;
	int size=clist_size(lst);
    if(currptr!=NULL){
        CNode *nextptr=currptr->next;
        if(nextptr==NULL){		//checking whether the list contains more than one element or not
            lst->head=NULL;
            free(currptr);
        }
        else{
            int i;
            for(i=0;i<size-2;i++){
            	currptr=nextptr;
            	nextptr=nextptr->next;
            }
            currptr->next=nextptr->next;
            free(nextptr);
        }
    }
}

// Remove an element from the beginning of the list
void clist_remove_first( CList* lst ){
	int size=clist_size(lst);
	CNode *currptr=lst->head;
    CNode *nextptr;
    if(currptr!=NULL){			
        nextptr=currptr->next;
        if(nextptr==NULL){		//checking whether the list contains more than one element or not
        	free(currptr);
        	lst->head=NULL;
        }
        else{
        	int i;
        	CNode *newptr=lst->head;
        	for(i=0;i<size-1;i++){
        		newptr=newptr->next;
        	}
        	lst->head=nextptr;
        	free(currptr);
        	newptr->next=lst->head;
        }
    }
}

// Remove an element from an arbitrary @idx position in the list
void clist_remove( CList* lst, int idx ){
	int size=clist_size(lst);
    int i;
    if(size>idx){		//checking whether the given index is in range
        if(idx==0){
            clist_remove_first(lst);
        }
        else if(idx==size-1){
        	clist_remove_last(lst);
        }
        else{
            CNode *nextptr=lst->head;
            CNode *currptr=lst->head;
            for(i=0;i<idx-1;i++){
                nextptr=currptr->next;
                currptr=nextptr;

                
            } 
            CNode *tmpptr=nextptr->next;  
            currptr->next=(currptr->next)->next;
            free(tmpptr);
        }
    }
}

// reverse the list
void clist_reverse(CList* lst){
	int size=clist_size(lst);
	if(size>=2){
		int i;
		CNode *a=lst->head;
		CNode *b=a->next;
		CNode *c;
		CNode *d;
		for(i=0;i<=size-2;i++){
			c=b;
			d=b->next;
			b->next=a;
			a=c;
			b=d; 
		}
		((lst->head)->next)=a;
		lst->head=a;
	}	
}