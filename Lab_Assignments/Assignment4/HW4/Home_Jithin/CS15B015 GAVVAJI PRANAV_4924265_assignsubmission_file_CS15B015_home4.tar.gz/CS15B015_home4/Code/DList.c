/*      Program to implement basic operations on doubly linked lists
            G.Pranav        CS15B015        3-9-2016*/

#include "DList.h"
#include<stdio.h>
#include<stdlib.h>

// Create a new node with next set to NULL
DNode* dnode_new( int data){
	DNode *newnodeptr=malloc(sizeof(DNode));
    newnodeptr->data=data;
    newnodeptr->next=NULL;
    return newnodeptr;
}

// Create an empty list (head shall be NULL)
DList* dlist_new(){
	DList *listptr=malloc(sizeof(DList));
    listptr->head=NULL;
    return listptr;
}

// Traverse the linked list and return its size
int dlist_size( DList* lst ){
	int size=0;
    if(lst==NULL) return 0;
    else{
        DNode *currptr=lst->head;
        while((currptr)!=NULL){
            size++;
            currptr=currptr->next;
        }
        return size;
    }
}

// Traverse the linked list and print each element
void dlist_print( DList* lst ){
	DNode *currptr=lst->head;
    while(currptr!=NULL){
        printf("%d ",currptr->data);
        currptr=currptr->next;
    }
    printf("\n");
}

//get the element at position @idx
int dlist_get( DList* lst, int idx ){
	int num;
    int i;
    DNode *currptr=lst->head;
    for(i=0;(i<idx)&&(currptr!=NULL);i++){
        currptr=currptr->next;
    }
    if(currptr==NULL) num=-1;       //checking whether the given index is present in the linked list
    else num=currptr->data;
    return num;
}

// Add a new element at the end of the list
void dlist_append( DList* lst, int data ){
	DNode *currptr=lst->head;
    if(currptr==NULL){
        DNode *newptr=dnode_new(data);
        newptr->prev=NULL;
        lst->head=newptr;
    }
    else{
        DNode *nextptr=currptr->next;
        while(nextptr!=NULL){
            currptr=currptr->next;
            nextptr=currptr->next;
        }
        DNode *newptr=dnode_new(data);
        currptr->next=newptr;
        newptr->prev=currptr;
    }
}

// Add a new element at the beginning of the list
void dlist_prepend( DList* lst, int data ){
	DNode *newptr=dnode_new(data);
    newptr->next=lst->head;
    lst->head=newptr;
    newptr->prev=NULL;
    if((newptr->next)!=NULL)((newptr->next)->prev)=newptr;
}

// Add a new element at the @idx index
void dlist_insert( DList* lst, int idx, int data ){
	int a=dlist_size(lst);
    int i;
    if(a>idx){         //checking whether the given idx is in the ranges
        if(idx==0){
            dlist_prepend(lst,data);
            return;
        }
        DNode *newptr=dnode_new(data);
        DNode *currptr=lst->head;
        DNode *nextptr;
        for(i=0;i<idx-1;i++){
            nextptr=currptr->next;
            currptr=nextptr;
        }
        nextptr=currptr->next;
        newptr->next=nextptr;
        currptr->next=newptr;
        newptr->prev=currptr;
        nextptr->prev=newptr;
    }
    else if(idx==a){          //adding the at the end when idx=size-1
        dlist_append(lst,data);
    }
    if((lst->head)==NULL){
    	dlist_prepend(lst,data);
    }
}

// Remove an element from the end of the list
void dlist_remove_last( DList* lst ){
	DNode *currptr=lst->head;
    if(currptr!=NULL){
        DNode *nextptr=currptr->next;
        if(nextptr==NULL){          //checking whether the list contains more than one element or not
            lst->head=NULL;
            free(currptr);
        }
        else{
            while(nextptr->next!=NULL){
                currptr=nextptr;
                nextptr=nextptr->next;
            }
            currptr->next=NULL;
            free(nextptr);
        }
    }
}

// Remove an element from the beginning of the list
void dlist_remove_first( DList* lst ){
	DNode *currptr=lst->head;
    DNode *nextptr;
    if(currptr!=NULL){          
        nextptr=currptr->next;
        nextptr->prev=NULL;
        lst->head=nextptr;
        free(currptr);
    }
}

// Remove an element from an arbitrary @idx position in the list
void dlist_remove( DList* lst, int idx ){
	int a=dlist_size(lst);
    int i;
    if(a>idx){          //checking whether the given index is in range
        if(idx==0){
            dlist_remove_first(lst);
        }
        else{
            DNode *nextptr=lst->head;
            DNode *currptr=lst->head;
            for(i=0;i<idx-1;i++){
                nextptr=currptr->next;
                currptr=nextptr;
            }   
            DNode *tempptr=nextptr->next;
            currptr->next=(currptr->next)->next;
            ((currptr->next)->prev)=currptr;
            free(tempptr);
        }
    }
}

void dlist_reverse(DList* lst){
	DNode *tempptr=NULL;  
    DNode *currptr=lst->head;
    while (currptr!=NULL)
	{
		tempptr=currptr->prev;
		currptr->prev=currptr->next;
		currptr->next=tempptr;              
		currptr=currptr->prev;
	}
	if(tempptr!=NULL ) lst->head=tempptr->prev;
}