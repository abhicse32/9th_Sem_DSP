/*      Program that helps sparsematrix.c to implement basic operations on sparse matrix
            G.Pranav        CS15B015        3-9-2016*/

#include "List.h"
#include<stdio.h>
#include<stdlib.h>
#include<limits.h>

// Create a new node with next set to NULL
Node* node_new( int data1, int data2){
	Node *newnodeptr=malloc(sizeof(Node));
	newnodeptr->col_ind=data1;
	newnodeptr->val=data2;
	newnodeptr->next=NULL;
	return newnodeptr;
}

// Create an empty list (head shall be NULL)
LList* llist_new(){
	LList *listptr=malloc(sizeof(LList));
    listptr->head=NULL;
    return listptr;
}

// Traverse the linked list and return its size
int llist_size( LList* lst ){
	int size=0;
    if(lst==NULL) return 0;
    else{
        Node *currptr=lst->head;
        while((currptr)!=NULL){
            size++;
            currptr=currptr->next;
        }
        return size;
    }
}

// Traverse the linked list and print the non-zero elements
void llist_print( LList* lst){
	Node *currptr=lst->head;
    while(currptr!=NULL){
        if(currptr->val!=0) printf("%d ",currptr->val);
        currptr=currptr->next;
    }
    printf("\n");
}

//get the element at position @idx
Node* llist_get( LList* lst, int idx ){
    int i;
    Node *currptr=lst->head;
    for(i=0;(i<idx)&&(currptr!=NULL);i++){
        currptr=currptr->next;
    }
    return currptr;			
}

// Add a new element at the end of the list
void llist_append( LList* lst, int col, int num){
	Node *currptr=lst->head;
    if(currptr==NULL){
        Node *newptr=node_new(col,num);
        lst->head=newptr;
    }
    else{
        Node *nextptr=currptr->next;
        while(nextptr!=NULL){
            currptr=currptr->next;
            nextptr=currptr->next;
        }
        Node *newptr=node_new(col,num);
        currptr->next=newptr;
    }
}

// Add a new element at the beginning of the list
void llist_prepend( LList* lst, int col, int num){
	Node *newptr=node_new(col,num);
    newptr->next=lst->head;
    lst->head=newptr;
}

// Add a new element at the @idx index
void llist_insert( LList* lst, int idx, int col, int num){
	int size=llist_size(lst);
    int i;
    if(idx<size){				//checking whether the idx is present in required range or not
        if(idx==0){
            llist_prepend(lst,col,num);
            return;
        }
        Node *newptr=node_new(col,num);
        Node *currptr=lst->head;
        Node *nextptr;
        for(i=0;i<idx-1;i++){
            nextptr=currptr->next;
            currptr=nextptr;
        }
        nextptr=currptr->next;
        newptr->next=nextptr;
        currptr->next=newptr;
    }
    else if(idx==size){
        llist_append(lst,col,num);
    }
    if(lst->head==NULL) llist_append(lst,col,num);
}