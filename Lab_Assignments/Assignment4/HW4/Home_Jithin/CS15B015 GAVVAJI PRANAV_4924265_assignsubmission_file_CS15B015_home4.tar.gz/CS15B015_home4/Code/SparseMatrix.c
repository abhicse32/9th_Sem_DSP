/*      Program to implement basic operations sparse matrix
            G.Pranav        CS15B015        3-9-2016*/

#include "SparseMatrix.h"
#include<stdio.h>
#include<stdlib.h>
#include<limits.h>

/*Add two matrices*/
Matrix add(Matrix a, Matrix b){
	Matrix ans;				//creating a matrix ans to store the result
	LList **listptr1=a.row_lst;
	int rows1=a.n_rows;
	LList **listptr2=b.row_lst;
	int rows2=b.n_rows;
	ans.n_rows=rows1;
	LList **listptr3=malloc(sizeof(LList *)*rows1);		//dynamically allocating memory for ans matrix
	int i;
	for(i=0;i<rows1;i++) listptr3[i]=malloc(sizeof(LList));
	ans.row_lst=listptr3;
	
	for(i=0;i<rows1;i++){					//finding elements of ans matrix starting from the first row
		Node *currptr1=listptr1[i]->head;
		Node *currptr2=listptr2[i]->head;
		while((currptr1!=NULL)&&(currptr2!=NULL)){
			int col1=currptr1->col_ind;
			int col2=currptr2->col_ind;
			int val1=currptr1->val;
			int val2=currptr2->val;
			if(col1<col2){
				llist_append(listptr3[i],col1,val1);		//appending elements to the ans matrix
				currptr1=currptr1->next;
			}
			else if(col1>col2){
				llist_append(listptr3[i],col2,val2);		//appending elements to the ans matrix
				currptr2=currptr2->next;
			}
			else{
				llist_append(listptr3[i],col1,val1+val2);		//appending elements to the ans matrix
				currptr1=currptr1->next;
				currptr2=currptr2->next;
			}
		}
		while(currptr1!=NULL){
			int col1=currptr1->col_ind;
			int val1=currptr1->val;
			llist_append(listptr3[i],col1,val1);		//appending elements to the ans matrix
			currptr1=currptr1->next;	
		}
		while(currptr2!=NULL){
			int col2=currptr2->col_ind;
			int val2=currptr2->val;
			llist_append(listptr3[i],col2,val2);		//appending elements to the ans matrix
			currptr2=currptr2->next;
		}
	}
	return ans;
}

/*Subtract Matrix b from a*/
Matrix subtract(Matrix a, Matrix b){
	Matrix ans;					//creating a matrix ans to store the result
	LList **listptr1=a.row_lst;
	int rows1=a.n_rows;
	LList **listptr2=b.row_lst;
	int rows2=b.n_rows;
	ans.n_rows=rows1;			//dynamically allocating memory for ans matrix
	LList **listptr3=malloc(sizeof(LList *)*rows1);
	int i;
	for(i=0;i<rows1;i++) listptr3[i]=malloc(sizeof(LList));
	ans.row_lst=listptr3;
	
	for(i=0;i<rows1;i++){					//finding elements of ans matrix starting from the first row
		Node *currptr1=listptr1[i]->head;
		Node *currptr2=listptr2[i]->head;
		while((currptr1!=NULL)&&(currptr2!=NULL)){
			int col1=currptr1->col_ind;
			int col2=currptr2->col_ind;
			int val1=currptr1->val;
			int val2=currptr2->val;
			if(col1<col2){
				llist_append(listptr3[i],col1,val1);			//appending elements to the ans matrix
				currptr1=currptr1->next;
			}
			else if(col1>col2){
				llist_append(listptr3[i],col2,(-1)*val2);		//appending elements to the ans matrix
				currptr2=currptr2->next;
			}
			else{
				llist_append(listptr3[i],col1,val1-val2);		//appending elements to the ans matrix
				currptr1=currptr1->next;
				currptr2=currptr2->next;
			}
		}
		while(currptr1!=NULL){
			int col1=currptr1->col_ind;
			int val1=currptr1->val;
			llist_append(listptr3[i],col1,val1);			//appending elements to the ans matrix
			currptr1=currptr1->next;
		}
		while(currptr2!=NULL){
			int col2=currptr2->col_ind;
			int val2=currptr2->val;
			llist_append(listptr3[i],col2,(-1)*val2);			//appending elements to the ans matrix
			currptr2=currptr2->next;
		}
	}
	return ans;
}

/*Multiply an M x N matrix with N X 1 vector*/
Matrix matrix_vect_multiply(Matrix mat, Matrix vect){
	Matrix ans;						//creating a matrix ans to store the result
	LList **listptr1=mat.row_lst;
	int rows1=mat.n_rows;
	LList **listptr2=vect.row_lst;
	int rows2=vect.n_rows;
	ans.n_rows=rows1;
	LList **listptr3=malloc(sizeof(LList *)*rows1);			//dynamically allocating memory for ans matrix
	int i,j;
	for(i=0;i<rows1;i++) listptr3[i]=malloc(sizeof(LList));
	ans.row_lst=listptr3;
	for(i=0;i<rows1;i++){				//finding elements of ans matrix starting from the first row
		int temp=0;
		Node *currptr=listptr1[i]->head;
		while(currptr!=NULL){
			int col=currptr->col_ind;
			int num1=currptr->val;
			Node *tempptr=listptr2[col]->head;
			if(tempptr!=NULL){
				int num2=tempptr->val;
				temp=temp+(num1*num2);
			}
			currptr=currptr->next;
		}
		llist_append(listptr3[i],0,temp);		//appending elements to the ans matrix
	}

	return ans;
}