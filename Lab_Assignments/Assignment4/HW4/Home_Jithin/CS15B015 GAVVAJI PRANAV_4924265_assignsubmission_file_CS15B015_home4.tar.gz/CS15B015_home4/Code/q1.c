/*      Program that implements basic operations on sparse matrix using functions defined in sparsematrix.c
            G.Pranav        CS15B015        3-9-2016*/

#include "SparseMatrix.h"
#include "List.h"
#include<stdio.h>
#include<stdlib.h>
void printarray(Matrix mat);
int main(){
	int choice;
	scanf("%d",&choice);
	while(choice!=-1){		//condition to terminate the loop
		if(choice==1){		//implementing addition of the matrices
			int m,n;
			scanf("%d%d",&m,&n);
			Matrix mat1,mat2;		//taking input into mat1 and mat2
			mat1.n_rows=m;
			mat2.n_rows=m;
			LList **listptr1=malloc(sizeof(LList *)*m);
			LList **listptr2=malloc(sizeof(LList *)*m);
			int i,j;
			for(i=0;i<m;i++) listptr1[i]=malloc(sizeof(LList));
			for(i=0;i<m;i++) listptr2[i]=malloc(sizeof(LList));
			mat1.row_lst=listptr1;
			mat2.row_lst=listptr2;
			for(i=0;i<m;i++){
				for(j=0;j<n;j++){
					int num;
					scanf("%d",&num);
					if(num!=0) llist_append(listptr1[i],j,num);
				}
			}
			for(i=0;i<m;i++){
				for(j=0;j<n;j++){
					int num;
					scanf("%d",&num);
					if(num!=0) llist_append(listptr2[i],j,num);
				}
			}
			Matrix ans=add(mat1,mat2); 	//calling add function and storing the result in ans
            printarray(ans);
		}
		else if(choice==2){			//implementing subtraction of the matrices
			int m,n;
			scanf("%d%d",&m,&n);
			Matrix mat1,mat2;		//taking input into mat1 and mat2
			mat1.n_rows=m;
			mat2.n_rows=m;
			LList **listptr1=malloc(sizeof(LList *)*m);
			LList **listptr2=malloc(sizeof(LList *)*m);
			int i,j;
			for(i=0;i<m;i++) listptr1[i]=malloc(sizeof(LList));
			for(i=0;i<m;i++) listptr2[i]=malloc(sizeof(LList));
			mat1.row_lst=listptr1;
			mat2.row_lst=listptr2;
			for(i=0;i<m;i++){
				for(j=0;j<n;j++){
					int num;
					scanf("%d",&num);
					if(num!=0) llist_append(listptr1[i],j,num);
				}
			}
			for(i=0;i<m;i++){
				for(j=0;j<n;j++){
					int num;
					scanf("%d",&num);
					if(num!=0) llist_append(listptr2[i],j,num);
				}
			}
			Matrix ans=subtract(mat1,mat2); 			//calling subtract function and storing the result in ans
            printarray(ans);
		}
		else{			//implementing multiplication of the matrices
			int m,n;
			scanf("%d%d",&m,&n);
			Matrix mat1,mat2;		//taking input into mat1 and mat2
			mat1.n_rows=m;
			mat2.n_rows=n;
			LList **listptr1=malloc(sizeof(LList *)*m);
			LList **listptr2=malloc(sizeof(LList *)*n);
			int i,j;
			for(i=0;i<m;i++) listptr1[i]=malloc(sizeof(LList));
			for(i=0;i<n;i++) listptr2[i]=malloc(sizeof(LList));
			mat1.row_lst=listptr1;
			mat2.row_lst=listptr2;
			for(i=0;i<m;i++){
				for(j=0;j<n;j++){
					int num;
					scanf("%d",&num);
					if(num!=0) llist_append(listptr1[i],j,num);
				}
			}
			for(i=0;i<n;i++){
				int num;
				scanf("%d",&num);
				if(num!=0) llist_append(listptr2[i],0,num);
			}
			Matrix ans=matrix_vect_multiply(mat1,mat2); //calling matrix_vect_multiply function and storing the result in ans
            printarray(ans);
		}
		scanf("%d",&choice);		//inputting the choice of the user
	}
	return 0;
}
//	Program to print the elements in the sparse matrix in the given matrix
void printarray(Matrix mat){
	LList **listptr=mat.row_lst;
	int rows=mat.n_rows;
	int i;
	for(i=0;i<rows;i++){
		Node *currptr=listptr[i]->head;
		if(currptr!=NULL){
		while(currptr!=NULL){
			printf("%d ",currptr->val);
			currptr=currptr->next;
		}
		printf("\n");
		}
	}
}

