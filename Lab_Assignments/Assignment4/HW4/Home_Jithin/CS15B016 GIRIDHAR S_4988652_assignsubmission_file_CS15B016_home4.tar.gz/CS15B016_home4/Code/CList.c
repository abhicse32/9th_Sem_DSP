#include "CList.h"
#include<stdio.h>
#include<malloc.h>
#include<limits.h>

// Create a new node with next set to NULL
CNode* cnode_new( int data){
	CNode* new;
	new=(CNode*)malloc(sizeof(CNode));
	new->data=data;
	new->next=NULL;
	return new;
}

// Create an empty list (head shall be NULL)
CList* clist_new(){
	CList* list;
	list=(CList*)malloc(sizeof(CList));
	list->head=NULL;
	return list;

}

// Traverse the linked list and return its size
int clist_size( CList* lst ){
	if(lst->head==NULL){
		return 0;
	}

	CNode *cur;
	cur=lst->head;
	int count=1;

	while(cur->next!=lst->head){
		cur=cur->next;
		count++;
	}

	return count;
}

// Traverse the linked list and print each element
void clist_print( CList* lst ){
	if(lst->head==NULL)
		return;
	else{
		CNode *cur;
		cur=lst->head;
		int count=1;
		do{
			printf("%d ",cur->data);
			cur=cur->next;
		}while(cur!=lst->head);
	}
	printf("\n");
}

//get the element at position @idx
int clist_get( CList* lst, int idx ){


	int length=clist_size(lst);
	if((idx>=length)||(idx<0))
		return -1;
	
	int i=0;
	CNode* cur=lst->head;
	while(i<idx){
		cur=cur->next;
		i++;
	}
	return cur->data;
	
}


// Add a new element at the end of the list
void clist_append( CList* lst, int data ){
	CNode* cur;
	cur=lst->head;
	if(cur==NULL){
		lst->head=cnode_new(data);
		lst->head->next=lst->head;
	}
	else{
		while(cur->next!=lst->head){
			cur=cur->next;
		}
		CNode* new=cnode_new(data);
		new->next=cur->next;
		cur->next=new;
	}
}

// Add a new element at the beginning of the list
void clist_prepend( CList* lst, int data ){
	CNode* cur;
	cur=lst->head;
	if(cur==NULL){
		lst->head=cnode_new(data);
		lst->head->next=lst->head;
	}
	else{
		while(cur->next!=lst->head){
			cur=cur->next;
		}
		CNode* new=cnode_new(data);
		new->next=cur->next;
		cur->next=new;
		lst->head=new;
	}

}

// Add a new element at the @idx index
void clist_insert( CList* lst, int idx, int data ){
	int length=clist_size(lst);
	if(idx==0){
		clist_prepend(lst,data);
	}	
	else if((idx>length)||(idx<0))
		return;
	
	else{
		int i=1;
		CNode* cur=lst->head;
		CNode* target=cnode_new(data);
		while(i<idx){
			cur=cur->next;
			i++;
		}
		target->next=cur->next;
		cur->next=target;
	}

	
}

// Remove an element from the end of the list
void clist_remove_last( CList* lst ){
	if(lst->head==NULL){
	}
	
	else if(lst->head->next==NULL){
		lst->head=NULL;
	}
	else{
		CNode* cur=lst->head;
		CNode* nx=cur->next;
		while(nx->next!=lst->head){
			cur=cur->next;
			nx=nx->next;
		}
		cur->next=lst->head;
		nx->next=NULL;
	//delete(nx)
	}
}

// Remove an element from the beginning of the list
void clist_remove_first( CList* lst ){
	if(lst->head==NULL){
	}
	
	else if(lst->head->next==NULL){
		lst->head=NULL;
	}
	else{
		CNode* cur=lst->head;
		CNode* nx=cur->next;
		while(nx->next!=lst->head){
			cur=cur->next;
			nx=nx->next;
		}
		cur=cur->next;
		nx=nx->next;
		cur->next=nx->next;
		lst->head=nx->next;
		nx=NULL;
	//delete(nx)
	}
}


// Remove an element from an arbitrary @idx position in the list
void clist_remove( CList* lst, int idx ){

	int length=clist_size(lst);
	
	if(idx==0){
		clist_remove_first(lst);
		return;	
	}

	if((idx>=length)||(idx<0)) return;
	//	printf("Error");
	
	


	else if(idx==length-1){
		clist_remove_last(lst);
	}

	else{
		int i=1;
		CNode* cur=lst->head;
		CNode* tmp;
		while(i!=idx){
			cur=cur->next;
			i++;
		}

		tmp=cur->next;
		cur->next=tmp->next;
		//delete tmp
	}
}


// reverse the list
void clist_reverse(CList* lst){
	CNode* prvs=lst->head;
	if((prvs==NULL)||(prvs->next==prvs))
		return;
	CNode* cur=prvs->next;
	if(cur->next==prvs){
		lst->head->next=cur;
		cur->next=prvs;
		return;
	}
	CNode* nx=cur->next;
	do{
		cur->next=prvs;
		prvs=cur;
		cur=nx;
		nx=nx->next;
	}while(cur!=lst->head);
	cur->next=prvs;
	nx->next=cur;
	lst->head=cur;
	lst->head=prvs;	
}

