#include "DList.h"
#include<stdlib.h>
#include<stdio.h>
#include<malloc.h>
//#include<limits.h>
#define INT_MIN -1 

// Create a new node with next set to NULL
DNode* dnode_new( int data){
	DNode* node;
	node=(DNode*)malloc(sizeof(struct Node_));
	if(node==NULL){}
	else{	
	node->data=data;
	node->prev=NULL;
	node->next=NULL;}
	return node;
}

// Create an empty list (head shall be NULL)
DList* dlist_new(){
	DList *dlist;
	dlist=(DList*)malloc(sizeof(DList));

	if(dlist==NULL){
//		printf("error! out of memory!!");
	}
	else{	
	dlist->head=NULL;}
	return dlist;
}

// Traverse the linked list and return its size
int dlist_size( DList* lst ){
//	printf("here ");
	if(lst->head==NULL)
		return 0;
	else{
		int count=1;
		DNode* tmp;
		tmp=lst->head;
		while(tmp->next!=NULL){
		//	printf("to infinity ");
			count++;
			tmp=tmp->next;
			
			}
		return count;
	}
}

// Traverse the linked list and print each element
void dlist_print( DList* lst ){
	if(lst->head==NULL)
		return;
	else{
		DNode* cur=lst->head;
		while(1){
			printf("%d ",cur->data);
			if(cur->next!=NULL){
				cur=cur->next;
			}
			else
				break;
		}
	}
	printf("\n");
}

//get the element at position @idx
int dlist_get( DList* lst, int idx ){

	int length=dlist_size(lst);
	if((idx>=length)||(idx<0))
		return INT_MIN;
	else{
		int i=0;
		DNode* cur=lst->head;
		while(i!=idx){
			cur=cur->next;
			i++;
		}

		return cur->data;
	}
}

// Add a new element at the end of the list
void dlist_append( DList* lst, int data ){

	if(lst->head==NULL){
		DNode* target=dnode_new(data);
		lst->head=target;
	}
	

	else{
		DNode* cur=lst->head;
		DNode* target=dnode_new(data);
		while(cur->next!=NULL){
			cur=cur->next;
		}
		cur->next=target;
		target->prev=cur;
	}
}

// Add a new element at the beginning of the list
void dlist_prepend( DList* lst, int data ){
		
	if(lst->head==NULL){
		DNode* target=dnode_new(data);
		lst->head=target;
	}
	else{
		DNode* target=dnode_new(data);
		target->next=lst->head;
		lst->head->prev=target;
		lst->head=target;
	}
}

// Add a new element at the @idx index
void dlist_insert( DList* lst, int idx, int data ){

	int length=dlist_size(lst);
	if((idx>length)||(idx<0));
	//	printf("Error");

	else if(idx==0){
		dlist_prepend(lst, data);
	}

	else if(idx==length){
		dlist_append(lst, data);
	}

	else{
		int i=1;
		DNode* cur=lst->head;
		DNode* target=dnode_new(data);
		while(i!=idx){
			cur=cur->next;
			i++;
		}

		target->next=cur->next;
		target->prev=cur;

		cur->next->prev=target;
		cur->next=target;
	}
}	

// Remove an element from the end of the list
void dlist_remove_last( DList* lst ){
	if(lst->head==NULL){
	//	printf("List is empty");
	}
	
	else if(lst->head->next==NULL){
		lst->head=NULL;
	}
	else{
		DNode* cur=lst->head;
		DNode* nx=cur->next;
		while(nx->next!=NULL){
			cur=cur->next;
			nx=nx->next;
		}
		nx->prev=NULL;
		cur->next=NULL;
	}
}

// Remove an element from the beginning of the list
void dlist_remove_first( DList* lst ){
	if(lst->head==NULL){
	//	printf("List is empty");
	}
	
	else if(lst->head->next==NULL){
		lst->head=NULL;
	}
	else{
	//	DNode *tmp;
	//	tmp=lst->head;
		lst->head->next->prev=NULL;
		lst->head=lst->head->next;
	}

}

// Remove an element from an arbitrary @idx position in the list
void dlist_remove( DList* lst, int idx ){

	int length=dlist_size(lst);
	if((idx>=length)||(idx<0))
		return;
	//	printf("Error");
	
	if(idx==0){
	//	DNode* temp;
	//	temp=lst->head;
	//	lst->head=lst->head->next;
		dlist_remove_first(lst);
	}
	else if(idx==length-1){
		dlist_remove_last(lst);
	}

	else{
		int i=1;
		DNode* cur=lst->head;
		DNode* tmp;
		while(i!=idx){
			cur=cur->next;
			i++;
		}

		tmp=cur->next;
		cur->next=tmp->next;
		tmp->next->prev=cur;
		tmp->next=NULL;
		tmp->prev=NULL;
		//delete tmp
	}
}

void dlist_reverse(DList* lst){
//	if(lst->head==NULL||lst->head->next==NULL)
//		return;
	DNode *tmp;
	DNode *cur=lst->head;
	while(cur!=NULL){
		tmp=cur->next;
		cur->next=cur->prev;
		cur->prev=tmp;
		if(cur->prev==NULL)
			lst->head=cur;
		cur=cur->prev;

	}
}