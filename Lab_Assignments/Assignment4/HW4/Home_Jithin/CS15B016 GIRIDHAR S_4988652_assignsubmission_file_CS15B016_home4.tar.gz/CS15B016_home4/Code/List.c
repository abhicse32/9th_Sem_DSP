#include "List.h"
#include <stdio.h>
#include <malloc.h>
#include <stdlib.h>


// Create a new node with next set to NULL
Node* node_new( int data1, int data2){
	Node* node;
	node=(Node*)malloc(sizeof(struct Node_));
	if(node==NULL){
		printf("eror! out of memory!!");
	}
	else{	
	node->col_ind=data1;
	node->val=data2;
	node->next=NULL;}
	return node;
}


// Create an empty list (head shall be NULL)
LList* llist_new(){
	LList *llist;
	llist=(LList*)malloc(sizeof(LList));

	if(llist==NULL){
//		printf("error! out of memory!!");
	}
	else{	
	llist->head=NULL;}
	return llist;
}

// Traverse the linked list and return its size
int llist_size( LList* lst ){
//	printf("here ");
	if(lst->head==NULL)
		return 0;
	else{
		int count=1;
		Node* tmp;
		tmp=lst->head;
		while(tmp->next!=NULL){
		//	printf("to infinity ");
			count++;
			tmp=tmp->next;
			
			}
		return count;
	}
}

// Traverse the linked list and print each element
void llist_print( LList* lst){
	if(lst==NULL){
		lst=llist_new();
		lst->head=NULL;
	}
	if(lst->head==NULL)
		printf("0 ");
	else{
		Node* cur=lst->head;
		while(1){
			printf("%d ",cur->val);
			if(cur->next!=NULL){
				cur=cur->next;
			}
			else
				break;
		}
	}
printf("\n");
}

//get the element at position @idx
Node* llist_get( LList* lst, int idx ){

	int length=llist_size(lst);
	if((idx>=length)||(idx<0))
		return NULL;
	else{
		int i=0;
		Node* cur=lst->head;
		while(i!=idx){
			cur=cur->next;
			i++;
		}

		return cur;
	}
}

// Add a new element at the end of the list
void llist_append( LList* lst, int col, int dat){
	if(lst==NULL){
		lst=llist_new();
	}
	if(lst->head==NULL){
		Node* target=node_new(col,dat);
		lst->head=target;
	}
	

	else{
		Node* cur=lst->head;
		Node* target=node_new(col,dat);
		while(cur->next!=NULL){
			cur=cur->next;
		}
		cur->next=target;
	}
}

// Add a new element at the beginning of the list
void llist_prepend( LList* lst, int col, int data){
		
	if(lst->head==NULL){
		Node* target=node_new(col,data);
		lst->head=target;
	}
	else{
		Node* target=node_new(col,data);
		target->next=lst->head;
		lst->head=target;
	}
}
	

// Add a new element at the @idx index
void llist_insert( LList* lst, int idx, int col, int data){

	int length=llist_size(lst);
	if((idx>length)||(idx<0));
	//	printf("Error");

	else if(idx==0){
		Node* target=node_new(col,data);
		target->next=lst->head;
		lst->head=target;}

	else{
		int i=1;
		Node* cur=lst->head;
		Node* target=node_new(col,data);
		while(i!=idx){
			cur=cur->next;
			i++;
		}

		target->next=cur->next;
		cur->next=target;
	}
}		
