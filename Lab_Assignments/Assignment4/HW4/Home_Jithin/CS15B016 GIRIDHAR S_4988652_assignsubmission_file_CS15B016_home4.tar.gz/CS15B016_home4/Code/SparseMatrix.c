#include "SparseMatrix.h"
#include "List.h"
#include <malloc.h>
#include <stdio.h>

/*
typedef struct Matrix{
	LList** row_lst;
	int n_rows;
}Matrix;*/

/*Multiply an M x N matrix with N X 1 vector*/
Matrix matrix_vect_multiply(Matrix A, Matrix vect){
	int i,j,k;

	Matrix prod;
	prod.n_rows=A.n_rows;
	prod.row_lst=(LList**)malloc(sizeof(LList*)*prod.n_rows);
	for(i=0;i<A.n_rows;i++){
		prod.row_lst[i]=llist_new();
	}

	int vect_size=vect.n_rows;

	int* a;
	int* b;
	a=(int*)malloc(sizeof(int)*vect_size);
	b=(int*)malloc(sizeof(int)*A.n_rows);

	for(i=0;i<prod.n_rows;i++){
		LList* row=A.row_lst[i];
		k=0;
		if(llist_size(A.row_lst[i])==0) {
			for(j=0;j<vect_size;j++){
				a[j]=0;
			}
		}

		else{
			Node* cur=llist_get(row,k);
			int flag=1;
			for(j=0;j<vect_size;j++){
				if(flag&&cur->col_ind==j){
					a[j]=cur->val;
					k++;
					cur=llist_get(row,k);
					if(cur==NULL)
						flag=0;
				}
				else{
					a[j]=0;
				}
			}
		}

		b[i]=0;
		for(j=0;j<vect_size;j++){
			Node* node=vect.row_lst[j]->head;
			if(node!=NULL){
				
					{b[i]+=a[j]*node->val;
					} 

			}

		}
	}
	for(i=0;i<prod.n_rows;i++){
		if(b[i]!=0)
			{llist_append(prod.row_lst[i],0,b[i]);}
	}

	


	return prod;
}














/*Add two matrices*/
Matrix add(Matrix A, Matrix B){
	Matrix sum;
	sum.n_rows=A.n_rows;

	Node* target;
//	printf("Vishnu\n");
	if(A.n_rows!=B.n_rows){

	}
	else{
		int rnum=A.n_rows;
		sum.row_lst=(LList**)malloc(sizeof(LList*)*rnum);
		int i;
		for(i=0;i<rnum;i++){
			
			

			Node* curA;
			Node* curB;
			int j1=0, j2=0;
			int flag1=1, flag2=1;
			sum.row_lst[i]=llist_new();
			Node* cursum=sum.row_lst[i]->head;

			while(flag1==1&&flag2==1){

				curA=llist_get(A.row_lst[i],j1);
				curB=llist_get(B.row_lst[i],j2);

				if(llist_get(A.row_lst[i],j1)==NULL)
					{flag1=0; break;}
				if(llist_get(B.row_lst[i],j2)==NULL)
					{flag2=0; break;}
				

				if(curA->col_ind==curB->col_ind){
		
					
					llist_append(sum.row_lst[i],curA->col_ind, curA->val+curB->val);
				 

					j1++; j2++;
				 }

				else if(curB->col_ind<curA->col_ind){
					
					llist_append(sum.row_lst[i],curB->col_ind, curB->val);

					j2++;
				}
				
				else if(curB->col_ind>curA->col_ind){
					
					llist_append(sum.row_lst[i],curA->col_ind, curA->val);

				 	j1++;
				}


			}

		
			while(curB!=NULL){
				
				llist_append(sum.row_lst[i],curB->col_ind, curB->val);

				j2++;
				curB=llist_get(B.row_lst[i],j2);

			}

			while(curA!=NULL){

				
				llist_append(sum.row_lst[i],curA->col_ind, curA->val);

				j1++;
				curA=llist_get(A.row_lst[i],j1);

			}

		}
	}
	return sum;
}

/*Subtract Matrix b from a*/
Matrix subtract(Matrix A, Matrix B){
	Matrix sum;
	Node* target;
	if(A.n_rows!=B.n_rows){

	}
	else{
		int rnum=A.n_rows;
		sum.row_lst=(LList**)malloc(sizeof(LList*)*rnum);
		int i;
		for(i=0;i<rnum;i++){
			
			

			Node* curA;
			Node* curB;
			int j1=0, j2=0;
			int flag1=1, flag2=1;
			sum.row_lst[i]=llist_new();
			Node* cursum=sum.row_lst[i]->head;

			while(flag1==1&&flag2==1){

				curA=llist_get(A.row_lst[i],j1);
				curB=llist_get(B.row_lst[i],j2);

				if(llist_get(A.row_lst[i],j1)==NULL)
					{flag1=0; break;}
				if(llist_get(B.row_lst[i],j2)==NULL)
					{flag2=0; break;}
				

				if(curA->col_ind==curB->col_ind){
				
					
					llist_append(sum.row_lst[i],curA->col_ind, curA->val-curB->val);
				 

					j1++; j2++;
						
				 }

				else if(curB->col_ind<curA->col_ind){
					
				 	
					llist_append(sum.row_lst[i],curB->col_ind, (-1)*curB->val);

					j2++;
				}
				
				else if(curB->col_ind>curA->col_ind){
				
					llist_append(sum.row_lst[i],curA->col_ind, curA->val);

				 	j1++;
				}


			}

			
			while(curB!=NULL){
				
				llist_append(sum.row_lst[i],curB->col_ind, (-1)*curB->val);

				j2++;
				curB=llist_get(B.row_lst[i],j2);

			}

			while(curA!=NULL){

				
				llist_append(sum.row_lst[i],curA->col_ind, curA->val);

				j1++;
				curA=llist_get(A.row_lst[i],j1);

			}

		}
	}
	return sum;
}
