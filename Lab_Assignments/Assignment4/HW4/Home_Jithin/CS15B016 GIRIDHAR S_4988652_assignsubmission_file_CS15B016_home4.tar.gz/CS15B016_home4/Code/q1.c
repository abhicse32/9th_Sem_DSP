#include <stdio.h>
#include "SparseMatrix.h"
#include "List.h"
#include <stdlib.h>
#include <malloc.h>


void output(Matrix M, int col, int rows){
	int i,j;
//	printf("\nin--%d*%d\n",M.n_rows,col);
	for(i=0;i<rows;i++){
		llist_print(M.row_lst[i]);
/*		if(cur==NULL){
		}
		for(j=0;j<col; j++){
			if(cur!=NULL){

				if(cur->col_ind==j){
					printf("%d ",cur->val);
					cur=cur->next;
				}
				else
					printf("%d ",0);
			}
			else
				printf("%d ",0);
			}
			printf("\n");
		}*/
	
	}
}


void output_sum(Matrix M, int col, int rows){
	int i,j;
//	printf("\nin--%d*%d\n",M.n_rows,col);
	for(i=0;i<rows;i++){
		if(M.row_lst[i]->head) llist_print(M.row_lst[i]);
/*		if(cur==NULL){
		}
		for(j=0;j<col; j++){
			if(cur!=NULL){

				if(cur->col_ind==j){
					printf("%d ",cur->val);
					cur=cur->next;
				}
				else
					printf("%d ",0);
			}
			else
				printf("%d ",0);
			}
			printf("\n");
		}*/
	
	}
}


int main(){
	int option=0,rows,cols;
	int i,j,num;
	Matrix M1,M2,M3;
	
	while(option!=-1)
	{
	scanf("%d",&option);

	switch(option){
		case 1:
			scanf("%d",&rows);
			scanf("%d",&cols);
			M1.n_rows=M2.n_rows=rows;
			M1.row_lst=(LList**)malloc(sizeof(LList*)*rows);
			M2.row_lst=(LList**)malloc(sizeof(LList*)*rows);
			for(i=0;i<rows;i++){
				M1.row_lst[i]=llist_new();
				M2.row_lst[i]=llist_new();
			}
			for(i=0;i<rows;i++){
				for(j=0;j<cols;j++){
					scanf("%d",&num);
					if(num){
						llist_append(M1.row_lst[i],j,num);
					}
				}
			}
		//	output(M1,cols);
			for(i=0;i<rows;i++){
				for(j=0;j<cols;j++){
					scanf("%d",&num);
					if(num){
						llist_append(M2.row_lst[i],j,num);
					}
				}
			}

		//	output(M2, cols);
			M3=add(M1,M2);
			M3.n_rows=M1.n_rows;
			output_sum(M3,cols,rows);
			break;
		case 2:

			scanf("%d",&rows);
			scanf("%d",&cols);
			M1.n_rows=M2.n_rows=rows;
			M1.row_lst=(LList**)malloc(sizeof(LList*)*rows);
			M2.row_lst=(LList**)malloc(sizeof(LList*)*rows);
			for(i=0;i<rows;i++){
				M1.row_lst[i]=llist_new();
				M2.row_lst[i]=llist_new();
			}
			for(i=0;i<rows;i++){
				for(j=0;j<cols;j++){
					scanf("%d",&num);
					if(num){
						llist_append(M1.row_lst[i],j,num);
					}
				}
			}
			for(i=0;i<rows;i++){
				for(j=0;j<cols;j++){
					scanf("%d",&num);
					if(num){
						llist_append(M2.row_lst[i],j,num);
					}
				}
			}
			M3=subtract(M1,M2);
			M3.n_rows=M1.n_rows;
			output_sum(M3,cols,rows);
			break;
		case 3:

			scanf("%d",&rows);
			scanf("%d",&cols);
			M1.n_rows=rows;
			M2.n_rows=cols;
			M1.row_lst=(LList**)malloc(sizeof(LList*)*rows);
			M2.row_lst=(LList**)malloc(sizeof(LList*)*cols);
			for(i=0;i<rows;i++){
				M1.row_lst[i]=llist_new();
			}

			for(i=0;i<cols;i++){
				M2.row_lst[i]=llist_new();
			}

			for(i=0;i<rows;i++){
				for(j=0;j<cols;j++){
					scanf("%d",&num);
					if(num){
						llist_append(M1.row_lst[i],j,num);
					}
				}
			}
			for(i=0;i<cols;i++){
			//	for(j=0;j<cols;j++){
				scanf("%d",&num);
				if(num){
					llist_append(M2.row_lst[i],0,num);
				}
			//	}
			}
			M3=matrix_vect_multiply(M1,M2);
			output(M3,1,rows);
			break;

		case -1: return 1;
		default: break;

	}

}

}