#include<stdio.h>
#include<stdlib.h>
#include"CList.h"

CNode* cnode_new(int data)					//new node with next set to NULL
{
 	CNode* cnode;
	cnode = (CNode*)malloc(sizeof(CNode));
	cnode -> data = data;
	cnode -> next = NULL;
	return cnode;
}


CList* clist_new()						//creating an empty list
{
	CList* emptylist =(CList*) malloc(sizeof(CList));
	emptylist -> head == NULL;
	return emptylist;
}

int clist_size(CList* lst)					//for the sizeof the list
{
   	
   	CNode* current = lst -> head;
   	
	if(current == NULL) return 0;
	else if((current -> next) == (lst -> head))	return 1;
	else
	{
		int l = 1;
   		for(current = lst -> head->next; current != lst -> head; current = current-> next)	l++;

   		return l;
   	}
}

void clist_print(CList* lst)					//printing elements in the list
{
	CNode* current = lst -> head;
	if(current==NULL) {printf("\n");return;}
	printf("%d ",current -> data);
	CNode* ptr = lst -> head -> next;	
   	while(ptr != lst -> head)
	{        
      		printf("%d ",ptr -> data);
      		ptr = ptr -> next;
   	}	
	printf("\n");
	fflush(stdout);
	
	return;
}

int clist_get( CList* lst, int idx )				//for a element at any index
{
   	CNode* current = lst -> head; int i = 0;

   	int l = clist_size(lst);

    	if( l <= idx) return -1;
	else
   	{
		while(i != idx)		
		{
			current = current -> next;
			i++;
		}
   	}     
   	return current -> data;
}


void clist_prepend( CList* lst, int data )				//adding a element at the first
{
	
	CNode* cnode = cnode_new(data);


   	if(lst -> head == NULL)
   	{
   		lst -> head   = cnode;
   		cnode -> next = lst -> head;
   		return;
   	}
   	else
   	{
   		//cnode -> data = data;
   		int l = clist_size(lst); 
                cnode -> next = (lst->head);
                lst -> head = cnode;

                CNode* current = lst->head;
                int i = 0;
                
                while(i != l)
                {
                        current = current -> next;
                        i++;
               	}
                current -> next = lst -> head;
   	}
   	return;
}

void clist_append( CList* lst, int data )				//adding an element at the last
{

	CNode* cnode = cnode_new(data);

	CNode* current = lst -> head;
	
 	if(current == NULL)
 	{
                clist_prepend (lst, data);
 	}
 	else
 	{
     		while((current -> next) !=( lst -> head))
     		{
     			current = current -> next;
     		}
   		current -> next = cnode;
   		cnode -> next 	= lst -> head;
 	}
}

void clist_insert( CList* lst, int idx, int data )			//adding an element at any index
{
    	CNode* current = lst->head;
   
   	CNode* cnode = cnode_new(data);
   
    	if(idx == 0)	{clist_prepend(lst,data);return;}
    	if(idx==clist_size(lst)) {clist_append(lst,data);return;}
    	if(idx>clist_size(lst)) {return;}
    	
    	int i;
   
    	for(i = 0; i < idx - 1; i++) 	current = current->next;
   
    	cnode->next = current->next;
    	current->next = cnode;

}

void clist_remove_last( CList* lst )					//removing the last element
{
	CNode *current = lst -> head;
	if(current == NULL);
	else if ((current -> next) == (lst -> head))
	{
		lst -> head = NULL;
		return ;
	} 
	
	while(((current -> next) -> next) != (lst -> head))
	{
		current = current -> next;
	}
	current -> next = lst -> head;
	return;
}

void clist_remove_first( CList* lst )					//removing the first element
{	
	CNode* current = lst -> head;
	if(current == NULL);
	else if ((current -> next) == (lst -> head))
	{
		lst -> head = NULL;
		
	}
	
	
	else
	{
		current = current -> next;
		lst->head = current;
		while( ((current -> next) -> next)  != lst -> head)
		{
			current = current -> next;
		}
		current -> next = lst -> head;
		return;
	}
	
}

void clist_remove( CList* lst, int idx )				//removing the element at any index
{
   	CNode* current = lst -> head;int i;
   	int l = clist_size( lst);	
   	
   	if(idx == 0)		clist_remove_first( lst );
   	else if(idx == l-1)	clist_remove_last( lst );
  	else if(idx>=l) return;
  	else
  	{
    		for(i = 0; i < idx - 1; i++)
    		{
    			current = current -> next;
    		}
    		current -> next = ((current -> next) -> next);	
    	}
}


void clist_reverse(CList* lst)						//reversing the list
{
      	int i;
      	
      	for(i=1;i<clist_size(lst);i++)
      	{
      		clist_prepend(lst, clist_get(lst, i));
      		clist_remove(lst, i+1);
      	}
}
	


