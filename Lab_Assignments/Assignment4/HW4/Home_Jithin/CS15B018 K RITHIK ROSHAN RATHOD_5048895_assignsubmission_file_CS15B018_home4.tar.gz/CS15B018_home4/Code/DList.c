#include<stdio.h>
#include<stdlib.h>
#include"DList.h"

DNode* dnode_new(int data)					//new node with next set to NULL
{
 	DNode* dnode;
	dnode = (DNode*)malloc(sizeof(DNode));
	dnode -> data = data;
	dnode -> next = NULL;
	dnode -> prev = NULL;
	return dnode;
}


DList* dlist_new()						//creating an empty list
{
	DList* emptylist = malloc(sizeof(DList));
	emptylist -> head == NULL;
	return emptylist;
}

int dlist_size(DList* lst)					//for the sizeof the list
{
   	int l = 0;
   	DNode* current;
	
   	for(current = lst -> head; current != NULL; current = current-> next)	l++;

   	return l;
}

void dlist_print(DList* lst)					//printing elements in the list
{
	DNode* ptr = lst -> head;	
   	while(ptr != NULL)
	{        
      		printf("%d ",ptr -> data);
      		ptr = ptr -> next;
   	}	
	printf("\n");
	fflush(stdout);
	
	return;
}

int dlist_get( DList* lst, int idx )				//for a element at any index
{
   	int l = dlist_size(lst);   
   	 
    	if( idx > l-1 ) 	return -1;   
    	
    	int i = 0; 
    	DNode* current = lst->head;  

    	while(i != idx)   
    	{
		current = current -> next;
                i++;
        }
    	return current -> data;
}

void dlist_append( DList* lst, int data )				//adding an element at the last
{

	DNode* dnode = dnode_new(data);

	DNode* current = lst -> head;
	
 	if(current == NULL)
 	{
   		lst -> head = dnode;
   		return;
 	}
 	else
 	{
     		while(current->next != NULL)
     		{
     			current = current -> next;
     		}
                current -> next = dnode;
                dnode -> prev   = current;
 	}
}
void dlist_prepend( DList* lst, int data )				//adding a element at the first
{
	
	DNode* dnode = dnode_new(data);


   	if(lst -> head == NULL)
   	{
   		lst -> head = dnode;
   		return;
   	}
   	else
   	{
            	dnode -> next = lst -> head;
            	lst -> head -> prev = dnode;
            	lst -> head = dnode;	
   	}
   	return;
}

void dlist_insert( DList* lst, int idx, int data )			//adding an element at any index
{
    	DNode* current = lst->head;  
   	DNode* dnode = dnode_new(data);
   	int l = dlist_size(lst);  
   	
    	if(idx == 0 || l == 0)
    	{
        	dnode->next = (lst->head);   
        	lst->head   = dnode;
        	return ;
    	} 	
    	else if ( idx > l );
    	else
    	{
    		int i = 1;
    		while(i != idx)
    		{ 
    			current = current->next;
    			i++;
    		}
    		if(idx == l)
    		{
    			current -> next = dnode;
    			dnode -> prev = current;
    		}
    		else
    		{
    			current -> next -> prev = dnode;
        		dnode -> next = current -> next;
        		current -> next = dnode;
        		dnode -> prev = current;
        	}
        }
}

void dlist_remove_last( DList* lst )					//removing the last element
{
	DNode *current = lst -> head;
	if(current -> next == NULL) 
	{
		lst -> head = NULL;
		return;
	}
	
	while(((current -> next) -> next) != NULL)
	{
		current = current -> next;
	}
	current -> next = NULL;
	return;
}

void dlist_remove_first( DList* lst )					//removing the first element
{
	if(((lst -> head) -> next) == NULL) {lst->head = NULL; return;}

	lst -> head = ((lst -> head) -> next); 
	lst -> head -> prev = NULL;
}

void dlist_remove( DList* lst, int idx )				//removing the element at any index
{
   	DNode* current = lst -> head;int i;
   	
   	if(idx == 0)	dlist_remove_first( lst );
  	
 
   
    	for(i = 0; i < idx - 1; i++)
    	{
    		current = current -> next;
    	}
    	current -> next = ((current -> next) -> next);	
    	current -> next -> prev = current;
}

void dlist_reverse(DList* lst)						//reversing the list
{

      	DNode* current = lst->head;
       	int temp;
        
	if(current==NULL)
	{
		return;
	}              
	temp=current->data;
	dlist_remove_first(  lst );
	dlist_reverse( lst);
	dlist_append( lst, temp );
	return;
}
	
