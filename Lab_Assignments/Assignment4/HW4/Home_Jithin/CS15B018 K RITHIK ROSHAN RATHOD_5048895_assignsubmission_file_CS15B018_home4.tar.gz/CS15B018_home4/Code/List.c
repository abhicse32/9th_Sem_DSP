#include<stdio.h>
#include<stdlib.h>
#include"List.h"

Node* node_new(int col_ind, int val)					//new node with next set to NULL
{
 	Node* node;
	node = (Node*)malloc(sizeof(Node));
	node -> col_ind = col_ind;
	node -> val = val;
	node -> next = NULL;
	return node;
}


LList* llist_new()						//creating an empty list
{
	LList* emptylist = malloc(sizeof(LList));
	emptylist -> head == NULL;
	return emptylist;
}

int llist_size(LList* lst)					//for the sizeof the list
{
   	int l = 0;
   	Node* current;
	
   	for(current = lst -> head; current != NULL; current = current-> next)	l++;

   	return l;
}

void llist_print(LList* lst)					//printing elements in the list
{
	Node* ptr = lst -> head;	
   	while(ptr != NULL)
	{        
      		printf("%d ",ptr -> val);
      		ptr = ptr -> next;
   	}	
	printf("\n");
	fflush(stdout);
	
	return;
}

Node* llist_get( LList* lst, int idx )				//for a element at any index
{
   	Node* current = lst -> head; int i = 0;

   	if(current == NULL);
	else
   	{
		while(i != idx)		
		{
			i++;
			current = current -> next;
		}
   	}     
   	return current;
}

void llist_append( LList* lst, int col_ind, int val)				//adding an element at the last
{

	

	Node* current = lst -> head;
	
 	if(current == NULL)
 	{
   		Node *node = (Node*) malloc(sizeof(Node)); 
                node->val = val;
                node->col_ind=col_ind;
                node->next = NULL;
                lst->head = node;
 	}
 	else
 	{
     		while(current -> next != NULL)
     		{
     			current = current -> next;
     		}
   		
   		Node *new= node_new(col_ind,val);    
            	current->next = new;
 	}
}
void llist_prepend( LList* lst, int col_ind, int val )				//adding a element at the first
{
	
	Node* node = (Node*) malloc(sizeof(Node)); /*Creating a new node*/
    	node -> val= val;     /*Adding data into it*/
    	node -> col_ind = col_ind;
    	node -> next = (lst->head);
    	lst -> head = node;
}

void llist_insert( LList* lst, int idx, int col_ind, int val)		//adding an element at any index
{
	
   
    	int l = llist_size(lst);   

    	if ((l == 0) || (idx == 0)) llist_prepend(lst,col_ind,val); 
    	else if (idx>=l) 	llist_append(lst,col_ind,val); 
    	
    	else
    	{
    		Node *current;  
                current = lst->head;
                int i = 1;  

                while (i!=(idx))
                {
                        current = current->next;
                        i++;
                }
                Node *node = (Node*) malloc(sizeof(int));   
                node->val	= val;
                node->col_ind = col_ind;                          
                node->next = current->next;
                current->next  = node;
	}

}

