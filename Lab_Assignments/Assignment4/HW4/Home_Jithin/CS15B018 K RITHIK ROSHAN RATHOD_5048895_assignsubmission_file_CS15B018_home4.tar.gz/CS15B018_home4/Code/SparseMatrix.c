#include "SparseMatrix.h"
#include<stdlib.h>
#include<stdio.h>

Matrix add(Matrix A, Matrix B)
{
    	Matrix ADD;
    	ADD.n_rows = A.n_rows;
    	ADD.row_lst = (LList**) malloc((sizeof(LList*))*(A.n_rows));
    	int i;

    	for(i = 0; i < ADD.n_rows; i++)
    	{    
        	ADD.row_lst[i] = llist_new();
        	int x = llist_size(A.row_lst[i]);
        	int y = llist_size(B.row_lst[i]);

            	int j = 0, k= 0;
            	
            	

            	while((j < x) && (k < y))
            	{
            	
            		Node* a = llist_get(A.row_lst[i],j);
                	Node* b = llist_get(B.row_lst[i],k);

                    	if((a -> col_ind) > (b -> col_ind))
                    	{
   	            		llist_append(ADD.row_lst[i], b -> col_ind, b -> val);
                        	k++;
                    	}

                    	else if((a -> col_ind) < (b -> col_ind)) 
                    	{
                    		llist_append(ADD.row_lst[i], a -> col_ind, a -> val);
                        	j++;
                    	}
                    	else
                    	{
                    		int c = (a -> val) + (b -> val);
                        	llist_append(ADD.row_lst[i], a -> col_ind, c);
                        	j++;
                        	k++;                            
                    	}
		}

            	while(j < x)
                {
                	Node* a = llist_get(A.row_lst[i],j);
                    	llist_append( ADD.row_lst[i], a -> col_ind, a -> val);
                    	j++;
                }

            	while(k < y)
                {
                	Node* b = llist_get(B.row_lst[i],k);
                    	llist_append( ADD.row_lst[i], b -> col_ind, b -> val);
                    	k++;
                }
        }
        
   	return ADD;
}

Matrix subtract(Matrix A, Matrix B)
{
    	Matrix SUB;
    	SUB.n_rows = A.n_rows;
    	SUB.row_lst = (LList**) malloc((sizeof(LList*))*(SUB.n_rows));
    	int i;

    	for(i=0;i<(SUB.n_rows);i++)
        {
        
        	SUB.row_lst[i] = llist_new();
        	int x = llist_size(A.row_lst[i]);
        	int y = llist_size(B.row_lst[i]);
            	
            	int j = 0;
            	int k = 0;
            	
            	

            	while( j < x && k < y)
                {
                
                	Node* a = llist_get(A.row_lst[i],j);
                	Node* b = llist_get(B.row_lst[i],k);
                    	if((a -> col_ind) > (b -> col_ind))   
                    	{
                        	llist_append(SUB.row_lst[i], (b -> col_ind), -(b -> val));
                                k++;
                        }

                    	else if((a -> col_ind) < (b -> col_ind))   
                    	{
                        	llist_append(SUB.row_lst[i], (a -> col_ind), (a -> val));
                                j++;
                        }
                    	else 
                    	{
                                int c = (a -> val) - (b -> val);
                                if(c != 0) llist_append(SUB.row_lst[i], (a -> col_ind), c);
                                j++;
                                k++;                            
                        }
                }

            	while(j < x)
                {
                	Node* a = llist_get(A.row_lst[i],j);
                    	llist_append( SUB.row_lst[i], a -> col_ind, a -> val);
                    	j++;
                }

            	while(k < y)
                {
                	Node* b = llist_get(B.row_lst[i],k);
                    	llist_append( SUB.row_lst[i], b -> col_ind, -(b -> val));
                    	k++;
                }
        }
        
   	return SUB;
}

Matrix matrix_vect_multiply( Matrix A, Matrix B)
{
	Matrix MUL;
	MUL.n_rows = A.n_rows;
    	MUL.row_lst = (LList**) malloc((sizeof(LList*))*(MUL.n_rows));
    	int i;
    	for(i = 0; i < MUL.n_rows; i++)
    	{
    		MUL.row_lst[i] = llist_new();
    		int m = llist_size(A.row_lst[i]);
    		int c = 0;
    		int j;
    		for(j = 0; j < m; j++)
    		{
    			Node* a = llist_get(A.row_lst[i], j);
    			int col = a -> col_ind;
    			if(((B.row_lst[col]) -> head) != NULL)
    		        {
    		        	Node* b = llist_get(B.row_lst[col], 0);
    				c = c + ((a->val) * (b->val));
 			}	
    		}
		llist_append(MUL.row_lst[i], 0, c);
    	}
    	return MUL;
}
