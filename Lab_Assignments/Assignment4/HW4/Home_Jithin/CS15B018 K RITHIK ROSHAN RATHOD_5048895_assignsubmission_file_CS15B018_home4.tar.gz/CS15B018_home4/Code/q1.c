#include<stdio.h>
#include<stdlib.h>
#include"List.h"
#include"SparseMatrix.h"

int main()
{
	while(1)
        {
		int option;
		scanf("%d",&option);
		
		if(option==-1) break;
			
		switch(option)
            	{
			
			case 1:
			{
				Matrix A;
				Matrix B;
				int m;
				scanf("%d",&m);
				
				int n;
				scanf("%d",&n);
				
				A.n_rows = B.n_rows = m;
				
				A.row_lst = (LList**) malloc((sizeof(LList*))*m);
				B.row_lst = (LList**) malloc((sizeof(LList*))*m);
					            
				int i, j, k;						//i = row index
					            					//j = column index
				for(i = 0; i < m; i++)					//k = element 
				{
					                
					A.row_lst[i] = llist_new();
					for(j = 0; j < n; j++)
					{
						scanf("%d", &k);
						if(k != 0) 
						{
					        	llist_append(A.row_lst[i], j, k);
					        }
					}
				}	                 
				for(i = 0; i < m; i++)
				{
					                
					B.row_lst[i] = llist_new();
					for(j = 0; j < n; j++)
					{
						scanf("%d", &k);
					        if(k != 0) 
					        {
					        	llist_append(B.row_lst[i], j, k);
					        }
					}
				}
					                 
				Matrix ADD = add(A,B);					//output matrix
					            
				for(i=0;i<m;i++)
				llist_print(ADD.row_lst[i]);
					                
				break;
			}                  
				
			case 2:
			{
				Matrix A;
				Matrix B;
				int m;
				scanf("%d",&m);
				
				int n;
				scanf("%d",&n);
				
				A.n_rows = B.n_rows = m;
				
				A.row_lst = (LList**) malloc((sizeof(LList*))*m);
				B.row_lst = (LList**) malloc((sizeof(LList*))*m);
					            
				int i, j, k;						//i = row index
					            					//j = column index
				for(i = 0; i < m; i++)					//k = element 
				{
					                
					A.row_lst[i] = llist_new();
					for(j = 0; j < n; j++)
					{
						scanf("%d", &k);
						if(k != 0) 
						{
					        	llist_append(A.row_lst[i], j, k);
					        }
					}
				}	                 
				for(i = 0; i < m; i++)
				{
					                
					B.row_lst[i] = llist_new();
					for(j = 0; j < n; j++)
					{
						scanf("%d", &k);
					        if(k != 0) 
					        {
					        	llist_append(B.row_lst[i], j, k);
					        }
					}
				}
					                 
				Matrix SUB = subtract(A,B);					//output matrix
					            
				for(i=0;i<m;i++)
				llist_print(SUB.row_lst[i]);
					                
				break;
			}       	         
					
			case 3:
			{
				int m;
				int n;
				scanf("%d",&m);
				scanf("%d",&n);
				            
				Matrix A;
				Matrix B;
				A.n_rows = m;
				B.n_rows = n;
				            
				A.row_lst = (LList**) malloc(sizeof(LList*)*m);
				B.row_lst = (LList**) malloc(sizeof(LList*)*n);
				
				int i, j, k;
				for(i = 0; i < m; i++)
				{
					A.row_lst[i] = llist_new();
					for(j = 0; j < n; j++)
					{
						scanf("%d", &k);
					        if(k != 0)
					        {
					         	llist_append(A.row_lst[i], j, k);
					        }
					}
				}	
					                 
				for(i = 0;i < n; i++)
				{	
					B.row_lst[i] = llist_new();
					scanf("%d", &k);
					if(k != 0) llist_append(B.row_lst[i], 0, k);
				}
					            
				Matrix MUL = matrix_vect_multiply(A,B);				//output matrix
						           
				for(i = 0; i < MUL.n_rows; i++)		llist_print(MUL.row_lst[i]);
					                
				break;
			}
            	}					           
        }	
}	
            	
