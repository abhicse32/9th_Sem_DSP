#include "CList.h"
//#include "List.h"
#include<stdlib.h>
#include<stdio.h>
#include<limits.h>

CNode* node_new( int data)
{
    CNode *new_node;
    
    new_node=(CNode*)malloc(sizeof(CNode));
    
    
    
    if(new_node!=NULL)
    {
        new_node->data=data;
        new_node->next=new_node;
    }
    
    return new_node;
}

CList* clist_new()
{ CList* new_list;
    new_list=(CList*)malloc(sizeof(CList));
    
    if(new_list!=NULL)
    { new_list->head=NULL;
    }
    
    return new_list;
}

int clist_size( CList* lst )
{ int ctr=0;
    CNode *start,*mid;
    
    start=lst->head;
    if(start==NULL)
        return ctr;
    do
    { ctr++;
        mid=start->next;
        start=mid;
    }while(start!=lst->head);
    
    return ctr;
}

void clist_print( CList* lst )
{ CNode *start,*mid;
    
    start=lst->head;
    while(start!=NULL)
    { printf("%d ",start->data);
        mid=start->next;
        start=mid;
        if(start==lst->head)
            break;
    }
    printf("\n");
}

int clist_get( CList* lst, int idx )
{ CNode  *start,*mid;
    start=lst->head;
    while(start!=NULL)
    { if(idx==0)
    { return (start->data);
    }
        mid=start->next;
        start=mid;
        idx--;
        if(start==lst->head)
            break;
    }
    return -1;
}

void clist_append( CList* lst, int data )
{ CNode *start,*mid;
    start=lst->head;
    if(start==NULL)
    { lst->head=node_new(data);
        return;
    }
    
    while(1)
    {
        mid=start->next;
        if(mid==lst->head)
        { start->next=node_new(data);
            start->next->next=lst->head;
            return;
        }
        start=mid;
    }
    
}

void clist_prepend( CList* lst, int data )
{ CNode *start,*mid;
    int temp;
    
   if(lst->head==NULL)
   { lst->head=node_new(data);
       return;
   }
    if(lst->head->next==lst->head)
    { start=lst->head;
    lst->head=node_new(data);
        lst->head->next=start;
        start->next=lst->head;
        return;
    }
    start=lst->head;
    temp=lst->head->data;
    mid=node_new(temp);
    mid->next=start->next;
    start->next=mid;
    start->data=data;
}

void clist_insert( CList* lst, int idx, int data )
{ CNode  *start,*mid;
    start=lst->head;
    if(idx==0)
    { clist_prepend(lst,data);
        return;
    }
    if(idx==clist_size(lst))
    { clist_append(lst,data);
        return;
    }
    do
    { if(idx==0)
    { mid->next=node_new(data);
        (mid->next)->next=start;
        return;
    }
        mid=start;
        start=start->next;
        idx--;
    }while(start!=lst->head);
}

void clist_remove_last( CList* lst )
{ CNode *start,*mid;
    
    start=lst->head;
    if(start==NULL)
        return;
    if(start->next==lst->head)
    { lst->head=NULL;
        return;
    }
    while(start->next->next!=lst->head)
    { start=start->next;
    }
    start->next=lst->head;

}

void clist_remove_first( CList* lst )
{ CNode *start,*mid;
    int temp;
    if(lst->head==NULL)
        return;
    if(lst->head->next==lst->head)
    { lst->head=NULL;
        return;
    }
    
    start=lst->head;
    start->data=start->next->data;
    start->next=start->next->next;

}

void clist_remove( CList* lst, int idx )
{ CNode  *start,*mid;
    start=lst->head;
    if(idx==0)
    { clist_remove_first(lst);
        return;
    }
    if(idx==clist_size(lst)-1)
    { clist_remove_last(lst);
        return;
    }
     do
    { if(idx==0)
    { mid->next=start->next;
        //free(start);
        return;
    }
        mid=start;
        start=start->next;
        idx--;
    } while(start!=lst->head);
}

void clist_reverse(CList* lst)
{ CNode *start,*mid,*start2;
    start=lst->head;
    CList* x=clist_new();
    
    do{  clist_prepend(x,start->data);
        start=start->next;
        
    } while(start!=lst->head);
    start=lst->head;
    start2=x->head;
    do{  start->data=start2->data;
        start=start->next;
        start2=start2->next;
    } while(start!=lst->head);
}



    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
