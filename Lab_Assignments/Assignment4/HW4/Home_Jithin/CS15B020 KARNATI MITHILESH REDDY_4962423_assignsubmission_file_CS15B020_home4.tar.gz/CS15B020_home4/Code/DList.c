#include "DList.h"
#include<stdlib.h>
#include<stdio.h>
#include<limits.h>

DNode* dnode_new( int data)
{
    DNode *new_node;
    
    new_node=(DNode*)malloc(sizeof(DNode));
    
    
    
    if(new_node!=NULL)
    {
        new_node->data=data;
        new_node->next=NULL;
    }
    
    return new_node;
}

DList* dlist_new()
{ DList* new_list;
    new_list=(DList*)malloc(sizeof(DList));
    
    if(new_list!=NULL)
    { new_list->head=NULL;
    }
    
    return new_list;
}

int dlist_size( DList* lst )
{ int ctr=0;
    DNode *start,*mid;
    
    start=lst->head;
    if(start==NULL)
        return ctr;
    do
    { ctr++;
        mid=start->next;
        start=mid;
    }while(start!=NULL);
        
        return ctr;
}

void dlist_print( DList* lst )
{ DNode *start,*mid;
    
    start=lst->head;
    while(start!=NULL)
    { printf("%d ",start->data);
        mid=start->next;
        start=mid;
    }
    printf("\n");
}

int dlist_get( DList* lst, int idx )
{ DNode  *start,*mid;
    start=lst->head;
    while(start!=NULL)
    { if(idx==0)
    { return (start->data);
    }
        mid=start->next;
        start=mid;
        idx--;
    }
    return -1;//INT_MIN;
}

void dlist_append( DList* lst, int data )
{ DNode *start,*mid;
    start=lst->head;
    if(start==NULL)
    { lst->head=dnode_new(data);
        return;
    }
    
    while(start!=NULL)
    {
        mid=start->next;
        if(mid==NULL)
        { start->next=dnode_new(data);
            start->next->prev=start;
            return;
        }
        start=mid;
    }
    
}

void dlist_prepend( DList* lst, int data )
{ DNode *start,*mid;
    int temp;
    
    if(lst->head==NULL)
    { lst->head=dnode_new(data);
        return;
    }
    
    start=lst->head;
    mid=dnode_new(data);
    mid->next=start;
    mid->next->prev=mid;
    lst->head=mid;
}

void dlist_insert( DList* lst, int idx, int data )
{ DNode  *start,*mid;
    start=lst->head;
    if(idx==0)
    { dlist_prepend(lst,data);
        return;
    }
    if(idx==dlist_size(lst))
    { dlist_append(lst,data);
        return;
    }
    while(start!=NULL)
    { if(idx==0)
    { mid->next=dnode_new(data);
        (mid->next)->next=start;
        mid->next->prev=mid;
        start->prev=mid->next;
        return;
    }
        mid=start;
        start=start->next;
        idx--;
    }
}

void dlist_remove_last( DList* lst )
{ DNode *start,*mid;
    
    start=lst->head;
    if(start==NULL)
        return;
    if(start->next==NULL)
    { free(start);
        return;
    }
    while(start->next->next!=NULL)
    { start=start->next;
    }
    start->next=NULL;
    
}

void dlist_remove_first( DList* lst )
{ DNode *start,*mid;
    int temp;
    if(lst->head==NULL)
        return;
    if(lst->head->next==NULL)
    { free(lst->head);
        return;
    }
    
    start=lst->head;
    mid=start->next;
    lst->head=mid;
}

void dlist_remove( DList* lst, int idx )
{ DNode  *start,*mid;
    start=lst->head;
    if(idx==0)
    { dlist_remove_first(lst);
        return;
    }
    if(idx==dlist_size(lst)-1)
    { dlist_remove_last(lst);
        return;
    }
    do
    { if(idx==0)
    { mid->next=start->next;
        mid->next->prev=mid;
        free(start);
        return;
    }
        mid=start;
        start=start->next;
        idx--;
    } while(start!=NULL);
}

void dlist_reverse(DList* lst)
{ DNode *start,*mid,*start2;
    start=lst->head;
    DList* x=dlist_new();
    
    do{  dlist_prepend(x,start->data);
        start=start->next;
        
    } while(start!=NULL);
   start2=x->head;
   start=lst->head;
    do{  start->data=start2->data;
        start=start->next;
        start2=start2->next;
    } while(start!=NULL);
    
}

















