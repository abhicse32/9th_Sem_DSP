#include "DList.h"
#include<stdlib.h>
#include<stdio.h>
#include<limits.h>
DNode* dnode_new( int data)
{
	DNode *new ;
	new = (DNode*)malloc(sizeof(DNode));
	new->data = data;
	new->next = NULL;
}
DList* dlist_new()
{
	DList *new;
	new = (DList*)malloc(sizeof(DList));
	new->head = NULL;
}
int dlist_size( DList* lst )
{
	if(lst->head == NULL)
	{
		return 0;
	}
	int k = 0;
	DNode*head1 = lst->head;
	while(head1 != NULL)
	{
		head1 = head1->next;
		k++;
	}
	return k;
}
void dlist_print( DList* lst )
{
	if(lst->head == NULL)
	{
		return;
	}
	DNode *head1 = lst->head;
	while(head1 != NULL)
	{
		printf("%d ",head1->data);
		head1 = head1->next;
	}
	printf("\n");
	fflush(stdout);
}
int dlist_get( DList* lst, int idx )
{
	if(lst->head == NULL)
	{
		return -1;
	}
	int k = dlist_size(lst);
	if(idx > k-1)
	{
		return -1;
	}
	int j = 0;
	DNode *head1 = lst->head;
	while(j != idx)
	{
		head1 = head1->next;
		j++;
	}
	return head1->data;
}
void dlist_append( DList* lst, int data )
{
	if(lst->head == NULL)
	{
		DNode *new;
		new = (DNode*)malloc(sizeof(DNode));
		new->data = data;
		new->next = NULL;
		lst->head = new;
		return;
	}
	DNode *new;
	new = (DNode*)malloc(sizeof(DNode));
	DNode *head1 = lst->head;
	while(head1->next != NULL)
	{
		head1 = head1->next;
	}
	head1->next = new;
	new->prev = head1;
	new->next = NULL;
	new->data = data;
	return;
}
void dlist_prepend( DList* lst, int data )
{
	if(lst->head == NULL)
	{
		DNode *new;
		new = (DNode*)malloc(sizeof(DNode));
		new->data = data;
		new->next = NULL;
		lst->head = new;
		return;
	}
	DNode *new;
	new = (DNode*)malloc(sizeof(DNode));
	DNode *head1 = lst->head;
	head1->prev = new;
	new->next = head1;
	new->data = data;
	lst->head = new;
	return;
}
void dlist_insert( DList* lst, int idx, int data )
{
	if(idx == 0)
	{
		dlist_prepend(lst,data);
		return;
	}
	int k = dlist_size(lst);
	if(idx == k)
	{
		dlist_append(lst,data);
		return;
	}
	if(idx > k)
	{
		return;
	}
		
	DNode *new;
	new = (DNode*)malloc(sizeof(DNode));
	DNode *head1 = lst->head;
	int j = 0;
	while(j != idx-1)
	{
		head1 = head1->next;
		j++;
	}
	new->next = head1->next;
	new->data = data;
	new->prev = head1;
	(new->next)->prev = new;
	head1->next = new;
	return;
}
void dlist_remove_last( DList* lst )
{
	if(lst->head == NULL)
	{
		return;
	}
	int k = dlist_size(lst);
	if(k == 1)
	{
		lst->head = NULL;
		return;
	}
	DNode *head1 = lst->head;
	while((head1->next)->next != NULL)
	{
		head1 = head1->next;
	}
	head1->next = NULL;
	return;
}
void dlist_remove_first( DList* lst )
{
	if(lst->head == NULL)
	{
		return;
	}
	int k = dlist_size(lst);
	if(k == 1)
	{
		lst->head == NULL;
		return;
	}
	DNode *head1 = lst->head;
	head1 = head1->next;
	lst->head = head1;
	head1->prev = NULL;
	return;
}
void dlist_remove( DList* lst, int idx )
{
	if(lst->head ==  NULL)
	{
		return;
	}
	if(idx == 0)
	{
		dlist_remove_first(lst);
		return;
	}
	int k = dlist_size(lst);
	if(idx >k-1)
	{
		return;       
	}
	if(idx == k-1)
	{
		dlist_remove_last(lst);
		return;
	}
	DNode *head1 = lst->head;
	int j =0;
	while(j != idx-1)
	{
		head1 = head1->next;
		j++;
	}
	((head1->next)->next)->prev = head1;
	head1->next = (head1->next)->next;
	return;
}
void dlist_reverse(DList*lst)
{
	if(lst->head == NULL)
	{
		return;
	}
	int k = dlist_size(lst);
	if(k == 1)
	{
		return;
	}
	DNode *head1 = lst->head;
	int array[200];
	int j = 0;
	while(head1 != NULL)
	{
		array[j] = head1->data;
		head1 = head1->next;
		j++;
	}
	DNode*head2 = lst->head;
	int l;
	for(l = k-1;(head2!=NULL)&&l>=0;l--)
	{
		head2->data = array[l];
		head2 = head2->next;
	}
	return;
}
		
		
	
	
