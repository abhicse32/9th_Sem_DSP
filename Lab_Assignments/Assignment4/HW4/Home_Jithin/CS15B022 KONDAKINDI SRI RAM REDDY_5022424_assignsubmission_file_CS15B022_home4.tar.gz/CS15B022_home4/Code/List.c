#include "List.h"
#include<stdio.h>
#include<stdlib.h>
#include<limits.h>
Node* node_new( int data1,int data2)
{
    Node *node_new;
    node_new = ( Node*)malloc(sizeof( Node));
    node_new->next = NULL;
    node_new->col_ind = data1;
    node_new->val = data2;
    return node_new;
}
LList* llist_new()
{
    LList *llist_new;
    llist_new = (LList*)malloc(sizeof(LList));
    llist_new->head = NULL;
    return llist_new;
}
int llist_size( LList* lst)
{
    Node *head = lst->head;
    int counter = 0;
    while(head != NULL)
    {
        head = head->next;
        counter = counter + 1;
     }
     return counter;
 }
 void llist_print( LList* lst )
 {	int i = llist_size(lst);
 	if(i == 0)    
 	{
 		return;
 	}
    Node *head = lst->head;
    while(head!=NULL)
    {	
    	
        printf("%d ",head->val);
        
        head = head->next;
     }
     printf("\n");
 }
 Node* llist_get( LList* lst, int idx )
 {
    Node *head = lst->head;
    int i = 0;
    while(head!=NULL)
    {   
        if(i == idx)
            return head;
        head = head->next;
        i++;
    }
    return NULL;         
 }
 void llist_append( LList* lst, int data1,int data2 )
 {
    
    if(lst == NULL)
    {
    	lst =  llist_new();
    	Node *demo1 ;
    	demo1 = (Node*)malloc(sizeof(Node));
    	demo1->col_ind  = data1;
    	demo1->val = data2;
    	demo1->next = NULL;
    	lst->head = demo1;
    	return;
	}
    	
    int j = llist_size(lst);
    if(j == 0)
    {
    	Node *demo1 ;
    	demo1 = (Node*)malloc(sizeof(Node));
    	demo1->col_ind  = data1;
    	demo1->val = data2;
    	demo1->next = NULL;
    	lst->head = demo1;
    	return;
    }
    Node *head1 = lst->head;
    int i = 0;
    while(head1->next!=NULL)
    {
    	head1 = head1->next;
    	i = i+1;
    }
    Node *demo2;
    demo2 = (Node*)malloc(sizeof(Node));
    demo2->col_ind = data1;
    demo2->val = data2;
    demo2->next = NULL;
    head1->next = demo2;
}    
void llist_prepend( LList* lst, int data1,int data2 )
{	int j = llist_size(lst);
	if(j == 0)
	{
    Node*head;
    head = (Node*)malloc(sizeof(Node));
    head->col_ind = data1;
    head->val = data2;
    head->next = NULL;
    lst->head = head;
    return;
    }
    Node*head;
    head = (Node*)malloc(sizeof(Node));
    head->col_ind = data1;
    head->val = data2;
    head->next = lst->head;
    lst->head = head;
 }
 void llist_insert( LList* lst, int idx, int data1,int data2 )
 {	int j = llist_size(lst);
 	if(idx>j)
 	{
 		return;
 	}
 	if(idx == 0)
 	{
 		llist_prepend(lst,data1,data2);
 		return;
 	}
 	if(idx == j)
 	{
 		llist_append(lst,data1,data2);
 		return;
 	}	
    Node *head1 = lst->head;
    Node *demon;
    
    demon = (Node*)malloc(sizeof(Node));
    demon->col_ind = data1;
    demon->val = data2;
    int i =0;
    
    while(i!=idx-1)
    {
          head1 = head1->next;
          i = i+1;
    }
    demon->next = head1->next;
    head1->next = demon;
  }    

