#include "SparseMatrix.h"
#include<stdlib.h>
#include "List.h"

Matrix add(Matrix m1, Matrix m2)
{ Matrix m3;
  Node *x1,*x2,*x3;
  int i;
  m3.row_lst=(LList**)malloc(m1.n_rows*sizeof(LList*));
  for(i=0;i<m1.n_rows;i++)
  { m3.row_lst[i]=llist_new();
  }
  
  for(i=0;i<m1.n_rows;i++)
  {  
    x1=m1.row_lst[i]->head; x2=m2.row_lst[i]->head;
     while(x1!=NULL || x2!=NULL)
     { if(x1!=NULL && x2!=NULL)
         { if(x1->col_ind > x2->col_ind)
           { llist_append(m3.row_lst[i],x2->col_ind,x2->val);
             x2=x2->next;
           }
           else if(x1->col_ind < x2->col_ind)
           { llist_append(m3.row_lst[i],x1->col_ind,x1->val);
             x1=x1->next;           
           }
           else
           { llist_append(m3.row_lst[i],x1->col_ind,x1->val+x2->val);
             x1=x1->next;
             x2=x2->next;           
           }
          
         }
        else if(x1==NULL)
        { llist_append(m3.row_lst[i],x2->col_ind,x2->val);
             x2=x2->next;
        }     
        else if(x2==NULL)
        { llist_append(m3.row_lst[i],x1->col_ind,x1->val);
             x1=x1->next;
        }
     }
   }
   
   return m3;
 }
 
 Matrix subtract(Matrix m1, Matrix m2)
{ Matrix m3;
  Node *x1,*x2,*x3;
  int i;
  m3.row_lst=(LList**)malloc(m1.n_rows*sizeof(LList*));
  for(i=0;i<m1.n_rows;i++)
  { m3.row_lst[i]=llist_new();
  }
  
  for(i=0;i<m1.n_rows;i++)
  {  
    x1=m1.row_lst[i]->head; x2=m2.row_lst[i]->head;
     while(x1!=NULL || x2!=NULL)
     { if(x1!=NULL && x2!=NULL)
         { if(x1->col_ind > x2->col_ind)
           { llist_append(m3.row_lst[i],x2->col_ind,-(x2->val));
             x2=x2->next;
           }
           else if(x1->col_ind < x2->col_ind)
           { llist_append(m3.row_lst[i],x1->col_ind,x1->val);
             x1=x1->next;           
           }
           else
           { llist_append(m3.row_lst[i],x1->col_ind,x1->val-x2->val);
             x1=x1->next;
             x2=x2->next;           
           }
          
         }
        else if(x1==NULL)
        { llist_append(m3.row_lst[i],x2->col_ind,-(x2->val));
             x2=x2->next;
        }     
        else if(x2==NULL)
        { llist_append(m3.row_lst[i],x1->col_ind,x1->val);
             x1=x1->next;
        }
     }
   }
   
   return m3;
 }
 
 Matrix matrix_vect_multiply(Matrix mat, Matrix vect)
 {  Matrix m3;
  Node *x1,*x2,*x3;
  int i,j,sum;
  m3.row_lst=(LList**)malloc(mat.n_rows*sizeof(LList*));
  for(i=0;i<mat.n_rows;i++)
  { m3.row_lst[i]=llist_new();
  }
  
  for(i=0;i<mat.n_rows;i++)
  {  
    x1=mat.row_lst[i]->head;
    sum=0;
    while(x1!=NULL)
    { if((vect.row_lst[x1->col_ind]->head)!=NULL)
      sum=sum+(x1->val)*(vect.row_lst[x1->col_ind]->head->val);
      x1=x1->next;
    }
    
    
   llist_append(m3.row_lst[i],0,sum);
          }
   
   return m3;
 }
