#include "CList.h"
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

CNode* cnode_new( int data)                                //Create a new node with next set to NULL
{
  	CNode *temp;
  	temp = (CNode *)malloc(sizeof(CNode));
  	temp->data = data;
  	temp->next = temp;
  	return temp; 
}

CList* clist_new()                                         //Create an empty list(head shall be NULL)
{
  	CList *list;
  	list = (CList *)malloc(sizeof(CList));
  	list->head = NULL;
  	return list;
}

int clist_size( CList* lst )                               //Traverse the linked list and return its size
{ 
  	CNode *temp;
  	temp = (CNode *)malloc(sizeof(CNode));
  	temp = lst->head;
	if(temp == NULL)
		return 0;
  	int len = 1;
	temp = temp->next;
  	while(temp != lst->head)
  	{
    	len++;
   	 	temp = (temp->next);
  	}
  	return len;
}

void clist_print( CList* lst )                             //Traverse the linked list and print each element
{
  	CNode *temp;
  	temp = (CNode *)malloc(sizeof(CNode));
  	temp = lst->head;
	if(temp == NULL)
		return;
 	do
  	{
    	printf("%d ",(temp->data));
    	temp = (temp->next);
  	}while(temp != lst->head);
  	printf("\n");
}

int clist_get( CList* lst, int idx )                       //Get the element at position @idx
{
  	CNode *temp;
  	temp = (CNode *)malloc(sizeof(CNode));
  	temp = lst->head;
  	int i =0;
	if(temp == NULL)
		return -1;
  	do
  	{
    	if(i == idx)
    	{
      		return (temp->data);
    	}
    	i++;
    	temp = (temp->next);
  	}while(temp != lst->head);
 	return -1;                                         //Returning -1 if idx >= size
}

void clist_append( CList* lst, int data )                  //Add a new element at the end of the list
{
  	CNode *temp;
  	temp = (CNode *)malloc(sizeof(CNode));
  	temp = lst->head;
  	if(temp == NULL)
  	{
    	CNode *new = cnode_new(data);
    	lst->head = new;
    	return;
  	}
  	do
  	{
    	temp = (temp->next);
  	}while(temp->next != lst->head);
  	
	CNode *new = cnode_new(data);
  	temp->next = new;
	new->next = lst->head;
}

void clist_prepend( CList* lst, int data )                 //Add a new element at the beginning of the list
{
  	CNode *temp;
  	temp = (CNode *)malloc(sizeof(CNode));
  	temp = lst->head;
  	if(temp == NULL)
  	{
    	CNode *new = cnode_new(data);
    	lst->head = new;
    	return;
  	}
  	CNode *new = cnode_new(data);
  	new->next = lst->head;
  	do
  	{
    	temp = (temp->next);
  	}while(temp->next != lst->head);
  	temp->next = new;
  	lst->head = new;
}

void clist_insert( CList* lst, int idx, int data )         //Add a new element at the @idx index
{
   	CNode *temp;
   	temp = (CNode *)malloc(sizeof(CNode));
   	temp = lst->head;
	if(lst->head == NULL)
	{
		clist_prepend(lst,data);
		return;
	}
  	if(idx == 0)
  	{
   	 	clist_prepend(lst,data);
  	}
  	else if(idx < clist_size(lst))
  	{
    	int i = 0;
    	while(i < (idx-1))
    	{
      		temp = temp->next;
      		i++;
    	}
    	CNode *new = cnode_new(data);
    	new->next =temp->next;
		temp->next =new;
  	}
	else if(idx == clist_size(lst))
	{
		clist_append(lst,data);
	}
	else
	{
		return;
	}
}

void clist_remove_last( CList* lst )                       //Removing the element at the end
{
  	CNode *temp;
  	temp = (CNode *)malloc(sizeof(CNode));
  	temp = lst->head;
	if(temp->next == lst->head)
	{
		lst->head = NULL;
		return;
	}
  	do
  	{
    	temp = temp->next;
  	}while(((temp->next)->next) != lst->head);
  	(temp->next) = lst->head;
}

void clist_remove_first( CList* lst )                      //Removing the element at the beginning
{
  	CNode *temp;
  	temp = (CNode *)malloc(sizeof(CNode));
  	temp = lst->head;
	if(temp->next == lst->head)
	{
		lst->head = NULL;
		return;
	}
  	do
  	{
    	temp = (temp->next);
  	}while(temp->next != lst->head);
  	(lst->head) = ((lst->head)->next);
	temp->next = lst->head;
}

void clist_remove( CList* lst, int idx )                   //Removing the element at the @idx index
{
  	if(idx == 0)
  	{
   		clist_remove_first(lst);
  	}
  	else if(idx < clist_size(lst))
  	{
    	CNode *temp;
    	temp = (CNode *)malloc(sizeof(CNode));
    	temp = lst->head;
    	int i = 0;
    	while(i < (idx-1))
    	{
      		temp = temp->next;
      		i++;
    	}
    	temp->next = (temp->next)->next;
  	}
	else
	{
		return;
	}
}

void clist_reverse(CList* lst)                             //Reversing the list
{
	if((lst->head) == NULL)
	{
		return;
	}
  	CNode *q;
  	q = (CNode *)malloc(sizeof(CNode));
  	q = lst->head;
  	CNode *r;
  	r = (CNode *)malloc(sizeof(CNode));
  	r = NULL;
  	CNode *s;
  	s = (CNode *)malloc(sizeof(CNode));
  	s = NULL;
	do
	{
		s = r;
		r = q;
		q = q->next;
		r->next = s;
	}while (q != lst->head);
    lst->head = r;
	q->next = r;
}
