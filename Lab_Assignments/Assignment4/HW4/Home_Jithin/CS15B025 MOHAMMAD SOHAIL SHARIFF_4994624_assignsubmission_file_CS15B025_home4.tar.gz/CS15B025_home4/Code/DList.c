#include "DList.h"
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

DNode* dnode_new( int data)                                //Create a new node with next set to NULL
{
   	DNode *new;
   	new = (DNode *)malloc(sizeof(DNode));
   	new->data = data;
   	new->prev = NULL;
   	new->next = NULL;
   	return new;
}

DList* dlist_new()                                         //Create an empty list(head shall be NULL)
{
   	DList *new;
   	new = (DList *)malloc(sizeof(DList *));
   	new->head = NULL;
   	return new;
}

int dlist_size( DList* lst )                               //Traverse the linked list and return its size
{
   	DNode *temp;
   	temp = (DNode *)malloc(sizeof(DNode *));
   	temp = lst->head;
    int size = 0;
   	while(temp != NULL)
	{
		size++;
       	temp = temp->next;
	}
	return size;
}

void dlist_print( DList* lst )                             //Traverse the linked list and print each element
{
	DNode *temp;
    temp = (DNode *)malloc(sizeof(DNode *));
    temp = lst->head;
	while(temp != NULL)
 	{
		printf("%d ", (temp->data));
		temp = temp->next;
	}
	printf("\n");
}

int dlist_get( DList* lst, int idx )                       //Get the element at position @idx
{
	DNode *temp;
	temp = (DNode *)malloc(sizeof(DNode));
	temp = lst->head;
  	int i =0;
 	while(temp != NULL)
  	{
    	if(i == idx)
   	 	{
      		return (temp->data);
    	}
    	i++;
    	temp = (temp->next);
  	}
 	return -1;                                         //Returning -1 if idx >= size
}

void dlist_append( DList* lst, int data )                  //Add a new element at the end of the list
{
  	DNode *temp;
  	temp = (DNode *)malloc(sizeof(DNode));
  	temp = lst->head;
  	if(temp == NULL)
  	{
    	DNode *new = dnode_new(data);
    	lst->head = new;
    	return;
  	}
  	while(temp->next != NULL)
  	{
    	temp = (temp->next);
  	}
  	DNode *new = dnode_new(data);
  	temp->next = new;
	new->prev = temp;
}

void dlist_prepend( DList* lst, int data )                 //Add a new element at the beginning of the list
{
  	DNode *temp;
  	temp = (DNode *)malloc(sizeof(DNode));
  	temp = lst->head;
  	if(temp == NULL)
  	{
    	DNode *new = dnode_new(data);
    	lst->head = new;
    	return;
  	}
  	DNode *new = dnode_new(data);
  	new->next = lst->head;
  	lst->head = new;
	(new->next)->prev = new;
}

void dlist_insert( DList* lst, int idx, int data )         //Add a new element at the @idx index
{
   	DNode *temp;
   	temp = (DNode *)malloc(sizeof(DNode));
   	temp = lst->head;
	if(lst->head == NULL)
	{
		dlist_prepend(lst,data);
		return;
	}
  	if(idx == 0)
  	{
   	 	dlist_prepend(lst,data);
  	}
  	else if(idx < dlist_size(lst))
  	{
    	int i = 0;
    	while((i < (idx-1))&&(temp->next != NULL))
    	{
      		temp = temp->next;
      		i++;
    	}
    	DNode *new = dnode_new(data);
    	new->next =temp->next;
		new->prev = temp;
    	temp->next = new;  
		temp = new->next;
		temp->prev = new;
  	}
	else if(idx == dlist_size(lst))
	{
		dlist_append(lst,data);
	}
	else
	{
		return;
	}
}

void dlist_remove_last( DList* lst )                       //Removing the element at the end
{
  	DNode *temp;
  	temp = (DNode *)malloc(sizeof(DNode));
  	temp = lst->head;
  	while(((temp->next)->next) != NULL)
  	{
    	temp = temp->next;
  	}
  	(temp->next) = NULL;
}

void dlist_remove_first( DList* lst )                      //Removing the element at the beginning
{
  	(lst->head) = ((lst->head)->next);
	(lst->head)->prev = NULL;
}

void dlist_remove( DList* lst, int idx )                   //Removing the element at the @idx index
{
	int n = dlist_size(lst);
  	if(idx == 0)
  	{
   		dlist_remove_first(lst);
  	}
  	else if(idx <= n)                                      /* ADDED CASE FOR IDX > N */
  	{
    	DNode *temp;
    	temp = (DNode *)malloc(sizeof(DNode));
    	temp = lst->head;
    	int i = 0;
    	while((i < (idx-1))&&(temp->next != NULL))
    	{
      		temp = temp->next;
      		i++;
    	}
    	(temp->next) = ((temp->next)->next);
		(temp->next)->prev = temp;
  	}
}

void dlist_reverse(DList* lst)                             //Reversing the list
{
	if((lst->head) == NULL)
	{
		return;
	}
  	DNode *temp;
  	temp = (DNode *)malloc(sizeof(DNode));
  	temp = lst->head;
  	DNode *p;
  	p = (DNode *)malloc(sizeof(DNode));
  	p = temp->next;
	temp->next = NULL;
	temp->prev = p;
	temp = p;
	if(temp != NULL)
	{
		while((temp->next) != NULL)
		{
			p = temp->next;
			temp->next = temp->prev;
			temp->prev = p;
			temp = p;
		}
		temp->next = temp->prev;
		temp->prev = NULL;
		lst->head = temp;
	}
}
