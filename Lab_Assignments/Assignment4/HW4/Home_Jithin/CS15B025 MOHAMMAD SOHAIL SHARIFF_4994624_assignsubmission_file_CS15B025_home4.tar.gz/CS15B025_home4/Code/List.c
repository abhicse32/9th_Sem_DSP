#include "List.h"
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

Node* node_new( int data1, int data2)                                //Create a new node with next set to NULL
{
  	Node *temp;
  	temp = (Node *)malloc(sizeof(Node));
  	temp->col_ind = data1;
  	temp->val = data2;
  	temp->next = NULL;
  	return temp; 
}

LList* llist_new()                                                   //Create an empty list (head shall be NULL)
{
  	LList *list;
  	list = (LList *)malloc(sizeof(LList));
  	list->head = NULL;
  	return list;
}

int llist_size( LList* lst )                                         //Traverse the linked list and return its size
{ 
  	Node *temp;
  	temp = (Node *)malloc(sizeof(Node));
  	temp = lst->head;
  	int len = 0;
  	while(temp != NULL)
  	{
    	len++;
    	temp = (temp->next);
  	}
  	return len;
}

void llist_print( LList* lst )                                       //Traverse the linked list and print each element
{
 	if(lst->head == NULL)                                        /* NOT PRINTING EMPTY LIST */
 		return;
  	Node *temp;
  	temp = (Node *)malloc(sizeof(Node));
  	temp = lst->head;
  	while(temp != NULL)
  	{
    	printf("%d ",(temp->val));
    	temp = (temp->next);
  	}	
  	printf("\n");
}

Node* llist_get( LList* lst, int idx )                               //Get the element at position @idx
{
  	Node *temp;
  	temp = (Node *)malloc(sizeof(Node));
  	temp = lst->head;
  	int i =0;
  	while(temp != NULL)
  	{
    	if(i == idx)
    	{
      		return temp;
    	}
    	i++;
    	temp = (temp->next);
  	}
	return NULL;
}

void llist_append( LList* lst, int data1, int data2 )                //Add a new element at the end of the list
{ 
  	Node *temp;
  	temp = (Node *)malloc(sizeof(Node));
  	temp = lst->head;
  	if(temp == NULL)
  	{
    	Node *new = node_new(data1,data2);
    	lst->head = new;
    	return;
  	}
  	while(temp->next != NULL)
  	{
    	temp = (temp->next);
  	}
  	Node *new = node_new(data1,data2);
  	temp->next = new;
}

void llist_prepend( LList* lst, int data1, int data2)                //Add a new element at the beginning of the list
{
  	Node *temp;
  	temp = (Node *)malloc(sizeof(Node));
  	temp = lst->head;
  	if(temp == NULL)
  	{
    	Node *new = node_new(data1,data2);
    	lst->head = new;
    	return;
  	}
  	Node *new = node_new(data1,data2);
  	new->next = lst->head;
  	lst->head = new;
}

void llist_insert( LList* lst, int idx, int data1, int data2 )       //Add a new element at the @idx index
{
  	if(idx == 0)
  	{
    	llist_prepend(lst,data1,data2);
  	}	
  	else
  	{
    	Node *temp;
    	temp = (Node *)malloc(sizeof(Node));
    	temp = lst->head;
    	int i = 0;
    	while((i < (idx-1))&&(temp->next != NULL))
    	{
      		temp = temp->next;
      		i++;
    	}
    	Node *new = node_new(data1,data2);
    	new->next =temp->next;
    	temp->next = new;  
  	}
}
