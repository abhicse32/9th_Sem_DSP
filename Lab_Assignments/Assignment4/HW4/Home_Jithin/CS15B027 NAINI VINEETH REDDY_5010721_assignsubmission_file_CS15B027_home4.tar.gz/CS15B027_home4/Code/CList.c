#include<stdio.h>
#include "CList.h"
#include<stdlib.h>
#include<limits.h>
CNode* cnode_new( int data)
{
  CNode* p=(CNode *)malloc(sizeof (CNode));  // creating a new CNode p
  p->data = data;
  p->next = NULL;   // next set to null
  return p;
} 
CList* clist_new()
{
  CList* cnode=(CList *)malloc(sizeof(CList));  // creating an empty list
  cnode->head = NULL;                           // head set to null
  return cnode;
}
int clist_size( CList* lst )
{
    if(lst->head == NULL)
    {
      return 0;
    }
  	CNode* p=(CNode *)malloc(sizeof (CNode));
    p = (lst->head)->next;
    int size = 1;              // initialising
     while(p != lst->head)           // traversing the linked list
     {
       size++;
       p = p->next;
     }
     return size;
}
void clist_print( CList* lst )
{ 
    if(lst->head == NULL)
    {
      return;
    }
      CNode* p=(CNode *)malloc(sizeof (CNode));
      p = (lst->head)->next;
      printf("%d ",(lst->head)->data);
      while(p != lst->head)
      {
         printf("%d ",p->data);              // traversing and printing each element
         p = p->next;
      }
     printf("\n");
     return;
}
int clist_get( CList* lst, int idx )
{
   if(idx>clist_size(lst)) return -1;
   CNode* p=(CNode *)malloc(sizeof (CNode));
   p=lst->head;
   int i;
   for(i=0;i<idx;i++)
   {
      p=p->next;
   }
   return p->data;
}
void clist_append( CList* lst, int data )           // adding new element at end of the list
{
    CNode *new = cnode_new(data);                    // creating new dnode
    if(lst->head == NULL)       // if head is null
    {
       lst->head = new;
       new->next = lst->head;
      return;
    }
          CNode* p=(CNode *)malloc(sizeof (CNode));
          p = (lst->head);
        while(p->next != lst->head)
       {
           p = p->next;
       }
       p->next = new;
       new->next=lst->head;
     return;
}
void clist_prepend( CList* lst, int data )
{
   if(lst->head==NULL)
   {
      CNode *p=cnode_new(data);
      lst->head = p;
      p->next = p;
      return;
   }
   CNode*p;
   p=lst->head;
   while(p->next!=lst->head)
   {
      p=p->next;
   }
    CNode *new = cnode_new(data);                     
    new->next = lst->head;               
    lst->head = new;            //new becomes head
    p->next = lst->head;
}
void clist_insert( CList* lst, int idx, int data )
{
   if(lst->head==NULL)
   {
      clist_append(lst,data);
      return;
   }
    if(idx > clist_size(lst))return;
    if(idx == 0)
    {
        clist_prepend(lst,data);   //adding in the beginning if idx is zero 
    }
     else
     {
          CNode* p=(CNode *)malloc(sizeof (CNode));
           p = (lst->head);
          int i = 0;
          while((i < idx-1)&&(p->next)!=NULL)
          {
             p = p->next;
             i++;
          }
            CNode *new = cnode_new(data);
            new->next = p->next;
            p->next = new;
    }
}
void clist_remove_last( CList* lst )
{
    CNode* p=(CNode *)malloc(sizeof (CNode));
    p = (lst->head);
       while((p->next)->next != lst->head)            // moving the pointer till just before last
       {
           p = p->next;
       }
         p->next=lst->head;
}
void clist_remove_first( CList* lst )
{
   CNode* p=(CNode *)malloc(sizeof (CNode));
   p=lst->head;
   while(p->next!=lst->head)
   {
      p=p->next;
   }
   lst->head=(lst->head)->next;            // changing the head
   p->next=lst->head;}
void clist_remove( CList* lst, int idx )
{
    if(idx >= clist_size(lst))return;
 else if(idx==0)
 {
   clist_remove_first(lst);                   // using remove first if idx is zero
 }
   else
   {
    int i=0;
    CNode* p=(CNode *)malloc(sizeof (CNode));
    p = (lst->head);
    while((i < (idx-1))&&(p->next != NULL))
    {
      p = p->next;
      i++;
    }
        (p->next) = ((p->next)->next);
   }
}
void clist_reverse(CList* lst)
{
   CNode*p,*c,*n;
   p=NULL;
   c=lst->head;
   while((c->next)!=lst->head)
   {
      n=c->next;
      c->next=p;
      p=c;
      c=n;
   }
   c->next=p;
   p=c;
   lst->head=c;

   CNode*ptr;
   ptr=lst->head;
   while(ptr->next!=NULL)
   {
      ptr=ptr->next;
   }
   ptr->next=lst->head;
}  
