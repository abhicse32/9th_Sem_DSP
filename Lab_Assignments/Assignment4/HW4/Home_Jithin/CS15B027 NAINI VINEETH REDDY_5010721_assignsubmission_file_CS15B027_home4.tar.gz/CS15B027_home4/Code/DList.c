#include<stdio.h>
#include "DList.h"
#include<stdlib.h>
#include<limits.h>
DNode* dnode_new( int data)
{
  DNode* p=(DNode *)malloc(sizeof (DNode));  // creating a new dnode p
  p->data = data;
  p->prev = NULL;
  p->next = NULL;   // next set to null
  return p;
} 
DList* dlist_new()
{
  DList* dnode=(DList *)malloc(sizeof(DList));  // creating an empty list
  dnode->head = NULL;                           // head set t null
  return dnode;
}
int dlist_size( DList* lst )
{
    DNode* p=(DNode *)malloc(sizeof (DNode));
    p = (lst->head);
    int size = 0;              // initialising
     while(p!=NULL)           // traversing the linked list
     {
       size++;
       p = p->next;
     }
     return size;
}
void dlist_print( DList* lst )
{
    DNode* p=(DNode *)malloc(sizeof (DNode));
    p = (lst->head);
   while(p!=NULL)
   {
      printf("%d ",p->data);              // traversing and printing each element
      p = p->next;
   }
  printf("\n");
}
int dlist_get( DList* lst, int idx )
{
    DNode* p=(DNode *)malloc(sizeof (DNode));
    p = (lst->head);
    int i=0;
    while(p != NULL)
    {
      if(i==idx)
      {
      return p->data;                 // returning the data
      }
      i++;
      p = p->next;
    }
      return -1;                // returning -1 if idx is out of bound
}
void dlist_append( DList* lst, int data )           // adding new element at end of the list
{
    DNode *new = dnode_new(data);                    // creating new dnode
    if(lst->head == NULL)       // if head is null
    {
       lst->head = new;                          
    return;}
    DNode* p=(DNode *)malloc(sizeof (DNode));
    p = (lst->head);
        while(p->next!=NULL)
       {
           p = p->next;
      }
  p->next = new;
  new->prev = p;
  return;
}
void dlist_prepend( DList* lst, int data )
{
    DNode *new = dnode_new(data);                     
    new->next = lst->head;          
    lst->head = new;            //new becomes head
    if(new->next != NULL)
    (new->next)->prev = new;  
}
void dlist_insert( DList* lst, int idx, int data )
{
  int size = dlist_size( lst );
  if(size < idx )
  {
   return;
  }
  if(idx == 0)
  {
    dlist_prepend(lst,data);   //adding in the beginning if idx is zero 
  }
  else
  {
    DNode* p=(DNode *)malloc(sizeof (DNode));
    p = (lst->head);
    int i = 0;
    while((i < idx-1)&&(p->next)!=NULL)
    {
      p = p->next;
      i++;
    }
    DNode *new = dnode_new(data);
    if((p->next)!=NULL)
    (p->next)->prev = new;
    new->next = p->next;
    new->prev = p;
    p->next = new;
  }
}
void dlist_remove_last( DList* lst )
{
    DNode* p=(DNode *)malloc(sizeof (DNode));
    p = (lst->head);
       while((p->next)->next != NULL)            // moving the pointer till just before last
       {
           p = p->next;
       }
       p->next = NULL;
}
void dlist_remove_first( DList* lst )
{
   lst->head = (lst->head)->next;             // changing the head
}
void dlist_remove( DList* lst, int idx )
{
  int size = dlist_size(lst);
  if(size <= idx )
  {
   return;
  }
  if(idx==0)
  {
     dlist_remove_first(lst);                   // using remove first if idx is zero
  }
   else
   {
    int i=0;
    DNode* p=(DNode *)malloc(sizeof (DNode));
    p = (lst->head);
    while((i < (idx-1))&&(p->next != NULL))
    {
      p = p->next;
      i++;
    }
        ((p->next)->next)->prev = p;
        (p->next) = ((p->next)->next);
   }
}
void dlist_reverse(DList*lst)
{
   DNode*p,*c,*n;
   c=lst->head;
   p=NULL;
   while(c->next!=NULL)
   {
      n=c->next;
      c->next=p;
      c->prev=n;
      p=c;
      c=n;
   }
   c->next=p;
   c->prev=NULL;
   lst->head=c;
}
