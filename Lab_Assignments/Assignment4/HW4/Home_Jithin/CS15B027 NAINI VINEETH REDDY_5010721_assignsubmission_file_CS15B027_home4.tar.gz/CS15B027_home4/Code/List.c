#include<stdio.h>
#include "List.h"
#include<stdlib.h>
#include<limits.h>
Node* node_new( int data1, int data2)
{
  Node* p=(Node *)malloc(sizeof (Node));                     // creating a new node p
  p->col_ind = data1;
  p->val = data2;
  p->next = NULL;                                              // next set to null
  return p;
} 
LList* llist_new()
{
  LList* node=(LList *)malloc(sizeof(LList));                       // creating an empty list
  node->head = NULL;                                              // head set t null
  return node;
}
int llist_size( LList* lst )
{
    Node* p=(Node *)malloc(sizeof (Node));
    p = (lst->head);
    int size = 0;                                      // initialising
     while(p!=NULL)                                    // traversing the linked list
     {
       size++;
       p = p->next;
     }
     return size;
}
void llist_print( LList* lst )
{
    Node* p=(Node *)malloc(sizeof (Node));
    p = (lst->head);
   while(p!=NULL)
   {
      printf("%d ",p->val);                           // traversing and printing each value
      p = p->next;
   }
  printf("\n");
}

Node* llist_get( LList* lst, int idx )
{
    Node* p=(Node *)malloc(sizeof (Node));
    p = (lst->head);
    int i=0;
    while(p != NULL)
    {
      if(i==idx)
      {
      return p;                                 // returning the node
      }
      i++;
      p = p->next;
    }
      return NULL;                               // returning NULL if idx is out of bound
}
void llist_append( LList* lst, int data1, int data2)                            // adding new element at end of the list
{
    Node *new = node_new(data1,data2);                                   // creating new node
    if(lst->head == NULL)                               // if head is null
    {
       lst->head = new;                          
    return;}
    Node* p=(Node *)malloc(sizeof (Node));
    p = (lst->head);
        while(p->next!=NULL)
       {
           p = p->next;
      }
  p->next = new;
return;}
void llist_prepend( LList* lst, int data1, int data2)
{
    Node *new = node_new(data1,data2);                     
    new->next = lst->head;               
    lst->head = new;                                        //new becomes head
}
void llist_insert( LList* lst, int idx, int data1, int data2)
{
  if(idx == 0)
  {
    llist_prepend(lst,data1,data2);                   //adding in the beginning if idx is zero 
  }
  else
  {
    Node* p=(Node *)malloc(sizeof (Node));
    p = (lst->head);
    int i = 0;
    while((i < idx-1)&&(p->next)!=NULL)
    {
      p = p->next;
      i++;
    }
    Node *new = node_new(data1,data2);
    new->next = p->next;
    p->next = new;
  }
}
