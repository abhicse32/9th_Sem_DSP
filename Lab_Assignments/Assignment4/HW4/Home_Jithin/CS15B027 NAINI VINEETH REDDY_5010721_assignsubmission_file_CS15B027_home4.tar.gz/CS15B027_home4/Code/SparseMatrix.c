#include "SparseMatrix.h"
#include<stdio.h>
#include<stdlib.h>
#include<limits.h>
Matrix add(Matrix a, Matrix b)           //adding two sparse matrices
{
	Matrix A;
    LList **listptr1 = a.row_lst;
    int r1 = a.n_rows;
    LList **listptr2 = b.row_lst;
    int r2 = b.n_rows;
    A.n_rows = r1;
	LList **listptr3 = (LList**)malloc((sizeof(LList*)*r1));       //declaring a new ptr
    int i;
    for(i=0;i<r1;i++)
    {
      listptr3[i] = llist_new();    
    }
      A.row_lst = listptr3;
      for(i=0;i<r1;i++)                    // doing a merge sort type algorithm
      {
        while((listptr1[i]->head != NULL) && (listptr2[i]->head != NULL))
        {
           int col1 = (listptr1[i]->head)->col_ind;
           int col2 = (listptr2[i]->head)->col_ind;
           int a1 = (listptr1[i]->head)->val;
           int a2 = (listptr2[i]->head)->val;
           if(col1<col2)
           {
             llist_append(listptr3[i],col1,a1);
             (listptr1[i]->head) = (listptr1[i]->head)->next;
           }
            if(col1>col2)
           {
             llist_append(listptr3[i],col2,a2);
             (listptr2[i]->head) = (listptr2[i]->head)->next;
           }
            if(col1==col2)
           {
             llist_append(listptr3[i],col1,a1+a2);
             (listptr1[i]->head) = (listptr1[i]->head)->next;
             (listptr2[i]->head) = (listptr2[i]->head)->next;
           }
       }
           while(listptr1[i]->head != NULL)
           {
             int col1 = (listptr1[i]->head)->col_ind;
             int a1 = (listptr1[i]->head)->val;
             llist_append(listptr3[i],col1,a1);
             (listptr1[i]->head) = (listptr1[i]->head)->next;
           }
           while(listptr2[i]->head != NULL)
           {
             int col2 = (listptr2[i]->head)->col_ind;
             int a2 = (listptr2[i]->head)->val;
             llist_append(listptr3[i],col2,a2);
             (listptr2[i]->head) = (listptr2[i]->head)->next;
           }
      }
   return A;                              // returning the matrix
}
Matrix subtract(Matrix a, Matrix b)          //subracting b from matrix a
{
	Matrix A;
    LList **listptr1 = a.row_lst;
    int r1 = a.n_rows;
    LList **listptr2 = b.row_lst;
    int r2 = b.n_rows;
    A.n_rows = r1;
	LList **listptr3 = (LList**)malloc((sizeof(LList*)*r1));       //declaring a new ptr
    int i;
    for(i=0;i<r1;i++)
    {
      listptr3[i] = llist_new();
    }
      A.row_lst = listptr3;
      for(i=0;i<r1;i++)                                      // doing a merge sort type algorithm
      {
        while((listptr1[i]->head != NULL) &&(listptr2[i]->head != NULL))
        {
           int col1 = (listptr1[i]->head)->col_ind;
           int col2 = (listptr2[i]->head)->col_ind;
           int a1 = (listptr1[i]->head)->val;
           int a2 = (listptr2[i]->head)->val;
           if(col1<col2)
           {
             llist_append(listptr3[i],col1,a1);
             (listptr1[i]->head) = (listptr1[i]->head)->next;
           }
           else if(col1>col2)
           {
             llist_append(listptr3[i],col2,-a2);
             (listptr2[i]->head) = (listptr2[i]->head)->next;
           }
           else
           {
             llist_append(listptr3[i],col1,a1-a2);
             (listptr1[i]->head) = (listptr1[i]->head)->next;
             (listptr2[i]->head) = (listptr2[i]->head)->next;
           }
        }
           while(listptr1[i]->head != NULL)
           {
             int col1 = (listptr1[i]->head)->col_ind;
             int a1 = (listptr1[i]->head)->val;
             llist_append(listptr3[i],col1,a1);
             (listptr1[i]->head) = (listptr1[i]->head)->next;
           }
           while(listptr2[i]->head != NULL)
           {
             int col2 = (listptr2[i]->head)->col_ind;
             int a2 = (listptr2[i]->head)->val;
             llist_append(listptr3[i],col2,-a2);
             (listptr2[i]->head) = (listptr2[i]->head)->next;
           }
      }
   return A;                              // returning the matrix
}
Matrix matrix_vect_multiply(Matrix mat, Matrix vect)               //multiplying a matrix with vector
{
	Matrix A;
    LList **listptr1 = mat.row_lst;
    int r1 = mat.n_rows;
    LList **listptr2 = vect.row_lst;
    int r2 = vect.n_rows;
    A.n_rows = r1;  
	LList **listptr3 = (LList**)malloc((sizeof(LList*)*r1));         //declaring a new ptr
    int i;
    for(i=0;i<r1;i++)
    {
      listptr3[i] = llist_new();        //initialising
    }
      A.row_lst = listptr3;
      for(i=0;i<r1;i++)
      {
        int s=0;                                                  // s for temporary storage 
        Node* p = listptr1[i]->head;
        while(p != NULL)
        {
           int col1 = p->col_ind;
           int a1 = p->val;
           Node *q = (listptr2[col1]->head);
           if(q !=NULL)
           {
              s+=a1*(q->val);
           }
              p=p->next;
        }
           llist_append(listptr3[i],0,s);                      // appending
      }
   return A;                              // returning the matrix
}
