ulimit -m 200000
ulimit -v 200000
./executables/q3 < ../../testcases/input/q3/19 > result.delme
