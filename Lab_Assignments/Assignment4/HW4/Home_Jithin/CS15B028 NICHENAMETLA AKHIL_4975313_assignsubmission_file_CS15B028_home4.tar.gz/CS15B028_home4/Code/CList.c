#include "CList.h"
#include <stdio.h>
#include <stdlib.h>
CNode* cnode_new(int data)
{
  CNode*p = (CNode*)malloc(sizeof(CNode));
  p->data = data;
  p->next = NULL;
  return p;
}
CList* clist_new()
{
   CList*lst = (CList*)malloc(sizeof(CList));
   lst->head = NULL;
   return lst;
}
int clist_size( CList* lst )
{
   if(lst->head==NULL)
   {
      return 0;
   }
   int s=1;
   CNode*p;
   p=(lst->head)->next;
   while(p!=lst->head)
   {
      s++;
      p=p->next;
   }
   return s;  
}
void clist_print( CList* lst )
{
   if(lst->head==NULL) return;
   printf("%d ",(lst->head)->data);
   CNode*p;
   p=(lst->head)->next;
   while(p!=lst->head)
   {
      printf("%d ",p->data);
      p=p->next;
   }
   printf("\n");
}
int clist_get( CList* lst, int idx )
{
	if(idx < 0 || idx > clist_size(lst)) return -1;
   CNode*p;
   p=lst->head;
   int i;
   for(i=0;p!=NULL&&i<idx;i++)
   {
      p=p->next;
   }
   return p->data;
}
void clist_append( CList* lst, int data )
{
   CNode*p;
   p=lst->head;
   if(lst->head==NULL)
   {
      CNode*p1=cnode_new(data);
      lst->head=p1;
      p1->next=lst->head;
      return;
   }
   while(p->next!=lst->head)
   {
      p=p->next;
   }
   CNode*p1=cnode_new(data);
   p->next=p1;
   p1->next=lst->head;

}
void clist_prepend(CList *lst,int data)
{
   if(lst->head == NULL)
   {
      CNode*p1 = cnode_new(data);
      lst->head = p1;
      p1->next = p1;
      return;
   }
   CNode *p;
   p = lst->head;
   while(p->next != lst->head)
   {
      p = p->next;
   }
   CNode*p1 = cnode_new(data);
   p1->next = lst->head;
   lst->head = p1;
   p->next = lst->head;
}
void clist_insert( CList* lst, int idx, int data )
{
	if(idx < 0 || idx > clist_size(lst)) return;
   if(lst->head==NULL)
   {
      clist_append(lst,data);
      return;
   }
   if(idx==0)
   {
      clist_prepend(lst,data);
      return;
   }
   CNode*p;
   p=lst->head;
   int i;
   for(i=0;p!=NULL&&i<idx-1;i++)
   {
     p=p->next;
   }
   CNode*p1=cnode_new(data);
   p1->next=p->next;
   p->next=p1;
}
void clist_remove_last( CList* lst )
{
   CNode*p;
   p=lst->head;
   while((p->next)->next != lst->head)
   {
      p=p->next;
   }
   p->next=lst->head;
}
void clist_remove_first( CList* lst )
{
   CNode*p;
   p=lst->head;
   while(p->next!=lst->head)
   {
      p=p->next;
   }
   lst->head=(lst->head)->next;
   p->next=lst->head;
}
void clist_remove(CList*lst,int idx)
{
	if(idx < 0 || idx > clist_size(lst)) return;
   if(idx==0)
   {
      clist_remove_first(lst);
      return;
   }
   if(idx == clist_size(lst))
   {
   	clist_remove_last(lst);
   	return;
   }
   CNode*p;
   p=lst->head;
   int i;
   for(i=0;p!=NULL&&i<idx-1;i++)
   {
      p=p->next;
   }
   p->next=(p->next)->next;
}
void clist_reverse(CList*lst)
{
	if(lst->head==NULL) return;
	else if(lst->head->next==lst->head) return;
   CNode*p,*c,*n;
   p=NULL;
   c=lst->head;
   while((c->next)!=lst->head)
   {
      n=c->next;
      c->next=p;
      p=c;
      c=n;
   }
   c->next=p;
   p=c;
   lst->head=c;
   CNode*ptr;
   ptr=lst->head;
   while(ptr->next!=NULL)
   {
      ptr=ptr->next;
   }
   ptr->next=lst->head;
}

  

