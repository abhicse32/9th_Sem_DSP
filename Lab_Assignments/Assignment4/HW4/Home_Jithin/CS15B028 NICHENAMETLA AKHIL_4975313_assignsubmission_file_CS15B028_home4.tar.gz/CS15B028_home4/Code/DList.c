#include "DList.h"
#include <stdio.h>
#include <stdlib.h>
DNode* dnode_new( int data)
{
   DNode*p=(DNode*)malloc(sizeof(DNode));
   p->data=data;
   p->next=NULL;
   p->prev=NULL;
   return p; 
}
DList* dlist_new()
{
   DList*lst=(DList*)malloc(sizeof(DList));
   lst->head=NULL;
   return lst;
}
int dlist_size( DList* lst )
{
   int s=0;
   DNode*p;
   p=lst->head;
   while(p!=NULL)
   {
      s++;
      p=p->next;
   }
  return s;
}
void dlist_print( DList* lst )
{
   DNode*p;
   p=lst->head;
   while(p!=NULL)
   {
      printf("%d ",p->data);
      p=p->next;
   }
  printf("\n");
}
int dlist_get( DList* lst, int idx )
{
   if(idx >= dlist_size(lst) || idx < 0) return -1;
   if(lst->head == NULL) return -1;
   DNode*p;
   p=lst->head;
   int i;
   for(i=0;i<idx;i++)
   {
      p=p->next;
   } 	
   return p->data;
}
void dlist_append( DList* lst, int data )
{   
    DNode*p;
    p=lst->head;
    if(lst->head==NULL)
    {
       DNode*p1=dnode_new(data);
       lst->head=p1;
       return;
    }   
    while(p->next!=NULL)
    {
       p=p->next;
    }
    DNode*p1=dnode_new(data);
    p->next=p1;
    p1->prev=p;
}
void dlist_prepend( DList* lst, int data )
{
    DNode*p = dnode_new(data);
    if(lst->head == NULL)
    {
       lst->head = p;
       return;
    }
    p->next=lst->head;
    lst->head = p;
    (p->next)->prev = p;
}
void dlist_insert(DList *lst, int idx,int data)
{
   if(idx > dlist_size(lst)||idx < 0) return;
    DNode *p;
    p = lst->head;
    int i;
    if(idx == 0)
    {
       dlist_prepend(lst,data);
       return;
    }
    if(idx == dlist_size(lst))
    {
    	  dlist_append(lst,data);
    	  return;
    }
    for(i = 0;i < idx-1; i++)
    {
       p=p->next;
    }
   DNode*p1=dnode_new(data);
   p1->next=p->next;
   (p->next)->prev=p1;
   p1->prev=p;
   p->next=p1;
}
void dlist_remove_last( DList* lst )
{
   if(lst->head==NULL) return ;
   DNode*p;
   p = lst->head;
   if(dlist_size(lst) == 1) lst->head = NULL;
   while((p->next)->next!=NULL)
   {
      p=p->next;
   }
   free(p->next);
   p->next = NULL;
}
void dlist_remove_first( DList* lst )
{
	if(lst->head == NULL) return;
	DNode *p = lst->head;
 	lst->head = (lst->head)->next;
 	free(p);
}
void dlist_remove( DList* lst, int idx )
{
   if(idx > dlist_size(lst) || idx < 0) return;
   if(lst->head==NULL) return;
   int i;
   DNode*p;
   p=lst->head;
   if(idx==0)
   {
      dlist_remove_first(lst);
      return;
   }
   if(idx==dlist_size(lst)-1)
   {
      dlist_remove_last(lst);
      return;
   }
   for(i=0;i<idx-1;i++)
   {
      p=p->next;
   }
  p->next=(p->next)->next;
  (p->next)->prev=p;
}

void dlist_reverse(DList*lst)
{
	if(lst->head == NULL) return;
   DNode*p,*c,*n;
   c=lst->head;
   p=NULL;
   while(c->next!=NULL)
   {
      n=c->next;
      c->next=p;
      c->prev=n;
      p=c;
      c=n;
   }
   c->next=p;
   c->prev=NULL;
   lst->head=c;
}
/*int main()
{

   DList *lst=dlist_new();
   int n,i,x;
   scanf("%d",&n);
   for(i=0;i<n;i++)
   {
      scanf("%d",&x);
      dlist_prepend(lst,x);
   }
   dlist_insert(lst,5,9000);
   dlist_print(lst);
   printf("%d\n",dlist_get(lst,6));
   dlist_insert(lst,0,-32);
   dlist_print(lst);
}*/  
    


   
