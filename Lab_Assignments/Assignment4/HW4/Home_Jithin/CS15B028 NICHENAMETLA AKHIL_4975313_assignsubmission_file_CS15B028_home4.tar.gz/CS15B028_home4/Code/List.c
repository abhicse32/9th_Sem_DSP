#include "List.h"
#include <stdio.h>
#include <stdlib.h>

Node* node_new( int data1, int data2)
{
   Node*p=(Node*)malloc(sizeof(Node));
   p->col_ind=data1;
   p->val=data2;
   p->next=NULL;
   return p;
}
LList* llist_new()
{
   LList*lst=(LList*)malloc(sizeof(LList));
   lst->head=NULL;
   return lst;
}
int llist_size( LList* lst )
{
   Node* p;
   p = (lst->head);
   int size = 0;
   while(p!=NULL)
   {
      size++;
      p = p->next;
   }
   return size;
}
void llist_print( LList* lst)
{
   Node* p;
   p = (lst->head);
   while(p!=NULL)
   {
      printf("%d ",p->val);
      p = p->next;
   }
   printf("\n");
}
int llist_get( LList* lst, int idx )
{
    Node*p;
    p=lst->head;
    int i;
    for(i=0;i<idx;i++)
    {
       p=p->next;
    }
    return p->val;
}
void llist_append( LList* lst, int data1, int data2)
{
    Node* p;
    p = lst->head;
    if(lst->head != NULL)
    {
       while(p->next != NULL)
       {
           p = p->next;
       }
       Node *p1 = node_new(data1,data2);
       p->next = p1;
    }
    else
    {
       Node *p1 = node_new(data1,data2);
       lst->head = p1;
    }
}
void llist_prepend( LList* lst, int data1, int data2)
{
   Node *ptr = node_new(data1,data2);
   ptr->next = lst->head;
   lst->head = ptr;
}
void llist_insert( LList* lst, int idx, int data1, int data2)
{
  if(idx == 0)
  {
    llist_prepend(lst,data1,data2);
  }
  else
  {
    	Node* p;
    	p = (lst->head);
    	int i = 0;
    	while((i < idx-1)&&(p->next)!=NULL)
    	{
   		 p = p->next;
    		 i++;
    	}
    	Node *new = node_new(data1,data2);
    	new->next = p->next;
    	p->next = new;
  }
}

   

