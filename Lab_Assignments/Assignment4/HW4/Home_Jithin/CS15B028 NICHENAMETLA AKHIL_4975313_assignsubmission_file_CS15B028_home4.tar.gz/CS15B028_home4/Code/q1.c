#include <stdio.h>
#include <stdlib.h>
#include "SparseMatrix.h"
int main()
{
    int choice,i,x;
    scanf("%d",&choice);
    while(choice != -1)
    {
    	  int m,n;
        if(choice == 1||choice == 2)
        {
            Matrix *mat1 = (Matrix*)malloc(sizeof(Matrix));
            Matrix *mat2 = (Matrix*)malloc(sizeof(Matrix));
            scanf("%d %d",&m,&n);
	     	   mat1->n_rows = m;
	         mat2->n_rows = m;
            mat1->row_lst = (LList**)malloc(m*sizeof(LList*));
            mat2->row_lst = (LList**)malloc(m*sizeof(LList*));
            int i,x;
            for(i = 0;i < m; i++)  mat1->row_lst[i] = llist_new();
            for(i = 0;i < m; i++)  mat2->row_lst[i] = llist_new();
            for(i = 0;i < m; i++)
            {
                int j;
                for(j = 0;j < n; j++)
                {
                    scanf("%d",&x);
                    if(x != 0) llist_append(mat1->row_lst[i],j,x);
                }
            }
            for(i = 0;i < m; i++)
            {
                int j;
                for(j = 0;j < n; j++)
                {
                    scanf("%d",&x);
                    if(x != 0) llist_append(mat2->row_lst[i],j,x);
                }
            }
            if(choice == 1)
            {
                Matrix mat3;
                mat3 = add(mat1,mat2);
                print(&mat3);
            }
            else if(choice == 2)
            {
                Matrix mat4;
                mat4=subtract(mat1,mat2);
                print(&mat4);
            }
        }
        else if(choice == 3)
        {
            Matrix *mat1 = (Matrix*)malloc(sizeof(Matrix));        
            scanf("%d %d",&m,&n);
            mat1->n_rows = m;
            mat1->row_lst = (LList**)malloc(m*sizeof(LList*));
            Matrix *vect = (Matrix*)malloc(sizeof(Matrix)); 
            vect->n_rows = n;  
            vect->row_lst = (LList**)malloc(n*sizeof(LList*));
            for(i = 0;i < m; i++)
            {
                 mat1->row_lst[i] = llist_new();
            }
            for(i = 0;i < n; i++)
            {
                vect->row_lst[i] = llist_new();
            }
            for(i = 0;i < m; i++)
            {
                int j;
                for(j = 0;j < n; j++)
                {
                    scanf("%d",&x);
                    if(x != 0) llist_append(mat1->row_lst[i],j,x);
                }
            }
            for(i = 0;i < n; i++)
            { 
                scanf("%d",&x);
                llist_append(vect->row_lst[i],0,x);
            }
            Matrix mat5;
            mat5 = matrix_vect_multiply(mat1,vect);
            print(&mat5);
         }
         scanf("%d ",&choice);
    }   
}   
