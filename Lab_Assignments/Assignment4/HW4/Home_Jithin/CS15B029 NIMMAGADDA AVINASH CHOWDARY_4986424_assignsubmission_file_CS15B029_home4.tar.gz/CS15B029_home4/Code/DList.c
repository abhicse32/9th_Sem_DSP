#include<stdio.h>
#include<stdlib.h>
#include "DList.h"
#include<limits.h>

// Creating a new node with next set to NULL
DNode* dnode_new( int data)
{
  DNode*p=(DNode*)malloc(sizeof(DNode));
   p->data=data;
   p->next=NULL;
   p->prev=NULL;
   return p; 
}

// Creating an empty list (head is NULL)
  
 DList* dlist_new()
{
  DList* list=(DList*)malloc(sizeof(DList));
  list->head = NULL;
  return list;
}

// Traversing the linked list and returning its size
 
 int dlist_size( DList* lst )
      {DNode * p;
       if(lst->head==NULL)
         {return 0;}
       else
         {
          p=lst->head;
         }
       
       int s=1;   
          while(p->next!=NULL)
            {
             s++;
             p=p->next;
            }
          
        return s;      
       }
       
 //Traversing the linked list and printing its elements
 
 void dlist_print( DList* lst )
{
    DNode* temp;
    temp = (lst->head);
   while(temp!=NULL)
   {
      printf("%d ",temp->data);
      temp = temp->next;
   }
  printf("\n");
}

 //get the element at position @idx
 
 int dlist_get( DList* lst, int idx )
{
     int s=dlist_size(lst );
      
       if(idx>=s || idx<0)
       {
        return -1;
       }
       else{
       DNode* temp=lst->head;
       int i=0;
       while(i<idx){
         temp = temp->next;
         i++;
      }
      return temp->data;
      }
 }
      
 // Adding a new element at the end of the list
 
 void dlist_append( DList* lst, int data ){
        DNode*new=dnode_new(data);     
        DNode* p;
        p=lst->head;
        if(lst->head==NULL){
                lst->head=new;
                new->next=NULL;
                return;
        }
        while(p->next!=NULL){
                p=p->next;
        }
        p->next=new;
        new->next=NULL;
        new->prev=p;
        return;
}

// Adding a new element at the beginning of the list
 
 void dlist_prepend( DList* lst, int data )
{
    DNode*p=dnode_new(data);
    if(lst->head==NULL)
    {
      lst->head=p;
      return;
      }
    p->next=lst->head;
    lst->head=p;
    p->next->prev=p;
    p->prev=NULL;
}
// Adding a new element at the @idx index
 
void dlist_insert(DList *lst, int idx,int data)
{
   if(idx > dlist_size(lst)||idx < 0) return;
    DNode *p;
    p = lst->head;
    int i;
    if(idx == 0)
    {
       dlist_prepend(lst,data);
       return;
    }
    if(idx == dlist_size(lst))
    {
    	  dlist_append(lst,data);
    	  return;
    }
    for(i = 0;i < idx-1; i++)
    {
       p=p->next;
    }
   DNode*p1=dnode_new(data);
   p1->next=p->next;
   (p->next)->prev=p1;
   p1->prev=p;
   p->next=p1;
}

// Removing an element from the end of the list 

 void dlist_remove_last( DList* lst )
      {DNode * p=lst->head;
       if(lst->head!=NULL)
     {    if(p->next==NULL)
            lst->head=NULL;
          else
          {
          while((p->next)->next!=NULL)
               p=p->next;

          p->next=NULL;
          }
         }
       }

// Removing an element from the beginning of the list
 
void dlist_remove_first( DList* lst )
{
   lst->head = (lst->head)->next;
   (lst->head)->prev = NULL;
}

 // Removing an element from an arbitrary @idx position in the list
  
void dlist_remove( DList* lst, int idx )
{
   if(idx > dlist_size(lst) || idx < 0) return;
   if(lst->head==NULL) return;
   int i;
   DNode*p;
   p=lst->head;
   if(idx==0)
   {
      dlist_remove_first(lst);
      return;
   }
   if(idx==dlist_size(lst)-1)
   {
      dlist_remove_last(lst);
      return;
   }
   for(i=0;i<idx-1;i++)
   {
      p=p->next;
   }
  p->next=(p->next)->next;
  (p->next)->prev=p;
}

 //reversing the linked list
void dlist_reverse(DList*lst)
{
 if (lst->head == NULL || (lst->head) == NULL)
 {return ;
 }
 DNode *p1 = lst->head,*p2;
 while(p1->next !=NULL){
       p2 = p1->next;
       p1->next=p1->prev;
       p1->prev=p2;
       p1 = p1->prev;
 }
  p1->next = p1->prev;
  p1->prev = NULL;
  lst->head = p1;
   
}      



