#include<stdio.h>
#include<stdlib.h>
#include "SparseMatrix.h"

Matrix add(Matrix p,Matrix q)
{
  Matrix r;
  r.n_rows = p.n_rows;
  r.row_lst = (LList **)malloc(sizeof(LList *)*(p.n_rows));
  int j=0;
  
  for(j=0;j < p.n_rows;j++){
     (r.row_lst[j])=llist_new();
  }
  Node *cur1;
  Node *cur2;
  LList *cur3;
  int k=0;
 while(k<p.n_rows){
    cur1 = (p.row_lst[k])->head;
    cur2 = (q.row_lst[k])->head;
    cur3 = r.row_lst[k];
    while((cur1!=NULL) && (cur2!=NULL))
   {
     if(cur1 -> col_ind == cur2 -> col_ind)
     {
       llist_append(cur3 , (cur1->col_ind) , (cur1->val + cur2->val));
       cur1 = cur1->next;
       cur2 = cur2->next;
     }
     else if((cur1->col_ind)<(cur2->col_ind))
     {
       llist_append(cur3 , (cur1->col_ind) , (cur1->val));
       cur1 = cur1->next;
     }
     else
     {
       llist_append(cur3 , (cur2->col_ind) , (cur2->val));
       cur2 = cur2->next;
     }
   }
    if(cur1 == NULL)
      {
        while(cur2!=NULL)
        {
          llist_append(cur3 , (cur2->col_ind) , (cur2->val));
          cur2 = cur2->next;
        }
      }
    if(cur2 == NULL)
      {
        while(cur1!=NULL)
       {
         llist_append(cur3 , (cur1->col_ind) , (cur1->val));
         cur1 = cur1->next;
       }
      }
      k++;
      
   }   
    return r;
 }
 
 Matrix subtract(Matrix p,Matrix q)
{
  Matrix r;
  r.n_rows = p.n_rows;
  r.row_lst = (LList **)malloc(sizeof(LList *)*(p.n_rows));
  int j;
  
  for(j=0;j < p.n_rows;j++){
     (r.row_lst[j])=llist_new();
  }
  Node *cur1;
  Node *cur2;
  LList *cur3;
  int k=0;
  while(k < p.n_rows){
    cur1 = (p.row_lst[k])->head;
    cur2 = (q.row_lst[k])->head;
    cur3 = r.row_lst[k];
    while((cur1!=NULL) && (cur2!=NULL))
   {
     if(cur1 -> col_ind == cur2 -> col_ind)
     {
       llist_append(cur3 , (cur1->col_ind) , (cur1->val - cur2->val));
       cur1 = cur1->next;
       cur2 = cur2->next;
     }
     else if((cur1->col_ind)<(cur2->col_ind))
     {
       llist_append(cur3 , (cur1->col_ind) , (cur1->val));
       cur1 = cur1->next;
     }
     else
     {
       llist_append(cur3 , (cur2->col_ind) , -(cur2->val));
       cur2 = cur2->next;
     }
   }
    if(cur1 == NULL)
      {
        while(cur2!= NULL)
        {
          llist_append(cur3 , (cur2->col_ind) , -(cur2->val));
          cur2 = cur2->next;
        }
      }
    if(cur2 == NULL)
      {
        while(cur1!=NULL)
       {
         llist_append(cur3 , (cur1->col_ind) , (cur1->val));
         cur1 = cur1->next;
       }
      }
      k++;
      
   }   
    return r;
 }
 
 Matrix matrix_vect_multiply(Matrix mat, Matrix vect)
 {
  Matrix pro;
  pro.n_rows = mat.n_rows;
  int a=0;
  int b=0;
  int s=0;
   pro.row_lst = (LList **)malloc(sizeof(LList *)*(mat.n_rows));
   for(a=0;a<mat.n_rows;a++)
   {
     (pro.row_lst[a]) = llist_new();
		
	}	
    Node *cur1;
  Node *cur2;
  LList *cur3;
    for(a=0;a<mat.n_rows;a++)
  {
    cur1 = (mat.row_lst[a])->head;
    cur3 = pro.row_lst[a];
     for(b=0;cur1!=NULL;b++)
   {
     cur2 = (vect.row_lst[b])->head;
     if((cur1->col_ind) == b)
     {
        s = s + (cur1->val)*(cur2->val);
        cur1 = cur1->next;
     }
   }
   llist_append(cur3 , 0 , s);
   s = 0;
   
 }
  return pro;
}      
         
         
      
    
       
  
    
