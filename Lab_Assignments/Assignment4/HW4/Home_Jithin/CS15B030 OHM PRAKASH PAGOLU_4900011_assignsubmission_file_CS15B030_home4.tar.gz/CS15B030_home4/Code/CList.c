#include <stdio.h>
#include <stdlib.h>
#include "CList.h"

CNode* cnode_new(int data) {
	CNode* new = (CNode*) malloc(sizeof(CNode));
	new->data = data;
	new->next = NULL;
	return new;
}

CList* clist_new() {
	CList* new = (CList*) malloc(sizeof(CList));
	new->head = NULL;
	return new;
}

int clist_size(CList* lst) {
	CNode* tmp = lst->head;
	if (lst->head == NULL) {
		return 0;
	}
	int size = 1;
	while (tmp->next != lst->head) {
		size++;
		tmp = tmp->next;
	}
	return size;
}

void clist_print(CList* lst) {
	CNode* tmp = lst->head;
	if (lst->head == NULL) {
		return;
	}
	printf("%d ", tmp->data);
	while (tmp->next != lst->head) {
		tmp = tmp->next;
		printf("%d ", tmp->data);
	}
	printf("\n");
}

int clist_get(CList* lst, int idx) {
	int size = clist_size(lst);
	if (idx >= size || idx < 0) {
		return -1;
	}
	CNode* tmp = lst->head;
	int i = 0;
	while (i < idx) {
		tmp = tmp->next;
		i++;
	}
	return tmp->data;
}

void clist_append(CList* lst, int data) {
	CNode* new = cnode_new(data);
	if (lst->head == NULL) {
		lst->head = new;
		new->next = new;
		return;
	}
	new->next = lst->head;
	CNode* tmp = lst->head;
	while (tmp->next != lst->head) {
		tmp = tmp->next;
	}
	tmp->next = new;
}

void clist_prepend(CList* lst, int data) {
	CNode* new = cnode_new(data);
	if (lst->head == NULL) {
		lst->head = new;
		new->next = new;
		return;
	}
	new->next = lst->head;
	CNode* tmp = lst->head;
	while (tmp->next != lst->head) {
		tmp = tmp->next;
	}
	tmp->next = new;
	lst->head = new;
}

void clist_insert(CList* lst, int idx, int data) {
	CNode* new = cnode_new(data);
	if (idx > clist_size(lst)) {
		return;
	}
	if (idx == 0) {
		clist_prepend(lst, data);
		return;
	}
	CNode* tmp = lst->head;
	int i = 0;
	while (i < idx - 1) {
		tmp = tmp->next;
		i++;
	}
	new->next = tmp->next;
	tmp->next = new;
}

void clist_remove_last(CList* lst) {
	CNode* tmp = lst->head;
	if (tmp == NULL) {
		return;
	} else if (tmp->next == tmp) {
		lst->head = NULL;
		free(tmp);
		return;
	}
	while (tmp->next->next != lst->head) {
		tmp = tmp->next;
	}
	CNode* tmp1 = tmp->next;
	tmp->next = lst->head;
	free(tmp1);
}

void clist_remove_first(CList* lst) {
	CNode* tmp = lst->head;
	if (tmp == NULL) {
		return;
	} else if (tmp->next == tmp) {
		lst->head = NULL;
		free(tmp);
		return;
	}
	while (tmp->next != lst->head) {
		tmp = tmp->next;
	}
	tmp->next = lst->head->next;
	tmp = lst->head;
	lst->head = tmp->next;
	free(tmp);
}

void clist_remove(CList* lst, int idx) {
	CNode* tmp = lst->head;
	if (idx >= clist_size(lst)) {
		return;
	}
	if (idx == 0) {
		clist_remove_first(lst);
		return;
	}
	int i = 0;
	while (i < idx - 1) {
		tmp = tmp->next;
		i++;
	}
	CNode* tmp1 = tmp->next;
	tmp->next = tmp->next->next;
	free(tmp1);
}

void clist_reverse(CList* lst) {
	if (lst->head == NULL || lst->head == lst->head->next) {
		return;
	}
	CNode *prv = lst->head, *cur = prv->next, *nxt = cur;
	while (cur->next != lst->head) {
		nxt = cur->next;
		cur->next = prv;
		prv = cur;
		cur = nxt;
	}
	cur->next = prv;
	lst->head->next = cur;
	lst->head = cur;
}
