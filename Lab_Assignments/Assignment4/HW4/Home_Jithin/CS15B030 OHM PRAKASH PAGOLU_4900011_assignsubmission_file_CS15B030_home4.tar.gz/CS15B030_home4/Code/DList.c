#include <stdio.h>
#include <stdlib.h>
#include "DList.h"

DNode* dnode_new(int data) {
	DNode* new = (DNode*) malloc(sizeof(DNode));
	new->data = data;
	new->prev = new->next = NULL;
	return new;
}

DList* dlist_new() {
	DList* new = (DList*) malloc(sizeof(DList));
	new->head = NULL;
	return new;
}

int dlist_size(DList* lst) {
	DNode* tmp = lst->head;
	if (lst->head == NULL) {
		return 0;
	}
	int size = 1;
	while (tmp->next != NULL) {
		size++;
		tmp = tmp->next;
	}
	return size;
}

void dlist_print(DList* lst) {
	DNode* tmp = lst->head;
	if (lst->head == NULL) {
		return;
	}
	printf("%d ", tmp->data);
	while (tmp->next != NULL) {
		tmp = tmp->next;
		printf("%d ", tmp->data);
	}
	printf("\n");
}

int dlist_get(DList* lst, int idx) {
	int size = dlist_size(lst);
	if (idx >= size || idx < 0) {
		return -1;
	}
	DNode* tmp = lst->head;
	int i = 0;
	while (i < idx) {
		tmp = tmp->next;
		i++;
	}
	return tmp->data;
}

void dlist_append(DList* lst, int data) {
	DNode* new = dnode_new(data);
	if (lst->head == NULL) {
		lst->head = new;
		return;
	}
	DNode* tmp = lst->head;
	while (tmp->next != NULL) {
		tmp = tmp->next;
	}
	tmp->next = new;
	new->prev = tmp;
}

void dlist_prepend(DList* lst, int data) {
	DNode* new = dnode_new(data);
	if (lst->head == NULL) {
		lst->head = new;
		return;
	}
	new->next = lst->head;
	lst->head->prev = new;
	lst->head = new;
}

void dlist_insert(DList* lst, int idx, int data) {
	DNode* new = dnode_new(data);
	if (idx > dlist_size(lst)) {
		return;
	}
	if (idx == 0) {
		dlist_prepend(lst, data);
		return;
	}
	DNode* tmp = lst->head;
	int i = 0;
	while (i < idx - 1) {
		tmp = tmp->next;
		i++;
	}
	new->next = tmp->next;
	tmp->next = new;
	new->prev = tmp;
	if(new->next != NULL){
	    new->next->prev = new;
	}
}

void dlist_remove_last(DList* lst) {
	DNode* tmp = lst->head;
	if (tmp == NULL) {
		return;
	} else if (tmp->next == NULL) {
		lst->head = NULL;
		free(tmp);
		return;
	}
	while (tmp->next->next != NULL) {
		tmp = tmp->next;
	}
	DNode* tmp1 = tmp->next;
	tmp->next = NULL;
	free(tmp1);
}

void dlist_remove_first(DList* lst) {
	DNode* tmp = lst->head;
	if (tmp == NULL) {
		return;
	} else if (tmp->next == NULL) {
		lst->head = NULL;
		free(tmp);
		return;
	}
	tmp = tmp->next;
	tmp->prev = NULL;
	tmp = lst->head;
	lst->head = tmp->next;
	free(tmp);
}

void dlist_remove(DList* lst, int idx) {
	DNode* tmp = lst->head;
	if (idx >= dlist_size(lst)) {
		return;
	}
	if (idx == 0) {
		dlist_remove_first(lst);
		return;
	}
	int i = 0;
	while (i < idx - 1) {
		tmp = tmp->next;
		i++;
	}
	DNode* tmp1 = tmp->next;
	tmp->next = tmp->next->next;
	if (tmp->next != NULL) {
		tmp->next->prev = tmp;
	}
	free(tmp1);
}

void dlist_reverse(DList* lst) {
	if (lst->head == NULL || lst->head->next == NULL) {
		return;
	}
	DNode *tmp1 = lst->head,*tmp2;
	while(tmp1->next != NULL){
		tmp2 = tmp1->next;
		tmp1->next = tmp1->prev;
		tmp1->prev = tmp2;
		tmp1 = tmp1->prev;
	}
	tmp1->next = tmp1->prev;
	tmp1->prev = NULL;
	lst->head = tmp1;
}
