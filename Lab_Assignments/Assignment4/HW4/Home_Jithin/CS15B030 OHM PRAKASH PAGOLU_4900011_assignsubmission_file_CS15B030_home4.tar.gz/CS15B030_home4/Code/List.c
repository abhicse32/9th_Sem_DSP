#include <stdio.h>
#include <stdlib.h>
#include "List.h"

Node* node_new(int data1, int data2) {
	Node *node = (Node*) malloc(sizeof(Node));
	node->col_ind = data1;
	node->val = data2;
	node->next = NULL;
	return node;
}

LList* llist_new() {
	LList *list = (LList*) malloc(sizeof(LList));
	list->head = NULL;
	return list;
}

int llist_size(LList* lst) {
	Node *tmp = lst->head;
	int size = 0;
	while (tmp != NULL) {
		size++;
		tmp = tmp->next;
	}
	return size;
}

void llist_print(LList* lst) {
	Node *tmp = lst->head;
	while (tmp != NULL) {
		printf("%d ", tmp->val);
		tmp = tmp->next;
	}
	printf("\n");
}

Node* llist_get(LList* lst, int idx) {
	Node *tmp = lst->head;
	int i = 0;
	int size = llist_size(lst);
	if (idx >= size || idx < 0) {
		return NULL;
	}
	while (i != idx) {
		tmp = tmp->next;
		i++;
	}
	return tmp;
}

void llist_append(LList* lst, int data1, int data2) {
	Node *new = node_new(data1, data2);
	if (lst->head == NULL) {
		lst->head = new;
		return;
	}
	Node *tmp = lst->head;
	while (tmp->next != NULL) {
		tmp = tmp->next;
	}
	tmp->next = new;
}

void llist_prepend(LList* lst, int data1, int data2) {
	Node *new = node_new(data1, data2);
	new->next = lst->head;
	lst->head = new;
}

void llist_insert(LList* lst, int idx, int data1, int data2) {
	int size = llist_size(lst);
	if (idx > size || idx < 0) {
		return;
	} else if (idx == 0) {
		llist_prepend(lst, data1, data2);
		return;
	}
	Node *new = node_new(data1, data2);
	Node *tmp = lst->head;
	int i = 0;
	while (i != idx - 1) {
		tmp = tmp->next;
		i++;
	}
	new->next = tmp->next;
	tmp->next = new;
}
