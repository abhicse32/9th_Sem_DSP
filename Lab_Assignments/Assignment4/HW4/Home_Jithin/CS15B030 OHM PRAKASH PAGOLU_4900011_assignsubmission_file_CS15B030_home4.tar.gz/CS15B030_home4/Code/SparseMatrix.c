#include <stdio.h>
#include <stdlib.h>
#include "SparseMatrix.h"

LList* add_list(LList* lst1, LList* lst2) {
	LList *lst = llist_new();
	Node* h1 = lst1->head;
	Node* h2 = lst2->head;
	while (h1 != NULL && h2 != NULL) {
		if (h1->col_ind == h2->col_ind) {
			llist_append(lst, h1->col_ind, h1->val + h2->val);
			h1 = h1->next;
			h2 = h2->next;
		} else if (h1->col_ind < h2->col_ind) {
			llist_append(lst, h1->col_ind, h1->val);
			h1 = h1->next;
		} else {
			llist_append(lst, h2->col_ind, h2->val);
			h2 = h2->next;
		}
	}
	if (h1 == NULL) {
		while (h2 != NULL) {
			llist_append(lst, h2->col_ind, h2->val);
			h2 = h2->next;
		}
	} else {
		while (h1 != NULL) {
			llist_append(lst, h1->col_ind, h1->val);
			h1 = h1->next;
		}
	}
	return lst;
}

LList* subtract_list(LList* lst1, LList* lst2) {
	LList *lst = llist_new();
	Node* h1 = lst1->head;
	Node* h2 = lst2->head;
	while (h1 != NULL && h2 != NULL) {
		if (h1->col_ind == h2->col_ind) {
			llist_append(lst, h1->col_ind, h1->val - h2->val);
			h1 = h1->next;
			h2 = h2->next;
		} else if (h1->col_ind < h2->col_ind) {
			llist_append(lst, h1->col_ind, h1->val);
			h1 = h1->next;
		} else {
			llist_append(lst, h2->col_ind, -h2->val);
			h2 = h2->next;
		}
	}
	if (h1 == NULL) {
		while (h2 != NULL) {
			llist_append(lst, h2->col_ind, -h2->val);
			h2 = h2->next;
		}
	} else {
		while (h1 != NULL) {
			llist_append(lst, h1->col_ind, h1->val);
			h1 = h1->next;
		}
	}
	return lst;
}

Matrix add(Matrix mat1, Matrix mat2) {
	Matrix *mat = (Matrix*) malloc(sizeof(Matrix));
	mat->n_rows = mat1.n_rows;
	mat->row_lst = (LList**) malloc(mat->n_rows * sizeof(LList*));
	int row = 0;
	while (row < mat1.n_rows) {
		mat->row_lst[row] = add_list(mat1.row_lst[row], mat2.row_lst[row]);
		row++;
	}
	return *mat;
}

Matrix subtract(Matrix a, Matrix b) {
	Matrix *mat = (Matrix*) malloc(sizeof(Matrix));
	mat->n_rows = a.n_rows;
	mat->row_lst = (LList**) malloc(mat->n_rows * sizeof(LList*));
	int row = 0;
	while (row < a.n_rows) {
		mat->row_lst[row] = subtract_list(a.row_lst[row], b.row_lst[row]);
		row++;
	}
	return *mat;
}

int list_multiply(LList* lst1, Matrix lst2) {
	int res = 0, row = 0;
	Node* h1 = lst1->head;
	Node* h2;
	while (row < lst2.n_rows && h1 != NULL) {
		h2 = lst2.row_lst[row]->head;
		if (h1->col_ind == row) {
			res += h1->val * h2->val;
			h1 = h1->next;
		}
		row++;
	}
	return res;
}

Matrix matrix_vect_multiply(Matrix mat, Matrix vect) {
	Matrix *matmul = (Matrix*) malloc(sizeof(Matrix));
	matmul->n_rows = mat.n_rows;
	matmul->row_lst = (LList**) malloc(matmul->n_rows * sizeof(LList*));
	int row = 0;
	while (row < mat.n_rows) {
		matmul->row_lst[row] = llist_new();
		int res = list_multiply(mat.row_lst[row], vect);
		llist_append(matmul->row_lst[row], 0, res);
		row++;
	}
	return *matmul;
}
