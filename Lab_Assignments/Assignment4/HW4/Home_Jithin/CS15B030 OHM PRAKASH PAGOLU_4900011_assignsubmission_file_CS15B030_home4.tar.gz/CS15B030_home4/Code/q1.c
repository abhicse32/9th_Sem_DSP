#include <stdio.h>
#include <stdlib.h>
#include "SparseMatrix.h"

void print_matrix(Matrix mat) {
	int i, pr;
	Node* tmp;
	for (i = 0; i < mat.n_rows; i++) {
		tmp = mat.row_lst[i]->head;
		pr = 0;
		while (tmp != NULL) {
			printf("%d ", tmp->val);
			pr = 1;
			tmp = tmp->next;
		}
		if (pr == 1) {
			printf("\n");
		}
	}
}

int main() {
	int opt;
	scanf("%d", &opt);
	Matrix mat;
	while (opt != -1) {
		int m, n;
		scanf("%d%d", &m, &n);
		Matrix mat1;
		mat1.n_rows = m;
		mat1.row_lst = (LList**) malloc(m * sizeof(LList*));
		int i, j, inp;
		for (i = 0; i < m; i++) {
			mat1.row_lst[i] = llist_new();
			for (j = 0; j < n; j++) {
				scanf("%d", &inp);
				if (inp != 0) {
					llist_append(mat1.row_lst[i], j, inp);
				}
			}
		}
		if (opt == 1 || opt == 2) {
			Matrix mat2;
			mat2.n_rows = m;
			mat2.row_lst = (LList**) malloc(m * sizeof(LList*));
			for (i = 0; i < m; i++) {
				mat2.row_lst[i] = llist_new();
				for (j = 0; j < n; j++) {
					scanf("%d", &inp);
					if (inp != 0) {
						llist_append(mat2.row_lst[i], j, inp);
					}
				}
			}
			if (opt == 1)
				mat = add(mat1, mat2);
			else
				mat = subtract(mat1, mat2);
			free(mat2.row_lst);
		} else {
			Matrix vect;
			vect.n_rows = n;
			vect.row_lst = (LList**) malloc(n * sizeof(LList*));
			for (i = 0; i < n; i++) {
				vect.row_lst[i] = llist_new();
				scanf("%d", &inp);
				llist_append(vect.row_lst[i], 0, inp);
			}
			mat = matrix_vect_multiply(mat1, vect);
			free(vect.row_lst);
		}
		print_matrix(mat);
		scanf("%d", &opt);
		free(mat1.row_lst);
		free(mat.row_lst);
	}
	return 0;
}
