//Author: Phalguna Rao Ch.
//CS15B031
#include "CList.h"
#include<stdio.h>
#include<stdlib.h>
CNode* cnode_new( int data){
	CNode* node = (CNode*) malloc(sizeof(CNode));
	node->data = data;
	node->next = NULL;
	return node;
}
CList* clist_new(){
	CList* list = (CList*) malloc(sizeof(CList));
	list->head = NULL;
	return list;
}
int clist_size( CList* lst ){
	int size = 0;
	CNode* curr;
	curr = lst->head;
	if(curr == NULL) return 0;
	else{
		while(1){
			size++;
			if(curr->next == lst->head) return size;
			else curr = curr->next;
		}
	}
}
void clist_print( CList* lst ){
	CNode* curr;
	if(lst->head != NULL){								//if head = NULL : do nothing
		for(curr = lst->head; ; curr = curr->next){		//traversing and printing 
			printf("%d ", curr->data);
			if(curr->next == lst->head) break;				//end of list
		}
	}
	printf("\n");
	fflush(stdout);
	return ;
}
int clist_get( CList* lst, int idx ){
	int index = 0;
	CNode* curr;
	if(lst->head == NULL) return -1;					//empty list
 	else{
		for(curr = lst->head; ; curr = curr->next){		//traversing  till idx
			if(index == idx) return curr->data;			//retrieving the value
			index++;
			if(curr->next == lst->head) break;				//end of list
		}
	}
	return -1;
}	
void clist_append( CList* lst, int data ){
	CNode* curr;
	CNode* target = (CNode*) malloc(sizeof(CNode));		//allocating memory to node
	if(lst->head == NULL){									//empty list
		lst->head = target;
		target->data = data;
		target->next = lst->head;
	}
	else{			
		for(curr = lst->head; ; curr = curr->next){			//travesing till the end
			if(curr->next == lst->head){
				target->data = data;
				target->next = lst->head;
				curr->next = target;
				break;
			}
		}
	}	
}
void clist_prepend( CList* lst, int data ){						//basically.. it is similar to clist_append
	CNode* target = (CNode*) malloc(sizeof(CNode));			//allocating memory to node
	CNode* curr;
	if(lst->head == NULL){									//if empty list
		lst->head = target;
		target->data = data;
		target->next = lst->head;
	}
	else{													//non empty list
		target->data = data;
		target->next = lst->head;
		for(curr = lst->head; ; curr = curr->next){			//travesing till the end
			if(curr->next == lst->head){
				curr->next = target;
				break;
			}
		}
		lst->head = target;		
	}
}
void clist_insert( CList* lst, int idx, int data ){
	CNode *prev;         										//to have a note of prev node
	CNode* target = (CNode*) malloc(sizeof(CNode));            	//allocating memory to target node 
	prev = lst->head;
 	int i;
	if(idx > clist_size(lst)) return ;
	if(idx == 0) clist_prepend(lst, data);					
	else{													//traversing till idx
		for( i = 0 ; i < idx-1 ; i++ ){
      			prev = prev->next;       
 		}
		target->data = data;
		target->next = prev->next;
		prev->next = target;
	}
}
void clist_remove_last( CList* lst ){
	CNode* curr;											//current node 
	CNode* prev;											//prev node
	curr = lst->head;
	while(curr->next != lst->head){							//to have a note of last but one node 
		prev = curr;
		curr = curr->next;
	}
	prev->next = lst->head;									//pointing last but one node to lst->head
	free(curr);													//removing last node
}
void clist_remove_first( CList* lst ){
	CNode* curr;											//current node 
	CNode* prev;											//prev node
	curr = lst->head;
	while(1){												//to have a note of last but one node 
		prev = curr;
		curr = curr->next;
		if(curr == lst->head) break;
	}
	lst->head = curr->next;
	prev->next = lst->head;									//pointing last node to lst->head
	free(curr);													//removing first node
}
void clist_remove( CList* lst, int idx ){
	if(idx >= clist_size(lst)) return ;
	if(idx == 0) clist_remove_first(lst);
	else{
		CNode* curr;		
		CNode* prev;
		curr = lst->head;
		while(idx--){										//having note of current and prev nodes
			prev = curr;
			curr = curr->next;
		}
		prev->next = curr->next;							//pointing prev node to lst->head
		free(curr);											//removing curr node
	}
	return ;
}
void clist_reverse(CList* lst){								//always remove the last element and insert in correct order to get reverse list
	int size = clist_size(lst);
	int i; 
	CNode* curr = lst->head;
	for(i = 0; i < size; i++){
		clist_insert(lst, i, clist_get(lst, size-1));			
		clist_remove_last(lst);
	}
}			



	
	































	
	

