#include "DList.h"
#include<stdio.h>
#include<stdlib.h>
DNode* dnode_new( int data){
	DNode* node = (DNode*) malloc(sizeof(DNode));
	node->data = data;
	node->next = NULL;
	node->prev = NULL;
 	return node;
}
DList* dlist_new(){
	DList* list = (DList*) malloc(sizeof(DList));
	list->head = NULL;
	return list;
}	
int dlist_size( DList* lst ){
	int size = 1;
	DNode* curr;	
	if(lst->head == NULL) return 0;					//when empty list
	if(lst->head != NULL){								//traversing and noting size
		for(curr = lst->head; curr->next != NULL; curr = curr->next) size++;
	}
	return size;
}
void dlist_print( DList* lst ){
	DNode* curr;	
	if(lst->head != NULL){								//if head = NULL : do nothing
		for(curr = lst->head; ; curr = curr->next){		//traversing and printing 
			//fflush(stdout);
			printf("%d ", curr->data);
			if(curr->next == NULL) break;				//end of list
		}
	}
	printf("\n");
	fflush(stdout);
	return ;
}
int dlist_get( DList* lst, int idx ){
	int index = 0;
	DNode* curr;
	if(lst->head == NULL) return -1;			//empty list
 	else{
		for(curr = lst->head; ; curr = curr->next){		//traversing  till idx
			if(index == idx) return curr->data;			//retrieving the value
			index++;
			if(curr->next == NULL) break;				//end of list
		}
	}
	return -1;
}
void dlist_append( DList* lst, int data ){
	DNode* curr;
	DNode* target = (DNode*) malloc(sizeof(DNode));		//allocating memory to node
	if(lst->head == NULL){									//empty list
		target->data = data;
		target->next = NULL;
		target->prev = NULL;
		lst->head = target;
	}
	else{			
		for(curr = lst->head; ; curr = curr->next){			//travesing till the end
			if(curr->next == NULL){
				target->data = data;
				target->next = NULL;
				target->prev = curr;
				curr->next = target;
				break;
			}
		}
	}	
}
void dlist_prepend( DList* lst, int data ){
	DNode* target = (DNode*) malloc(sizeof(DNode));			//allocating memory to node
	if(lst->head == NULL){									//if empty list
		target->data = data;
		target->next = NULL;
		target->prev = NULL;
		lst->head = target;
	}
	else{													//non empty list
		target->data = data;
		target->next = lst->head;
		target->prev = NULL;
		lst->head->prev = target;
		lst->head = target;
	}
}
void dlist_insert( DList* lst, int idx, int data ){
	DNode* target = (DNode*) malloc(sizeof(DNode));            	//allocating memory to target node 
	DNode* curr;
 	int i;
	int size = dlist_size(lst);
	if(idx > size) return ;
	if(idx == size){
		dlist_append(lst, data);
		return ;
	}
	if(idx == 0) dlist_prepend(lst, data);					
	else{													//traversing till idx
		curr = lst->head;
		for( i = 0; i < idx-1; i++){
			curr = curr->next;
		}
		target->data = data;
		target->next = curr->next;
		target->prev = curr;
		curr->next->prev = target;
		curr->next = target;
	}
}
void dlist_remove_last( DList* lst ){				//traverse till last one node and assign next to NULL
	DNode* curr;	
	curr = lst->head;
	int size = dlist_size(lst);
	if(size == 1){
		lst->head = NULL;
		return ;
	}
	while(1){
		if(curr->next == NULL){	
			(curr->prev)->next = NULL;
			break;
		}
		curr = curr->next;
	}
	free(curr);
}
void dlist_remove_first( DList* lst ){					//just  change the head to second node and assign prev of second node to NULL
	DNode* curr = lst->head;
	int size = dlist_size(lst);
	if(size == 1){
		lst->head = NULL;
		return ;
	}
	lst->head = curr->next;
	(curr->next)->prev = NULL;
	free(curr);
}
void dlist_remove( DList* lst, int idx ){				//traverse till the index and assign next of the prev node to next node.. and prev of next node to prev node
	DNode* curr = lst->head;
	int i;
	int size = dlist_size(lst);
	if(idx > size) return;
	if(idx == 0){
		dlist_remove_first(lst);
		return ;
	}
	if(idx == size-1){
		dlist_remove_last(lst);
		return ;
	}
	for(i = 0; i < idx; i++){
		 curr = curr->next;
	}
	(curr->prev)->next = curr->next;
	(curr->next)->prev = curr->prev;
	free(curr);
}
void dlist_reverse(DList* lst){							//always remove the last node and place it in order from first 
	int size = dlist_size(lst);
	int i; 
	DNode* curr = lst->head;
	for(i = 0; i < size; i++){
		dlist_insert(lst, i, dlist_get(lst, size-1));			
		dlist_remove_last(lst);
	}
}			
	
	

	



	






























