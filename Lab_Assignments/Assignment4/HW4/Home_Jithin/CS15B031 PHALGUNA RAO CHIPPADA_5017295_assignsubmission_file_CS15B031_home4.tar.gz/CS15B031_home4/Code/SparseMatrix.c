#include "SparseMatrix.h"
#include <stdio.h>
#include <stdlib.h>

Matrix add(Matrix a, Matrix b)                                                           //To add 2 sparse matrices
{
	Matrix c;
	c.row_lst = (LList **)malloc(sizeof(LList *)*(a.n_rows));
	int i = 0;
	while(i < a.n_rows)
	{
		(c.row_lst[i]) = llist_new();
		i++;
	}
	Node *t1;
	Node *t2;
	LList *t3;
	for(i = 0;i < a.n_rows;i++)                                                      //Adding is simailar to adding Polynomials(or Merge Sort)
	{
		t1 = (a.row_lst[i])->head;
		t2 = (b.row_lst[i])->head;
		t3 = c.row_lst[i];
		while((t1 != NULL) && (t2 != NULL))
		{
			if(t1->col_ind == t2->col_ind)
			{
				llist_append(t3,(t1->col_ind),(t1->val + t2->val));
				t1 = t1->next;
				t2 = t2->next;
			}
			else if(t1->col_ind < t2->col_ind)
			{
				llist_append(t3,(t1->col_ind),(t1->val));
				t1 = t1->next;
			}				
			else
			{
				llist_append(t3,(t2->col_ind),(t2->val));
				t2 = t2->next;
			}
		}
  		if(t2 == NULL)
  		{
    		while(t1 != NULL)
    		{
      			llist_append( t3, (t1->col_ind),(t1->val) );
			    t1 = (t1->next);
		    }
  		}
  		if(t1 == NULL)
  		{
    		while(t2 != NULL)
    		{
      			llist_append( t3, (t2->col_ind),(t2->val) );
			    t2 = (t2->next);
		    }
  		}
	}
	return c;
}
Matrix subtract(Matrix a, Matrix b)                                                      //Subtraction of two sparse matrices
{
	Matrix c;
	c.row_lst = (LList **)malloc(sizeof(LList *)*(a.n_rows));
	int i = 0;
	while(i < a.n_rows)
	{
		(c.row_lst[i]) = llist_new();
		i++;
	}
	Node *t1;
	Node *t2;
	LList *t3;
	for(i = 0;i < a.n_rows;i++)                                                      //Subtraction is simailar to adding Polynomials(or Merge Sort)
	{
		t1 = (a.row_lst[i])->head;
		t2 = (b.row_lst[i])->head;
		t3 = (c.row_lst[i]);
		while((t1 != NULL) && (t2 != NULL))
		{
			if(t1->col_ind == t2->col_ind)
			{
				llist_append(t3,(t1->col_ind),(t1->val - t2->val));
				t1 = t1->next;
				t2 = t2->next;
			}
			else if(t1->col_ind < t2->col_ind)
			{
				llist_append(t3,(t1->col_ind),(t1->val));
				t1 = t1->next;
			}				
			else
			{
				llist_append(t3,(t2->col_ind),(-(t2->val)));
				t2 = t2->next;
			}
		}
  		if(t2 == NULL)
  		{
    		while(t1 != NULL)
    		{
      			llist_append( t3, (t1->col_ind),(t1->val) );
			    t1 = (t1->next);
		    }
  		}
  		if(t1 == NULL)
  		{
    		while(t2 != NULL)
    		{
      			llist_append( t3, (t2->col_ind),(-(t2->val)) );
			    t2 = (t2->next);
		    }
  		}
	}
	return c;
}

Matrix matrix_vect_multiply(Matrix mat, Matrix vect)                                     //Multiply an M x N matrix with N X 1 vector
{
	Matrix pdt;
	pdt.row_lst = (LList **)malloc(sizeof(LList *)*(mat.n_rows));
	int i = 0;
	int j = 0;
	int sum = 0;
	while(i < mat.n_rows)
	{
		(pdt.row_lst[i]) = llist_new();
		i++;
	}
	Node *t1;
	Node *t2;
	LList *t3;
	for(i = 0;i < mat.n_rows;i++)
	{
		t1 = (mat.row_lst[i])->head;
		t3 = (pdt.row_lst[i]);
		for(j = 0;(t1 != NULL);j++)
		{
			t2 = (vect.row_lst[j])->head;
			if((t1->col_ind) == j)
			{
				sum = sum + ((t1->val) * (t2->val));
				t1 = t1->next;
			}
		}
		llist_append(t3,0,sum);
		sum = 0;
	}
	return pdt;
}
