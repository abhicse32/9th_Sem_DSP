/*
	To implement addition, subtraction and multiplication 
	of sparse matrices using linked lists
*/
#include "List.h"
#include"SparseMatrix.h"
#include<stdlib.h>
#include<stdio.h>
int main()
{
	int choice;
	int i;
	int j;
	int n;
	int m;
	int inp;
	scanf("%d",&choice);                                                       //Taking in choice
	while(choice!=-1)                                                          //Sentinal val -1
	{
		switch(choice)
		{
			case 1:
			case 2:{                                                           //If choice = 1 or 2 the input matrices are similar(both are m x n)
				   	Matrix *a = (Matrix *)malloc(sizeof(Matrix));
					Matrix *b = (Matrix *)malloc(sizeof(Matrix));
					Matrix *c = (Matrix *)malloc(sizeof(Matrix));
					scanf("%d %d",&m,&n);
					a->n_rows = m;
					a->row_lst = (LList **)malloc(sizeof(LList *)*m);
					b->n_rows = m;
					b->row_lst = (LList **)malloc(sizeof(LList *)*m);
					for(i = 0;i < m;i++)
					{
						(a->row_lst[i]) = llist_new();
						for(j = 0;j < n;j++)
						{
							scanf("%d",&inp);
							if(inp == 0)
								continue;
							llist_append((a->row_lst[i]),j,inp);               //Storing if element != 0
						}
					}
					for(i = 0;i < m;i++)
					{
						(b->row_lst[i]) = llist_new();
						for(j = 0;j < n;j++)
						{
							scanf("%d",&inp);
							if(inp == 0)
								continue;
							llist_append((b->row_lst[i]),j,inp);               //Storing if element != 0
						}
					}
					if(choice == 1)                                            //Addition if choice is 1
					{
						*c = add(*a,*b);
					}
					else                                                       //Subtraction if choice is 2
					{
						*c = subtract(*a,*b);
					}
					for(i = 0;i < m;i++)
					{
						llist_print(c->row_lst[i]);                            //Printing the sparse matrix
					}
					break;
				   }
			case 3:{
				   	Matrix *a = (Matrix *)malloc(sizeof(Matrix));              //Taking 2 matrices m x n and n x 1
					Matrix *b = (Matrix *)malloc(sizeof(Matrix));
					Matrix *c = (Matrix *)malloc(sizeof(Matrix));
					scanf("%d %d",&m,&n);
					a->n_rows = m;
					a->row_lst = (LList **)malloc(sizeof(LList *)*m);
					b->n_rows = n;
					b->row_lst = (LList **)malloc(sizeof(LList *)*n);
					for(i = 0;i < m;i++)
					{
						(a->row_lst[i]) = llist_new();
						for(j = 0;j < n;j++)
						{
							scanf("%d",&inp);
							if(inp == 0)
								continue;
							llist_append((a->row_lst[i]),j,inp);               //Storing if element != 0
						}
					}
					for(i = 0;i < n;i++)
					{
						(b->row_lst[i]) = llist_new();
						for(j = 0;j < 1;j++)
						{
							scanf("%d",&inp);
							llist_append((b->row_lst[i]),j,inp);
						}
					}
					*c = matrix_vect_multiply(*a,*b);                          //Multiplication, as choice = 3
					for(i = 0;i < m;i++)
					{
						llist_print(c->row_lst[i]);                            //Printing the sparse matrix
					}
					break;
				   }
		}
		scanf("%d",&choice);                                                   //Taking in choice again
	}
}
