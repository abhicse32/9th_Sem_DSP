//CList.c by Raghavan S CS15B034 Home Assignment 4
#include "CList.h"
#include<stdio.h>
#include<stdlib.h>
#define INT_MIN -1

// Create a new Node with next set to NULL

CNode* cnode_new( int data)
{
	CNode *n;
	n = (CNode*)malloc(sizeof(CNode));
	if(n==NULL)
	{
		printf("overflow");
		return NULL;
	}
	n->next=NULL;
	n->data=data;
	return n;
}

// Create an empty list (head shall be NULL)
CList* 	clist_new()
{
	CList *l=(CList*)malloc(sizeof(CList));
	l->head=NULL;
	return l;
}

//Creates new node in an empty LL
void clist_crfirstCNode(CList *l,int data)
{
	CNode *n = cnode_new(data);
	l->head=n;
  l->head->next=l->head;
}

// Traverse the linked list and return its size
int clist_size( CList* lst )
{
	int i=1;
	if(lst->head==NULL)
		return 0;
	else
	{
		CNode *n;
		for(n=lst->head;n->next!=lst->head;n=n->next)
		{
			i++;
		}
		return i;
	}
}

// Traverse the linked list and print each element
void clist_print( CList* lst )
{
	if(lst->head==NULL)
	{
		return;
	}
	else
	{
		CNode *n=(CNode*)malloc(sizeof(CNode));
		for(n=lst->head;n->next!=lst->head;n=n->next)
		{
			printf("%d ",n->data);
		}
    printf("%d ",n->data);
	}
	printf("\n");
}

//get the element at position @idx
int clist_get( CList* lst, int idx )
{
	int t;
	if(idx<0||lst->head==NULL||idx>=clist_size(lst))
		return INT_MIN;
	int i=0;
	CNode *n;
	n=lst->head;
	while(i<idx)
	{
		n=n->next;
		i++;
	}
	return(n->data);
}

// Add a new element at the end of the list
void clist_append( CList* lst, int data )
{
	if(lst->head==NULL)
	{
		clist_crfirstCNode(lst,data);
		return;
	}
	CNode *n;
	n=lst->head;
	while(n->next!=lst->head)
	{
		n=n->next;
	}
	CNode *n2;
	n2=cnode_new(data);
  n2->next=n->next;
  n->next=n2;
}
// Add a new element at the beginning of the list
void clist_prepend( CList* lst, int data )
{
	if(lst->head==NULL)
	{
		clist_crfirstCNode(lst,data);
		return;
	}
	else
	{
    CNode *n2=cnode_new(data);
  	CNode *n=lst->head;
    while(n->next!=lst->head)
  	{
  		n=n->next;
  	}
		n->next=n2;
		n2->next=lst->head;
    lst->head=n2;
	}
}

// Add a new element at the @idx index
void clist_insert( CList* lst, int idx, int data )
{
	if(idx<0||idx>clist_size(lst))
		return;
	if(idx==0)
	{
		clist_prepend(lst,data);
		return;
	}
	int i=0;
	CNode *n;
	n=lst->head;
	while(i<idx-1)
	{
		n=n->next;
		i++;
	}
	CNode *n2=cnode_new(data);
	n2->next=n->next;
	n->next=n2;
}

// Remove an element from the end of the list
void clist_remove_last( CList* lst )
{
	if(lst->head==NULL)
		return;
	CNode *n;
	CNode *n2;
	n=lst->head;
	if(lst->head->next==lst->head)
	{
		lst->head=NULL;
		free(n);
		return;
	}
	while((n->next)->next!=lst->head)
	{
		n=n->next;
	}
	n2=n->next;
  n->next=lst->head;
	free(n2);
}

// Remove an element from the beginning of the list
void clist_remove_first( CList* lst )
{
	if(lst->head==NULL)
		return;
	CNode *n;
	n=lst->head;
	if(lst->head->next==lst->head)
		{
			clist_remove_last(lst);
			return;
		}
  while(n->next!=lst->head)
  	{
  		n=n->next;
  	}
	CNode *n2=lst->head;
  n->next=lst->head->next;
  lst->head=lst->head->next;
  free(n2);
}

// Remove an element from an arbitrary @idx position in the list
void clist_remove( CList* lst, int idx )
{
	if(idx<0||lst->head==NULL||idx>=clist_size(lst))
		return;
	if(idx==0)
	{
		clist_remove_first(lst);
		return;
	}
	int i=0;
	CNode *n;
	n=lst->head;
	while(i<idx-1)
	{
		n=n->next;
		i++;
	}
	CNode *n2;
	n2=n->next;
	n->next=(n->next)->next;
	free(n2);
}
// reverse the list
void clist_reverse(CList *l)
{
if(l->head==NULL||l->head->next==l->head)
  return;
CNode *prev=NULL,*curr=l->head,*n;
while (curr->next != l->head)
    {
        n = curr->next;
        curr->next = prev;
        prev = curr;
        curr = n;
    }
    curr->next=prev;
    l->head->next=curr;
    l->head=curr;
}
