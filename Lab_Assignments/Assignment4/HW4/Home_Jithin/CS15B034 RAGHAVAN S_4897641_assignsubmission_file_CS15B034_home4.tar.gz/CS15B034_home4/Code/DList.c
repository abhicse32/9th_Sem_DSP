//DList.c by Raghavan S CS15B034 Home Assignment 4
#include "DList.h"
#include <stdio.h>
#include <stdlib.h>
#define INT_MIN -1
// Create a new Node with next set to NULL
DNode* dnode_new( int data)
{
	DNode *n;
	n = (DNode*)malloc(sizeof(DNode));
	if(n==NULL)
	{
		printf("overflow");
		return NULL;
	}
	n->next=NULL;
	n->data=data;
  n->prev=NULL;
	return n;
}

// Create an empty list (head shall be NULL)
DList* 	dlist_new()
{
	DList *l=(DList*)malloc(sizeof(DList));
	l->head=NULL;
	return l;
}

//Creates new node in an empty LL
void dlist_crfirstdnode(DList *l,int data)
{
	DNode *n = dnode_new(data);
	l->head=n;
}

// Traverse the linked list and return its size
int dlist_size( DList* lst )
{
	int i=0;
	if(lst->head==NULL)
		return 0;
	else
	{
		DNode *n;
		for(n=lst->head;n!=NULL;n=n->next)
		{
			i++;
		}
		free(n);
		return i;
	}
}

// Traverse the linked list and print each element
void dlist_print( DList* lst )
{
	if(lst->head==NULL)
	{
		return;
	}
	else
	{
		DNode *n;
		for(n=lst->head;n!=NULL;n=n->next)
		{
			printf("%d ",n->data);
		}
		free(n);
	}
	printf("\n");
}

//get the element at position @idx
int dlist_get( DList* lst, int idx )
{
	int t;
	if(idx<0||lst->head==NULL)
		return INT_MIN;
	int i=0;
	DNode *n;
	n=lst->head;
	while(i<idx&&n!=NULL)
	{
		n=n->next;
		i++;
	}
	if(n==NULL)
		return INT_MIN;
	else
		return(n->data);
}

// Add a new element at the end of the list
void dlist_append( DList* lst, int data )
{
	if(lst->head==NULL)
	{
		dlist_crfirstdnode(lst,data);
		return;
	}
	DNode *n;
	n=lst->head;
	while(n->next!=NULL)
	{
		n=n->next;
	}
	DNode *n2=dnode_new(data);
	n->next=n2;
  n2->prev=n;
	}
// Add a new element at the beginning of the list
void dlist_prepend( DList* lst, int data )
{
	DNode *n=dnode_new(data);
	if(lst->head==NULL)
	{
		dlist_crfirstdnode(lst,data);
		return;
	}
	else
	{
		n->next=lst->head;
		lst->head->prev=n;
    lst->head=n;
	}
}

// Add a new element at the @idx index
void dlist_insert( DList* lst, int idx, int data )
{
	if(idx<0||idx>dlist_size(lst))
		return;
	if(idx==0)
	{
		dlist_prepend(lst,data);
		return;
	}
	int i=0;
	DNode *n;
	n=lst->head;
	while(i<idx-1&&n!=NULL)
	{
		n=n->next;
		i++;
	}
  DNode *n3=n->next;
  DNode *n2=dnode_new(data);
	n2->next=n->next;
  n2->prev=n;
  n->next=n2;
  if(n2->next!=NULL)
    n2->next->prev=n2;
}

// Remove an element from the end of the list
void dlist_remove_last( DList* lst )
{
	if(lst->head==NULL)
		return;
	DNode *n;
	DNode *n2;
	n=lst->head;
	if(lst->head->next==NULL)
	{
		lst->head=lst->head->next;
		free(n);
		return;
	}
	while((n->next)->next!=NULL)
	{
		n=n->next;
	}
	n2=n->next;
	free(n2);
	n->next=NULL;
}

// Remove an element from the beginning of the list
void dlist_remove_first( DList* lst )
{
	if(lst->head==NULL)
		return;
	DNode *n;
	n=lst->head;
	if(lst->head->next==NULL)
		{
			dlist_remove_last(lst);
			return;
		}
	lst->head=lst->head->next;
	free(n);
  lst->head->prev=NULL;
}

// Remove an element from an arbitrary @idx position in the list
void dlist_remove( DList* lst, int idx )
{
	if(idx<0||lst->head==NULL||idx>=dlist_size(lst))
		return;
	if(idx==0)
	{
		dlist_remove_first(lst);
		return;
	}
	int i=0;
	DNode *n;
	n=lst->head;
	while(i<idx-1&&n!=NULL)
	{
		n=n->next;
		i++;
	}
	DNode *n2;
	n2=n->next;
	n->next=n2->next;
  if(n2->next!=NULL)
    n2->next->prev=n;
  free(n2);
}

// reverse the list
void dlist_reverse(DList *l)
{
  if(dlist_size(l)<=1)
  return;
  DNode *n=l->head,*t;
  while(n->next!=NULL)
  {
    t=n->next;
    n->next=n->prev;
    n->prev=t;
    n=t;
  }
  t=n->next;
  n->next=n->prev;
  n->prev=t;
  l->head=n;
}
