//SparseMatrix.c by Raghavan S CS15B034 Home Assignment 4
#include "SparseMatrix.h"
#include<stdio.h>
#include<stdlib.h>
//creates a new matrix
Matrix newmat(int n)
{
  int i;
  Matrix a;
  a.n_rows=n;
  a.row_lst=(LList**)malloc(sizeof(LList*)*n);
  for(i=0;i<n;i++)
  a.row_lst[i]=llist_new();
  return a;
}

/*Multiply an M x N matrix with N X 1 vector*/
Matrix matrix_vect_multiply(Matrix mat, Matrix vect)
{
  int m,i;
  m=mat.n_rows;
  Matrix r=newmat(m);
  int t,j;
  for(i=0;i<m;i++)
  {
    t=0;
    j=0;
    Node *n=mat.row_lst[i]->head;
    while(n!=NULL)
    {
      j=n->col_ind;
      if(vect.row_lst[j]->head!=NULL)
      {
        t+=n->val*vect.row_lst[j]->head->val;
      }
      n=n->next;
    }
    if(t!=0)
    llist_append(r.row_lst[i],0,t);
  }
return r;
}
/*Add two matrices*/
Matrix add(Matrix p, Matrix q)
{
  int m;
  m=p.n_rows;
  Matrix r=newmat(m);
  int i,j;
  for(i=0;i<m;i++)
  {
    j=0;
    Node *n1=p.row_lst[i]->head;
    Node *n2=q.row_lst[i]->head;
    while(n1!=NULL&&n2!=NULL)
    {
      if(n1->col_ind==j&&n2->col_ind==j)
      {
        //if(n1->val+n2->val!=0)
        llist_append(r.row_lst[i],j,n1->val+n2->val);
        n2=n2->next;
        n1=n1->next;
        j++;
      }
      else if(n1->col_ind==j)
      {
        llist_append(r.row_lst[i],j,n1->val);
        n1=n1->next;
        j++;
      }
      else if(n2->col_ind==j)
      {
        llist_append(r.row_lst[i],j,n2->val);
        n2=n2->next;
        j++;
      }
      else
      j++;
    }
    while(n1!=NULL)
    {
      if(n1->col_ind==j)
      {
        llist_append(r.row_lst[i],j,n1->val);
        n1=n1->next;
        j++;
      }
      else
      j++;
    }
    while(n2!=NULL)
    {
      if(n2->col_ind==j)
      {
        llist_append(r.row_lst[i],j,n2->val);
        n2=n2->next;
        j++;
      }
      else
      j++;
    }
  }
return r;
}

/*Subtract Matrix b from a*/
Matrix subtract(Matrix p, Matrix q)
{
  int m;
  m=p.n_rows;
  Matrix r=newmat(m);
  int i,j;
  for(i=0;i<m;i++)
  {
    j=0;
    Node *n1=p.row_lst[i]->head;
    Node *n2=q.row_lst[i]->head;
    while(n1!=NULL&&n2!=NULL)
    {
      if(n1->col_ind==j&&n2->col_ind==j)
      {
        //if(n1->val-n2->val!=0)
        llist_append(r.row_lst[i],j,n1->val-n2->val);
        n2=n2->next;
        n1=n1->next;
        j++;
      }
      else if(n1->col_ind==j)
      {
        llist_append(r.row_lst[i],j,n1->val);
        n1=n1->next;
        j++;
      }
      else if(n2->col_ind==j)
      {
        llist_append(r.row_lst[i],j,-1*n2->val);
        n2=n2->next;
        j++;
      }
      else
      j++;
    }
    while(n1!=NULL)
    {
      if(n1->col_ind==j)
      {
        llist_append(r.row_lst[i],j,n1->val);
        n1=n1->next;
        j++;
      }
      else
      j++;
    }
    while(n2!=NULL)
    {
      if(n2->col_ind==j)
      {
        llist_append(r.row_lst[i],j,-1*n2->val);
        n2=n2->next;
        j++;
      }
      else
      j++;
    }
  }
return r;
}
