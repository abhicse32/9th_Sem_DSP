//q1.c by Raghavan S CS15B034 Home Assignment 4
#include "List.h"
#include "SparseMatrix.h"
#include <stdio.h>
#include <stdlib.h>
/*Prints only the non-zero elements of each row unless it is matrix multiplication
and the resultant matrix is n*1 (p=1 denotes multiplication)*/
void pseudoprint(Matrix m,int p)
{
  int i;
  for(i=0;i<m.n_rows;i++)
  {
    Node *n=m.row_lst[i]->head;
    if(n==NULL&&p==1)
    printf("%d ",0);
    else if(n==NULL)
    continue;
    while(n!=NULL)
    {
        printf("%d ",n->val);
        n=n->next;
    }
    printf("\n");
  }
}

//prints the matrix along with zeros
void print(Matrix m,int n1)
{
  int i,j;
  for(i=0;i<m.n_rows;i++)
  {
    j=0;
    Node *n=m.row_lst[i]->head;
    while(n!=NULL)
    {
      if(n->col_ind==j)
      {
        printf("%d ",n->val);
        n=n->next;
        j++;
        continue;
      }
      printf("%d ",0);
      j++;
    }
    while(j<n1)
    {
      printf("%d ",0);
      j++;
    }
    printf("\n");
  }
}
/*Gets input matrix m*n and stores it in the SparseMatrix structure(only non -zero
elements in linked lists)*/
Matrix getinp(int m,int n)
{
int i,j,t;
Matrix p=newmat(m);
for(i=0;i<m;i++)
for(j=0;j<n;j++)
{
  scanf("%d",&t);
  if(t!=0)
  llist_append(p.row_lst[i],j,t);
}
return p;
}

int main()
{
  int ch;
  int m,n;
  Matrix m1,m2,m3;
  do
  {
    scanf("%d",&ch);
    switch(ch)
    {
      case 1: scanf("%d",&m);
              scanf("%d",&n);
              m1=getinp(m,n);
              m2=getinp(m,n);
              m3=add(m1,m2);
              // print(m3,n);
              pseudoprint(m3,0);
              break;
      case 2: scanf("%d",&m);
              scanf("%d",&n);
              m1=getinp(m,n);
              m2=getinp(m,n);
              m3=subtract(m1,m2);
              // print(m3,n);
              pseudoprint(m3,0);
              break;
      case 3: scanf("%d",&m);
              scanf("%d",&n);
              m1=getinp(m,n);
              m2=getinp(n,1);
              m3=matrix_vect_multiply(m1,m2);
              // print(m3,1);
              pseudoprint(m3,1);
              break;
    }
  } while(ch!=-1);
return 0;
}
