#include "CList.h"
#include<stdlib.h>
#include<limits.h>
#include<stdio.h>

CNode* cnode_new(int data){
    CNode* new = (CNode*) malloc(sizeof(CNode));        
    new->data=data;
    new->next=NULL;    
    return new;
}

CList* clist_new(){
	CList* list;
    list=(CList*)malloc(sizeof(CList));
    list->head==NULL;
    return list;
}


int clist_size( CList* lst ){
    CNode* temp;
    temp=lst->head;
    int i=1;
    if(temp==NULL) return 0;
    while(temp->next!=lst->head){                
            temp=temp->next;
            i++;
    }
    return i;
}

void clist_print( CList* lst ){
    CNode* temp;
    if(lst->head==NULL) return;
    temp=lst->head;
    if(lst->head!=NULL){
    	printf("%d ",temp->data);
    	temp=temp->next;
    }	
    while(temp!=lst->head){
            printf("%d ",temp->data);
            temp=temp->next;
    }
    printf("\n");
    
}

int clist_get( CList* lst, int idx ){
    if(idx<0) return -1;
    int i=1;
    CNode* temp=lst->head;
    if(temp!=NULL&&idx==0){
    return temp->data;  
    }
    temp=temp->next; 	
    while(temp!=lst->head){
            if(i==idx) return temp->data;
            else{
                    temp=temp->next;
                    i++;
            }
    }
    if(temp==lst->head&&i!=idx) return -1;
}

void clist_append( CList* lst, int data ){
    CNode* new = cnode_new(data);      
    CNode* temp;
    if(lst->head==NULL){
            lst->head=new;
            new->next=lst->head;
            return;
    }
    temp=(lst->head)->next;
    while(temp->next!=lst->head){
            temp=temp->next;
    }
    temp->next=new;
    new->next=lst->head;
    return;
        
}

void clist_prepend( CList* lst, int data ){
    CNode* new = cnode_new(data);
    if(lst->head==NULL){ 
    lst->head=new;
    new->next=new;
    return;
    }
    else if((lst->head)->next==lst->head){
    	new->next=lst->head;
    	lst->head=new;
    	(new->next)->next=lst->head;
    	return; 
    }
    else{
    	new->next=lst->head;
    	CNode* temp=lst->head;
    	while(temp->next!=lst->head){
    		temp=temp->next;
    	}
    	temp->next=new;
    	lst->head=new;	
    }               
}

void clist_insert( CList* lst, int idx, int data ){
	if(idx>clist_size(lst)) return;
	if(idx==0){
	clist_prepend(lst,data);
	return;
	}
	
	if(idx == clist_size(lst)){
	clist_append(lst,data);
	return;
	}         
    int i=idx;
    CNode *curr,*temp,*prev;
    curr=lst->head;
    prev=NULL;
    while(i!=0){
    	prev=curr;
    	curr=curr->next;
    	i--;
    }
    CNode* new=cnode_new(data);
    new->next=curr;
    prev->next=new;          
}

void clist_remove_last( CList* lst ){
        CNode *last,*prev;
        if(lst->head==NULL) return;
        prev=lst->head;
        last=(lst->head)->next;
        if(last==lst->head){
        	lst->head=NULL;
        	free(prev);
        	return;
        }
        while(last->next!=lst->head){
                prev=last;
                last=last->next;
        }
        free(last);
        prev->next=lst->head;
   
}

void clist_remove_first( CList* lst ){
        if(lst->head==NULL) return;
        CNode* temp=lst->head;
        if(temp->next==lst->head){
        	lst->head=NULL;
        	free(temp);
        	return;
        }
        CNode* p=lst->head;
    	while(p->next!=lst->head){
    		p=p->next;
    	}
        lst->head=(lst->head)->next;
        p->next=lst->head;
        free(temp);
}

void clist_remove( CList* lst, int idx ){
		if(idx>=clist_size(lst)) return;
        if(idx==0) clist_remove_first(lst);
        else if(idx == (clist_size(lst)-1)) clist_remove_last(lst);
        else{
        	CNode *curr,*prev;
        	curr=lst->head;
        	prev=NULL;
        	int i=idx;
        	while(i!=0){
        		prev=curr;
        		curr=curr->next;
        		i--;
        	}
        	prev->next=curr->next;
        	free(curr);
        }
           
}

void clist_reverse(CList* lst){
	if(lst->head==NULL) return;
	else if(lst->head->next==lst->head) return;
	else{
		CNode *p1,*p2,*p3;
		p3=lst->head;
		p2=lst->head->next;
		p1=p2->next;
		while(p1!=lst->head){
			p2->next=p3;
			p3=p2;
			p2=p1;
			p1=p1->next;	
		}
		p2->next=p3;
		p1->next=p2;
		lst->head=p2;
	
	}
}




