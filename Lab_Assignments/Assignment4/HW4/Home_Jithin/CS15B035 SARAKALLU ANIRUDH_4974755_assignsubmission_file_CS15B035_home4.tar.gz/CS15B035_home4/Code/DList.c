#include "DList.h"
#include<stdlib.h>
#include<stdio.h>
#include<limits.h>



DNode* dnode_new( int data){
	DNode* new = (DNode*) malloc(sizeof(DNode));
	new->data = data;
	new->next = NULL;
	new->prev=NULL;
	return new;
}



DList* dlist_new(){
	DList* new = (DList*) malloc(sizeof(DList));
	new->head=NULL;
	return new;

}

int dlist_size( DList* lst ){
	DNode* temp;
    temp=lst->head;
    int i=0;
    while(temp!=NULL){                
    	temp=temp->next;
        i++;
    }
    return i;
}

void dlist_print( DList* lst ){
	DNode* temp;
    temp=lst->head;
    while(temp!=NULL){
    	printf("%d ",temp->data);
    	temp=temp->next;
    }
    printf("\n");
    if(temp==NULL) return;
}

int dlist_get( DList* lst, int idx ){
	if(idx<0) return -1;
	if(idx>dlist_size(lst)) return -1;
    int i=0;
    DNode* temp=lst->head;
    if(temp==NULL) return;
    if(temp->next==NULL&&idx==1) return temp->data;
    while(temp->next!=NULL){
            if(i==idx) return temp->data;
            else{
                    temp=temp->next;
                    i++;
            }
    }
    if(temp->next==NULL&&i==idx) return temp->data;
    if(temp->next==NULL&&i!=idx) return -1;
}


void dlist_append( DList* lst, int data ){
	DNode* new=dnode_new(data);
	DNode* temp;
	temp=lst->head;
	if(temp==NULL){
		lst->head=new;
		new->prev=NULL;
		return;
		}
	else{
		while(temp->next!=NULL){
			temp=temp->next;
		}
		temp->next=new;
		new->prev=temp;
		return;
	}
	
}

void dlist_prepend( DList* lst, int data ){
        DNode* new=dnode_new(data);
        if(lst->head==NULL){
			new->next=NULL;
			lst->head=new;
			new->prev=NULL;
			return;	
		}
		else{
        	new->next = (lst->head);
        	((lst->head))->prev=new;
        	(lst->head)=new;
        	new->prev=NULL;
       }
}

void dlist_insert( DList* lst, int idx, int data ){
	if(idx<0) return ;
	if(idx>dlist_size(lst)) return ;
	
	if(idx==0){ 
		dlist_prepend(lst,data);
		return;
	}	
	else if(idx == (dlist_size(lst))){ 
			dlist_append(lst,data);
			return;
			}
	else{
		DNode *curr,*prev;
		curr=lst->head;
		prev=NULL;
		int i=idx;
		while(curr!=NULL&&i!=0){
			prev=curr;
			curr=curr->next;
			i--;
		}
		if(curr==NULL&&i!=0) return;
		DNode* new=dnode_new(data);
		prev->next=new;
		new->prev=prev;
		(curr->prev)=new;
		new->next=curr;
		
	}
}

void dlist_remove_last( DList* lst ){
	DNode *prev,*curr;
	curr=lst->head;
	prev=NULL;
	if(curr->next==NULL){
	lst->head=NULL;
	free(curr);
	}
	else{
		while(curr->next!=NULL){
			prev=curr;
			curr=curr->next;		
		}
		prev->next=NULL;
		free(curr);
	}
}

void dlist_remove_first( DList* lst ){
	if(lst->head==NULL) return;
    DNode* temp=lst->head;
    lst->head=(lst->head)->next;
    (lst->head)->prev=NULL;
    free(temp);
}

void dlist_remove( DList* lst, int idx ){
	if(idx<0) return ;
	if(idx>dlist_size(lst)) return ;
	if(idx==0) dlist_remove_first(lst);
	else if(idx == (dlist_size(lst)-1)) dlist_remove_last(lst);
	else{
		DNode *prev,*curr;
		prev=NULL;
		curr=lst->head;
		int i=idx;
		while(i!=0){
		prev=curr;
		curr=curr->next;
		i--;
		}
		prev->next=curr->next;
		(curr->next)->prev=prev;
		free(curr);
	}

}

void dlist_reverse(DList* lst){
	DNode *curr,*prev,*temp;
	curr=lst->head;
	if(curr->next==NULL) return;
	while(curr->next!=NULL){
		temp=curr->next;
		curr->next=curr->prev;
		curr->prev=temp;
		curr=temp;
			
	}
	
	(lst->head)->next=NULL;
	curr->next=curr->prev;
	curr->prev=NULL;
	lst->head=curr;

}





