#include "List.h"
#include<stdlib.h>
#include<limits.h>
#include<stdio.h>

Node* node_new(int data1,int data2){
        Node* new = (Node*) malloc(sizeof(Node));
        if(new==NULL) return;
        else{
                new->col_ind=data1;
                new->val=data2;
                new->next=NULL;
        }
        return new;
}

LList* llist_new(){
        LList* list;
        list=(LList*)malloc(sizeof(LList));
        list->head=NULL;
        return list;
}


int llist_size( LList* lst ){
        Node* temp;
        temp=lst->head;
        int i=0;
        while(temp!=NULL){
                
                temp=temp->next;
                i++;
        }
        return i;
}

void llist_print( LList* lst ){
        Node* temp;
        temp=lst->head;
        while(temp!=NULL){
                printf("%d ",temp->val);
                temp=temp->next;
        }
        printf("\n");
        if(temp==NULL) return;
}

Node* llist_get( LList* lst, int idx ){
        if(idx<0) return ;
        int i=0;
        Node* temp=lst->head;
        if(temp==NULL) return;
        if(temp->next==NULL&&idx==0) return temp;
        while(temp->next!=NULL){
                if(i==idx) return temp;
                else{
                        temp=temp->next;
                        i++;
                }
        }
        if(temp->next==NULL&&i==idx) return temp;
        if(temp->next==NULL&&i!=idx) return ;

}

void llist_append( LList* lst, int data1,int data2 ){
        Node *new=node_new(data1,data2);      
        Node* temp;
        temp=lst->head;
        if(lst->head==NULL){
                lst->head=new;
                new->next=NULL;
                return;
        }
        while(temp->next!=NULL){
                temp=temp->next;
        }
        temp->next=new;
        new->next=NULL;
        return;
        
}

void llist_prepend( LList* lst, int data1,int data2 ){
        Node* new = node_new(data1,data2);
        new->next=lst->head;
        lst->head=new;               
}

void llist_insert( LList* lst, int idx, int data1,int data2 ){
        Node* new=node_new(data1,data2);
        int i=idx;
        Node *curr,*temp,*prev;
        curr=lst->head;
        prev=NULL;
        if(i==0){
                llist_prepend(lst,data1,data2);
                return;
        }
        
         while(curr!=NULL&&i!=0){
                prev=curr;
                curr=curr->next;
                i--;
        }
        if(curr==NULL&&i!=0) return;
       
        prev->next=new;
        new->next=curr;          
}






