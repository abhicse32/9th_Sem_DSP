#include "SparseMatrix.h"
#include<stdlib.h>
#include "List.h"
#include<stdio.h>


Matrix matrix_vect_multiply(Matrix mat, Matrix vect){
	
	Matrix *prod = (Matrix*)malloc(sizeof(Matrix));
	(prod->n_rows) = (mat.n_rows);	
	prod->row_lst = (LList**) malloc((prod->n_rows)*sizeof(LList*));
	int i=0;
	while(i<mat.n_rows){
		int result=0;
		prod->row_lst[i]=llist_new();
		Node* temp=(mat.row_lst[i])->head;
		while(temp!=NULL){		
			result =result + ((temp->val) * (((vect.row_lst[temp->col_ind]))->head)->val);
			temp = temp->next;	
	   	}
	   	
	   	llist_append(prod->row_lst[i],i,result);
	   	i++;
	}
	return *prod;
	
}


Matrix add(Matrix m1, Matrix m2){
	Matrix *sum = (Matrix*)malloc(sizeof(Matrix));
	(sum->n_rows) = (m1.n_rows);	
	sum->row_lst = (LList**) malloc((sum->n_rows)*sizeof(LList*));
	int i=0;
	while(i<m1.n_rows){
		sum->row_lst[i]=llist_new();
		Node* temp1=(m1.row_lst[i])->head;	
		Node* temp2=(m2.row_lst[i])->head;
		while(temp1!=NULL&&temp2!=NULL){
	
			if((temp1->col_ind) == (temp2->col_ind)){
			
				int res=temp1->val + temp2->val;
				llist_append(sum->row_lst[i],temp1->col_ind,res);
				temp1=temp1->next;
				temp2=temp2->next;
				
			}
			else if((temp1->col_ind) > (temp2->col_ind)){
			
				llist_append(sum->row_lst[i],temp2->col_ind,temp2->val);
				temp2=temp2->next;
			}
			else if((temp1->col_ind) < (temp2->col_ind)){
			
				llist_append(sum->row_lst[i],temp1->col_ind,temp1->val);
				temp1=temp1->next;
			}
		
		}
			if(temp1 == NULL&&temp2!=NULL){
			while(temp2!=NULL){
				//printf("c2 %d\n",temp2->col_ind);
				llist_append(sum->row_lst[i],temp2->col_ind,temp2->val);
				temp2=temp2->next;
			}
		
		}
			if(temp2 == NULL&&temp1!=NULL){
				while(temp1!=NULL){
					//printf("c1 %d \n",temp1->col_ind);
					llist_append(sum->row_lst[i],temp1->col_ind,temp1->val);
					temp1=temp1->next;
				}
			}
	
		i++;
	
	
	}
	return *sum;	


}



Matrix subtract(Matrix m1, Matrix m2){
	Matrix *sum = (Matrix*)malloc(sizeof(Matrix));
	sum->n_rows = m1.n_rows;	
	sum->row_lst = (LList**) malloc((sum->n_rows)*sizeof(LList*));
	int i=0;
	while(i<m1.n_rows){
		sum->row_lst[i]=llist_new();
		Node* temp1=(m1.row_lst[i])->head;	
		Node* temp2=(m2.row_lst[i])->head;
		while(temp1!=NULL&&temp2!=NULL){
			if((temp1->col_ind) == (temp2->col_ind)){
				int res=temp1->val - temp2->val;
				llist_append(sum->row_lst[i],temp1->col_ind,res);
				temp1=temp1->next;
				temp2=temp2->next;
				
			}
			else if((temp1->col_ind) > (temp2->col_ind)){
				llist_append(sum->row_lst[i],temp2->col_ind,-(temp2->val));
				temp2=temp2->next;
			}
			else if((temp1->col_ind) < (temp2->col_ind)){
				llist_append(sum->row_lst[i],temp1->col_ind,temp1->val);
				temp1=temp1->next;
			}
		
		}
		if(temp1 == NULL&&temp2!=NULL){
			while(temp2!=NULL){
				llist_append(sum->row_lst[i],temp2->col_ind,-(temp2->val));
				temp2=temp2->next;
			}
		
		}
		if(temp2 == NULL&&temp1!=NULL){
			while(temp1!=NULL){
				llist_append(sum->row_lst[i],temp1->col_ind,(temp1->val));
				temp1=temp1->next;
			}		
		
		}
		i++;
	
	}
	return *sum;	


}
