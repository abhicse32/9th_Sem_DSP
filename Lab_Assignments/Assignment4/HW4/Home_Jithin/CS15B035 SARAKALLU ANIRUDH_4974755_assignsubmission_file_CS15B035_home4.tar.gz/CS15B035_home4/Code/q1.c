#include <stdio.h>
#include <stdlib.h>
#include "SparseMatrix.h"

void print_matrix(Matrix mat) {
	int i;
	Node* temp;
	for (i=0;i<mat.n_rows;i++) {
		temp=mat.row_lst[i]->head;
		if(temp==NULL) continue;
		while (temp!=NULL) {
			printf("%d ",temp->val);
			temp=temp->next;
		}
			printf("\n");
	}
}

int main() {
	int choice;
	scanf("%d", &choice);
	Matrix mat;
	while (choice!=-1) {
		int m, n;
		scanf("%d%d", &m, &n);
		Matrix mat1;
		mat1.n_rows=m;
		mat1.row_lst=(LList**) malloc(m * sizeof(LList*));
		int i, j, input;
		for (i=0; i < m; i++) {
			mat1.row_lst[i]=llist_new();
			for (j=0; j<n; j++) {
				scanf("%d", &input);
				if (input!=0) {
					llist_append(mat1.row_lst[i], j, input);
				}
			}
		}
			if (choice==1){
				Matrix mat2;
				mat2.n_rows = m;
				mat2.row_lst = (LList**) malloc(m * sizeof(LList*));
				for (i = 0; i < m; i++) {
					mat2.row_lst[i] = llist_new();
					for (j = 0; j < n; j++) {
						scanf("%d", &input);
						if (input!= 0) {
							llist_append(mat2.row_lst[i], j, input);
						}
					}
				}
				mat = add(mat1, mat2);
				free(mat2.row_lst);
			}	
			if(choice==2){
				Matrix mat2;
				mat2.n_rows = m;
				mat2.row_lst = (LList**) malloc(m * sizeof(LList*));
				for (i = 0; i < m; i++) {
					mat2.row_lst[i] = llist_new();
					for (j = 0; j < n; j++) {
						scanf("%d", &input);
						if (input!= 0) {
							llist_append(mat2.row_lst[i], j, input);
						}
					}
				}
				mat = subtract(mat1, mat2);
				free(mat2.row_lst);
				
			}
		 
		if(choice==3){
			Matrix vect;
			vect.n_rows = n;
			vect.row_lst = (LList**) malloc(n * sizeof(LList*));
			for (i = 0; i < n; i++) {
				vect.row_lst[i] = llist_new();
				scanf("%d", &input);
				llist_append(vect.row_lst[i], 0, input);
			}
			mat = matrix_vect_multiply(mat1, vect);
			free(vect.row_lst);
		}
		print_matrix(mat);
		scanf("%d", &choice);
		free(mat1.row_lst);
		free(mat.row_lst);
	}
	return 0;
}
