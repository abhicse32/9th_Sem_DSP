#include "CList.h"
#include<stdlib.h>
#include <stdio.h>


// Create a new node with next set to NULL
CNode* cnode_new( int data)
{
	CNode * temp=(CNode*)malloc(sizeof(CNode));
	temp->data=data;
	temp->next=NULL;
	return temp;
}



// Create an empty list (head shall be NULL)
CList* clist_new()
{
	CList *temp=(CList*)malloc(sizeof(CList));
	temp->head=NULL;
	return temp;
}

// Traverse the linked list and return its size
int clist_size( CList* lst )
{
	CNode *p=lst->head;
	
	if(lst->head==NULL)
	return 0;
	int count=1;
	if(lst->head->next==NULL)
	return count;
	p=p->next;
	while(p!=lst->head)
	{
		count++;
		p=p->next;
	}
	return count;
}

// Traverse the linked list and print each element
void clist_print( CList* lst )
{
	if(lst->head==NULL)
	return ;
	CNode *p=lst->head;
	printf("%d ",p->data);
	p=p->next;
	while(p!=lst->head)
	{
		printf("%d ",p->data);
		p=p->next;
	}
	
	printf("\n");
}

//get the element at position @idx
int clist_get( CList* lst, int idx )
{
	int i;
	/*if(lst->head==NULL)
	return -1;*/
	if(idx==0)
	return lst->head->data;
	if(idx>=clist_size(lst))
	return -1;
	CNode *p=(CNode*)malloc(sizeof(CNode));
	p=lst->head;
	for(i=0;i<idx;i++)
	{
		p=p->next;
	}
	return p->data;
}

// Add a new element at the end of the list
void clist_append( CList* lst, int data )
{
	
	CNode *temp=(CNode*)malloc(sizeof(CNode));
	
	if(lst->head==NULL)
	{
	lst->head=temp;
	temp->data=data;
	temp->next=temp;
	return ;
	}
	CNode * p=lst->head;
	while(p->next!=lst->head)
	{
		
		p=p->next;
	}

	temp->data=data;
	p->next=temp;
	temp->next=lst->head;
	
}

// Add a new element at the beginning of the list
void clist_prepend( CList *lst, int data )
{
	clist_append( lst, data );
	CNode *p=lst->head;
	while(p->next!=lst->head)
	{
		p=p->next;
	}
	lst->head=p;
}

// Add a new element at the @idx index
void clist_insert( CList* lst, int idx, int data )
{
	
	
	if(idx==0)
	{
		clist_prepend(  lst,data );
		return ;
	}
	
	if(lst->head==NULL)
	{
		return;
	}
	else if(idx==clist_size( lst ))
	{
	clist_append( lst, data );
	return ;	
	}
	else if(idx>clist_size( lst ))
	{
		return ;
	}
	CNode * p=lst->head;
	CNode * q=lst->head;
	CNode *temp=(CNode*)malloc(sizeof(CNode));
	temp->data=data;
	int i;
	for(i=0;i<idx;i++)
	{
		q=p;
		p=p->next;
	}
	q->next=temp;
	temp->next=p;
	
}

// Remove an element from the end of the list
void clist_remove_last( CList* lst )
{
	if(lst->head==NULL)
	{
		return;
	}
	if(lst->head->next==lst->head)
	{
		lst->head=NULL;
	}
	
	CNode *p=lst->head;
	while(p->next->next!=lst->head)
	{
		p=p->next;
	}
	p->next=lst->head;
}

// Remove an element from the beginning of the list
void clist_remove_first( CList* lst )
{
	if(lst->head==NULL)
	{
		return ;
	}
	if(lst->head->next==lst->head)
	{
		lst->head=NULL;
		return ;
	}
	CNode *p=lst->head;
	while(p->next!=lst->head)
	{
		p=p->next;
	}
	lst->head=lst->head->next;
	p->next=lst->head;
	
}

// Remove an element from an arbitrary @idx position in the list
void clist_remove( CList* lst, int idx )
{
	if(lst->head==NULL)
	{
		return;
	}
	if(idx==0)
	{
	clist_remove_first( lst )	;
	return ;
	}
	else if(idx==clist_size( lst ))
	{
	clist_remove_last( lst );
	return ;	
	}
	else if(idx>clist_size( lst ))
	{
		return ;
	}
	CNode *p=lst->head;
	CNode *q=lst->head;
	int i;
	for(i=0;i<idx;i++)
	{
		q=p;
		p=p->next;
	}
	q->next=p->next;
	
}

// reverse the list
void clist_reverse(CList* lst)
{	
	CNode *temp=(CNode*)malloc(sizeof(CNode));
	if(lst->head==NULL||lst->head->next==NULL)
	return ;
	
	int i,j,n;
	n=clist_size(lst);
	i=0;
	CNode *p;
	
	while(n-i>0)
	{
	p=lst->head;
	for(j=0;j<i;j++)
	{
		p=p->next;
	}
	temp->data=p->data;
	clist_remove( lst, i);
	clist_prepend( lst, temp->data );
	i++;
	}
	
}
