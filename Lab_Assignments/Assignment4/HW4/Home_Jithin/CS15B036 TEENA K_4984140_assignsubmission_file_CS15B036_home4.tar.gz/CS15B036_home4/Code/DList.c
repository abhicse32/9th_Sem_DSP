#include"DList.h"
#include<stdlib.h>
#include <stdio.h>

// Create a new node with next set to NULL
DNode* dnode_new( int data)
{
	DNode *temp = (DNode*)malloc(sizeof(DNode));
	temp->data=data;
	temp->next=NULL;
	return temp;
}

// Create an empty list (head shall be NULL)
DList* dlist_new()
{
	DList *temp=(DList*)malloc(sizeof(DList));
	temp->head=NULL;
return temp;	
}

// Traverse the linked list and return its size
int dlist_size( DList* lst )
{
	int count=0;
	if(lst->head==NULL)
	{
		return 0;
	}
	DNode *p=lst->head;
	while(p!=NULL)
	{
		count++;
		p=p->next;
	}
	return count;
}
// Traverse the linked list and print each element
void dlist_print( DList* lst )
{
	if(lst->head==NULL)
	{
		return ;
	}
	DNode *p=lst->head;
	while(p!=NULL)
	{
		printf("%d ",p->data);
		p=p->next;
	}
printf("\n");
}

//get the element at position @idx
int dlist_get( DList* lst, int idx )
{	
	if(lst->head==NULL)
	{
		return -1;
	}

	if(idx>=dlist_size( lst ))
	return -1;
	DNode *p=lst->head;
	int i;
	for(i=0;i<idx;i++)
	{
		p=p->next;
	}
	return p->data;
}

// Add a new element at the end of the list
void dlist_append( DList* lst, int data )
{
	DNode *p=lst->head;
	DNode * temp= (DNode*)malloc(sizeof(DNode));
	if(lst->head==NULL)
	{
		lst->head=temp;
		temp->data=data;
	}
	else
	{
	
	while((p->next)!=NULL)
	{
		p=p->next;
	}
	
	p->next=temp;
	temp->data=data;
	temp->prev=p;
}
	
}

// Add a new element at the beginning of the list
void dlist_prepend( DList* lst, int data )
{
	DNode *temp=(DNode*)malloc(sizeof(DNode));
	if(lst->head==NULL)
	{
		lst->head=temp;
		temp->data=data;	
	}
	else
	{
	
	temp->data=data;
	temp->next=lst->head;
	lst->head->prev=temp;
	lst->head=temp;
}
	
}

// Add a new element at the @idx index
void dlist_insert( DList* lst, int idx, int data )
{
	
		int i;
	
	if(idx==0)
	{
		dlist_prepend( lst, data );
		return ;
	}
	else if(idx==dlist_size( lst ))
	{
		dlist_append( lst, data );
		return ;
	}
	else if(idx>dlist_size( lst ))
	{
		return ;
	}
	DNode *temp=(DNode*)malloc(sizeof(DNode));
	DNode *p=lst->head;
	{
		
		for(i=0;i<idx-1;i++)
		{
			p=p->next;
		}
		temp->data=data;
		temp->next=p->next;
		p->next=temp;
		temp->next->prev=temp;
		temp->prev=p;
		
	}
}

// Remove an element from the end of the list
void dlist_remove_last( DList* lst )
{
	if(lst->head==NULL)
	{
		return;
	}
	if(lst->head->next==NULL)
	{
		lst->head=NULL;
		return ;
	}
	else
	{
	
	DNode *temp=(DNode*)malloc(sizeof(DNode));
	DNode *p=lst->head;
	while(p->next!=NULL)
	{
		p=p->next;
	}
	p->prev->next=NULL;
	
}
}

// Remove an element from the beginning of the list
void dlist_remove_first( DList* lst )
{
	DNode *p;
	if(lst->head==NULL)
	{
		return;
	}
	if(lst->head->next==NULL)
	{
		lst->head=NULL;
		return;
	}
	else
	{
		p=lst->head->next;
		lst->head=p;
		p->prev=NULL;
	}
}

// Remove an element from an arbitrary @idx position in the list
void dlist_remove( DList* lst, int idx )
{
	
	if(idx==0)
	{	
		dlist_remove_first( lst );
		
		return ;
		
	}

	if(lst->head==NULL)
	{
		return ;
	}
	
	else if(idx>dlist_size( lst ))
	{
		return ;	
	}
	else if(idx==dlist_size( lst ))
	{
		dlist_remove_last( lst );
		return;
	}
	DNode *temp=(DNode*)malloc(sizeof(DNode));
	DNode *p=lst->head;
	int i;
	{
		for(i=0;i<idx;i++)
		{
			p=p->next;
		}
		p->prev->next=p->next;
		p->next->prev=p->prev;
	}
}

void dlist_reverse(DList* lst)
{
	if(lst->head==NULL||lst->head->next==NULL)
	{
	return ;
	}
	DNode *q=lst->head;
	DNode *temp = NULL;  

	while(q!=NULL)
	{
	temp = q->prev;
       	q->prev = q->next;
       	q->next = temp;              
       	q = q->prev;
	}
	if(temp != NULL )
	q=temp->prev;	

	lst->head=q;
	
}
