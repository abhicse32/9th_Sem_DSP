/*
*Written by Teratipally Srikar,CS15B037
*This program contains functions
*That performs operation on
*given circular linked list
*/
#include "CList.h"  /*Including required header files*/
#include<stdio.h>
#include<stdlib.h>

CNode* cnode_new( int data) /*This function creates a new node and returns its pointer*/
{
    CNode *new = (CNode*) malloc(sizeof(CNode));
    new->data = data;
    new->next = NULL;
    return new;
}

CList* clist_new()  /*This function creates a new circular linked list and returns its pointer*/
{
    CList* x = (CList*) malloc(sizeof(CList));
    x->head=NULL;
    return x;
}

int clist_size( CList* lst )    /*This function calculates the size of the given circular linked list*/
{
    int length = 0; /*Counter*/
    if( (lst-> head) == NULL) return length;    /*Since if head is pointing to null, then length will be zero*/
    else{
            length++;
            CNode* counter;  /*Counter*/
            counter = (lst->head)->next;
            while(counter!=(lst->head))
                {
                    counter = counter->next;
                    length++;
                }
            return length;
        }
}

void clist_print( CList* lst )  /*This function prints the data in the circular linked list*/
{
    int length = clist_size(lst);   /*This variable holds the length of the given list*/

    if(length ==0);
    else    {
                int i;  /*Counter*/
                CNode* counter = (lst->head);   /*Counter*/
                for(i=0;i<length;i++)
                    {
                        printf("%d ",counter->data);
                        counter = counter->next;
                    }
                printf("\n");
            }
}

int clist_get( CList* lst, int idx )    /*This function returns the data in the idx th element in the given list*/
{
    int length = clist_size(lst);   /*This variable holds the length of the given list*/

    if( length <= idx) return -1;
    else    {
                int i = 0;  /*Counter*/
                CNode *counter = (lst->head);   /*Counter*/

                while(idx!=i)
                    {
                        counter = (counter->next);
                        i++;
                    }

                return counter->data;
            }
}

void clist_append( CList* lst, int data )   /*This function inserts a node at the end of the list*/
{
    int length = clist_size(lst);/*This variable holds the length of the given list*/

    if(length==0)   {
                        CNode *node = cnode_new(data);  /*Counter*/
                        lst->head = node;
                        node->next = (lst->head);
                    }

    else    {
                CNode *counter = (lst->head);       /*Counter*/
                int i = 0;                          /*Counter*/

                while( i!= (length-1))
                    {
                        counter = counter->next;
                        i++;
                    }

                CNode *node = cnode_new(data);
                node->next = (lst->head);
                counter->next = node;
            }
}

void clist_prepend( CList* lst, int data )  /*This function inserts a node at the beginning of the list*/
{
    int length = clist_size(lst);   /*This variable holds the length of the given list*/

    if(length==0)   {
                        CNode *node = cnode_new(data);
                        lst->head = node;
                        node->next = lst->head;
                    }

    else    {
                CNode* n = (CNode*) malloc(sizeof(CNode)); /*Creating a new node*/
                n->data = data;     /*Adding data into it*/
                n -> next = (lst->head);
                lst -> head = n;

                CNode* counter = lst->head;     /*Counter*/
                int i = 0;                      /*Counter*/

                while(i!=length)
                    {
                        counter=counter->next;
                        i++;
                    }
                counter->next = lst->head;
            }
}

void clist_insert( CList* lst, int idx, int data )  /*This function inserts a node in the given index*/
{
    int length = clist_size(lst);   /*This variable stores the length of the given array*/

    if(idx==0) clist_prepend(lst,data); /*Since, if idx=0 we can directly prepend it*/
    else if(idx>=length) clist_append(lst,data);    /*Since if idx=l we can directly append it*/

    else    {
                int i = 0;                      /*Counter*/
                CNode* counter = lst->head;     /*Counter*/

                while(i!=(idx-1))
                    {
                        counter = counter->next;
                        i++;
                    }

                CNode* node = cnode_new(data);
                node->next = (counter->next);
                counter->next = node;
            }
}

void clist_remove_first( CList* lst )   /*This function removes a node at the beginning of the list*/
{
    int length = clist_size(lst);       /*This variable stores the length of the given array*/
    if(length == 0);    /*Since if length is 0, then nothing is to be done*/
    else if (length==1) lst->head=NULL; /*Since if there is only one element, then removing that element is fine*/

    else    {
                CNode* counter = lst->head;
                lst->head = counter->next;
                counter = lst->head;
                int i = 0;
                while(i!=(length-2))
                    {
                        counter = counter->next;
                        i++;
                    }
                counter->next = lst->head;
            }
}

void clist_remove_last( CList* lst )/*This function removes a node at the end of the list*/
{
    int length = clist_size(lst);
    if(length == 0);        /*Since if length is 0, then nothing is to be done*/
    else if (length==1) lst->head=NULL; /*Since if there is only one element, then removing that element is fine*/
    else    {
                int i = 0;                      /*Counter*/
                CNode* counter = lst->head;     /*Counter*/
                while(i!=(length-2))
                    {
                        counter = counter->next;
                        i++;
                    }
                counter->next = (lst->head);
            }
}

void clist_remove( CList* lst, int idx )/*This function removes a node of given index*/
{
    int length = clist_size(lst);/*This variable stores the length of the given list*/
    if(idx==0) clist_remove_first(lst); /*Since if length is 0, then nothing is to be done*/
    else if(idx== (length-1)) clist_remove_last(lst);   /*Since if there is only one element, then removing that element is fine*/
    else    {
                int i = 0;                  /*Counter*/
                CNode* counter = lst->head; /*Counter*/

                while(i!=(idx-1))
                    {
                        counter = counter->next;
                        i++;
                    }
                counter->next = (counter->next)->next;
            }
}

void clist_reverse(CList* lst)  /*This function reverses the given list*/
{
    int l = clist_size(lst);    /*This variable stores the length of the given list*/
    if((l==1) || (l==0));   /*Since if there is only one or no element, nothing is to be done*/
    else    {
                CNode* counter = lst->head;     /*Counter*/
                int i = 0;                      /*Counter*/
                while(i!=(l-1))
                    {
                        counter = counter->next;
                        i++;
                    }
                CNode* last_element = counter;

                for(i=l-1; counter!=(lst->head); i--)
                    {
                        CNode* lol = lst->head;
                        int j = 0;
                        while(j!=(i-1))
                            {
                                lol = lol->next;
                                j++;
                            }
                        counter->next = lol;
                        counter = lol;
                    }
                (lst->head)->next = last_element;
                lst->head = last_element;
            }
}
