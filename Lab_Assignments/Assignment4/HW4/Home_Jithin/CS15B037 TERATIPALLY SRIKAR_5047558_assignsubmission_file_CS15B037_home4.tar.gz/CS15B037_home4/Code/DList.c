/*
*Written by Teratipally Srikar,CS15B037
*This program contains functions
*That performs operation on
*given double linked list
*/
#include "DList.h"  /*Including the required header files*/
#include<stdio.h>
#include<stdlib.h>

DNode* dnode_new(int data)  /*This function creates a new node and returns its address*/
{
    DNode *new = (DNode*) malloc(sizeof(DNode));
    new->data = data;
    new->next = NULL;
    new->prev = NULL;
    return new;
}

DList* dlist_new()  /*This function creates a new linked list and returns its address*/
{
    DList* x = (DList*) malloc(sizeof(DList));
    x->head=NULL;
    return x;
}

int dlist_size( DList* lst )    /*This function calculates the size of the given linked list*/
{
    int length = 0;
    if( (lst-> head) == NULL) return length;    /*Since if head is pointing to null, then length will be zero*/
    else{
          DNode* counter = lst->head;
          length++;
          while((counter->next)!=NULL)
            {
                counter = counter->next;
                length++;
            }
          return length;
        }
}

void dlist_print( DList* lst )  /*This function prints the elements in the given linked list*/
{
    if(lst->head == NULL);  /*If the linked list is null then there is nothing to be printed*/

    else{
            DNode* counter;  /*Counter*/
            counter = lst-> head;

            while( counter!=NULL)   /*Since, we have to print the data till we hit the null pointer*/
                {
                    printf("%d ",counter->data);
                    counter = (counter->next);
                }
        }
    printf("\n");   /*Prints a new line*/
}

int dlist_get( DList* lst, int idx )    /*This function returns the data stored in the idx th index of a given linked list*/
{
    int l = dlist_size(lst);    /*Computing the length of the linked list*/
    if((l-1)<idx) return -1;   /*If the idx is greater than the size then we have to return int minimum*/
    int length = 0; /*Counter*/
    DNode* counter = lst->head;  /*Counter*/

    while(length != idx)    {
                                counter = counter->next;
                                length++;
                            }
    return counter->data;
}

void dlist_append( DList* lst, int data )   /*This function creates a new node and appends it at the end of the linked list*/
{
    int length = dlist_size(lst);   /*This variables stores the size of the given double linked list array*/

    if(length==0)   {
                        DNode* new = dnode_new(data);
                        lst->head = new;
                    }

    else    {
                DNode* counter = lst->head; /*Counter*/
                int i = 0;  /*Counter*/
                while(i!=(length-1))
                    {
                        counter = counter->next;
                        i++;
                    }
                DNode* new = dnode_new(data);
                counter->next = new;
                new->prev = counter;
            }
}

void dlist_prepend( DList* lst, int data )  /*This function creates a new node and inserts at the beginning of the array*/
{
    if(lst->head == NULL)   {
                                dlist_append(lst,data);
                            }   /*Since if there are no elements it is same as appending*/
    else{
            DNode* new = dnode_new(data);
            new->next = lst->head;
            (lst->head)->prev = new;
            lst->head = new;
        }
}

void dlist_insert( DList* lst, int idx, int data )  /*This function adds a node at the idx th index of the given double linked list*/
{
    int length = dlist_size(lst);   /*This variable stores the number of elements in the given double linked list*/
    if(idx==0) dlist_prepend(lst,data);
    else if (idx == length) dlist_append(lst,data);
    else if ( idx > length );     //dlist_append(lst,data) /*Change ha to done here*/
    else    {
                int i=0;    /*Counter*/
                DNode* counter = lst->head;     /*Counter*/
                while(i!=(idx-1))
                    {
                        counter = counter->next;
                        i++;
                    }
                DNode* new = dnode_new(data);
                new->next = counter->next;
                counter->next->prev = new;
                counter->next = new;
                new->prev = counter;
            }
}

void dlist_remove_last( DList* lst )    /*This function removes the last element of the given linked list*/
{
    int length = dlist_size(lst);   /*This variable stores the size of the given double linked list*/
    if(length==0);
    else if (length==1) lst->head = NULL;
    else    {
                int i = 0;
                DNode* counter = lst->head;
                while(i!=(length-2))
                    {
                        counter = counter->next;
                        i++;
                    }
                counter->next = NULL;
            }
}

void dlist_remove_first( DList* lst )   /*This function removes a node at the beginning of the given list*/
{
    if(lst->head == NULL);
    else if ((lst->head)->next == NULL) lst->head= NULL;
    else    {
                lst->head = (lst->head)->next;
                (lst->head)->prev = NULL;
            }
}

void dlist_remove( DList* lst, int idx )    /*This function removes a given index*/
{
    int length = dlist_size(lst);
    if(idx==0) dlist_remove_first(lst);
    else if (idx==(length-1)) dlist_remove_last(lst);
    else    {
                int i = 0;  /*Counter*/
                DNode* counter = lst->head;     /*Counter*/
                while(i!=(idx-1))
                    {
                        counter = counter->next;
                        i++;
                    }
                counter->next = (counter->next)->next;
                (counter->next)->prev = counter;
            }
}

void dlist_reverse(DList* lst)      /*This function reverses the given double linked list*/
{
    int length = dlist_size(lst);
    if((length==0) || (length==1));
    else    {
                int i = 0;      /*Counter*/
                DNode* counter = lst->head;     /*Counter*/
                for(i=0;i<(length-1);i++)
                    {
                        DNode* temp = counter->next;
                        counter->next = counter->prev;
                        counter->prev = temp;
                        counter = counter->prev;
                    }
                counter->next = counter->prev;
                counter->prev = NULL;
                lst->head = counter;
            }
}
