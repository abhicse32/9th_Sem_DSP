/*
*Written by Teratipally Srikar,CS15B037
*This program contains functions
*which operates on given
*linked lists
*/

#include "List.h"   /*Including the required header files*/
#include<stdio.h>
#include<stdlib.h>
#include<limits.h>

Node* node_new( int col_ind, int val)   /*This function creates a new node and returns it's address*/
{
    Node *new = (Node*) malloc(sizeof(Node));
    new->val = val;
    new->col_ind = col_ind;
    new->next = NULL;
    return new;
}

LList* llist_new()  /*This function creates a new linked list and returns its address*/
{
    LList* x = (LList*) malloc(sizeof(LList));
    x->head=NULL;
    return x;
}

int llist_size( LList* lst )    /*This function computes the size of the given linked list*/
{
    int length = 0;
    if( (lst-> head) == NULL) return length;    /*Since if head is pointing to null, then length will be zero*/
    else{
            Node* counter;  /*Counter*/
            counter = lst->head;
            while( counter!=NULL)   /*Since the end of the list is characterized by having NULL at its next datatype*/
                {
                    counter = counter->next;
                    length++;
                }
            return length;
        }
}

void llist_print( LList* lst)   /*This function prints the given linked list*/
{
    if(lst->head == NULL) return;  /*If the linked list is null then there is nothing to be printed*///changed here

    else{
            Node* counter;  /*Counter*/
            counter = lst->head;

            while(counter!=NULL)   /*Since, we have to print the data till we hit the null pointer*/
                {
                    printf("%d ",counter->val);
                    counter = (counter->next);
                }

                /*Prints a new line*/
        }
   printf("\n");
}

Node* llist_get( LList* lst, int idx )  /*This function returns the address of the index idx in the linked list*/
{
    int l = llist_size(lst);    /*Computing the length of the linked list*/
    int length = 0; /*Counter*/
    Node* counter = lst->head;  /*Counter*/

    while(length != idx)    {
                                counter = counter->next;
                                length++;
                            }
    return counter;
}

void llist_prepend( LList* lst, int col_ind, int val)   /*This function adds a node at the beginning of linked list by the given data*/
{

    Node* n = (Node*) malloc(sizeof(Node)); /*Creating a new node*/
    n->val = val;     /*Adding data into it*/
    n->col_ind = col_ind;
    n -> next = (lst->head);
    lst -> head = n;
}

void llist_append( LList* lst, int col_ind, int val )   /*This function creates a node the end of array and feeds data to it*/
{
    if (lst->head == NULL) {
                                Node *node = (Node*) malloc(sizeof(Node));  /*Creating a new node*/
                                node->val = val;
                                node->col_ind = col_ind;
                                node->next = NULL;
                                lst->head = node;
                           }
    else {
            Node *counter;      /*Counter*/
            counter = lst->head;
            while ((counter->next)!= NULL)
                {
                    counter = counter->next;
                }
            Node *x= node_new(col_ind,val);    /*Creating a new node*/
            counter->next = x;
        }
}

void llist_insert( LList* lst, int idx, int col_ind, int val)   /*This function adds a node at the index idx in the given linked list*/
{
    int length = llist_size(lst);   /*Getting the size of the list*/

    if ((length==0) || (idx == 0)) llist_prepend(lst,col_ind,val); /*Since if idx=0 then it is same as prepending*/
    else if (idx>=length) llist_append(lst,col_ind,val);   /*Since if idx is very large then it is same as appending*/
    else    {
                Node *counter;  /*Counter*/
                counter = lst->head;
                int l = 1;  /*Counter*/

                while (l!=(idx))
                    {
                        counter = counter->next;
                        l++;
                    }
                Node *node = (Node*) malloc(sizeof(int));   /*Creating a new node*/
                node->val = val;
                node->col_ind = col_ind;                          /*Adding data into it*/
                node->next = counter->next;
                counter->next  = node;
            }
}
