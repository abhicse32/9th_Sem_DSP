/*
*Written by Teratipally Srikar, CS15B037
*This program contains 3 functions,
*which adds,subtracts and multiples
*the given sparse matrices
*/

#include "SparseMatrix.h"   /*Including the required header files*/
#include<stdlib.h>
#include<stdio.h>

Matrix add(Matrix A, Matrix B)  /*This function adds two sparse matrices and then returns the result*/
{
    Matrix C;   /*Declaring matrix which has to returned*/
    C.n_rows = A.n_rows;    /*Since C and A will have same number of rows*/
    C.row_lst = (LList**) malloc((sizeof(LList*))*(A.n_rows));
    int i;  /*Counter*/

    for(i=0;i<(C.n_rows);i++)   /*This loop adds the elements*/
        {

            C.row_lst[i] = llist_new(); /*Intializing a row*/
            int n = llist_size(A.row_lst[i]);   /*Stores the number of columns in ith row of A*/
            int m = llist_size(B.row_lst[i]);   /*Stores the number of columns in ith row of B*/

            int j = 0;  /*Counter*/
            int k = 0;  /*Counter*/

            while((j<n) && (k<m))
                {
                    Node* elementa = llist_get(A.row_lst[i],j); /*Stores the address of the currently processing node*/
                    Node* elementb = llist_get(B.row_lst[i],k); /*Stores the address of the currently processing node*/

                    if((elementa->col_ind) > (elementb->col_ind))   {
                                                                        llist_append(C.row_lst[i], (elementb->col_ind), (elementb->val));
                                                                        k++;
                                                                    }

                    else if((elementa->col_ind) < (elementb->col_ind))   {
                                                                             llist_append(C.row_lst[i],(elementa->col_ind),(elementa->val));
                                                                             j++;
                                                                         }
                    else    {
                                int sum = (elementa->val) + (elementb->val);
                                /*if(sum!=0)*/ llist_append(C.row_lst[i], (elementa->col_ind), sum);
                                j++;
                                k++;
                            }
                }

            while(j<n)  /*Since if matrix A elements are left, then we should directly append them into C*/
                {
                	Node* elementa = llist_get(A.row_lst[i],j);
                    llist_append( C.row_lst[i], elementa->col_ind, elementa->val);
                    j++;
                }

            while(k<m)  /*Since if matrix B elements are left, then we should directly append them into C*/
                {
                	Node* elementb = llist_get(B.row_lst[i],k);
                    llist_append( C.row_lst[i], elementb->col_ind, elementb->val);
                    k++;
                }
        }

   return C;    /*Returning the resultant matrix*/
}

Matrix subtract(Matrix A, Matrix B) /*This function subtracts two matrices and returns a resultant matrix*/
{
    Matrix C;   /*Declaring matrix which has to returned*/
    C.n_rows = A.n_rows;    /*Since C and A will have same number of rows*/
    C.row_lst = (LList**) malloc((sizeof(LList*))*(A.n_rows));
    int i;  /*Counter*/

    for(i=0;i<(C.n_rows);i++)   /*This loop subtracts the elements*/
        {

            C.row_lst[i] = llist_new(); /*Intializing a row*/
            int n = llist_size(A.row_lst[i]);   /*Stores the number of columns in ith row of A*/
            int m = llist_size(B.row_lst[i]);   /*Stores the number of columns in ith row of B*/

            int j = 0;  /*Counter*/
            int k = 0;  /*Counter*/

            while((j<n) && (k<m))
                {
                    Node* elementa = llist_get(A.row_lst[i],j); /*Stores the address of the currently processing node*/
                    Node* elementb = llist_get(B.row_lst[i],k); /*Stores the address of the currently processing node*/

                    if((elementa->col_ind) > (elementb->col_ind))   {
                                                                        llist_append(C.row_lst[i], (elementb->col_ind), -(elementb->val));
                                                                        k++;
                                                                    }

                    else if((elementa->col_ind) < (elementb->col_ind))   {
                                                                             llist_append(C.row_lst[i],(elementa->col_ind),(elementa->val));
                                                                             j++;
                                                                         }
                    else    {
                                int sum = (elementa->val) - (elementb->val);
                                /*if(sum!=0)*/ llist_append(C.row_lst[i], (elementa->col_ind), sum);
                                j++;
                                k++;
                            }
                }

            while(j<n)  /*Since if matrix A elements are left, then we should directly append them into C*/
                {
                	Node* elementa = llist_get(A.row_lst[i],j);
                    llist_append( C.row_lst[i], elementa->col_ind, elementa->val);
                    j++;
                }

            while(k<m)  /*Since if matrix B elements are left, then we should directly append them into C*/
                {
                	Node* elementb = llist_get(B.row_lst[i],k);
                    llist_append( C.row_lst[i], elementb->col_ind, -(elementb->val));
                    k++;
                }
        }

   return C;    /*Returning the resultant matrix*/
}

Matrix matrix_vect_multiply( Matrix A, Matrix B)    /*This function multiplies a given matrix and a vector*/
{
	Matrix C;   /*This matrix stores the result*/
	C.n_rows = A.n_rows;    /*Since the number of rows will be equal to the first matrix*/
    C.row_lst = (LList**) malloc((sizeof(LList*))*(C.n_rows));
    int i;  /*Counter*/
    for(i=0;i<C.n_rows;i++) /*This loop multiples the matrix, for each iteration it gets 1 element*/
    	{
    		C.row_lst[i] = llist_new();
    		int n = llist_size(A.row_lst[i]);   /*Number of num-zero elements in ith row of A*/
    		int sum = 0;    /*For storing the sum*/
    		int j;  /*Counter*/
    		for(j=0;j<n;j++)
    			{
    				Node* elementa = llist_get(A.row_lst[i],j);
    				int column = elementa->col_ind;
    				if(((B.row_lst[column])->head)!=NULL)
    				        {
    				            Node* elementb = llist_get(B.row_lst[column],0);
    				            sum = sum + ((elementa->val)*(elementb->val));
    				        }

    				//sum = sum + ((elementa->val)*(B.row_lst[column]->head->val));
    			}

    		/*if(sum!=0)*/	llist_append(C.row_lst[i],0,sum);   /*Since we have to append the result only if the element is non zero*/

    	}
    return C;   /*Returning the result of the matrix*/
}

