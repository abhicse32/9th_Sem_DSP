/*
*Written by Teratipally Srikar, CS15B037
*This program is driver program
*which does a specific operation on
*two user given sparse matrices
*/

#include<stdio.h>   /*Including the required header files*/
#include<stdlib.h>
#include"List.h"
#include"SparseMatrix.h"

int main()
{
	while(1)
        {
			int option; /*This option has the info, of what has to be performed*/
			scanf("%d",&option);

			if(option==-1) break;   /*Terminating condition-Centinal*/

			switch(option)
            {

				case 1:     /*If option 1 we have to take 2 matrices and add them*/
				case 2:     /*If option 2 we have to take 2 matrices and subtract them*/
				        {
				            Matrix A;   /*First matrix*/
				            Matrix B;   /*Second matrix*/

				            int m;  /*Number of rows for a matrix*/
				            int n;  /*Columns of rows for a matrix*/
				            scanf("%d",&m);
				            scanf("%d",&n);

				            A.n_rows = m;   /*Assigning the number of rows*/
				            B.n_rows = m;   /*Assigning the number of rows*/

				            A.row_lst = (LList**) malloc((sizeof(LList*))*m);
				            B.row_lst = (LList**) malloc((sizeof(LList*))*m);

				            int temp;   /*Temporary variable*/
				            int i;      /*Counter*/
				            int j;      /*Counter*/

				            for(i=0;i<m;i++)    /*This loop scans the data given by the user and stores them in matrix A*/
				                {

				                    A.row_lst[i] = llist_new();
				                    for(j=0;j<n;j++)
				                        {
				                            scanf("%d",&temp);
				                            if(temp!=0) {
				                                            llist_append(A.row_lst[i],j,temp);
				                                        }
				                        }
				                 }

				            for(i=0;i<m;i++)    /*This loop scans the data given by the user and stores them in matrix B*/
				                {

				                    B.row_lst[i] = llist_new();
				                    for(j=0;j<n;j++)
				                        {
				                            scanf("%d",&temp);
				                            if(temp!=0) {
				                                            llist_append(B.row_lst[i],j,temp);
				                                        }
				                        }
				                 }

				            Matrix C;

				            if(option==1) C = add(A,B); /*If option 1 we have to add them*/
				            else C = subtract(A,B);     /*If option 2 we have to subtract them*/

				            for(i=0;i<m;i++)
				                llist_print(C.row_lst[i]);  /*Printing the result*/

				            break;
				        }

				case 3:     /*If option 3 we have to multiply a matrix and vector*/
				        {
				            int m;  /*Number of rows in the matrix*/
				            int n;  /*Number of columns in the matrix*/
				            scanf("%d",&m);
				            scanf("%d",&n);

				            Matrix A;   /*matrix*/
				            Matrix B;   /*Column Vector*/
				            A.n_rows = m;
				            B.n_rows = n;

				            A.row_lst = (LList**) malloc(sizeof(LList*)*m);
				            B.row_lst = (LList**) malloc(sizeof(LList*)*n);
				            int i;  /*Counter*/
				            int j;  /*Counter*/
				            int temp;   /*Temporary variable*/

				            for(i=0;i<m;i++)    /*This loop scans the input given by user and stores them in matrix A*/
				                {
				                    A.row_lst[i] = llist_new();
				                    for(j=0;j<n;j++)
				                        {
				                            scanf("%d",&temp);
				                            if(temp!=0) {
				                                            llist_append(A.row_lst[i],j,temp);
				                                        }
				                        }
				                 }

				            for(i=0;i<n;i++)    /*This loop scans the input given by user and stores them in matrix B*/
				                {
				                    B.row_lst[i] = llist_new();
				                    scanf("%d",&temp);
				                    if(temp!=0) llist_append(B.row_lst[i],0,temp);
				                }
				           Matrix C = matrix_vect_multiply(A,B);    /*Matrix C holds the output when matrix and vector are multiplied*/

				            for(i=0;i<C.n_rows;i++) /*Printing the result*/
				                llist_print(C.row_lst[i]);

				            break;
				        }
            }

            fflush(stdout);
        }
}

