
#include "CList.h"  
#include<stdio.h>
#include<stdlib.h>

CNode* cnode_new( int data) 
{
    CNode *new = (CNode*) malloc(sizeof(CNode));
    new->data = data;
    new->next = NULL;
    return new;
}

CList* clist_new()  
{
    CList* x = (CList*) malloc(sizeof(CList));
    x->head=NULL;
    return x;
}

int clist_size( CList* lst )   
{
    int length = 0; 
    if( (lst-> head) == NULL) return length;    
    else{
            length++;
            CNode* counter;  
            counter = (lst->head)->next;
            while(counter!=(lst->head))
                {
                    counter = counter->next;
                    length++;
                }
            return length;
        }
}

void clist_print( CList* lst )  
{
    int length = clist_size(lst);  

    if(length ==0);
    else    {
                int i;  
                CNode* counter = (lst->head);   
                for(i=0;i<length;i++)
                    {
                        printf("%d ",counter->data);
                        counter = counter->next;
                    }
                printf("\n");
            }
}

int clist_get( CList* lst, int idx )    
{
    int length = clist_size(lst);   

    if( length <= idx) return -1;
    else    {
                int i = 0;  
                CNode *counter = (lst->head);   

                while(idx!=i)
                    {
                        counter = (counter->next);
                        i++;
                    }

                return counter->data;
            }
}

void clist_append( CList* lst, int data )  
{
    int length = clist_size(lst);
    if(length==0)   {
                        CNode *node = cnode_new(data);  
                        lst->head = node;
                        node->next = (lst->head);
                    }

    else    {
                CNode *counter = (lst->head);      
                int i = 0;                          

                while( i!= (length-1))
                    {
                        counter = counter->next;
                        i++;
                    }

                CNode *node = cnode_new(data);
                node->next = (lst->head);
                counter->next = node;
            }
}

void clist_prepend( CList* lst, int data )  {
    int length = clist_size(lst);  

    if(length==0)   {
                        CNode *node = cnode_new(data);
                        lst->head = node;
                        node->next = lst->head;
                    }

    else    {
                CNode* n = (CNode*) malloc(sizeof(CNode)); 
                n->data = data;    
                n -> next = (lst->head);
                lst -> head = n;

                CNode* counter = lst->head;     
                int i = 0;                     

                while(i!=length)
                    {
                        counter=counter->next;
                        i++;
                    }
                counter->next = lst->head;
            }
}

void clist_insert( CList* lst, int idx, int data )
  {
    int length = clist_size(lst);  
    if(idx==0) clist_prepend(lst,data); 
    else if(idx>=length) clist_append(lst,data);    

    else    {
                int i = 0;                      
                CNode* counter = lst->head;     

                while(i!=(idx-1))
                    {
                        counter = counter->next;
                        i++;
                    }

                CNode* node = cnode_new(data);
                node->next = (counter->next);
                counter->next = node;
            }
}

void clist_remove_first( CList* lst ){  
    int length = clist_size(lst);       
    if(length == 0);    
    else if (length==1) lst->head=NULL; 
    else    {
                CNode* counter = lst->head;
                lst->head = counter->next;
                counter = lst->head;
                int i = 0;
                while(i!=(length-2))
                    {
                        counter = counter->next;
                        i++;
                    }
                counter->next = lst->head;
            }
}

void clist_remove_last( CList* lst ){
    int length = clist_size(lst);
    if(length == 0);        
    else if (length==1) lst->head=NULL;
    else    {
                int i = 0;                     
                CNode* counter = lst->head;     
                while(i!=(length-2))
                    {
                        counter = counter->next;
                        i++;
                    }
                counter->next = (lst->head);
            }
}

void clist_remove( CList* lst, int idx ){
    int length = clist_size(lst);
    if(idx==0) clist_remove_first(lst); 
    else if(idx== (length-1)) clist_remove_last(lst);   
    else    {
                int i = 0;                  
                CNode* counter = lst->head; 
                while(i!=(idx-1))
                    {
                        counter = counter->next;
                        i++;
                    }
                counter->next = (counter->next)->next;
            }
}

void clist_reverse(CList* lst)  
{
    int l = clist_size(lst);   
    if((l==1) || (l==0));   
    else    {
                CNode* counter = lst->head;     
                int i = 0;                      
                while(i!=(l-1))
                    {
                        counter = counter->next;
                        i++;
                    }
                CNode* last_element = counter;

                for(i=l-1; counter!=(lst->head); i--)
                    {
                        CNode* lol = lst->head;
                        int j = 0;
                        while(j!=(i-1))
                            {
                                lol = lol->next;
                                j++;
                            }
                        counter->next = lol;
                        counter = lol;
                    }
                (lst->head)->next = last_element;
                lst->head = last_element;
            }}

