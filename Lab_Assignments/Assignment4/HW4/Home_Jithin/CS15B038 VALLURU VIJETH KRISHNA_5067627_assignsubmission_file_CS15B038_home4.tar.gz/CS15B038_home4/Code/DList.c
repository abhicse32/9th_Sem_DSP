/*
*written by VijethV CS15B038
*this program
* does operations on doubly linked lists
*/

#include<stdio.h>
#include "DList.h"
#include<stdlib.h>

DNode* dnode_new( int data)
{
     DNode* x = (DNode*)malloc(sizeof(DNode));
     
     x->data = data;
     x->prev = NULL;
     x->next = NULL;

     return x;
}

DList* dlist_new()
{
     DList* x = (DList*)malloc(sizeof(DList));
     
     x->head = NULL;
     
     return x;
}

int dlist_size( DList* lst )
{
     int i = 0;
     DNode* x;

     x = lst->head;

     if(x == NULL) return 0;

     while(x != NULL)
          
          {
            i++;
            x = x->next;                     
          }

     return i;
}

void dlist_print( DList* lst )
{
     DNode* x;
     
     x = lst->head;

     while(1)

          {
            if(x->next == NULL) {printf("%d \n", x->data); break;}
            else printf("%d ", x->data);
            x = x->next;
          }

}

int dlist_get( DList* lst, int idx )
{
     int i = 0;
     DNode* x;

     x = lst->head;

     if(idx > dlist_size( lst )-1) return -1;

     while(1)
          
          {
            if(i == idx) return x->data;
            x = x->next;
            i++;
          }
}

void dlist_append( DList* lst, int data )
{
     DNode* x;
     DNode* y = dnode_new(data);

     x = lst->head;

     if(x == NULL) 

          {  
            lst->head = y;
            return ;
          }

     while(1)

          {
            if(x->next == NULL) { y->prev = x; x->next = y; break;}
            x = x->next;          
          }     
}

void dlist_prepend( DList* lst, int data )
{
     DNode* x;
     DNode* y = (DNode*)malloc(sizeof(DNode));

     x = lst->head;

     if(x == NULL)

          {
            dlist_append( lst, data );
            return ;
          }

     y->data = data;
     y->next = x;
     y->prev = NULL;
     x->prev = y;
     lst->head = y;

}

void dlist_insert( DList* lst, int idx, int data )
{
     

     DNode* x;  
     DNode* y = (DNode*)malloc(sizeof(DNode));
     DNode* t;
     int i = 0;

     x = lst->head;

     y->data = data;
 
     if(idx == 0) 

          {
            dlist_prepend( lst, data);
            return ;
          }

     
     if(idx > dlist_size( lst )-1) return ;

     while(1)

          {
            if(i == idx - 1)

               {
                 t = x->next;
                 x->next = y;
                 y->prev = x;
                 y->next = t;
                 t->prev = y;
                 break;
               }

            i++;
            x = x->next;            
          }
}

void dlist_remove_last( DList* lst )
{
     DNode* x;

     x = lst->head;

     if(x->next == NULL)

          {
            x = NULL;
            return ; 
          }

     while(1)

          {
            if((x->next)->next == NULL) 

               {
                 x->next = NULL;
                 break;
               }

            x = x->next;
          }
}

void dlist_remove_first( DList* lst )
{
     DNode* x;

     x = lst->head;

     if(x->next == NULL)

          {
            x = NULL;
            return ; 
          }
     
     lst->head = x->next;
     (lst->head)->prev = NULL;
}

void dlist_remove( DList* lst, int idx )
{
     DNode* x;
     int i = 0;

     x = lst->head;

     if(idx == 0)

          {
            dlist_remove_first( lst );
            return;
          }

     if(idx == dlist_size( lst )-1)

          {
            dlist_remove_last( lst );
            return ;
          }

     while(1)

          {
            if(i == idx - 1) 

               {
                 ((x->next)->next)->prev = x; 
                 x->next = (x->next)->next;
                 break;
               }
             
            i++;
            x = x->next;
          }
}

void dlist_reverse(DList* lst)
{
     int i;
     
     for(i=1; i<dlist_size( lst ); i++)

          {
            dlist_prepend( lst, dlist_get( lst, i ) ); 
            dlist_remove( lst, i+1 );
          }
}
