/*
*written by VijethV CS15B038
*this program
* does operations on linked lists
*/

#include<stdio.h>
#include "List.h"
#include<stdlib.h>

Node* node_new( int data1, int data2)
{
     Node* x = (Node*)malloc(sizeof(Node));

     x->col_ind = data1;
     x->val = data2;
     x->next = NULL;

     return x;
}


LList* llist_new()
{
     LList* x = (LList*)malloc(sizeof(LList));

     x->head = NULL;

     return x;     
}


int llist_size( LList* lst )
{
     int i = 0;
     Node* x;

     x = lst->head;

     if(x == NULL) return 0;

     while(x != NULL)
          
          {
            i++;
            x = x->next;                     
          }

     return i;
}


void llist_print( LList* lst )
{
     Node* x;
     x = lst->head;
     if(x == NULL) {return;}

     while(1)
          
          {
            if(x->next == NULL) {printf("%d \n", x->val); break;}
            else printf("%d ",x->val);
            x = x->next;
          }

}


Node* llist_get( LList* lst, int idx )
{
     int i = 0;
     Node* x;

     x = lst->head;

     while(1)
          
          {
            if(i == idx) return x;
            x = x->next;
            i++;
          }

}


void llist_append( LList* lst, int data1, int data2)
{
     Node* x;
     Node* y = node_new( data1, data2);

     x = lst->head;

     if(x == NULL) 

          {  
            lst->head = y;
            return ;
          }

     while(1)

          {
            if(x->next == NULL) { x->next = y; break; }
            x = x->next;          
          }     
}


void llist_prepend( LList* lst, int data1, int data2)
{
     Node* x;
     Node* y = (Node*)malloc(sizeof(Node));

     x = lst->head;
     y->val = data2;
     y->col_ind = data1;
     y->next = x;
     lst->head = y;
}

void llist_insert( LList* lst, int idx, int data1, int data2)
{
     Node* x;  
     Node* y = (Node*)malloc(sizeof(Node));
     Node* t;
     int i = 0;

     x = lst->head;

     y->val = data2;
     y->col_ind = data1; 

     if(idx == 0) 

          {
            llist_append( lst, data1, data2);
            return ;
          }

     if(idx == llist_size( lst )-1)

          {
            llist_prepend( lst, data1, data2);
            return ;
          }

     while(1)

          {
            if(i == idx - 1)

               {
                 t = x->next;
                 x->next = y;
                 y->next = t;
                 break;
               }

            i++;
            x = x->next;            
          }
}
