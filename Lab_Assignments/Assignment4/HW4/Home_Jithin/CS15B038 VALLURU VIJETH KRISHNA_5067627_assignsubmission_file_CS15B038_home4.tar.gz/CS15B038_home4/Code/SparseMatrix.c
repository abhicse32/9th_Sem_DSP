/*
*written by VijethV CS15B038
*this program
* adds and subtracts 2 Marix
* multipies a matrix with a vector
*/
#include<stdio.h>
#include "List.h"
#include "SparseMatrix.h"
#include <stdlib.h>

Matrix add(Matrix A, Matrix B)
{
     Matrix C;
     int i, j, k, m, n, l;
     l = A.n_rows;

     C.row_lst = (LList**)malloc(sizeof(LList*)*l);
     
     i=0; j=0; k=0;
     C.n_rows = l;     

     for(k=0; k<l; k++) // adding row wise

          {
            i = 0; j = 0;

            n = llist_size(A.row_lst[k]);
            m = llist_size(B.row_lst[k]);

            C.row_lst[k] = llist_new();

            while(i<n && j<m) // i, j are counters   this part is simlar to merging tw sorted arrays

               {     
                 if(llist_get(A.row_lst[k], i)->col_ind < llist_get(B.row_lst[k], j)->col_ind)

                    {
                      llist_append(C.row_lst[k], llist_get(A.row_lst[k], i)->col_ind, llist_get(A.row_lst[k], i)->val);
                      i++;
                    } 

                 else if(llist_get(A.row_lst[k], i)->col_ind > llist_get(B.row_lst[k], j)->col_ind)

                    {
                      llist_append(C.row_lst[k], llist_get(B.row_lst[k], j)->col_ind, llist_get(B.row_lst[k], j)->val);
                      j++;
                    }   

                 else
     
                    {
                      if(llist_get(B.row_lst[k], j)->val + llist_get(A.row_lst[k], i)->val != 0)
                      {
                         llist_append(C.row_lst[k], llist_get(B.row_lst[k], j)->col_ind, llist_get(B.row_lst[k], j)->val + llist_get(A.row_lst[k], i)->val);
                      }
                       i++; j++;
                    } 
               }

            while(i<n)

               {
                 llist_append(C.row_lst[k], llist_get(A.row_lst[k], i)->col_ind, llist_get(A.row_lst[k], i)->val);
                 i++;                 
               } 

            while(j<m)

               {
                 llist_append(C.row_lst[k], llist_get(B.row_lst[k], j)->col_ind, llist_get(B.row_lst[k], j)->val);
                 j++;                 
               }     
          }

     return C;
}

Matrix subtract(Matrix A, Matrix B)    // same as addition
{
     Matrix C;
     int l = A.n_rows;

     C.row_lst = (LList**)malloc(sizeof(LList*)*l);

     int i, j, k, m, n;
     
     i=0; j=0; k=0;
     C.n_rows = l;     

     for(k=0; k<l; k++)

          {
            i = 0; j = 0;

            n = llist_size(A.row_lst[k]);
            m = llist_size(B.row_lst[k]);

            C.row_lst[k] = llist_new();

            while(i<n && j<m)

               {
                 if(llist_get(A.row_lst[k], i)->col_ind < llist_get(B.row_lst[k], j)->col_ind)

                    {
                      llist_append(C.row_lst[k], llist_get(A.row_lst[k], i)->col_ind, llist_get(A.row_lst[k], i)->val);
                      i++;
                    } 

                 else if(llist_get(A.row_lst[k], i)->col_ind > llist_get(B.row_lst[k], j)->col_ind)

                    {
                      llist_append(C.row_lst[k], llist_get(B.row_lst[k], j)->col_ind, -(llist_get(B.row_lst[k], j)->val));
                      j++;
                    }   

                 else
          
                    {
                      if(llist_get(A.row_lst[k], i)->val - llist_get(B.row_lst[k], j)->val != 0)
                      {
                         llist_append(C.row_lst[k], llist_get(B.row_lst[k], j)->col_ind, llist_get(A.row_lst[k], i)->val - llist_get(B.row_lst[k], j)->val);
                         
                      }
                      i++; j++;
                    } 
               }

            while(i<n)

               {
                 llist_append(C.row_lst[k], llist_get(A.row_lst[k], i)->col_ind, llist_get(A.row_lst[k], i)->val);
                 i++;                 
               } 

            while(j<m)

               {
                 llist_append(C.row_lst[k], llist_get(B.row_lst[k], j)->col_ind, -(llist_get(B.row_lst[k], j)->val));
                 j++;                 
               }     
          }

     return C;
}

Matrix matrix_vect_multiply(Matrix mat, Matrix vect)
{
     Matrix Z;
     int i, j, k, m, n, l, sum;
     l = mat.n_rows;                                    // vect is stored as a row Matrix to make program easier

     Z.row_lst = (LList**)malloc(sizeof(LList*)*l);
     
     Z.n_rows = l; 

   

     for(k=0; k<l; k++)   // multiplying kth row of mat with vect

          {
            i = 0; j = 0; sum =0;

            m = llist_size(mat.row_lst[k]);
            n = llist_size(vect.row_lst[0]);

            Z.row_lst[k] = llist_new();

            while(i<m && j<n)   // this part is almost similar to merging two sorted arrays with slight change

               {
                 if(llist_get(mat.row_lst[k], i)->col_ind < llist_get(vect.row_lst[0], j)->col_ind)

                    {
                      i++;
                    } 

                 else if(llist_get(mat.row_lst[k], i)->col_ind > llist_get(vect.row_lst[0], j)->col_ind)

                    {
                      j++;
                    }   

                 else
     
                    {
                      sum = sum + (llist_get(mat.row_lst[k], i)->val) * (llist_get(vect.row_lst[0], j)->val);
                      i++; j++;
                    } 
               }

            
               
                 llist_append(Z.row_lst[k], 1, sum);
               

          }

     return Z;
}
