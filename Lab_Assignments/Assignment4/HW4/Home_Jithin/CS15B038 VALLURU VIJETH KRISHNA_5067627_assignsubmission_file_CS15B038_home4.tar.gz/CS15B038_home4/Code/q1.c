#include<stdio.h>
#include "List.h"
#include "SparseMatrix.h"
#include <stdlib.h>

Matrix scan(Matrix A, int m, int n);  // a function to take input for a Matrix
void print(Matrix A, int m, int n);   // a function to print resultant

int main()
{
     int m, n;       // rows and columns
     int k;          // option
     

     scanf("%d",&k);  // option input
     
     while(k != -1)   // exiting if input is -1 

          {

            if(k == 1)

               { 
                 Matrix A, B, Z;
                 scanf("%d",&m);
                 scanf("%d",&n);
                 A = scan(A, m, n);
                 B = scan(B, m, n);
                 Z = add(A, B);
                 print(Z, m, n);
               }

            else if(k == 2)

               { 
                 Matrix A, B, Z;
                 scanf("%d",&m);
                 scanf("%d",&n);
                 A = scan(A, m, n);
                 B = scan(B, m, n);
                 Z = subtract(A, B);
                 print(Z, m, n);
               }

            else if(k == 3)

               { 
                 Matrix A, B, Z;
                 scanf("%d",&m);
                 scanf("%d",&n);
                 A = scan(A, m, n);
                 B = scan(B, 1, n);                    // taking input Nx1 Matrix as 1xN since it is easier during Multiplication 
                 Z = matrix_vect_multiply(A, B);
                 print(Z, m, 1);
               }

            scanf("%d",&k);            // taking option again

            fflush(stdout);
          }

}

Matrix scan(Matrix A, int m, int n)
{
     int i, j, x;
     A.row_lst = (LList**)malloc(sizeof(LList*)*m);
          
     A.n_rows = m;

     for(i=1; i<=m; i++)
          
          {
            A.row_lst[i-1] = llist_new();

            for(j=1; j<=n; j++)

               {
                 scanf("%d",&x);

                 if(x != 0)

                    {
                      llist_append(A.row_lst[i-1], j, x);  // since it is sparse append only if != 0 
                    }        
               }
          }
     
     return A;
}

void print(Matrix A, int m, int n)
{
     int i;
     
     for(i=1; i<=m; i++)

          {
            llist_print( A.row_lst[i-1] );
               fflush(stdout);
          }
}
