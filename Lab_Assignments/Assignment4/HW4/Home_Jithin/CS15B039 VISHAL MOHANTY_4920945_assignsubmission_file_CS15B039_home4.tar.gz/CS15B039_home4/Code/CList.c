#include "CList.h"
#include<stdlib.h>
#include<stdio.h>

// Create a new node with next set to NULL
CNode* cnode_new( int data){
	CNode *node;
	node = (CNode *)malloc( sizeof(CNode));
	if (node==NULL)
		printf("Malloc Error");
	else{
		node->data = data;
		node->next = NULL;
	}
	return node;
}

// Create an empty list (head shall be NULL)
CList* clist_new(){
	CList * clist;
	clist = (CList *)malloc(sizeof(CList));
	clist->head = NULL;
	return clist;
}

// Traverse the linked list and return its size
int clist_size( CList* lst ){
	int count=1;
	CNode *cur;
	cur = lst->head;
	if(cur!=NULL){
		while(cur->next !=lst->head){
			count++;
			cur = cur->next;
		}
	}
	return count;
}

// Traverse the linked list and print each element
void clist_print( CList* lst ){
	//printf("print called");
	CNode* cur;
	cur = lst->head;
	if(cur != NULL){
		printf("%d ", cur->data);
		cur = cur -> next;
	}
	else return;	
	while(cur!=lst->head){
		printf("%d ", cur->data);
		cur =cur ->next;	
	}
	printf("\n");
	fflush(stdout);

}

//get the element at position @idx
int clist_get( CList* lst, int idx ){
	int n = clist_size(lst);
	CNode *cur;
	int count=0;
	
	cur = lst->head;
	
	if(idx>=0 && idx<n && cur!=NULL){
		while(count!=idx){
			cur = cur->next;
			count++;
		}
		return(cur->data);
	}
	return(-1);
	
}

// Add a new element at the end of the list
void clist_append( CList* lst, int data ){
	//printf("append called");
	//fflush(stdout);
	CNode *new_node, *cur;
	
	new_node = cnode_new(data);
	cur = lst->head;
	
	if(cur!=NULL){
		while(cur->next!=lst->head){
			cur = cur->next;
		}
		cur->next = new_node;
		new_node->next = lst->head;
	}
	else{
		new_node->next = new_node;
		lst->head = new_node;
	}		
}	

// Add a new element at the beginning of the list
void clist_prepend( CList* lst, int data ){
	CNode *new_node, *cur;
	int n = clist_size(lst);
	
	new_node = cnode_new(data);
	cur = lst->head;
	
	if(cur!=NULL){
		while(cur->next!=lst->head)
			cur = cur->next;
	}
	if(lst->head!=NULL){
		new_node->next = (lst->head);
		lst->head = new_node;
		cur->next = new_node;
	}
	else{
		new_node->next = new_node;
		lst->head = new_node;
	}
}

// Add a new element at the @idx index
void clist_insert( CList* lst, int idx, int data ){
	int n = clist_size(lst);
	CNode *cur;
	int count=1;
	
	CNode *new_node;
	
	new_node = cnode_new(data);
	
	cur = lst->head;
	if(idx>0 && idx<=n && cur!=NULL){
		while(count!=idx){
			cur = cur->next;
			count++;
		}
		new_node->next = cur->next;
		cur->next = new_node;
	}
	else if(idx==0){
		clist_prepend( lst, data );
	}
	
}

// Remove an element from the end of the list
void clist_remove_last( CList* lst ){
	int n = clist_size(lst);
	clist_remove(lst, n-1);	
}

// Remove an element from the beginning of the list
void clist_remove_first( CList* lst ){
	clist_remove(lst, 0);
}

// Remove an element from an arbitrary @idx position in the list
void clist_remove( CList* lst, int idx ){
	CNode *cur, *tmp, *cur1;
	cur1 = cur = lst->head;
	int count=1;
	int n = clist_size(lst);
	
	if(cur!=NULL){
		while(cur1->next!=lst->head)
			cur1 = cur1->next;
	}
	if(idx>0 && idx<n && cur!=NULL){
		while(count!=idx){
			cur = cur->next;
			count++;
		}
		tmp = cur->next;
		cur->next = (cur->next)->next;
		free(tmp);
	}
	else if(idx==0 && cur!=NULL){
		tmp = cur;
		lst->head = (cur->next);
		free(tmp);
		cur1->next = lst->head;
	}
}

void reverse(CNode * head, CNode * cur){

	if(head==NULL)
		return;
	CNode *tmp;
	if(cur->next == head){
		cur->next = cur;
		return;
		}
	else{
		reverse(head, cur->next);
		tmp = cur->next;
		cur->next = (cur->next)->next;
		tmp->next = cur;
	}
}

// reverse the list
void clist_reverse(CList* lst){
	reverse(lst->head, lst->head);
	lst->head = (lst->head)->next;
}


