#include "DList.h"
#include<stdlib.h>
#include<stdio.h>

// Create a new node with next set to NULL
DNode* dnode_new( int data){
	DNode *node;
	
	node = (DNode *)malloc(sizeof(DNode));
	if (node==NULL)
		printf("Malloc Error");
	else{
		node->data = data;
		node->prev = NULL;
		node->next = NULL;
	}
	return node;
}

// Create an empty list (head shall be NULL)
DList* dlist_new(){
	DList * lst;
	lst = (DList *)malloc(sizeof(DList));
	lst->head = NULL;
	return lst;
}

// Traverse the linked list and return its size
int dlist_size( DList* lst ){
	DNode * cur;
	int count = 0;
	cur = lst->head;
	while(cur !=NULL){
		count++;
		cur=cur->next;
		}
	return count;
}

// Traverse the linked list and print each element
void dlist_print( DList* lst ){
	//printf("Print called");
	//fflush(stdout);
	DNode * cur;
	cur = lst->head;
	if(cur!=NULL){
		while(cur->next!=NULL){
			printf("%d ", cur->data);
			cur = cur->next;
			}
		printf("%d \n", cur->data);
		fflush(stdout);
	}
}

//get the element at position @idx
int dlist_get( DList* lst, int idx ){
	int n, count;
	count = 0;
	DNode * cur;
	
	n=dlist_size(lst);
	cur = lst->head;
	if(idx>=0 && idx<n){
		while(count!=idx){
			cur = cur->next;
			count ++;
			}
		return cur->data;
	}
	else
		return (-1);
}

// Add a new element at the end of the list
void dlist_append( DList* lst, int data ){
	//printf("Append called");
	//fflush(stdout);
	DNode *cur;
	DNode *new_node;
	int n = dlist_size(lst);
	int count = 1;
	
	new_node = dnode_new( data);
	cur=lst->head;
	
	if(cur!=NULL){

		while(cur->next!=NULL){
			cur = cur->next;
		}
		new_node->next = NULL;
		new_node->prev = cur;
		cur->next = new_node;
	}
	else{
		lst->head = new_node;
	}
}

// Add a new element at the beginning of the list
void dlist_prepend( DList* lst, int data ){
	DNode *new_node;
	
	new_node = dnode_new( data);
	
	if(lst->head!=NULL){
		lst->head->prev = new_node;
		new_node->next = lst->head;
		}
	lst->head = new_node;
}

// Add a new element at the @idx index
void dlist_insert( DList* lst, int idx, int data ){
	DNode *cur;
	DNode *new_node;
	int count=1;
	int n = dlist_size(lst);
	
	new_node = dnode_new( data);
	cur=lst->head;
	
	if(cur!=NULL && idx>0 && idx<n){
		while(count<idx){
			cur = cur->next;
			count++;	
		}
	
		new_node->prev = cur;
		(cur->next)->prev = new_node;
		new_node->next = cur->next;
		cur->next = new_node;
	}
	else if(idx==0){
		dlist_prepend(lst, data);
		
		
	}
	else if(idx==n)
		dlist_append(lst, data);
}

// Remove an element from the end of the list
void dlist_remove_last( DList* lst ){
	DNode *cur, *tmp;

	int n = dlist_size(lst);
	int count = 1;

	cur=lst->head;
	
	if(cur!=NULL){
		while(count<n){
			cur = cur->next;
			count++;	
		}
		tmp = cur;
		if(n!=1)
			(cur->prev)->next = NULL;
		else
			lst->head = NULL;
		free(tmp);
	}
}

// Remove an element from the beginning of the list
void dlist_remove_first( DList* lst ){
	dlist_remove( lst, 0);
}

// Remove an element from an arbitrary @idx position in the list
void dlist_remove( DList* lst, int idx ){
	DNode *cur, *tmp;

	int count=0;
	int n = dlist_size(lst);
	
	cur=lst->head;
	
	if(cur!=NULL && idx>=0 && idx<n){
		while(count<idx){
			cur = cur->next;
			count++;	
		}
		if(cur->next!=NULL){
			tmp = cur;
			(cur->next)->prev = cur->prev;
			if(idx!=0)
				(cur->prev)->next = cur->next;
			else
				lst->head = cur->next;
			free(tmp);
			}
		else{
			tmp = cur;
			(cur->prev)->next = cur->next;
			free(tmp);
			}
	}
}

void dlist_reverse(DList* lst){
	if(lst->head==NULL) return;
	DNode *cur, *tmp;
	cur = lst->head;
	while(cur->next!=NULL){
		tmp = cur->next;
		cur->next = cur->prev;
		cur->prev = tmp;
		cur = cur->prev;
	}
	(lst->head)=cur;
	tmp = cur->next;
	cur->next = cur->prev;
	cur->prev = tmp;
}	
