#include "List.h"
#include "List.h"
#include<ctype.h>
#include<stdlib.h>
#include<limits.h>
#include<stdio.h>

// Create a new node with next set to NULL
Node* node_new( int data1, int data2){
	
	Node *node;
	node = (Node *)malloc( sizeof(Node));
	if (node==NULL)
		printf("Malloc Error");
	else{
		node->col_ind = data1;
		node->val = data2;
		node->next = NULL;
	}
	return node;
}

// Create an empty list (head shall be NULL)
LList* llist_new(){
	
	LList * lst;
	lst = (LList *)malloc(sizeof(LList));
	lst->head = NULL;
	return lst;
}

// Traverse the linked list and return its size
int llist_size( LList* lst ){

	Node * cur;
	int count = 0;
	cur = lst->head;
	while(cur !=NULL){
		count++;
		cur=cur->next;
		}
	return count;
}

// Traverse the linked list and print each element
void llist_print( LList* lst ){

	Node * cur;
	cur = lst->head;
	while(cur!=NULL){
		printf("%d ", cur->val);
		cur=cur->next;
		}
	printf("\n");
}		

//get the element at position @idx
Node* llist_get( LList* lst, int idx ){

	int n, count;
	count = 0;
	Node * cur;
	
	n=llist_size(lst);
	cur = lst->head;
	if(idx>=0 && idx<n){
		while(count!=idx){
			cur = cur->next;
			count ++;
			}
		return cur;
	}
	else
		return (NULL);
	
}

// Add a new element at the end of the list
void llist_append( LList* lst, int data1, int data2 ){

	Node *cur;
	Node *new_node;
	new_node = node_new( data1, data2 );
	cur=lst->head;
	if (lst->head != NULL){
		while(cur->next != NULL){
			cur=cur->next;
		}
		cur->next = new_node;
	}
	else 
		lst->head = new_node;
}

// Add a new element at the beginning of the list
void llist_prepend( LList* lst, int data1, int data2 ){

	Node * new_node;
	new_node = node_new(data1, data2);
	new_node->next = lst->head;
	lst->head = new_node;
}

// Add a new element at the @idx index
void llist_insert( LList* lst, int idx, int data1, int data2 ){

	int n, count;
	Node * cur;
	Node * new_node;
	new_node = node_new(data1, data2);
	
	n = llist_size(lst);
	count = 1;

	if (lst->head!=NULL){
		cur = lst->head;
		if(idx>=0 && idx<n){
			if(idx!=0){
				while(count!=idx){
					cur = cur->next;
					count ++;	
				}
			new_node->next = cur->next;
			cur->next = new_node;
			}
			else
				llist_prepend(lst, data1, data2);
		}
		if(idx==n)	
			llist_append(lst, data1, data2);
		
		
	}
	else{
		lst->head = new_node;
		new_node->next = NULL;
	}
}
