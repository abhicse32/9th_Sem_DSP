#include "SparseMatrix.h"
#include<stdlib.h>
#include<stdio.h>

Matrix add(Matrix a, Matrix b){
		Matrix sum;
		int i, j, k;// Counters
		int m = a.n_rows;
		LList * a_row, * b_row, * s_row;
		Node * a_col, * b_col;
		
		sum.row_lst = (LList **)malloc(m * sizeof(LList *));
		sum.n_rows = a.n_rows;
		for(i=0;i<m;i++)
			sum.row_lst[i] = llist_new();
			
		for(i=0;i<a.n_rows;i++){
			a_row = a.row_lst[i];
			b_row = b.row_lst[i];
			s_row = sum.row_lst[i];
			j=0;
			k=0;
			
			
			a_col = llist_get(a_row, j);
			b_col = llist_get(b_row, k);
			
			while(a_col!=NULL && b_col!=NULL){	
				if(a_col->col_ind == b_col->col_ind){
					llist_append(s_row, a_col->col_ind, a_col->val + b_col->val);
					j++;
					k++;
					}
					
				else if(a_col->col_ind > b_col->col_ind){
					llist_append(s_row, b_col->col_ind, b_col->val);
					k++;
					}
					
				else {
					llist_append(s_row, a_col->col_ind, a_col->val);
					j++;
					}
				a_col = llist_get(a_row, j);
				b_col = llist_get(b_row, k);
				}
				
			while(a_col!=NULL){
				llist_append(s_row, a_col->col_ind, a_col->val);
				j++;
				a_col = llist_get(a_row, j);
			}
			
			while(b_col!=NULL){
				llist_append(s_row, b_col->col_ind, b_col->val);
				k++;
				b_col = llist_get(b_row, k);
			}
				
		}
		return sum;	
}

Matrix subtract(Matrix a, Matrix b){

		Matrix dif;
		int i, j, k;// Counters
		int m = a.n_rows;
		LList * a_row, * b_row, *d_row;
		Node * a_col, * b_col;
		
		dif.n_rows=m;
		dif.row_lst = (LList **)malloc(m * sizeof(LList *));
		for(i=0;i<m;i++)
			dif.row_lst[i] = llist_new();
			
		for(i=0;i<a.n_rows;i++){
			a_row = a.row_lst[i];
			b_row = b.row_lst[i];
			d_row = dif.row_lst[i];
			j=0;
			k=0;
			
			
			a_col = llist_get(a_row, j);
			b_col = llist_get(b_row, k);
			
			while(a_col!=NULL && b_col!=NULL){	
				if(a_col->col_ind == b_col->col_ind){
					llist_append(d_row, a_col->col_ind, a_col->val - b_col->val);
					j++;
					k++;
					}
					
				else if(a_col->col_ind > b_col->col_ind){
					llist_append(d_row, b_col->col_ind, -(b_col->val));
					k++;
					}
					
				else {
					llist_append(d_row, a_col->col_ind, a_col->val);
					j++;
					}
				a_col = llist_get(a_row, j);
				b_col = llist_get(b_row, k);
				}
				
			while(a_col!=NULL){
				llist_append(d_row, a_col->col_ind, a_col->val);
				j++;
				a_col = llist_get(a_row, j);
			}
			
			while(b_col!=NULL){
				llist_append(d_row, b_col->col_ind, -(b_col->val));
				k++;
				b_col = llist_get(b_row, k);
			}
				
		}

		return dif;	
}

Matrix matrix_vect_multiply(Matrix mat, Matrix vect){

		Matrix prod;
		int i;// Counters
		int m = mat.n_rows;
		int sum; // Temporary storage
		Node *cur;
		
		prod.row_lst = (LList **)malloc(m * sizeof(LList *));
		
		for(i=0;i<m;i++){
		    prod.row_lst[i] = llist_new();

			
			sum = 0;
			cur = mat.row_lst[i]->head;
			
			while(cur!=NULL){

				if(vect.row_lst[cur->col_ind]->head!=NULL)	
					sum+= (vect.row_lst[cur->col_ind]->head->val) * cur->val;
				cur = cur->next;
			}
			
				
			llist_append(prod.row_lst[i], 0, sum);
			}
		
		return prod;
}	
