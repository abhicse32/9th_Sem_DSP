#include "SparseMatrix.h"
#include<stdio.h>
#include<stdlib.h>

void mat_init(Matrix, int, int);

int main(void){
	
	int option;
	

	int i, j; //Counters
	int elm;
	int m, n;//Rows, cols
	
	scanf("%d",&option);
	
	while(option!=-1){
	
		scanf("%d%d", &m, &n);
	
			 
		Matrix a, b, v, ans;
		LList * ans_row;
		Node * ans_col;

		a.n_rows = m;
		a.row_lst = (LList **)malloc(m * sizeof(LList *));
		for(i=0;i<m;i++)
			a.row_lst[i] = llist_new();
	
		b.n_rows = m;
		b.row_lst = (LList **)malloc(m * sizeof(LList *));
		for(i=0;i<m;i++)
			b.row_lst[i] = llist_new();
	
		v.n_rows = n;
		v.row_lst = (LList **)malloc(n * sizeof(LList *));
		for(i=0;i<n;i++)
			v.row_lst[i] = llist_new();
		
		ans.n_rows = m;
		ans.row_lst = (LList **)malloc(m * sizeof(LList *));
		for(i=0;i<m;i++)
			ans.row_lst[i] = llist_new();
	
		switch(option){
	
			case 1: 
	
				mat_init(a, m, n);
				mat_init(b, m, n);
				ans = add(a, b);
				break;
			
			case 2: 

				mat_init(a, m, n);
				mat_init(b, m, n);
				ans = subtract(a, b);
				break;
			
			case 3: 				
				mat_init(a, m, n);
		
				mat_init(v, n, 1);	
			
				ans = matrix_vect_multiply(a, v);
				break;
			
			case -1:
				break;

		}
		
		if(option==-1)
			break;
			
		//printf("Printing answer");
		for(i=0;i<m;i++){
			
			ans_row = ans.row_lst[i];
			j=0;
			ans_col = llist_get(ans_row, j);
			
			while(ans_col!=NULL){
				printf("%d ", ans_col->val);
				fflush(stdout);
				j++;
				ans_col = llist_get(ans_row, j);
			}
			if(j!=0)
				printf("\n");
			
		}
		scanf("%d", &option);

	}
	
	
	
	return 0;
}

void mat_init(Matrix M, int m, int n){
	
	int i, j;
	int elm;
	
	M.n_rows = m;
	for(i=0;i<m;i++){
		for(j=0;j<n;j++){

			scanf("%d", &elm);
			if(elm!=0)
				llist_append(M.row_lst[i], j, elm);
		}
	}
}

