#include "CList.h"
#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<limits.h>

//creating a new node for a circular linked list
 
CNode* cnode_new( int data){

	CNode* new=(CNode*)malloc(sizeof(CNode));
	new->data=data;
	new->next=NULL;
	return new;
  
}

//creating a new empty circular linked list

CList* clist_new(){

	CList* New=(CList*)malloc(sizeof(CList));
	New->head=NULL;
	return New;
   
}

//calculating the size of a circular linked list

int clist_size( CList* lst ){

	int size=1;
	CNode* cur;
	cur=(lst->head);
	if(lst->head==NULL){
	      return 0;
	}
	
	
	for(;(cur->next)!=lst->head;cur=cur->next){
	
		size++;
	
	}
	return size;  
}

//printing the elements of a circular linked list

void clist_print( CList* lst ){
	
	CNode* cur=(lst->head)->next;

	if(lst->head==NULL){
		return;
	}
	printf("%d ",(lst->head)->data);
	

		for(;(cur)!=lst->head;cur=cur->next){
			printf("%d ",cur->data);
		}
		printf("\n");
}

//retrieving an element at index idx in a circular linked list

int clist_get( CList* lst, int idx ){

	CNode* cur;
	cur=lst->head;
	
	if(cur==NULL){
		return -1;
	}
	if(idx>=clist_size(lst) || idx<0){
		return -1;
	}
	else{
		if(idx==0){
			return cur->data;
		}
		
		else{
			cur=cur->next;
			       
			int i;
			for(i=1;cur!=lst->head && i<idx;){
				cur=cur->next;
				i++;
			}
			return cur->data;
		}
	}
}

//adding a node at the end of a ciicular linked list

void clist_append( CList* lst, int data ){

	CNode* cur;
	cur=lst->head;
	CNode* target=cnode_new(data);
	
	if(lst->head==NULL){
		lst->head=target;
		target->next=lst->head;
		return;
	}
	for(cur=lst->head;cur->next!=lst->head;cur=cur->next){

	}
		cur->next=target;
		target->next=lst->head;

}

//adding a node at the beginning of the circular linked list

void clist_prepend(CList*lst,int data){

	CNode* cur;
	cur=lst->head;
	CNode* target=cnode_new(data);

	if(lst->head==NULL){

		lst->head=target;
		target->next=target;
		return;
	}
	
	for(cur=lst->head;cur->next!=lst->head;cur=cur->next){
	
	}
	
	target->next=(lst->head);
	lst->head=target;
	cur->next=lst->head;
	
}

//inserting a node at index idx in a circular linked list

void clist_insert( CList* lst, int idx, int data ){
 
	int size=clist_size( lst );
	CNode* cur;
	cur=(lst->head);
	CNode* target = cnode_new(data);
	
	if(idx==0){
		clist_prepend(lst,data);
		return;
	}
	else if(idx==size){
		clist_append(lst,data);
		return;
	}
	else if(idx>size || idx<0){
		return;
	} 
	else {
		int i=0;
	
		for(cur=lst->head;(i<(idx-1))&&(cur->next)!=lst->head;cur=cur->next){
			i++;
		}
		
		target->next=cur->next;
		cur->next=target;
	}
}

//removing the last element of a circular linked list

void clist_remove_last( CList* lst ){
	CNode* cur;
	cur=lst->head;
	
	while((cur->next)->next!=lst->head){
		cur=cur->next;
	     
	}
	cur->next=lst->head;
}

//removing the first element of a circular linked list

void clist_remove_first( CList* lst ){

	CNode* cur;
	cur=lst->head;
	
	while(cur->next!=lst->head){

		cur=cur->next;
	}
	
	lst->head=(lst->head)->next;
	cur->next=lst->head;
}

//removing a node at index idx in a circular linked list

void clist_remove( CList* lst, int idx ){

	int size=clist_size(lst );
	
	if(idx==0){

		clist_remove_first(lst);
	}
	else if(idx==size-1){

		clist_remove_last(lst);
	}
	else if(idx>=size || idx<0){

		return ;
	}
	else{
	
		int i=0;
		CNode* cur;
		cur=(lst->head);
		
		for(;(i<(idx-1))&&(cur->next!=NULL);cur=cur->next){
			i++;
		}
		(cur->next)=((cur->next)->next);
	}
}

//reversing the elements of a circular linked list

void clist_reverse(CList*lst){

	CNode* temp1=lst->head;  //previous node
	CNode* temp2=temp1->next;//current node
	CNode* temp3=temp2;      //next node
	   
	while((temp2->next)!=lst->head){

		temp3=temp2->next;
		temp2->next=temp1;
		temp1=temp2;
		temp2=temp3;
	}
	temp2->next=temp1;
	(lst->head)->next=temp2;
	lst->head=temp2;
}

  

