#include "DList.h"
#include<stdio.h>
#include<stdlib.h>
#include<limits.h>

// Creating a new node with next set to NULL

DNode* dnode_new( int data){
	
	DNode* new=(DNode*)malloc(sizeof(DNode));
	new->data=data;
	new->next=NULL;
	new->prev=NULL;
	return new;
}

// Creating an empty list (head is NULL)
  
DList* dlist_new(){
	
	DList* New=(DList*)malloc(sizeof(DList));
	New->head=NULL;
	return New;
}

// Traversing the linked list and returning its size

int dlist_size( DList* lst ){

	DNode* cur;
	cur=(lst->head);
	int count=1;
	
	if(lst->head==NULL){
		return 0;
	}
	
	for(cur=(lst->head);cur->next!=NULL;cur=cur->next){
		count++;
	}
	return count;
}
 
 //Traversing the linked list and printing its elements      

 void dlist_print( DList* lst ){

	DNode* cur;
	if(lst->head==NULL){
		return;
	}
	else{
		cur=(lst->head);
	
		while(cur!=NULL){
			printf("%d ",cur->data);
			cur=cur->next;
		}
		printf("\n");
	}
}

 //get the element at position @idx

 int dlist_get( DList* lst, int idx ){

	DNode* cur;
	cur=lst->head;
	int size=dlist_size(lst);
	if(lst->head==NULL){
		return -1;
	}
	if(idx<0||idx>=size){
		return -1;
	}
	
	else{
		int i;
		for(i=0;(i<idx);i++){
			cur=cur->next;
		}
		return cur->data;
	}
	
}

 // Adding a new element at the end of the list

void dlist_append( DList* lst, int data ){

	DNode* cur=lst->head;
	DNode* target=dnode_new(data);
	
	if(lst->head==NULL){
		lst->head=target;
		target->next=NULL;
		return;
	}
		int i;
		for(cur=lst->head;cur->next!=NULL;cur=cur->next){
		
		}
		cur->next=target;
		target->next=NULL;
		target->prev=cur;
		return;
}

// Adding a new element at the beginning of the list

void dlist_prepend( DList* lst, int data ){

	DNode* cur=lst->head;
	DNode* target=dnode_new(data);
	
	if(lst->head==NULL){
		lst->head=target;
		return;
	}
	
	target->next=(lst->head);
	lst->head=target;
	(target->next)->prev=target;
	target->prev=NULL;
}

// Adding a new element at the @idx index

void dlist_insert( DList* lst, int idx, int data ){

	DNode* cur;
	cur=lst->head;
	DNode* target=dnode_new(data);
	
	int size=dlist_size(lst);
	
	if(idx==0){
		dlist_prepend(lst,data);
		return;
	}
	else if(idx==size){
		dlist_append(lst,data);
		return;
	}
	else if(idx<0||idx>size-1){
		return;
	}
	else{
		int i;
		for(cur=lst->head;(cur->next!=NULL)&&(i<idx-1);cur=cur->next){
			i++;
		}
		target->next=cur->next;
		(cur->next)->prev=target;
		target->prev=cur;
		cur->next=target;
		
	}
}

// Removing an element from the end of the list 

void dlist_remove_last( DList* lst ){
	
	DNode* cur=lst->head;
	if(lst->head!=NULL){
		if(cur->next==NULL){
			lst->head==NULL;
		}

		else{	
			while((cur->next)->next!=NULL){
				cur=cur->next;
			}
			cur->next=NULL;
		}
	}
}

// Removing an element from the beginning of the list

void dlist_remove_first( DList* lst ){

	DNode* cur=lst->head;
	if(lst->head==NULL){
		return;
	}
	else{
		lst->head=(lst->head)->next;
		(lst->head)->prev=NULL;
	}
}

 // Removing an element from an arbitrary @idx position in the list
 
void dlist_remove( DList* lst, int idx ){
	
	DNode* cur=(DNode*)malloc(sizeof(DNode));
	cur=lst->head;
	int size=dlist_size(lst);
	if(idx < 0 || idx > size){
		return;
	}
	if(lst->head==NULL){
		return;
	}
	if(idx==0){
		dlist_remove_first(lst);
		return;
	}
	else if(idx==size-1){
		dlist_remove_last(lst);
		return;
	}
	else{
		int i;
		for(cur=lst->head;(i<idx-1)&&(cur->next!=NULL);cur=cur->next){
			i++;
		}
		cur->next=(cur->next)->next;
		(cur->next)->prev=cur;
	}
}

 //reversing the linked list
 
void dlist_reverse(DList*lst){

	if (lst->head == NULL){
		return;
	}
	DNode *cur=lst->head;
	DNode *nex,*p;
	p=NULL;
	
	while(cur->next !=NULL){
	       nex=cur->next;
	       cur->next=p;
	       cur->prev=nex;
	       p=cur;
	       cur=nex;
	}
	cur->next=p;
	cur->prev=NULL;
	lst->head=cur;
   
}
 
  
    


   
