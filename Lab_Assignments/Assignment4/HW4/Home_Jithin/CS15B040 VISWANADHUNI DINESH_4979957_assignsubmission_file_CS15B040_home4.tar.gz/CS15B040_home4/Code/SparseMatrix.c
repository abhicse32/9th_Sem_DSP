#include "SparseMatrix.h"
#include "List.h"
#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<limits.h>

Matrix matrix_vect_multiply(Matrix mat, Matrix vect){

	int product=0;
	Matrix mul;
	mul.row_lst=(LList**)malloc(sizeof(LList*)*(mat.n_rows));
	mul.n_rows=mat.n_rows;
	
	for(int j=0;j<mat.n_rows;j++){
		mul.row_lst[j]=llist_new();
	}
	Node* cur1;
	Node* cur2;
	LList* cur3;
	
	for(int k=0;k<mat.n_rows;k++){
		cur1=(mat.row_lst[k])->head;
		cur3=(mul.row_lst[k]);
		for(int i=0;cur1!=NULL;i++){
		
			cur2=(vect.row_lst[i])->head;
			
			if((cur1->col_ind)==i){
		
				product=product+(cur1->val)*(cur2->val);
				cur1=cur1->next;
			}
		}
		llist_append(mul.row_lst[k],0,product);
		product=0;
	}
	return mul;
}

Matrix add(Matrix a, Matrix b){

	Matrix c;
	c.n_rows=a.n_rows;
	
	c.row_lst=(LList**)malloc(sizeof(LList*)*(a.n_rows));
	
	for(int j=0;j<a.n_rows;j++){
		c.row_lst[j]=llist_new();
	}
	
	int i=0;
	Node* cur1;
	Node* cur2;
	LList* c3;
			
	while(i<a.n_rows){
			cur1=(a.row_lst[i])->head;
			cur2=(b.row_lst[i])->head;
			c3=(c.row_lst[i]);
			while((cur1!=NULL) && (cur2!=NULL)){
	
				if((cur1->col_ind) == (cur2->col_ind)){
					llist_append(c3,cur1->col_ind,(cur2->val)+(cur1->val));
					cur1=cur1->next;
					cur2=cur2->next;
				}
				else if((cur1->col_ind) < (cur2->col_ind)){
					llist_append(c3,cur1->col_ind,(cur1->val));
					cur1=cur1->next;
				}
				else{
					llist_append(c3,cur2->col_ind,(cur2->val));
					cur2=cur2->next;
				}
			}
			if(cur1==NULL){
		
				while(cur2!=NULL){
					llist_append(c3,cur2->col_ind,cur2->val);
					cur2=cur2->next;
				}
			}
			if(cur2==NULL){
			
				while(cur1!=NULL){
					llist_append(c3,cur1->col_ind,cur1->val);
					cur1=cur1->next;
				}
			}
			i++;
		}
		return c;
}

Matrix subtract(Matrix a, Matrix b){

	Matrix c;
	
	c.row_lst=(LList**)malloc(sizeof(LList*)*(a.n_rows));
	c.n_rows=a.n_rows;
		
	for(int j=0;j<a.n_rows;j++){
		c.row_lst[j]=llist_new();
	}
	
	int k=0;
	Node* cur1;
	Node* cur2;
	LList* c3;
	while(k<a.n_rows){
		
			cur1=(a.row_lst[k])->head;
			cur2=(b.row_lst[k])->head;
			c3=(c.row_lst[k]);	
	
			while((cur1!=NULL)&& (cur2!=NULL)){
	
				if((cur1->col_ind) == (cur2->col_ind)){
					llist_append(c3,cur1->col_ind,(cur1->val)-(cur2->val));
					cur1=cur1->next;
					cur2=cur2->next;
				}
				else if((cur1->col_ind)< (cur2->col_ind)){
					llist_append(c3,cur1->col_ind,(cur1->val));
					cur1=cur1->next;
				}
				else{
					llist_append(c3,cur2->col_ind,-1*(cur2->val));
					cur2=cur2->next;
				}
							
			}
			
		
		
			if(cur1==NULL){
		
				while(cur2!=NULL){
					llist_append(c3,(cur2->col_ind),-1*(cur2->val));
					cur2=cur2->next;
				}
			}
			if(cur2==NULL){
			
				while(cur1!=NULL){
					llist_append(c3,(cur1->col_ind),cur1->val);
					cur1=cur1->next;
				}
			}
			k++;
			}
			return c;
}
	
