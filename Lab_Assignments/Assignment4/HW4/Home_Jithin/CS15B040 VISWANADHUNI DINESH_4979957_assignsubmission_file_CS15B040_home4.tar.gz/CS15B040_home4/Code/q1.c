#include "List.h"
#include"SparseMatrix.h"
#include<stdlib.h>
#include<stdio.h>

void print_matrix(Matrix mat) {
	int i;
	Node* temp;
	for (i=0;i<mat.n_rows;i++) {
		temp=mat.row_lst[i]->head;
		if(temp==NULL) continue;
		while (temp!=NULL) {
			printf("%d ",temp->val);
			temp=temp->next;
		}
			printf("\n");
	}
}
int main()
{
	int choice;
	int i;
	int j;
	int n;
	int m;
	int inp;
	scanf("%d",&choice);
	while(choice!=-1)
	{
		switch(choice)
		{
			case 1:
			case 2:{
				   	Matrix *a = (Matrix *)malloc(sizeof(Matrix));
					Matrix *b = (Matrix *)malloc(sizeof(Matrix));
					Matrix *c = (Matrix *)malloc(sizeof(Matrix));
					scanf("%d %d",&m,&n);
					a->n_rows = m;
					a->row_lst = (LList **)malloc(sizeof(LList *)*m);
					b->n_rows = m;
					b->row_lst = (LList **)malloc(sizeof(LList *)*m);
					for(i = 0;i < m;i++)
					{
						(a->row_lst[i]) = llist_new();
						for(j = 0;j < n;j++)
						{
							scanf("%d",&inp);
							if(inp != 0){
							llist_append((a->row_lst[i]),j,inp);
							}
						}
					}
					for(i = 0;i < m;i++)
					{
						(b->row_lst[i]) = llist_new();
						for(j = 0;j < n;j++)
						{
							scanf("%d",&inp);
							if(inp !=0){
							llist_append((b->row_lst[i]),j,inp);
							}
						}
					}
					if(choice == 1)
					{
						*c = add(*a,*b);
					}
					else
					{
						*c = subtract(*a,*b);
					}
					print_matrix(*c);
				free(a->row_lst);
				free(b->row_lst);
				free(c->row_lst);
					fflush(stdout);
					break;
				   }
			case 3:{
				   	Matrix *a = (Matrix *)malloc(sizeof(Matrix));
					Matrix *b = (Matrix *)malloc(sizeof(Matrix));
					Matrix *c = (Matrix *)malloc(sizeof(Matrix));
					scanf("%d %d",&m,&n);
					a->n_rows = m;
					a->row_lst = (LList **)malloc(sizeof(LList *)*m);
					b->n_rows = n;
					b->row_lst = (LList **)malloc(sizeof(LList *)*n);
					for(i = 0;i < m;i++)
					{
						(a->row_lst[i]) = llist_new();
						for(j = 0;j < n;j++)
						{
							scanf("%d",&inp);
							if(inp == 0)
								continue;
							llist_append((a->row_lst[i]),j,inp);
						}
					}
					for(i = 0;i < n;i++)
					{
						(b->row_lst[i]) = llist_new();
						for(j = 0;j < 1;j++)
						{
							scanf("%d",&inp);
							llist_append((b->row_lst[i]),j,inp);
						}
					}
					*c = matrix_vect_multiply(*a,*b);
					print_matrix(*c);
				free(a->row_lst);
				free(b->row_lst);
				free(c->row_lst);
				   }
		}
		scanf("%d",&choice);
	}
}
