#include "CList.h"
#include<stdlib.h>
#include<stdio.h>
#include<limits.h>

CNode* cnode_new( int data)
{
	CNode* a;
	a=(CNode*)malloc(sizeof(CNode));
	a->data=data;
	a->next=a;
	return a;
	
}

/////////////////////////////////////////////////////////////

CList* clist_new()
{
	CList* new;
	new=(CList*) malloc(sizeof(CList)); 		
	new->head=NULL;
	
	return new;
}
/////////////////////////////////////////////////////////////////
void clist_reverse(CList* lst)
{	CNode *temp;
	temp=(CNode*)malloc(sizeof(CNode));
	if(lst->head==NULL||lst->head->next==NULL)
	return ;
	
	int i,j,n;
	n=clist_size(lst);
	i=0;
	CNode *p;
	
	while(n-i>0)
	{
	p=lst->head;
	for(j=0;j<i;j++)
	{
		p=p->next;
	}
	temp->data=p->data;
	clist_remove( lst, i);
	clist_prepend( lst, temp->data );
	i++;
	}
}
/////////////////////////////////////////////////////////////////////////////////////
void clist_remove( CList* lst, int idx )
{		
		if(lst->head==NULL)
	{
		return;
	}
	if(idx==0)
	{
	clist_remove_first( lst )	;
	return ;
	}
	else if(idx==clist_size( lst ))
	{
	clist_remove_last( lst );
	return ;	
	}
	else if(idx>clist_size( lst ))
	{
		return ;
	}
	CNode *p;
	p=lst->head;
	CNode *q;
	q=lst->head;
	int i;
	for(i=0;i<idx;i++)
	{
		q=p;
		p=p->next;
	}
	q->next=p->next;
	
}


////////////////////////////////////////////////////////////////////////////////////////////////

void clist_remove_first( CList* lst )
{
	CNode* a;
	a=lst->head;
	
		if(lst->head!=NULL)
		return;
		else
		while(a->next !=lst->head)
			{
				a=a->next;
			}
		
		lst->head=lst->head->next;
		a->next=lst->head->next;	
		
	free(a);
}
			
//////////////////////////////////////////////////////////////////////////////////////////////////				
		
void clist_remove_last( CList* lst )
{
		CNode* a;
	CNode* temp;
		a=lst->head;
		
		
		while(lst->head !=NULL)
		{
			while(a->next->next !=lst->head)	
			{
				a=a->next;
			}
		temp=a->next;		
		a->next=lst->head;
	
		}
	free(temp);
}
////////////////////////////////////////////////////////////////////////////////////////////////
void clist_insert( CList* lst, int idx, int data )
{

	int i=0; 
	CNode* a=lst->head;
	CNode* newNode=node_new(data);
	 if(idx==0)
	cllist_prepend( lst,data );
if(lst->head == NULL)
	return ;
	else
	{
	while(lst->head->next!=lst->head)
	{
		if(i+1==idx)
		{
			newNode->next=lst->head->next;
			lst->head->next=newNode;
		}
	lst->head=lst->head->next;
	i++;
	}
	 lst->head=a;
	if(lst->head->next==NULL && i==idx)
	{
	
	cllist_append(lst,data);
	}
}

}
///////////////////////////////////////////////////////////////////////////////////////////////////

	int clist_size( CList* lst )
	{
		 int count=0;
	
    	CNode* a;
	a=lst->head; 
	if(lst->head == NULL)
	return 0;
   	 while(a->next!=lst->head) 
    {  
        count++;
        a=a->next;
    }
	
    	return count;
   
  
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
void clist_print( CList* lst )
{
		
 CNode* a;
    a=lst->head;

    while(lst->head!= NULL)
    {	while(a->next!=lst->head)
	{

        printf("%d ",lst->head->data);
        a=a->next;
   	 }
   }
   printf("\n");


}
///////////////////////////////////////////////////////////////////////////////////////////////

int clist_get( CList* lst, int idx )
{
	int i=0;
	CNode* a;
	a=lst->head;
	
//int j;
	if(lst->head==NULL)
	return INT_MIN;
	while(a->next!=lst->head)
	{
		if(i==idx)
		{
			return a->data;
		}
		else 
		{
			a=a->next;
			i++;
		}
	}
	if(a->next == lst->head)
	return INT_MIN;
}
////////////////////////////////////////////////////////////////////////////////////////////


void clist_append( CList* lst, int data )
{
	 CNode* a;

    a=lst->head;
	if(lst->head == NULL)
	cllist_prepend(lst,data);// Add the case when lst is empty
else
	{
	
    while(a->next!=lst->head) //correct all these references
    { 
       a=a->next;
       
    }
	CNode* newNode=node_new(data);
	a->next=newNode;
	newNode->next=lst->head;
	
	}
}
////////////////////////////////////////////////////////////////////////////////////////////

void clist_prepend( CList* lst, int data )
{
	CNode* a;CNode* temp;
	a=node_new(data);
	if(lst->head== NULL)
	a=cnode_new(data);
	else
	{
		temp=lst->head;
		a->data=data;
		while(temp->next!=lst->head)
		{
			temp=temp->next;
		}
		a->next=lst->head;
		temp->next=a;
		lst->head=a;
	}
	
}
////////////////////////////////////////////////////////////////////////////////////////
//void main()
//{Clist d;
//	d=clist_new();
//scanf("%d",&d->head);

