#include "DList.h"
#include<stdlib.h>
#include <stdio.h>
#include"limits.h"

/////////////////////////////////////////////////////////////
DDNode* dNode_new( int data)
{
	DNode* new;
		new=(DNode*)malloc(sizeof(DNode));		//creating a new node
		new->data=data;
		new->next=NULL;
		return new;

}
/////////////////////////////////////////////////////////////////
DList* dlist_new()
{

	  DList* a;						//creating a new list
    a=(DList*) malloc(sizeof(DList)); 
    a->head=NULL;
    
	return a;

}
////////////////////////////////////////////////////////////////
int dlist_size( DList* lst )
{

	 int count=0;
	
    	DNode* a;
	a=lst->head; 
	if(lst->head == NULL)
	return 0;
   	 while(a!=NULL) 
    {  
        count++;
        a=a->next;
    }
	
    	return count;
   
}
///////////////////////////////////////////////////////////////
void dlist_print( DList* lst )
{
	DNode* a;
    a=lst->head;

    while(lst->head!= NULL)
    {
        printf("%d ",lst->head->data);
        lst->head=lst->head->next;
    }
   printf("\n");
lst->head=a;
}  
//////////////////////////////////////////////////////////////

int dlist_get( DList* lst, int idx )
{	
	int i=0;

	DNode* a;
	a=lst->head;
	
    while(a != NULL)
    {
        if(i==idx)
	return a->data;
            a=a-> next;
	i++;
        
   
    }
    
    return INT_MIN;
}
//////////////////////////////////////////////////////////////////
void dlist_append( DList* lst, int data )
{
	DNode* a;
	DNode* new;
	new=(DNode*)malloc(sizeof(DNode));
    a=lst->head;
	if(lst->head == NULL)
	dlist_prepend(lst,data);// Add the case when lst is empty
else
	{
	
    while(a->next!=NULL) 
    { 
       a=a->next;
       
    }
	
	a->next=new;
	new->data=data;
	new->prev=a;	//check
	
	}
}
//////////////////////////////////////////////////////////////////
void dlist_prepend( DList* lst, int data )
{

	DNode* a;
	a=dNode_new(data);
      	if(lst->head==NULL)
	{
		lst->head=a;
		a->data=data;	
	}
	else
	{
	
	a->data=data;
	a->next=lst->head;
	lst->head->prev=a;
	lst->head=a;
	}
}
//////////////////////////////////////////////////////////////
void dlist_insert( DList* lst, int idx, int data )
{

	 int i=0; 
	DNode* a=lst->head;
	DNode* new=Node_new(data);
	//b=Node_new( int data);
 if(idx==0)
	dlist_prepend( lst,data );
else{
	while(lst->head!=NULL)
	{
		if(i+1==idx)
		{
			new->next=lst->head->next;
			lst->head->next=new;			
			new->next->prev=new;                   //insert an element
			new->prev=lst->head;
		}
	lst->head=lst->head->next;
	i++;
	}
	 lst->head=a;
	if(lst->head->next==NULL && i==idx)
	{
	
	dlist_append(lst,data);
	}
  }
		
   
}

/////////////////////////////////////////////////////////////
void dlist_remove_last( DList* lst )
{
	DNode* a;

   
	a=lst->head;
	if(lst->head!=NULL)
	{ 
	

	if(lst->head->next==NULL)
	dlist_remove_first(lst);
	else
		{
		while(a->next->next!=NULL)			//remove the last element
		    {
			a=a->next;
		        
		    }
		
		free(a->next);
		a->next=NULL;
	 
  
		}
	}
	else
	return ;
}
/////////////////////////////////////////////
void dlist_remove_first( DList* lst )
{

	 
	if(lst->head==NULL)
	{
		return;
	}
	if(lst->head->next==NULL)
	{
		lst->head=NULL;
		return;
	}
	else
	{
		DNode *a;		
		a=lst->head->next;
		lst->head=a;
		a->prev=NULL;
	}
	
}
///////////////////////////////////////////
void dlist_remove( DList* lst, int idx )
{
	
	
	if(idx==0)
	{	
		dlist_remove_first( lst );
		
		return ;
		
	}

	if(lst->head==NULL)
	{
		return ;
	}
	
	else if(idx>dlist_size( lst ))
	{
		return ;	
	}
	else if(idx==dlist_size( lst ))
	{
		dlist_remove_last( lst );
		return;
	}
	
	DNode *a;
	a=lst->head;
	int i;
	{
		for(i=0;i<idx;i++)
		{
			a=a->next;
		}
		a->prev->next=a->next;
		a->next->prev=a->prev;
	}
}




///////////////////////////////////////
void dlist_reverse(DList* lst)
{	
	DNode* q;
	q=lst->head;
	DNode* a;
	a = NULL;  
	  if(lst->head==NULL||lst->head->next==NULL)
	{
	return ;
	}
	

	while(q!=NULL)
	{
	a = q->prev;
       	q->prev = q->next;
       	q->next = a;              
       	q = q->prev;
	}
	if(a != NULL )
	q=a->prev;	

	lst->head=q;
	
}
///////////////////////////////////////

