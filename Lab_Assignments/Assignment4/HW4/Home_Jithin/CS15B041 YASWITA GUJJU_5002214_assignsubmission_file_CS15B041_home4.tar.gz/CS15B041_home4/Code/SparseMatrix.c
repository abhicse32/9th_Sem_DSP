#include "SparseMatrix.h"

#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

int llist_col( LList* lst, int col )
{
	Node *curr;
	curr=(Node *)malloc(sizeof(Node));		
	curr = lst->head;
	
	while(curr!=NULL)
	{
		if(curr->col_ind == col)
		{
			return curr->val;
		}
			
		curr = curr->next;
	}
	return INT_MIN;
}


Matrix add(Matrix m1, Matrix m2)
{
	Matrix m;
	m.n_rows = m1.n_rows;
	m.row_lst = malloc(m.n_rows * sizeof(LList *));

	Node *curr1;
	curr1=(Node *)malloc(sizeof(Node));		
	Node *curr2;
	curr2=(Node *)malloc(sizeof(Node));	

	int i,j, temp;
	for(i=0; i<m1.n_rows; i++)
	{
		m.row_lst[i] = llist_new();
		curr1 = m1.row_lst[i]->head;
		curr2 = m2.row_lst[i]->head;

		while(curr1!=NULL && curr2!=NULL)
		{
			if(curr1->col_ind == curr2->col_ind)
			{
				temp = (llist_col(m1.row_lst[i], curr1->col_ind)) + (llist_col(m2.row_lst[i], curr2->col_ind));
				llist_append(m.row_lst[i], j, temp);
				curr1 = curr1->next;
				curr2 = curr2->next;	

			}
			else if(curr1->col_ind < curr2->col_ind)
			{
				temp = (llist_col(m1.row_lst[i], curr1->col_ind));
				llist_append(m.row_lst[i], curr1->col_ind, temp);
				curr1 = curr1->next;
				
			}
			else if(curr1->col_ind > curr2->col_ind)
			{
				temp = (llist_col(m2.row_lst[i], curr2->col_ind));
				llist_append(m.row_lst[i], curr1->col_ind, temp);
				curr2 = curr2->next;	
			}		
			
		}

		while(curr1!=NULL)
		{
			temp = (llist_col(m1.row_lst[i], curr1->col_ind));
			llist_append(m.row_lst[i], curr1->col_ind, temp);
			curr1 = curr1->next;	
		}
		while(curr2!=NULL)
		{
			temp = (llist_col(m2.row_lst[i], curr2->col_ind));
			llist_append(m.row_lst[i], curr2->col_ind, temp);
			curr2 = curr2->next;	
		}
	}
	return m;
}


Matrix subtract(Matrix m1, Matrix m2)
{
	Matrix m;
	m.n_rows = m1.n_rows;
	m.row_lst = malloc(m.n_rows * sizeof(LList *));

	Node *curr1;
	curr1=(Node *)malloc(sizeof(Node));		
	Node *curr2;
	curr2=(Node *)malloc(sizeof(Node));		
	
	int i,j, temp;
	for(i=0; i<m1.n_rows; i++)
	{
		m.row_lst[i] = llist_new();
		curr1 = m1.row_lst[i]->head;
		curr2 = m2.row_lst[i]->head;

		while(curr1!=NULL && curr2!=NULL)
		{
			if(curr1->col_ind == curr2->col_ind)
			{
				temp = (llist_col(m1.row_lst[i], curr1->col_ind)) - (llist_col(m2.row_lst[i], curr2->col_ind));
				llist_append(m.row_lst[i], j, temp);
				curr1 = curr1->next;
				curr2 = curr2->next;	

			}
			else if(curr1->col_ind < curr2->col_ind)
			{
				temp = (llist_col(m1.row_lst[i], curr1->col_ind));
				llist_append(m.row_lst[i], curr1->col_ind, temp);
				curr1 = curr1->next;
				
			}
			else if(curr1->col_ind > curr2->col_ind)
			{
				temp = -(llist_col(m2.row_lst[i], curr2->col_ind));
				llist_append(m.row_lst[i], curr1->col_ind, temp);
				curr2 = curr2->next;	
			}		
			
		}

		while(curr1!=NULL)
		{
			temp = (llist_col(m1.row_lst[i], curr1->col_ind));
			llist_append(m.row_lst[i], curr1->col_ind, temp);
			curr1 = curr1->next;	
		}
		while(curr2!=NULL)
		{
			temp = -(llist_col(m2.row_lst[i], curr2->col_ind));
			llist_append(m.row_lst[i], curr2->col_ind, temp);
			curr2 = curr2->next;	
		}
	}
	return m;
}

Matrix matrix_vect_multiply(Matrix m1, Matrix v)
{
	Matrix m;
	m.n_rows = m1.n_rows;
	m.row_lst = malloc(m.n_rows * sizeof(LList *));

	Node *curr1;
	curr1=(Node *)malloc(sizeof(Node));		
	
	int i,j, temp, sum, vec;
	for(i=0; i<m1.n_rows; i++)
	{
		m.row_lst[i] = llist_new();
		
		sum=0;
		for(j=0; j<v.n_rows; j++)
		{
			temp = llist_col(m1.row_lst[i], j);
			if( temp!= INT_MIN)
			{
				vec = v.row_lst[j]->head->val;
				sum = sum + vec * temp;
			}
		}
		llist_append(m.row_lst[i], 0, sum);
	}
	return m;
}

void print_matrix(Matrix m)
{
	int i, j, temp;
	for(i=0; i<m.n_rows; i++)
	{
		for(j=0; j<llist_size(m.row_lst[i]); j++)
		{
			temp = (llist_get(m.row_lst[i], j))->val;
			printf("%d ", temp);			
		}
		printf("\n");
	}
}
