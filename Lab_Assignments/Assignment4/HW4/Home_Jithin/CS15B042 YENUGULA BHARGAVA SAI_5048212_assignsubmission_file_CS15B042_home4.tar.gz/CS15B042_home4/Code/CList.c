/*Implements all functions Listed in CList.h
Y BHARGAVA SAI CS15B042 2nd Sep 2016*/

#include "CList.h"
#include <stdio.h>
#include <limits.h>
#include <stdlib.h>

// CNode for the link list
CNode* cnode_new( int data){
	CNode * new = (CNode *)malloc(sizeof(CNode));
	new -> data = data;
	new -> next = NULL;
	return new;
}

// Create an empty list (head shall be NULL)
CList* clist_new(){
	CList* new = (CList*)malloc(sizeof(CList));
	new -> head = NULL;	
	return new;
}

// Traverse the linked list and return its size
int clist_size( CList* lst ){
	CNode *x = lst -> head;
	if(x == NULL) return 0;
	int count = 1;
	while(x->next != lst -> head){
		count++;
		x = x->next;
	}
	return count;
}

// Traverse the linked list and print each element
void clist_print( CList* lst ){
	CNode * x = lst -> head;
	if(x == NULL) return ;
	printf("%d ",x -> data);
	x = x -> next;
	while(x != lst -> head){
		printf("%d ",x -> data);
		x = x -> next;
	}
	printf("\n");
	fflush(stdout);
	return;
}

//get the element at position @idx
int clist_get( CList* lst, int idx ){
	CNode *x = lst -> head;
	if(x == NULL) return -1;
	int i;	
	for(i = 0;i < idx;i++){
		x = x -> next;
		if(x == lst -> head) return -1;
	}
	return x -> data;
}

// Add a new element at the end of the list
void clist_append( CList* lst, int data ){
	CNode* new = cnode_new(data);
	CNode *x = lst -> head;
	if(x == NULL) {
		lst -> head = new;
		new -> next = new;
		return;
	}	
	while(x -> next != lst -> head) x = x -> next;
	x -> next = new;
	new -> next = lst -> head;
	return;
}

// Add a new element at the beginning of the list
void clist_prepend( CList* lst, int data ){
	CNode* new  = cnode_new(data);
	CNode* x = lst -> head;
	if(x != NULL){
		while(x -> next != lst -> head){
			x = x -> next;
		}
		new -> next = lst -> head;
		lst -> head = new;
		x -> next = new;
		return;
	}	
	lst -> head = new;
	new -> next = new;
	return;
}

// Add a new element at the @idx index
void clist_insert( CList* lst, int idx, int data ){
	CNode *x = lst -> head;
	CNode* new = cnode_new(data);
	if(x == NULL){
		lst -> head = new;
		new -> next = new;
		return;
	}	
	if(idx == 0){
		clist_prepend(lst,data);
		return;
	}
	int i;
	for(i = 1;i < idx;i++){
		x = x -> next;
		if(x == lst -> head) return;
	}
	new -> next = x -> next;
	x -> next = new;
	return;
}

// Remove an element from the end of the list
void clist_remove_last( CList* lst ){
	CNode *x = lst -> head;
	if(x == NULL) return;
	if(x -> next == lst -> head){
		lst -> head = NULL;
		return;
	}	
	while(x -> next -> next != lst -> head){
		x = x -> next;
	}		
	x -> next = lst -> head;
	return;
}

// Remove an element from the beginning of the list
void clist_remove_first( CList* lst ){
	if(lst -> head == NULL) return;
	CNode* x = lst -> head;
	while(x -> next != lst -> head){
		x = x -> next;
	}
	lst -> head = lst -> head -> next;
	x -> next = lst -> head;
	return;
}

// Remove an element from an arbitrary @idx position in the list
void clist_remove( CList* lst, int idx ){
	if(lst -> head == NULL) return;
	if(idx == 0){
		clist_remove_first( lst );
		return;
	}
	CNode *x = lst -> head;
	int i;	
	for(i = 1;i < idx;i++){
		x = x -> next;
		if(x == lst -> head) return;
	}
	if(x -> next == lst -> head) return;
	x -> next = x -> next -> next;
	return;
}

//auxiliary func to reverse clist
void recrev(CNode* cur,CNode* head){
	if(head == NULL) return;
	if(cur -> next == head){
		cur -> next = cur;
		return;
	}
	CNode* temp;
	recrev(cur -> next,head);
	temp = cur -> next;
	cur -> next = cur -> next -> next;
	temp -> next = cur;
	return; 
}

// reverse the list
void clist_reverse(CList* lst){
	//calls auxiliary function to recursively reverse th list 
	recrev(lst -> head,lst -> head);
	if(lst -> head != NULL)	lst -> head = lst -> head -> next;
	return;	
}