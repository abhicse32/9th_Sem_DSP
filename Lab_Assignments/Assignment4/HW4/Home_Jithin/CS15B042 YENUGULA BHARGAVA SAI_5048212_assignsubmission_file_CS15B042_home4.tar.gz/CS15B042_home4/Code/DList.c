/*Implements all functions Listed in DList.h
Y BHARGAVA SAI CS15B042 2nd Sep 2016*/

#include "DList.h"
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

// Create a new node with next set to NULL
DNode* dnode_new( int data){
	DNode * new = (DNode *)malloc(sizeof(DNode));
	new -> data = data;
	new -> next = NULL;
	return new;
}

// Create an empty list (head shall be NULL)
DList* dlist_new(){
	DList* new = (DList*)malloc(sizeof(DList));
	new -> head = NULL;	
	return new;
}

// Traverse the linked list and return its size
int dlist_size( DList* lst ){
	DNode *x = lst -> head;
	if(x == NULL) return 0;
	int count = 1;
	while(x->next != NULL){
		count++;
		x = x->next;
	}
	return count;
}

// Traverse the linked list and print each element
void dlist_print( DList* lst ){
	DNode * x = lst -> head;
	if(x == NULL) return ;
	while(x != NULL){
		printf("%d ",x -> data);
		x = x -> next;
	}
	printf("\n");
	fflush(stdout);
	return;
}

//get the element at position @idx
int dlist_get( DList* lst, int idx ){
	DNode *x = lst -> head;
	if(x == NULL) return -1;
	int i;	
	for(i = 0;i < idx;i++){
		x = x -> next;
		if(x == NULL) return -1;
	}
	return x -> data;
}

// Add a new element at the end of the list
void dlist_append( DList* lst, int data ){
	DNode * new = dnode_new(data);
	DNode *x = lst -> head;
	if(lst -> head == NULL){
		new -> prev = NULL;
		lst -> head = new;
		return;
	}
	while(x -> next != NULL) x = x -> next;
	x -> next = new;
	new -> prev = x;
	return;
}

// Add a new element at the beginning of the list
void dlist_prepend( DList* lst, int data ){
	DNode* new = dnode_new(data);
	new -> next = lst -> head;
	lst -> head = new;
	new -> prev = NULL;
	if(new->next) new -> next -> prev = new;
	return;
}

// Add a new element at the @idx index
void dlist_insert( DList* lst, int idx, int data ){
	DNode *x = lst -> head;
	DNode* new = dnode_new(data);
	if(x == NULL && idx == 0){
		lst -> head = new;
		new -> prev = NULL;
		return;
	}	
	if(idx == 0){
		dlist_prepend(lst,data);
		return;
	}
	int i;
	for(i = 1;i < idx;i++){
		x = x -> next;
		if(x == NULL) return;
	}
	new -> next = x -> next;
	x -> next = new;
	if(new -> next != NULL){
		new -> next -> prev = new;
	}
	new -> prev = x;
	return;
}

// Remove an element from the end of the list
void dlist_remove_last( DList* lst ){
	DNode *x = lst -> head;
	if(x == NULL) return;
	if(x -> next == NULL) {
		lst -> head = NULL;
		return;
	}	
	while(x -> next -> next != NULL){
		x = x -> next;
	}
	x -> next -> prev = NULL;		
	x -> next = NULL;
	return;
}

// Remove an element from the beginning of the list
void dlist_remove_first( DList* lst ){
	if(lst -> head == NULL) return;
	lst -> head = lst -> head -> next;
	lst -> head -> prev = NULL;
	return;
}

// Remove an element from an arbitrary @idx position in the list
void dlist_remove( DList* lst, int idx ){
	if(lst -> head == NULL) return;
	if(idx == 0){
		dlist_remove_first( lst );
		return;
	}
	DNode *x = lst -> head;
	int i;	
	for(i = 1;i < idx;i++){
		x = x -> next;
		if(x == NULL) return;
	}
	if(x -> next == NULL) return;
	if(x -> next -> next != NULL) x -> next -> next -> prev  = x;
	x -> next = x -> next -> next;
	return;	
}

//Iteratively reverses the list
void dlist_reverse(DList* lst){
	if(lst -> head == NULL) return;
	DNode* x = lst -> head;
	DNode* temp;
	while(x -> next != NULL){
		temp = x -> prev;
		x -> prev = x -> next;
		x -> next = temp;
		x = x -> prev;
	}
	temp = x -> prev;
	x -> prev = x -> next;
	x -> next = temp;
	lst -> head = x;
	return;
}