/*Implements all functions Listed in List.h
Y BHARGAVA SAI CS15B042 2nd Sep 2016*/

#include "List.h"
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>

// Create a new node with next set to NULL
Node* node_new( int val1,int val2){
	Node * new = (Node *)malloc(sizeof(Node));
	new -> val = val1;
	new -> col_ind = val2;
	new -> next = NULL;
	return new;
}

// Create an empty list (head shall be NULL)
LList* llist_new(){
	LList* new = (LList*)malloc(sizeof(LList));
	new -> head = NULL;	
	return new;
}

// Traverse the linked list and return its size
int llist_size( LList* lst ){
	Node *x = lst -> head;
	if(x == NULL) return 0;
	int count = 1;
	while(x->next != NULL){
		count++;
		x = x->next;
	}
	return count;
}

// Traverse the linked list and print each element
void llist_print( LList* lst ){
	Node * x = lst -> head;
	if(x == NULL) return ;
	while(x != NULL){
		printf("%d ",x -> val);
		x = x -> next;
	}
	printf("\n");
	fflush(stdout);
	return;
}

//get the element at position @idx
Node* llist_get( LList* lst, int idx ){
	Node *x = lst -> head;
	if(x == NULL) return NULL;
	int i;	
	for(i = 0;i < idx;i++){
		x = x -> next;
		if(x == NULL) return NULL;
	}
	return x ;
}

// Add a new element at the end of the list
void llist_append( LList* lst, int val1,int val2){
	Node* new = node_new(val1,val2);
	Node *x = lst -> head;
	if(x == NULL) {
		lst -> head = new;
		return;
	}
	while(x -> next != NULL) x = x -> next;
	x -> next = new;
	return;
}

// Add a new element at the beginning of the list
void llist_prepend( LList* lst, int val1,int val2){
	Node* new = node_new(val1,val2);
	new -> next = lst -> head;
	lst -> head = new;
	return;
}

// Add a new element at the @idx index
void llist_insert( LList* lst, int idx, int val1, int val2){
	Node *x = lst -> head;
	Node* new = node_new(val1,val2);
	if(x == NULL && idx == 0){
		lst -> head = new;
		return;
	}	
	if(idx == 0){
		llist_prepend(lst,val1,val2);
		return;
	}
	int i;
	for(i = 1;i < idx;i++){
		x = x -> next;
		if(x == NULL) return;
	}
	new -> next = x -> next;
	x -> next = new;
	return;
}




















