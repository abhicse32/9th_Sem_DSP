/*Performs operations listed in SparseMatrix.h
Y BHARGAVA SAI CS15B042 3rd sep 2016*/

#include "SparseMatrix.h"
#include <stdlib.h>
#include <stdio.h>


/*Multiply an M x N matrix with N X 1 vector*/
Matrix matrix_vect_multiply(Matrix mat, Matrix vect){
	Matrix m;	
	Node* x;
	int i,sum;
	m . row_lst = (LList**)malloc(sizeof(LList*)*mat . n_rows);		//allocates memory for m linked list pointers
	m . n_rows = mat . n_rows;
	//result[i][0] is computed in every iteration
	for(i = 0;i < m . n_rows;i++){
		m . row_lst[i] = llist_new();	//initializes each of m linked lists where head points to NULL
		sum = 0;		
		x = mat . row_lst[i] -> head;
		while(x != NULL){			
			if(vect . row_lst[x -> col_ind] -> head){
				sum += (vect . row_lst[x -> col_ind] -> head -> val)*(x -> val);
			}
			x = x -> next;
		}
		llist_append(m . row_lst[i],sum,0);		//appends the sum calculated in the while loop
	}
	return m;
}

/*Add two matrices*/
Matrix add(Matrix m1, Matrix m2){
	int i;
	Matrix result;
	result . row_lst = (LList**)malloc(sizeof(LList*)*m1 . n_rows);	//allocates memory for m linked list pointers
	result . n_rows = m1 . n_rows;
	for(i = 0;i < m1 . n_rows;i++){
		Node* a = m1 . row_lst[i] -> head;
		Node* b = m2 . row_lst[i] -> head;
		result . row_lst[i] = llist_new();	//initializes each of m linked lists where head points to NULL
		
		//This loop adds the elements of m1 and m2 then appends the value into the list 
		while(a != NULL && b != NULL){
			if(a -> col_ind == b -> col_ind){
				llist_append(result . row_lst[i],a -> val + b -> val,a -> col_ind);
				a = a -> next;
				b = b -> next;
			}
			else if(a -> col_ind > b -> col_ind){
				llist_append(result . row_lst[i],b -> val,b -> col_ind);
				b = b -> next;
			}
			else{
				llist_append(result . row_lst[i],a -> val,a -> col_ind);
				a = a -> next;
			}
		}
		if(a != NULL){
			while(a != NULL){
				llist_append(result . row_lst[i],a -> val,a -> col_ind);
				a = a -> next;
			}	
		}
		else if(b){
			while(b != NULL){
				llist_append(result . row_lst[i],b -> val,b -> col_ind);
				b = b -> next;
			}
		}
	}
	return result;
}

/*Subtract Matrix m2 from m1*/
Matrix subtract(Matrix m1, Matrix m2){
	int i;
	Matrix result;
	result . row_lst = (LList**)malloc(sizeof(LList*)*(m1 . n_rows));	//allocates memory for m linked list pointers
	result . n_rows = m1 . n_rows;
	for(i = 0;i < m1 . n_rows;i++){
		Node* a = m1 . row_lst[i] -> head;
		Node* b = m2 . row_lst[i] -> head;	
		result . row_lst[i] = llist_new();		//initializes each of m linked lists where head points to NULL
		
		//This loop subtracts the elements of m1 and m2 then appends the value into the list 
		while(a != NULL && b != NULL){
			if(a -> col_ind == b -> col_ind){
				llist_append(result . row_lst[i],a -> val - b -> val,a -> col_ind);
				a = a -> next;
				b = b -> next;
			}
			else if(a -> col_ind > b -> col_ind){
				llist_append(result . row_lst[i],-1*(b -> val),b -> col_ind);
				b = b -> next;
			}
			else{
				llist_append(result . row_lst[i],a -> val,a -> col_ind);
				a = a -> next;
			}
		}
		if(a){
			while(a != NULL){
				llist_append(result . row_lst[i],a -> val,a -> col_ind);
				a = a -> next;
			}
		}
		else if(b){
			while(b != NULL){
				llist_append(result . row_lst[i],-1*(b -> val),b -> col_ind);
				b = b -> next;
			}
		}
	}
	return result;
}	
 