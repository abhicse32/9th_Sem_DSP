/*Driver program to check functions listed in SparseMatrix.h
Y BHARGAVA SAI CS15B042 3rd sep 2016*/

#include "SparseMatrix.h"
#include <stdio.h>
#include <stdlib.h>

//Prints the matrix m using llist_print function
void print_matrix(Matrix m){
	int i;
	for(i = 0;i < m . n_rows;i++){
		llist_print(m . row_lst[i]);
	}
	return;	
}

int main(){
	int v,m,n,temp,i,j;
	scanf("%d",&v);
	while(v != -1){
		if(v == 1){
			//scanning for add
			scanf("%d%d",&m,&n);
			Matrix m1,m2;
			m1 . row_lst = (LList**)malloc(sizeof(LList*)*m);	//allocates memory for m linked list pointers
			m1 . n_rows = m;
			for(i = 0;i < m;i++){
				m1 . row_lst[i] = llist_new();		//initializes each of m linked lists where head points to NULL
				for(j = 0;j < n;j++){
					scanf("%d",&temp);
					if(temp != 0){
						llist_append(m1 . row_lst[i],temp,j);	//appends elements of ith row 
					}
				}
			}
			m2 . row_lst = (LList**)malloc(sizeof(LList*)*m);	//allocates memory for m linked list pointers
			m2 . n_rows = m;
			for(i = 0;i < m;i++){
				m2 . row_lst[i] = llist_new();		//initializes each of m linked lists where head points to NULL
				for(j = 0;j < n;j++){
					scanf("%d",&temp);
					if(temp != 0){
						llist_append(m2 . row_lst[i],temp,j);	//appends elements of ith row
					}
				}
			}
			Matrix result = add(m1,m2);
			print_matrix(result);
		}
		else if(v == 2){
			//scanning for subtract
			scanf("%d%d",&m,&n);
			Matrix m1,m2;
			m1 . row_lst = (LList**)malloc(sizeof(LList*)*m);	//allocates memory for m linked list pointers
			m1 . n_rows = m;
			for(i = 0;i < m;i++){
				m1 . row_lst[i] = llist_new();		//initializes each of m linked lists where head points to NULL
				for(j = 0;j < n;j++){
					scanf("%d",&temp);
					if(temp != 0){
						llist_append(m1 . row_lst[i],temp,j);	//appends elements of ith row
					}
				}
			}
			m2 . row_lst = (LList**)malloc(sizeof(LList*)*m);	//allocates memory for m linked list pointers
			m2 . n_rows = m;
			for(i = 0;i < m;i++){
				m2 . row_lst[i] = llist_new();		//initializes each of m linked lists where head points to NULL
				for(j = 0;j < n;j++){
					scanf("%d",&temp);
					if(temp != 0){
						llist_append(m2 . row_lst[i],temp,j);	//appends elements of ith row
					}
				}
			}
			Matrix result = subtract(m1,m2);
			print_matrix(result);
		}
		else if(v == 3){
			//scanning for mult
			scanf("%d%d",&m,&n);
			Matrix m1,m2;
			m1 . row_lst = (LList**)malloc(sizeof(LList*)*m);	//allocates memory for m linked list pointers
			m1 . n_rows = m;
			for(i = 0;i < m;i++){
				m1 . row_lst[i] = llist_new();		//initializes each of m linked lists where head points to NULL
				for(j = 0;j < n;j++){
					scanf("%d",&temp);
					if(temp != 0){
						llist_append(m1 . row_lst[i],temp,j);	//appends elements of ith row
					}
				}
			}
			m2 . row_lst = (LList**)malloc(sizeof(LList*)*n);	//allocates memory for n linked list pointers
			for(i = 0;i < n;i++){
				m2 . row_lst[i] = llist_new();		//initializes each of m linked lists where head points to NULL
				scanf("%d",&temp);
				if(temp){
					llist_append(m2 . row_lst[i],temp,0);	//appends elements of ith row
				}
			}
			Matrix result = matrix_vect_multiply(m1,m2);
			print_matrix(result);
		}
		scanf("%d",&v);
	}
	return 0;
}