
 #include "CList.h"
 #include<stdio.h>
 #include<stdlib.h>
 #include<limits.h>
 
 typedef CNode* PtrToNode;
 typedef CList* List;
 
 // Create a new node with next set to NULL

 CNode* cnode_new( int data )
{
  PtrToNode NewNode = ( CNode* )malloc( sizeof( CNode ) );
  NewNode->data = data;
  NewNode->next = NULL;
  
  return NewNode;
}

 // Create an empty list (head shall be NULL)
 
 CList* clist_new()
{
  List NewList = ( CList* )malloc( sizeof( CList ) );
  NewList->head = NULL;
  
  return NewList;
} 

 // Traverse the linked list and return its size
 
 int clist_size( CList *lst )
{
  PtrToNode Temp1 = lst->head ,  Temp2;
  int size = 1;
  
     if( !Temp1 )
      return 0;
      
  Temp2 = Temp1->next;    
  
     while( Temp2 != Temp1 )
    {
      size++;
      Temp2 = Temp2->next;
    }
    
  return size;   
} 

 // Traverse the linked list and print each element
 
 void clist_print( CList* lst )
{
  PtrToNode Temp1 = lst->head , Temp2;
    
     if( !Temp1 )
    {
      puts( "" );
      return;
    }  
  
  printf( "%d " , Temp1->data );  
  Temp2 = Temp1->next;
     
     while( Temp2 != Temp1 )
    {
      printf( "%d " , Temp2->data );
      Temp2 = Temp2->next;
    } 
    
  puts( "" );  
} 

 //get the element at position @idx
 
 int clist_get( CList* lst , int idx )
{ 
  PtrToNode Temp1 = lst->head , Temp2;
  int index = 0;
  
     if( !Temp1 )
      return INT_MIN;
      
  Temp2 = Temp1->next;
  
     if( !idx )
      return Temp1->data;
  
     while( Temp2 != Temp1 )
    {
      index++;
      
         if( index == idx )
          return Temp2->data;
          
      Temp2 = Temp2->next;    
    }      
    
  return -1;  
} 

 // Add a new element at the end of the list
 
 void clist_append( CList* lst , int data )
{
  PtrToNode Temp1 = lst->head , Temp2 = lst->head , NewNode;
  NewNode = cnode_new( data );
  
     if( !Temp1 )
    {
      lst->head = NewNode;
      NewNode->next = NewNode;
      return;
    }  
       
     while( Temp2->next != Temp1 )
      Temp2 = Temp2->next;
            
  NewNode->next = Temp1;
  Temp2->next = NewNode;        
} 

 // Add a new element at the beginning of the list
 
 void clist_prepend( CList* lst , int data )
{
  PtrToNode NewNode = cnode_new( data ) , Temp1 = lst->head;
  
     if( !lst->head )
    {
      lst->head = NewNode;
      NewNode->next = NewNode;
      return;
    }   
      
     while( Temp1->next != lst->head )
      Temp1 = Temp1->next;
       
  NewNode->next = lst->head;
  lst->head = NewNode;
  Temp1->next = NewNode;
}
 
 // Add a new element at the @idx index
 
 void clist_insert( CList* lst , int idx , int data )
{
  PtrToNode Temp1 = lst->head , Temp2 , Temp3 , NewNode;
  int index = 0;
  NewNode = cnode_new( data );
  
     if( !Temp1 )
    {
         if( !idx )
          clist_prepend( lst , data );
        
      return;  
    } 
      
  Temp2 = Temp1->next;
  
     if( !idx )
    {
      clist_prepend( lst , data );
      return; 
    }   
    
  Temp3 = Temp1;  
    
     while( Temp1 != Temp2 )
    {
      index++;
      
         if( index == idx )
        {
          NewNode->next = Temp2;
          Temp3->next = NewNode;
          return;
        }     
        
      Temp3 = Temp2;
      Temp2 = Temp2->next;  
    }  
    
     if( idx == index + 1 )
    {
      NewNode->next = Temp3->next;
      Temp3->next = NewNode;
      return;
    } 
    
  free( NewNode );  
} 

 // Remove an element from the end of the list
 
 void clist_remove_last( CList *lst )
{
  PtrToNode Temp1 = lst->head , Temp2 , Temp3;
  
     if( !Temp1 )
      return;
    
  Temp2 = Temp1->next;
 
     if( Temp1 == Temp2 )
    {
      free( Temp1 );
      lst->head = NULL;
      return;
    }  
     
  Temp3 = Temp1;            
     
     while( Temp2->next != Temp1 )
    {
      Temp3 = Temp2;
      Temp2 = Temp2->next;
    }       
    
  free( Temp2 );
  Temp3->next = lst->head;  
} 

 // Remove an element from the beginning of the list
 
 void clist_remove_first( CList *lst )
{
  PtrToNode Temp1 = lst->head , Temp2;
  
     if( !lst->head )
      return;
      
  Temp2 = Temp1->next;
  
     if( Temp2 == Temp1 )
    {
      free( Temp1 );
      lst->head = NULL;
      return;
    }        
 
     while( Temp2->next != Temp1 )
      Temp2 = Temp2->next;
      
  lst->head = Temp1->next;    
  free( Temp1 );
  Temp2->next = lst->head;     
} 

 // Remove an element from an arbitrary @idx position in the list
 
 void clist_remove( CList* lst, int idx )
{
     if( !idx )
    { 
      clist_remove_first( lst );
      return;
    } 
 
     if( !lst->head )
      return;
      
  PtrToNode Temp1 = lst->head , Temp2 , Temp3;
  int index = 0;
  Temp2 = Temp1->next;
  
     if( Temp2 == Temp1 )
      return;
      
  Temp3 = Temp1;
      
     while( Temp2 != Temp1 )
    {
      index++;
      
         if( index == idx )
        {
          Temp3->next = Temp2->next;
          free( Temp2 );
          return;
        } 
        
      Temp3 = Temp2;
      Temp2 = Temp2->next;  
    }                
} 

 // reverse the list
 
 void clist_reverse( CList *lst )
{
  PtrToNode Temp1 = lst->head , Temp2 = NULL , Temp3;
  int index = 0 , size = clist_size( lst );
  
     if( !lst->head )
      return;
      
     if( lst->head->next == lst->head )
      return; 
  
     while( index != size )
    {
      Temp3 = Temp2;
      Temp2 = Temp1;
      Temp1 = Temp1->next;
      Temp2->next = Temp3;
      index++;
    }      
    
  lst->head->next = Temp2;
  lst->head = Temp2;  
} 

 

 


 


















