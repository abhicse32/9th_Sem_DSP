
 #include "DList.h" 
 #include<stdio.h>
 #include<stdlib.h>
 #include<limits.h>
 
 typedef DNode *PtrToNode;
 typedef DList *List;
 
 // Create a new node with next set to NULL
 
 DNode* dnode_new( int data )
{ 
  PtrToNode NewNode = ( DNode* )malloc( sizeof( DNode ) );
  NewNode->data = data;
  NewNode->next = NULL;
  NewNode->prev = NULL;
  
  return NewNode;
}

 // Create an empty list (head shall be NULL)
 
 DList* dlist_new()
{
  List NewList = ( DList* )malloc( sizeof( DList ) );
  NewList->head = NULL;
  
  return NewList;
}
 
 // Traverse the linked list and return its size
 
 int dlist_size( DList *lst )
{
  PtrToNode Temp = lst->head;
  int size = 0;
  
     while( Temp )
    {
      size++;
      Temp = Temp->next;
    }
    
  return size;    
} 

 // Traverse the linked list and print each element
 
 void dlist_print( DList *lst )
{
  PtrToNode Temp = lst->head;
  
     while( Temp )
    {
      printf( "%d " , Temp->data );
      Temp = Temp->next;
    } 
    
  puts( "" );  
} 

 //get the element at position @idx

 int dlist_get( DList *lst , int idx )
{
  PtrToNode Temp = lst->head;
  int index = 0;
  
     while( Temp )
    {
         if( index == idx )
          return Temp->data;
          
      index++;
      Temp = Temp->next;    
    } 
    
  return -1;  
} 

 // Add a new element at the end of the list
 
 void dlist_append( DList* lst, int data )
{
  PtrToNode Temp = lst->head;
   
  if( !Temp )
 {
   lst->head = dnode_new( data );
   return;
 }
    
     while( Temp->next )
      Temp = Temp->next;
      
  Temp->next = dnode_new( data );
  Temp->next->prev = Temp;     
} 

 // Add a new element at the beginning of the list
 
 void dlist_prepend( DList *lst , int data )
{
  PtrToNode NewNode = dnode_new( data );
  
     if( !lst->head )
    {
      lst->head = NewNode;
      return;  
    }
       
  NewNode->next = lst->head;
  lst->head->prev = NewNode;
  lst->head = NewNode;
} 

 // Add a new element at the @idx index
 
 void dlist_insert( DList *lst , int idx , int data )
{
  PtrToNode Temp = lst->head , NewNode;
  int index = 0;
  
     if( !idx )
    {
      dlist_prepend( lst , data );
      return;
    } 
    
     while( Temp )
    {
         if( index == idx )
        {
          NewNode = dnode_new( data );
          NewNode->next = Temp;
          NewNode->prev = Temp->prev;
          Temp->prev->next = NewNode;
          Temp->prev = NewNode;
          return;
        } 
        
      index++;
      Temp =  Temp->next; 
    } 
    
     if( index == idx )
      dlist_append( lst , data );
} 

 // Remove an element from the end of the list
 
 void dlist_remove_last( DList *lst )
{
  PtrToNode Temp = lst->head;
  
     if( !Temp )
      return;
      
     while( Temp->next )
      Temp = Temp->next;
       
     if( !lst->head->next )  
    {
      lst->head = NULL;
      free( Temp );
      return;
    }
       
  Temp->prev->next = NULL;
  free( Temp );     
} 

 // Remove an element from the beginning of the list
 
 void dlist_remove_first( DList *lst ) 
{
  PtrToNode Temp = lst->head;
  
     if( !Temp )
      return;
      
     if( !lst->head->next )
    {
      lst->head = NULL;
      free( Temp );
      return;
    } 
    
  lst->head = Temp->next;
  Temp->next->prev = NULL;
  free( Temp );
} 

 // Remove an element from an arbitrary @idx position in the list
 
 void dlist_remove( DList *lst , int idx )
{
  PtrToNode Temp = lst->head;
  int index = 0;
  
     if( !idx )
    {
      dlist_remove_first( lst );
      return;
    }
    
     while( Temp )
    {
         if( index == idx )
        {
          Temp->prev->next = Temp->next;
          Temp->next->prev = Temp->prev;
          free( Temp );
          return;
        }        
        
      index++;
      Temp = Temp->next;   
    }        
} 

 // Reverse the Double Linked List
 
 void dlist_reverse( DList *lst )
{
  PtrToNode Temp1 = lst->head , Temp2 = NULL , Temp3;
  
     if( !Temp1 )
      return;
      
     if( !lst->head->next )
      return;
      
     while( Temp1 )
    {
      Temp3 = Temp2;
      Temp2 = Temp1;
      Temp1 = Temp1->next;
      Temp2->next = Temp3;
      
         if( Temp3 )
          Temp3->prev = Temp2;
    }   
    
  Temp2->prev = NULL;
  lst->head = Temp2;  
} 








 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
