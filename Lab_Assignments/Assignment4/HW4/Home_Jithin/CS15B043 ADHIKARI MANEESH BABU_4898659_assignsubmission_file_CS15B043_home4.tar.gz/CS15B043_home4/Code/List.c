
 #include "List.h"
 #include<stdio.h>
 #include<stdlib.h>

 typedef Node *PtrToNode;
 typedef LList *List;

 // Create a new node with next set to NULL
 
 Node* node_new( int col , int data )
{
  PtrToNode NewNode = ( Node* )malloc( sizeof( Node ) );
  NewNode->col_ind = col;
  NewNode->val = data;
  NewNode->next = NULL;
  
  return NewNode;
} 

 // Create an empty list (head shall be NULL)
 
 LList* llist_new()
{
  List NewList = ( LList* )malloc( sizeof( LList ) );
  NewList->head = NULL;
  
  return NewList; 
} 

 // Traverse the linked list and return its size
 
 int llist_size( LList* lst )
{
  PtrToNode Temp = lst->head;
  int size = 0;
  
     while( Temp )
    {
      size++;
      Temp = Temp->next;
    }
    
  return size;   
} 

 // Traverse the linked list and print each element
 
 void llist_print( LList* lst )
{
  PtrToNode Temp = lst->head;
  
     while( Temp )
    {
      printf( "%d " , Temp->val );
      Temp = Temp->next;
    }   
    
  puts( "" );  
} 

 //get the element at position @idx 
 
 Node* llist_get( LList* lst , int idx )
{
  PtrToNode Temp = lst->head;
  int index = -1;
  
     while( Temp )
    {
      index++;
       
         if( index == idx ) 
          return Temp;
          
      Temp = Temp->next;    
    } 
    
  return NULL;  
} 

 // Add a new element at the end of the list
 
 void llist_append( LList* lst , int col , int data )
{
  PtrToNode Temp = lst->head;
  
     if( !Temp )
    {
      lst->head = node_new( col , data );
      return; 
    }      
    
     while( Temp->next )
      Temp = Temp->next;
      
   Temp->next = node_new( col , data );       
} 

 // Add a new element at the beginning of the list
 
 void llist_prepend( LList* lst , int col , int data )
{
  PtrToNode NewNode;
  
  NewNode = node_new( col , data );
  NewNode->next = lst->head;
  lst->head = NewNode;    
} 

 // Add a new element at the @idx index
 
 void llist_insert( LList* lst , int idx , int col , int data )
{
  PtrToNode NewNode , Temp1;
  int index = 0;
  
     if( !idx )
    { 
      llist_prepend( lst , col , data );
      return;
    }  
    
  Temp1 = lst->head;
     
     while( Temp1->next )
    {
      index++;
      
         if( index == idx )
        {
          NewNode = node_new( col , data );
          NewNode->next = Temp1->next;
          Temp1->next = NewNode;
          return; 
        } 
        
      Temp1 = Temp1->next;  
    } 
    
     if( index + 1 == idx )
      Temp1->next = node_new( col , data );
} 





















