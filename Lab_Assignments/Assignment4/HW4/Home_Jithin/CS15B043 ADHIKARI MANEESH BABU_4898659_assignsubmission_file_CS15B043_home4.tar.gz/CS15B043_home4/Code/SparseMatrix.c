
 #include "SparseMatrix.h"
 #include "List.h"
 #include<stdio.h>
 #include<stdlib.h>
 
 typedef Matrix* Matrix_Ptr;
 typedef Node *PtrToNode;
 typedef LList *List;
 
 /* Function to take the input of a matrix */
 
 void Input_Sparse( Matrix *M , int rows , int columns )
{ 
  int temp , i , j;
  Initialize_Sparse( M , rows );
  
     for( i = 0 ; i < rows ; i++ )
    {
         for( j = 0 ; j < columns ; j++ )
        {
          scanf( "%d" , &temp );
           
             if( temp )
              llist_append( *( M->row_lst + i ) , j , temp );
        } 
    } 
} 

 /* Function to initailize Matrix Structures */

 void Initialize_Sparse( Matrix *M , int rows )
{
  M->row_lst = ( LList ** )malloc( rows * sizeof( LList* ) );
  int i;
  
     for( i = 0 ; i < rows ; i++ )
    {
      *( M->row_lst + i ) = ( List )malloc( sizeof( LList ) );
      ( *( M->row_lst + i ) )->head = NULL; 
    } 
    
  M->n_rows = rows;  
} 

 /*Add two matrices*/
 
 Matrix add( Matrix M1 , Matrix M2 )
{
  int i , index;
  List L1 , L2;
  PtrToNode P1 , P2;
  
     for( i = 0 ; i < M1.n_rows ; i++ )
    {
      index = 0;
      L1 = *( M1.row_lst + i );
      L2 = *( M2.row_lst + i );
      P1 = L1->head;
      P2 = L2->head;
      
         while( P1 && P2 )
        {
             if( P1->col_ind == P2->col_ind )
            {
              P1->val += P2->val;
              P1 = P1->next;
              P2 = P2->next;
            }  
             else
            {
                 if( P1->col_ind < P2->col_ind ) 
                  P1 = P1->next;
                 else
                { 
                  llist_insert( L1 , index , P2->col_ind , P2->val );
                  P2 = P2->next;
                }    
            }      
            
          index++;  
        } 
        
         if( !P1 )
        { 
             while( P2 )
            { 
              llist_append( L1 , P2->col_ind , P2->val );
              P2 = P2->next;
            }  
        } 
    } 
    
  return M1;  
} 

 // Function to print a Sparse Matrix for Multiplication
  
 void Print_Sparse_M( Matrix *M , int columns )
{
  List L;
  PtrToNode Temp;
  int i , flag;

     for( i = 0 ; i < M->n_rows ; i++ )
    {
      flag = 0;
      L = *( M->row_lst + i );
      Temp = L->head;
      
         while( Temp )
        { 
          flag = 1;
          printf( "%d " , Temp->val );
          Temp = Temp->next;
        }      
       
         if( !flag )
          printf( "%d " , 0 );
           
      puts( "" );  
    } 
} 

 // Function to print a Sparse Matrix for Addition and Subtraction
 
 void Print_Sparse_AS( Matrix *M , int columns )
{
  List L;
  PtrToNode Temp;
  int i , flag , result = 0;

     for( i = 0 ; i < M->n_rows ; i++ )
    {
      flag = 0;
      L = *( M->row_lst + i );
      Temp = L->head;
      
         while( Temp )
        { 
          result = 1;
          flag = 1;
          printf( "%d " , Temp->val );
          Temp = Temp->next;
        }      
         
         if( flag )
          puts( "" );
    } 
    
     if( !result )
      printf( "%d\n" , 0 );
} 

 /* Subtract Matrix M2 from M1 => M1 - M2 */
 
 Matrix subtract( Matrix M1 , Matrix M2 )
{
  PtrToNode P2;
  int i;
  
     for( i = 0 ; i < M1.n_rows ; i++ )
    {
      P2 = ( *( M2.row_lst + i ) )->head; 
     
         while( P2 )
        {
          P2->val *= -1;
          P2 = P2->next;
        }
    }      
    
  return add( M1 , M2 );  
} 

 /* Multiply an M x N matrix with N X 1 vector */
 
 Matrix matrix_vect_multiply( Matrix M , Matrix V )
{
  Matrix V1;
  List LM;
  PtrToNode PM , PV;
  int i , Sum , col;
  
  Initialize_Sparse( &V1 , M.n_rows );
  
     for( i = 0 ; i < M.n_rows ; i++ )
    {
      Sum = 0;
      LM = *( M.row_lst + i );
      PM = LM->head;
      
         while( PM )
        {
          col = PM->col_ind;
          PV = ( *( V.row_lst + col ) )->head;
          
             if( PV )
              Sum += PM->val * PV->val;
              
          PM = PM->next;    
        }     
        
         if( Sum )
          llist_prepend( *( V1.row_lst + i ) , 0 , Sum );          
    } 
    
  return V1;  
} 

 /* Function to free the memory allocated by Sparse Matrices */

 void Free_Sparse( Matrix M )
{
  PtrToNode P , Temp;
  int i;
  
     for( i = 0 ; i < M.n_rows ; i++ )
    {
      P = ( *( M.row_lst + i ) )->head;
      
         while( P )
        {
          Temp = P->next;
          free( P );
          P = Temp;
        } 
    }    
    
  free( M.row_lst );
} 
 

















