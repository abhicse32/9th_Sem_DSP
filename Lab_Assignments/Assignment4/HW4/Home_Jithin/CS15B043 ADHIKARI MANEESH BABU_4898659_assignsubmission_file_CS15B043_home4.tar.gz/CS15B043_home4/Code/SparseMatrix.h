#ifndef SPARCE_H
#define SPARCE_H
#include "List.h"

typedef struct Matrix{
	LList** row_lst;
	int n_rows;
}Matrix;

/*Multiply an M x N matrix with N X 1 vector*/
Matrix matrix_vect_multiply(Matrix mat, Matrix vect);

/*Add two matrices*/
Matrix add(Matrix, Matrix);

/*Subtract Matrix b from a*/
Matrix subtract(Matrix a, Matrix b);

/* Function to take the input of a matrix */
void Input_Sparse( Matrix* M , int rows , int columns );

/* Function to initailize Matrix Structures */
void Initialize_Sparse( Matrix *M , int rows );

// Function to print a Sparse Matrix for Multiplication
void Print_Sparse_M( Matrix *M , int columns );

// Function to print a Sparse Matrix for Addition and Subtraction
void Print_Sparse_AS( Matrix *M , int columns );

/* Function to free the memory allocated by Sparse Matrices */
void Free_Sparse( Matrix M );

#endif
