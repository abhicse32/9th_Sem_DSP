
 #include<stdio.h>
 #include<stdlib.h>
 #include "SparseMatrix.h"
 #include "List.h"
 
 int main( void )
{
  int option , rows , columns , m = 1;
  scanf( "%d" , &option );
  Matrix M1 , M2;
  
     while( m )
    {
         switch( option )
        {
          case 1:
           scanf( "%d%d" , &rows , &columns );
           Input_Sparse( &M1 , rows , columns );
           Input_Sparse( &M2 , rows , columns );
           M1 = add( M1 , M2 );
           Print_Sparse_AS( &M1 , columns );
           Free_Sparse( M1 );
           Free_Sparse( M2 );
           break;
           
          case 2:  
           scanf( "%d%d" , &rows , &columns );
           Input_Sparse( &M1 , rows , columns );
           Input_Sparse( &M2 , rows , columns );
           M1 = subtract( M1 , M2 );
           Print_Sparse_AS( &M1 , columns );
           Free_Sparse( M1 );
           Free_Sparse( M2 );
           break;
           
          case 3:
           scanf( "%d%d" , &rows , &columns );
           Input_Sparse( &M1 , rows , columns );
           Input_Sparse( &M2 , columns , 1 );
           M1 = matrix_vect_multiply( M1 , M2 );
           Print_Sparse_M( &M1 , 1 );
           Free_Sparse( M1 );
           Free_Sparse( M2 );
           break;   
        } 
        
      scanf( "%d" , &option );
      
         if( option == -1 )
          m = 0;  
    } 
  
  return 0;
} 
