/* To implement various insertion,deletion and creation operations on circular linked list
  Author:Jahnvi Patel CS15B046
  September 3, 2016
*/
#include "CList.h"
#include <limits.h>
#include <stdlib.h>
#include <stdio.h>

// Create a new CNode with next set to node itself
CNode* cnode_new( int data)
{
	CNode* newCNode;
	newCNode=(CNode*) malloc(sizeof(CNode));
		if(newCNode!=NULL)
		{
			newCNode->data=data;
			newCNode->next=newCNode;
		}
	return newCNode;

}

// Create an empty list (head shall be NULL)
CList* clist_new()
{
	CList* newList;
	newList=(CList*) malloc(sizeof(CList));
	if(newList!=NULL)
	newList->head=NULL;
	return newList;
	
}

// Traverse the linked list and return its size
int clist_size( CList* lst )
{
	CNode* initHead;
	initHead=lst->head;
	int size=0;
	int flag=0;
if(lst->head!=NULL)
{
	while(lst->head!=initHead || flag==0)
	{   size++;
		lst->head=lst->head->next;
		flag=1;

	}
	lst->head=initHead;
	return size;
}	
}

// Traverse the linked list and print each element
void clist_print( CList* lst )
{
	CNode* initHead;
	initHead=lst->head;
	int flag=0;
if(lst->head!=NULL)
	{
		while(lst->head!=initHead || flag==0)
		{
			printf("%d ",lst->head->data);
			lst->head=lst->head->next;
			flag=1;
		}
		printf("\n");
		lst->head=initHead;
	}
}

//get the element at position @idx
int clist_get( CList* lst, int idx )
{
	CNode* initHead;
	initHead=lst->head;
	int pos=-1;
if(lst->head!=NULL)
{
	pos=0;
	do
	{  
		if(pos==idx)
			{  	int num=lst->head->data;
				lst->head=initHead;
				return num;
			}
		lst->head=lst->head->next;
		pos++;

	}while(lst->head!=initHead);
}
	if(pos<idx)
		{   lst->head=initHead;
			return -1;
        }
}

// Add a new element at the end of the list
void clist_append( CList* lst, int data )
{
	CNode* newCNode;
	newCNode=cnode_new(data);
	CNode* initHead;
	int flag=0;
	initHead=lst->head;
	if(newCNode!=NULL)
	{
		if(lst->head==NULL)
		{
			lst->head=newCNode;
		 	flag=1;
		}
		else{
			while(lst->head->next!=initHead)
		{
			lst->head=lst->head->next;
		}
		/*LOOP BACK*/
		newCNode->next=initHead;
		lst->head->next=newCNode;
			}
	}
		if(flag==0)
			lst->head=initHead;
		
}

// Add a new element at the beginning of the list

void clist_prepend( CList* lst, int data )
{
	CNode* newCNode;
	newCNode=cnode_new(data);
	CNode* initHead;
	initHead=lst->head;
	if(newCNode!=NULL)
	{	
		if(lst->head==NULL)
			clist_append(lst,data);
		else
		{
			while(lst->head->next!=initHead)
				lst->head=lst->head->next;
		/*LOOP BACK*/
		newCNode->next=initHead;
		lst->head->next=newCNode;
	    lst->head=newCNode;
		}

	}
	
}

// Add a new element at the @idx index

void clist_insert( CList* lst, int idx, int data )
{
	CNode* newCNode;
	newCNode=cnode_new(data);
	CNode* initHead;
	initHead=lst->head;
	int pos=0;
	if(newCNode!=NULL)
	{   
		if(idx==0)
		 clist_prepend(lst,data);
		else if(lst->head!=NULL) 
		 {
		do
		{  
			if(pos+1==idx)
			{
				newCNode->next=lst->head->next;
				lst->head->next=newCNode;
				break;
			}
			lst->head=lst->head->next;
			pos++;
		}while(lst->head!=initHead);

		lst->head=initHead;
		if(pos==idx)
			clist_append(lst,data); 
		/*Works as append if idx=size of list*/
		}
	}
	
}

// Remove an element from the end of the list

void clist_remove_last( CList* lst )

{ 	CNode* initHead;
	CNode* prev;
	prev=(CNode*) malloc(sizeof(CNode));
	initHead=lst->head;
	
	if(lst->head!=NULL)
		if(lst->head->next==initHead)
		{
			CNode* temp;
			temp=lst->head;
			lst->head=NULL;
			free(temp);
		}
 		else
		{
			while(lst->head->next!=initHead)
			{  
				prev=lst->head;
				lst->head=lst->head->next;
			}
			

				CNode* temp;
				temp=lst->head;
				prev->next=initHead;
				//lst->head=NULL;
				free(temp);
				lst->head=initHead;
		
		}

      
 		

}

// Remove an element from the beginning of the list

void clist_remove_first( CList* lst )
{
	CNode* initHead;
	initHead=lst->head;
	
	if(lst->head!=NULL)
	{
		if(lst->head->next==initHead)
 		{
 				CNode* temp;
				temp=lst->head;
				lst->head=NULL;
				free(temp);
 		}
 		else
 		{
 			while(lst->head->next!=initHead)
				lst->head=lst->head->next;
 			lst->head->next=initHead->next;
 			lst->head=initHead->next;
 			free(initHead);
 		}

	}
}

// Remove an element from an arbitrary @idx position in the list

void clist_remove( CList* lst, int idx )
{
	CNode* initHead;
	initHead=lst->head;
	int pos=0;

	if(lst->head!=NULL)
	{
		if(idx==0 )
			clist_remove_first(lst);//Removing first elm
		else if(lst->head->next!=initHead)
		{	
			while(1)
			{  
				if(pos+1==idx)
				{
					CNode* temp;
 			    	temp=lst->head->next;
 					lst->head->next=lst->head->next->next;
 					free(temp);
			}
				
			lst->head=lst->head->next;
			if(lst->head->next==initHead)
				break;
			pos++;

		}
		lst->head=initHead;
		}
	
	
}
}
void clist_reverse(CList* lst)
{
	if(lst->head==NULL || lst->head->next==lst->head)
	{}
	else
	{	CNode* initHead=lst->head;
		CNode* prev;
		CNode* revHead;
		prev=lst->head;
		revHead=lst->head->next;
		lst->head->next=NULL;
		while(revHead!=initHead)
		{	
			CNode* temp=revHead->next;
			revHead->next=prev;
			prev=revHead;
			revHead=temp;
		}
		lst->head=prev;
		initHead->next=lst->head;
	}
}


/*

int main(int argc, char const *argv[])
{
	CList* c=clist_new();
	clist_append(c,20);
	clist_insert(c,0,5);
	clist_reverse(c);
	clist_print(c);
	return 0;
}*/
