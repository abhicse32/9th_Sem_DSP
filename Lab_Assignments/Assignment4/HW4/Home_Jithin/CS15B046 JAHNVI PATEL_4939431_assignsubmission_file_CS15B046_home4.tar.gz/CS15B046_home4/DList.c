/* To define various operations on a Doubly Linked List with each node storing 2 data values such as:
	Creation of new node, new list, finding list size, getting a list element, insert operation,
	Appending and Prepending, removing a node and reversing the linked list

   Author: Jahnvi Patel CS15B046
   September 3, 2016
*/


#include "DList.h"
#include <stdlib.h>
#include <stdio.h>

// Create a new node with next set to NULL
DNode* dnode_new( int data)
{
	DNode* newNode;
	newNode=(DNode*) malloc(sizeof(DNode));
		if(newNode!=NULL)
		{
			newNode->data=data;
			newNode->next=NULL;
			newNode->prev=NULL;
		}
	return newNode;

}

// Create an empty list (head shall be NULL)
DList* dlist_new()
{
	DList* newList;
	newList=(DList*) malloc(sizeof(DList));
	if(newList!=NULL)
		newList->head=NULL;
	return newList;
	
}

// Traverse the linked list and return its size
int dlist_size( DList* lst )
{
	DNode* initHead;
	initHead=lst->head;
	int size=0;
	
	while(lst->head!=NULL)
	{   size++;
		lst->head=lst->head->next;
		

	}
	lst->head=initHead;
	return size;
	
}

// Traverse the linked list and print each element
void dlist_print( DList* lst )
{
	DNode* initHead;
	initHead=lst->head;

	while(lst->head!=NULL)
		{
			printf("%d ",lst->head->data);
			lst->head=lst->head->next;
		}
		printf("\n");
		lst->head=initHead;
}

//get the element at position @idx
int dlist_get( DList* lst, int idx )
{
	DNode* initHead;
	initHead=lst->head;
	int pos=0;
	while(lst->head!=NULL)
	{  
		if(pos==idx)
			{  
				int num=lst->head->data;
				lst->head=initHead;
				return num;
			}
		lst->head=lst->head->next;
		pos++;

	}
	lst->head=initHead;
	if(pos<=idx)
		{   
			return -1;
        }
}

// Add a new element at the end of the list
void dlist_append( DList* lst, int data )
{
	DNode* newNode;
	newNode=dnode_new(data);
	DNode* initHead;
	initHead=lst->head;
	if(newNode!=NULL)
	{
		if(lst->head==NULL)
		{
			lst->head=newNode;
			lst->head->next=NULL;
			lst->head->prev=NULL;
		}
		 else
		{
			while(lst->head->next!=NULL)
			{
				lst->head=lst->head->next;
			}
		lst->head->next=newNode;
		newNode->prev=lst->head;
		lst->head=initHead;
		}
	}
		
			
		
}

// Add a new element at the beginning of the list

void dlist_prepend( DList* lst, int data )
{
	DNode* newNode;
	newNode=dnode_new(data);
	if(newNode!=NULL)
	{
		newNode->next=lst->head;
		newNode->prev=NULL;
		if(lst->head!=NULL)
			lst->head->prev=newNode;
	    lst->head=newNode;

	}
	
}

// Add a new element at the @idx index

void dlist_insert( DList* lst, int idx, int data )
{
	DNode* newNode;
	newNode=dnode_new(data);
	DNode* initHead;
	initHead=lst->head;
	int pos=0;
	if(newNode!=NULL)
	{   
		if(idx==0)
		 	dlist_prepend(lst,data);
		else
		{
			while(lst->head->next!=NULL)
			{  
				if(pos+1==idx)
				{
					newNode->next=lst->head->next;
					lst->head->next->prev=newNode;
					newNode->prev=lst->head;
					lst->head->next=newNode;
					break;
				}
			lst->head=lst->head->next;
			pos++;
			}

		lst->head=initHead;
		if(dlist_size(lst)==idx)
			dlist_append(lst,data); 
		/*Works as append if idx=size of list*/
		}
	}
	
}

// Remove an element from the end of the list

void dlist_remove_last( DList* lst )

{ 	DNode* initHead;
	DNode* prev;
	//prev=(DNode*) malloc(sizeof(DNode));
	initHead=lst->head;
	int flag=0;
	if(lst->head!=NULL)
		{
		if(lst->head->next==NULL)
		{
			DNode* temp;
			temp=lst->head;
			lst->head=NULL;
			free(temp);

		}
 		else
		{
			while(lst->head->next!=NULL)
			{  	
				lst->head=lst->head->next;
			}
			
			DNode* temp;
			temp=lst->head;
			lst->head->prev->next=NULL;
			lst->head=NULL;
			free(temp);
			lst->head=initHead;
		
		}

       
 		

		}
}
// Remove an element from the beginning of the list

void dlist_remove_first( DList* lst )
{
	
	if(lst->head!=NULL)
	{
		if(lst->head->next==NULL)
 		{
 				DNode* temp;
				temp=lst->head;
				lst->head=NULL;
				free(temp);
 		}
 		else
 		{
 			DNode* temp;
 			temp=lst->head;
 			lst->head=lst->head->next;
 			free(temp);
 		}

	}
}

// Remove an element from an arbitrary @idx position in the list

void dlist_remove( DList* lst, int idx )
{
	DNode* initHead;
	initHead=lst->head;
	int pos=0;
	if(lst->head!=NULL)
	{
	if(idx==0 )
		dlist_remove_first(lst);//Removing first elm
	else if(lst->head->next!=NULL)
	{	
		while(1)
		{  
			if(pos+1==idx)
			{
				DNode* temp;
 			    temp=lst->head->next;
 				lst->head->next=lst->head->next->next;
 				lst->head->next->prev=lst->head;
 				free(temp);
			}
			if(lst->head->next==NULL)
				break;
			lst->head=lst->head->next;
			pos++;

		}
		lst->head=initHead;
	}
	
	
}
}

/* To reverse the linked list*/
void dlist_reverse(DList* lst)
{
	DNode* initHead;
	initHead=lst->head;
	if(lst->head!=NULL && lst->head->next!=NULL)
	{
		DNode* temp;
		while(lst->head!=NULL)
		{
			temp=lst->head->prev;
			lst->head->prev=lst->head->next;
			lst->head->next=temp;
			lst->head=lst->head->prev;

		}
		lst->head=temp->prev;
		initHead->next=NULL;
	}

}

/*
int main(int argc, char const *argv[])
{
	DList* d=dlist_new();
	dlist_append(d,5);
	dlist_append(d,15);
	dlist_remove_last(d);
	dlist_print(d);
	return 0;
}
*/
