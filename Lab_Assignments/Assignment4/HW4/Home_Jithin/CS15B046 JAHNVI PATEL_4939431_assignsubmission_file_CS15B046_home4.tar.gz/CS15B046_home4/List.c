/* To define various operations on a Linked List with each node storing 2 data values such as:
	Creation of new node, new list, finding list size, getting a list element, insert operation,
	Appending and Prepending

   Author: Jahnvi Patel CS15B046
   September 3, 2016
*/


#include "List.h"
#include <limits.h>
#include <stdlib.h>
#include <stdio.h>

// Create a new node with next set to NULL
Node* node_new( int data1,int data2)
{
	Node* newNode;
	newNode=(Node*) malloc(sizeof(Node));
		if(newNode!=NULL)
		{
			newNode->col_ind=data1;
			newNode->val=data2;
			newNode->next=NULL;
		}
	return newNode;

}

// Create an empty list (head shall be NULL)
LList* llist_new()
{
	LList* newList;
	newList=(LList*) malloc(sizeof(LList));
	if(newList!=NULL)
		newList->head=NULL;
	return newList;
	
}

// Traverse the linked list and return its size
int llist_size( LList* lst )
{
	Node* initHead;
	initHead=lst->head;
	int size=0;
	
	while(lst->head!=NULL)
	{   size++;
		lst->head=lst->head->next;
		

	}
	lst->head=initHead;
	return size;
	
}

// Traverse the linked list and print each element
void llist_print( LList* lst )
{
	Node* initHead;
	initHead=lst->head;
	if(lst->head==NULL){}
		//printf("0\n");
	else
	{
	while(lst->head!=NULL)
		{
			printf("%d ",lst->head->val);
			lst->head=lst->head->next;
		}
		printf("\n");
		lst->head=initHead;
	}
}

//get the element at position @idx
Node* llist_get( LList* lst, int idx )
{
	Node* initHead;
	initHead=lst->head;
	int pos=0;
	while(lst->head!=NULL)
	{  
		if(pos==idx)
			{  
				Node* temp=lst->head;
				lst->head=initHead;
				return temp;
			}
		lst->head=lst->head->next;
		pos++;

	}
	if(pos<idx)
		{   lst->head=initHead;
			return NULL;
        }
}

// Add a new element at the end of the list
void llist_append( LList* lst, int data1, int data2 )
{
	Node* newNode;
	newNode=node_new(data1,data2);
	Node* initHead;
	int flag=0;
	initHead=lst->head;
	if(newNode!=NULL)
	{
		if(lst->head==NULL)
		{
			lst->head=newNode;
			lst->head->next=NULL;
		 	flag=1;
		}
		else
		{	
			while(lst->head->next!=NULL)
			{
				lst->head=lst->head->next;
			}
		lst->head->next=newNode;
		}
	}
		if(flag==0)
			lst->head=initHead;
		
}

// Add a new element at the beginning of the list

void llist_prepend( LList* lst, int data1, int data2 )
{
	Node* newNode;
	newNode=node_new(data1,data2);
	if(newNode!=NULL)
	{
		newNode->next=lst->head;
	    lst->head=newNode;

	}
	
}

// Add a new element at the @idx index

void llist_insert( LList* lst, int idx, int data1, int data2 )
{
	Node* newNode;
	newNode=node_new(data1, data2);
	Node* initHead;
	initHead=lst->head;
	int pos=0;
	if(newNode!=NULL)
	{   if(idx==0)
		 llist_prepend(lst,data1, data2);
		 else
		 {
		while(lst->head!=NULL)
		{  
			if(pos+1==idx)
			{
				newNode->next=lst->head->next;
				lst->head->next=newNode;
				break;
			}
			lst->head=lst->head->next;
			pos++;
		}

		lst->head=initHead;
		if(pos==idx)
			llist_append(lst,data1, data2); 
		/*Works as append if idx=size of list*/
		}
	}
	
}
