/* To define various operations on a Sparse Matrix ADT such as:
	1. Addition of two Sparse Matrices
	2. Subtraction of two Sparse Matrices and
	3. Multiply a matrix and a vector

   Author: Jahnvi Patel CS15B046
   September 3, 2016
*/

#include "SparseMatrix.h"
#include <stdio.h>
#include <stdlib.h>

/*Add two matrices
 Return type:Matrix structure
*/

Matrix add(Matrix a, Matrix b)
{
	int i;
	Matrix sum;
	(sum.row_lst)=(LList**) malloc(a.n_rows*sizeof(LList*));
	sum.n_rows=a.n_rows;
	for(i=0;i<a.n_rows;i++)
	{	
		(sum.row_lst)[i]=llist_new();
		
		while((a.row_lst)[i]->head!=NULL && (b.row_lst)[i]->head!=NULL)
		{
		/*If both the matrix elements for a particular column index non-zero*/
			if((a.row_lst)[i]->head->col_ind == (b.row_lst)[i]->head->col_ind)
			{
				int x=(a.row_lst)[i]->head->val + (b.row_lst)[i]->head->val;
				llist_append((sum.row_lst)[i], (a.row_lst)[i]->head->col_ind , x);
				(a.row_lst)[i]->head=(a.row_lst)[i]->head->next;
				(b.row_lst)[i]->head=(b.row_lst)[i]->head->next;
			}
		/*If one of the matrix elements for a particular column index zero*/
			else if((a.row_lst)[i]->head->col_ind < (b.row_lst)[i]->head->col_ind)
			{
				llist_append((sum.row_lst)[i], (a.row_lst)[i]->head->col_ind , (a.row_lst)[i]->head->val );
				(a.row_lst)[i]->head=(a.row_lst)[i]->head->next;
			}
			else
			{
				llist_append((sum.row_lst)[i], (b.row_lst)[i]->head->col_ind , (b.row_lst)[i]->head->val );
				(b.row_lst)[i]->head=(b.row_lst)[i]->head->next;
			}
		}

		/*Append remaining elements*/
		while(a.row_lst[i]->head!=NULL)
		{
			llist_append((sum.row_lst)[i], (a.row_lst)[i]->head->col_ind , (a.row_lst)[i]->head->val );
			(a.row_lst)[i]->head=(a.row_lst)[i]->head->next;
		}

		while(b.row_lst[i]->head!=NULL)
		{
			llist_append((sum.row_lst)[i], (b.row_lst)[i]->head->col_ind , (b.row_lst)[i]->head->val );
			(b.row_lst)[i]->head=(b.row_lst)[i]->head->next;
		}
	}

	return sum;
}

/*Subtract Matrix b from a
Return type:Matrix structure
*/

Matrix subtract(Matrix a, Matrix b)
{
	int i;
	Matrix diff;
	(diff.row_lst)=(LList**) malloc(a.n_rows*sizeof(LList*));
	diff.n_rows=a.n_rows;
	for(i=0;i<a.n_rows;i++)
	{	
		(diff.row_lst)[i]=llist_new();
		
		while((a.row_lst)[i]->head!=NULL && (b.row_lst)[i]->head!=NULL)
		{
			/*If both the matrix elements for a particular column index non-zero*/
			if((a.row_lst)[i]->head->col_ind == (b.row_lst)[i]->head->col_ind)
			{
				int x=(a.row_lst)[i]->head->val - (b.row_lst)[i]->head->val;
				llist_append((diff.row_lst)[i], (a.row_lst)[i]->head->col_ind , x);
				(a.row_lst)[i]->head=(a.row_lst)[i]->head->next;
				(b.row_lst)[i]->head=(b.row_lst)[i]->head->next;
			}
			/*If one of the matrix elements for a particular column index zero*/
			else if((a.row_lst)[i]->head->col_ind < (b.row_lst)[i]->head->col_ind)
			{
				llist_append((diff.row_lst)[i], (a.row_lst)[i]->head->col_ind , (a.row_lst)[i]->head->val );
				(a.row_lst)[i]->head=(a.row_lst)[i]->head->next;
			}
			else
			{
				llist_append((diff.row_lst)[i], (b.row_lst)[i]->head->col_ind , -(b.row_lst)[i]->head->val );
				(b.row_lst)[i]->head=(b.row_lst)[i]->head->next;
			}
		}

		/*Append remaining elements*/

		while(a.row_lst[i]->head!=NULL)
		{
			llist_append((diff.row_lst)[i], (a.row_lst)[i]->head->col_ind , (a.row_lst)[i]->head->val );
			(a.row_lst)[i]->head=(a.row_lst)[i]->head->next;
		}

		while(b.row_lst[i]->head!=NULL)
		{
			llist_append((diff.row_lst)[i], (b.row_lst)[i]->head->col_ind , -(b.row_lst)[i]->head->val );
			(b.row_lst)[i]->head=(b.row_lst)[i]->head->next;
		}
	}

	return diff;
}

/*Multiply an M x N matrix with N X 1 vectorReturn type:Matrix structure
Return type:Matrix structure
*/

Matrix matrix_vect_multiply(Matrix mat, Matrix vect)
{
	Matrix prod;
	(prod.row_lst)=(LList**) malloc(mat.n_rows*sizeof(LList*));
	prod.n_rows=mat.n_rows;

	int i;
	
	/*Loops for all m rows*/
	for(i=0;i<mat.n_rows;i++)
	{	
		(prod.row_lst)[i]=llist_new();
		int j=0,p=0;

	
		/*To obtain each row of product matrix */

		while((mat.row_lst)[i]->head!=NULL && j<vect.n_rows)
		{  
			/*If column entry of matrix and corresponding row  entry of vector both are non-zero */  
				if((mat.row_lst)[i]->head->col_ind == j) 
				{
					p+=(mat.row_lst)[i]->head->val * (vect.row_lst)[j]->head->val;
					j++;
					(mat.row_lst)[i]->head=(mat.row_lst)[i]->head->next;
				}
			/*If column entry of matrix non-zero and corresponding row  entry of vector is zero */ 
				else if((mat.row_lst)[i]->head->col_ind < j) 
				{
					(mat.row_lst)[i]->head=(mat.row_lst)[i]->head->next;
				}
			/*If column entry of matrix is zero and corresponding row  entry of vector is non-zero */ 
				else j++;
				
			
		}
			
			llist_append((prod.row_lst)[i], 0 , p );
		
	}
	return prod;
}
