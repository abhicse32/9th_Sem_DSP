/* To perform various operations on a Sparse Matrix ADT such as:
	1. Addition of two Sparse Matrices
	2. Subtraction of two Sparse Matrices and
	3. Multiply a matrix and a vector

   Author: Jahnvi Patel CS15B046
   September 3, 2016
*/


#include "SparseMatrix.h"
#include <stdio.h>
#include <stdlib.h>

void main()
{
	int op;
	do
	{
		scanf("%d",&op);
	/*ADDITION and SUBTRACTION*/
		if(op==1 || op==2)
		{
			int m,n;
			Matrix a,b;
			scanf("%d%d",&m,&n);
			int i,j;
			a.n_rows=m;
			b.n_rows=m;

			/*INPUT MATRIX 1*/

			(a.row_lst)=(LList**) malloc(m*sizeof(LList*));

			for(i=0;i<m;i++)
			{	
		

				(a.row_lst)[i]=llist_new();
		
				for(j=0;j<n;j++)
				{
					int elm;
					scanf("%d",&elm);
					if(elm!=0)
						llist_append((a.row_lst)[i],j,elm);
			
						
				}

			}

			/*INPUT MATRIX 2*/

			(b.row_lst)=(LList**) malloc(m*sizeof(LList*));


			for(i=0;i<m;i++)
			{
				(b.row_lst)[i]=llist_new();

				for(j=0;j<n;j++)
				{
		
					int elm;
					scanf("%d",&elm);
					if(elm!=0)
						llist_append((b.row_lst)[i],j,elm);
				}
		
			}

		
			/*OUTPUT MATRIX*/

			Matrix out;
			if(op==1)
				out=add(a,b);
			else out=subtract(a,b);
			for(i=0;i<m;i++)
				llist_print(out.row_lst[i]);
		}

	/*MULTIPLICATION BY A VECTOR*/

		else if(op==3)
		{
			int m,n;
			Matrix a,b;
			scanf("%d%d",&m,&n);
			int i,j;
			a.n_rows=m;
			b.n_rows=n;

			/*INPUT MATRIX 1*/

			(a.row_lst)=(LList**) malloc(m*sizeof(LList*));

			for(i=0;i<m;i++)
			{	
		

				(a.row_lst)[i]=llist_new();
		
				for(j=0;j<n;j++)
				{
					int elm;
					scanf("%d",&elm);
					if(elm!=0)
						llist_append((a.row_lst)[i],j,elm);
			
						
				}

			}

			/*INPUT VECTOR*/

			(b.row_lst)=(LList**) malloc(n*sizeof(LList*));


			for(i=0;i<n;i++)
			{
				(b.row_lst)[i]=llist_new();
		
				int elm;
				scanf("%d",&elm);
				llist_append((b.row_lst)[i],0,elm);
				
			}

			/*OUTPUT MATRIX*/
			Matrix out=matrix_vect_multiply(a,b);
			for(i=0;i<m;i++)
				llist_print(out.row_lst[i]);

		}


	}while(op!=-1);

	



}
