#include "CList.h"
#include<stdio.h>
#include<limits.h>
#include<stdlib.h>

//1)Create new CNode
CNode* cnode_new(int value)
{
	CNode *new;
	new = (CNode*)malloc(sizeof(CNode)) ;//Allocate memory
        //If no space available malloc returns NULL,so check for successfull memory allocation
	if(new != NULL)
	{
		new->data = value ;
		new->next = NULL;	//Point CNode's next field to NULL
	}
	return new;
}

//Create and Initialize Empty Linked List
CList* clist_new()
{
	CList *list;
	list = (CList*)malloc(sizeof(CList)); //Allocate Memory
	list->head = NULL ; //Initialize
	return list ;
}

//Calculates size of LL

int clist_size( CList* lst )
{
	CNode *temphead ;
	temphead = lst->head ;
	int size = 0;
	//Traverse to end of list and incrementing size together
	while(temphead->next != lst->head)
	{
		size++;
		temphead = temphead->next ;  
	}
	return size+1;
}

//Print LL
void clist_print( CList* lst )
{
	CNode *temphead ;
	temphead = lst->head ;
	
	if(temphead!=NULL)
	{
	        while(temphead->next != lst->head)
	        {
	                printf("%d ",temphead->data);
	                temphead = temphead ->next ;
	        }
	        printf("%d ",temphead->data);
	        printf("\n");
        }
}

//Gets element at given index
//If index is invalid returns INT_MIN
int clist_get( CList* lst, int idx )
{
	int count = 0;
	int value=0;
	CNode *temphead;
	temphead = lst->head ;
	//Check validity of index
	if( idx >= clist_size(lst) || idx < 0 )
	{
		return -1 ;
	}
	else
	{
	        //Traverse to index
		while(count<=idx-1)//count=idx on loop break 
		{
			temphead = temphead->next ;
			count++;
		}
		value = temphead->data ;		
		return value ;
	}	
}

//Appends element to end of LL

void clist_append( CList* lst, int value )
{
	CNode *new;
	CNode *temphead;
	//Check for empty list
	new = cnode_new(value); //Create new CNode
	
	//For Base Case
	if(lst->head==NULL)
	{
	        lst->head = new ;
	        new->next = lst->head ;
	}
	else
	{
	        temphead = lst->head ;
	        if(temphead ==temphead->next)
	        {
	                lst->head->next = new ;
	                new->next = lst->head ;
	        }
	        else
	        {
	                while(temphead->next != lst->head )
	                {
	                        temphead = temphead->next ;
	                }
	                new->next =lst->head ;
	                temphead->next = new ;
	        }
	}
}
//Prepends element before list
void clist_prepend( CList* lst, int value )
{
        clist_append(lst,value);
        CNode *temphead = lst->head ;
        while(lst->head->next != temphead)        	
                lst->head = lst->head->next ;
}

//Insert given element at given index
void clist_insert( CList* lst, int idx, int value )
{
	if(idx>0 && idx < clist_size(lst) )//Check index validity
	{
		int count = 0;
		CNode *new=cnode_new(value);//create CNode
		CNode *temphead = lst->head;//store head		
	
		while(count<=idx-2)//Traverse to idx-1
		{
			count++;
			lst->head = lst->head->next ;
		}
		
                //head->next points to current ele at idx position	
                //Insert new bet idx-1 and current idx
		new->next = lst->head->next ;
		lst->head->next = new ;
		lst->head = temphead ;//recover head
	}
	else if(idx==0) //insert at start-->prepend
	{
		clist_prepend(lst,value);
	}
	else if (idx==clist_size(lst))//insert at end-->append
	{
		clist_append(lst,value);
	}
}

//Remove Last Element from list  
void clist_remove_last( CList* lst )
{	
	if(lst->head != NULL)//Check for empty list
	{		
		CNode *temphead,*prev;//Maintain 2nd last element -->prev
		temphead = lst->head ;
		prev = lst->head ;
		//Only 1 element in list
		if(lst->head->next==NULL)
		{
			lst->head = NULL ;
		}
		
		while(lst->head->next!= temphead)
		{
			prev = lst->head;
			lst->head = lst->head->next ;			
		}
		//disconnect last ele by pointing prev to NULL
		prev->next = temphead ;
		lst->head = temphead ;		//recover head		
	}
}

//Remove first ele from LL
void clist_remove_first( CList* lst )
{
        //Check for empty list
	if(lst->head!=NULL)
	{	
	        if(lst->head->next != lst->head)
	        {	        
	                CNode *temphead  = lst->head ;	                	                	                	                	
		        while(temphead->next != lst->head)
		                temphead = temphead->next ;
	                temphead->next = temphead->next->next ;
	                lst->head =lst->head->next ;
	        }
	        else
	        {
	                lst->head = NULL ;               
	        }
	}
}

//Deletion at given index 
void clist_remove( CList* lst, int idx )
{
	int count = 0 ;
	if(idx >0 && idx < clist_size(lst)) //Check index validity
	{ 	
		CNode *temphead = lst->head ;
		if(idx==1)//Remove 2nd element
		{
			lst->head->next = lst->head->next->next ;//Next connection has to be changed to skip element
		}
		else
		{	//Traverse to idx-1	
			while(count <= idx-2)
			{
				lst->head = lst->head->next ;
				count++; 
			}
			lst->head->next = lst->head->next->next ;
		}
		lst->head = temphead ;
		
	}
	else if (idx==0)//Remove from 0th index = remove from first
	{
		clist_remove_first(lst);
	}
}

void clist_reverse(CList *lst)
{
        CNode *temphead = lst->head ;
        if(lst->head != NULL)
        {
                if(lst->head != temphead->next )
                {
                        CNode *dest,*curr,*temp;
                        dest = NULL;
                        curr = temphead ;
                        temp = temphead->next ;
                                     
                        while(curr->next != temphead)
                        {             
                                curr->next = dest;
                                dest = curr ;                
                                curr = temp ;                
                                temp = temp->next ;
                        }
                        curr->next = dest;
                        temphead->next = curr ;
                        lst->head = curr ;     
                }
        }         
}

