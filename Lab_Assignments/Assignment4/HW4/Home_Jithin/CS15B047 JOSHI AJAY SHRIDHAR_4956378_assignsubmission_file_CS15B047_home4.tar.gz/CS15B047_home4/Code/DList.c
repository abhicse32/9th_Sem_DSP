#include "DList.h"
#include<stdio.h>
#include<limits.h>
#include<stdlib.h>

//1)Create new DNode
DNode* dnode_new(int value)
{
	DNode *new;
	new = (DNode*)malloc(sizeof(DNode)) ;//Allocate memory
        //If no space available malloc returns NULL,so check for successfull memory allocation
	if(new != NULL)
	{
		new->data = value ;
		new->next = NULL; 	//Point DNode's next field to NULL
		new->prev = NULL;
	}
	return new;
}

//Create and Initialize Empty Linked List
DList* dlist_new()
{
	DList *list;
	list = (DList*)malloc(sizeof(DList)); //Allocate Memory
	list->head = NULL ; //Initialize
	return list ;
}

//Calculates size of LL
int dlist_size( DList* lst )
{
	DNode *temphead ;
	temphead = lst->head ;
	int size = 0;
	//Traverse to end of list and incrementing size together
	while(temphead != NULL)
	{
		size++;
		temphead = temphead->next ;  
	}
	return size;
}

//Print LL
void dlist_print( DList* lst )
{
	DNode *temphead ;
	temphead = lst->head ;
	//Traverse LL till end and print data element
	while(temphead != NULL)
	{
		printf("%d ",temphead->data);
		temphead = temphead->next ;
	}
	printf("\n");
}

//Gets element at given index
//If index is invalid returns INT_MIN
int dlist_get( DList* lst, int idx )
{
	int count = 0;
	int value=0;
	DNode *temphead;
	temphead = lst->head ;
	//Check validity of index
	if( idx >= dlist_size(lst) || idx < 0 )
	{
		return -1;
	}
	else
	{
	        //Traverse to index
		while(count<=idx-1)//count=idx on loop break 
		{
			temphead = temphead->next ;
			count++;
		}
		value = temphead->data ;		
		return value ;
	}	
}

//Appends element to end of LL
void dlist_append( DList* lst, int value )
{
	DNode *new;
	DNode *temphead;
	//Check for empty list
	if(lst->head!=NULL)
		temphead = lst->head ; //Store list head
	
	new = dnode_new(value); //Create new DNode
	
	//For Base Case
	if(lst->head == NULL)
	{
		lst->head = new ;
	}
	else
	{
	        //Traverse to last element	
		while(lst->head->next != NULL)
		{
			lst->head = lst->head->next ;
		}
		//Insert new DNode 
		lst->head->next = new ;
		new->prev = lst->head ;
		lst->head = temphead ;
	}
}
//Prepends element before list
void dlist_prepend( DList* lst, int value )
{
        if(lst->head!=NULL)
        {
                //Create new DNode
	        DNode *new;
	        new = dnode_new(value);
	        //Point new ele to head 
	        new->next = lst->head ;
	        lst->head->prev = new ;
	        //change head to new DNode
	        lst->head = new ;	
        }
        else
        {
                DNode *new;
	        new = dnode_new(value);
	        //Point new ele to head 
	        new->next = lst->head ;
                lst->head = new ;        
        }
}

//Insert given element at given index
void dlist_insert( DList* lst, int idx, int value )
{
	if(idx>0 && idx < dlist_size(lst) )//Check index validity
	{
		int count = 0;
		DNode *new=dnode_new(value);//create DNode
		DNode *temphead = lst->head;//store head		
	
		while(count<=idx-2)//Traverse to idx-1
		{
			count++;
			lst->head = lst->head->next ;
		}
		
                //head->next points to current ele at idx position	
                //Insert new bet idx-1 and current idx
		new->next = lst->head->next ;
		lst->head->next = new ;
		new->prev = lst->head ;
		new->next->prev = new ;
		
		lst->head = temphead ;//recover head
	}
	else if(idx==0) //insert at start-->prepend
	{
		dlist_prepend(lst,value);
	}
	else if (idx==dlist_size(lst))//insert at end-->append
	{
		dlist_append(lst,value);
	}
}

//Remove Last Element from list  
void dlist_remove_last( DList* lst )
{	
	if(lst->head != NULL)//Check for empty list
	{		
		DNode *temphead,*pr;//Maintain 2nd last element -->prev
		temphead = lst->head ;
		pr = lst->head ;
		//Only 1 element in list
		if(lst->head->next==NULL)
		{
			lst->head = NULL ;
		}
		
		while(lst->head->next!= NULL)
		{
			pr = lst->head;
			lst->head = lst->head->next ;			
		}
		//disconnect last ele by pointing prev to NULL
		DNode *temp = pr->next ;
		pr->next->prev = NULL ;
		pr->next=NULL;
		lst->head = temphead ;		//recover head
		free(temp);
		
	}
}

//Remove first ele from LL
void dlist_remove_first( DList* lst )
{
        //Check for empty list
	if(lst->head!=NULL)
	{	
	        DNode *temphead  = lst->head ;
		lst->head = lst->head->next ;
		lst->head->prev = NULL ;
		free(temphead);		//Change head to skip 1st element
	}
}

//Deletion at given index 
void dlist_remove( DList* lst, int idx )
{
	int count = 0 ;
	if(idx >0 && idx < dlist_size(lst)) //Check index validity
	{ 	
		DNode *temphead = lst->head ;
		if(idx==1)//Remove 2nd element
		{
		        DNode *temp = lst->head->next ;
			lst->head->next = lst->head->next->next ;//Next connection has to be changed to skip element
			lst->head->next->prev = lst->head ;
			free(temp);
		}
		else
		{	//Traverse to idx-1	
			while(count <= idx-2)
			{
				lst->head = lst->head->next ;
				count++; 
			}
			DNode *temp = lst->head->next ;
			lst->head->next=lst->head->next->next ;
			lst->head->next->prev = lst->head ;
			free(temp);
		}
		lst->head = temphead ;
		
	}
	else if (idx==0)//Remove from 0th index = remove from first
	{
		dlist_remove_first(lst);
	}
}

void dlist_reverse(DList *lst)
{
        if(lst->head != NULL && lst->head->next != NULL )
        {
                DNode *temphead = lst->head ;
                lst->head = lst->head->next ;
                dlist_reverse(lst);
                
                temphead->next->next = temphead ;
                temphead->next->prev = NULL ;
                temphead->prev = temphead->next ;
                temphead->next = NULL ;                
        }         
}



