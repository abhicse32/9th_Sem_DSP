#include<stdio.h>
#include "List.h"
#include<limits.h>
#include<stdlib.h>

//1)Create new Node
Node* node_new(int value1,int value2)
{
	Node *new;
	new = (Node*)malloc(sizeof(Node)) ;//Allocate memory
        //If no space available malloc returns NULL,so check for successfull memory allocation
	if(new != NULL)
	{
		new->col_ind = value1 ;
		new->val =value2 ;
		new->next = NULL;	//Point node's next field to NULL
	}
	return new;
}

//Create and Initialize Empty Linked List
LList* llist_new()
{
	LList *list;
	list = (LList*)malloc(sizeof(LList)); //Allocate Memory
	list->head = NULL ; //Initialize
	return list ;
}

//Calculates size of LL
int llist_size( LList* lst )
{
	Node *temphead ;
	temphead = lst->head ;
	int size = 0;
	//Traverse to end of list and incrementing size together
	while(temphead != NULL)
	{
		size++;
		temphead = temphead->next ;  
	}
	return size;
}

//Print LL
void llist_print( LList* lst )
{
	Node *temphead ;
	temphead = lst->head ;
	//Traverse LL till end and print data element
	while(temphead != NULL)
	{
		printf("%d ",temphead->val);
		temphead = temphead->next ;
	}
	printf("\n");
}

//Gets element at given index
//If index is invalid returns INT_MIN
Node *llist_get( LList* lst, int idx )
{
	int count = 0;
	int value=0;
	Node *temphead;
	temphead = lst->head ;
	//Check validity of index
	if( idx >= llist_size(lst) || idx < 0 )
	{
		temphead->col_ind = -1 ;
		temphead->val = -1 ;
		return temphead;
	}
	else
	{
	        //Traverse to index
		while(count<=idx-1)//count=idx on loop break 
		{
			temphead = temphead->next ;
			count++;
		}		
		return temphead ;
	}	
}

//Appends element to end of LL
void llist_append( LList* lst, int value1,int value2 )
{
	Node *new;
	Node *temphead;
	//Check for empty list
	if(lst->head!=NULL)
		temphead = lst->head ; //Store list head
	
	new = node_new(value1,value2); //Create new node
	
	//For Base Case
	if(lst->head == NULL)
	{
		lst->head = new ;
	}
	else
	{
	        //Traverse to last element	
		while(lst->head->next != NULL)
		{
			lst->head = lst->head->next ;
		}
		//Insert new node 
		lst->head->next = new ;
		lst->head = temphead ;
	}
}
//Prepends element before list
void llist_prepend( LList* lst, int value1,int value2 )
{
        //Create new node
	Node *new;
	new = node_new(value1,value2);
	//Point new ele to head 
	new->next = lst->head ;
	//change head to new node
	lst->head = new ;	
}

//Insert given element at given index
void llist_insert( LList* lst, int idx, int value1,int value2 )
{
	if(idx>0 && idx < llist_size(lst) )//Check index validity
	{
		int count = 0;
		Node *new=node_new(value1,value2);//create node
		Node *temphead = lst->head;//store head		
	
		while(count<=idx-2)//Traverse to idx-1
		{
			count++;
			lst->head = lst->head->next ;
		}
		
                //head->next points to current ele at idx position	
                //Insert new bet idx-1 and current idx
		new->next = lst->head->next ;
		lst->head->next = new ;
		lst->head = temphead ;//recover head
	}
	else if(idx==0) //insert at start-->prepend
	{
		llist_prepend(lst,value1,value2);
	}
	else if (idx==llist_size(lst))//insert at end-->append
	{
		llist_append(lst,value1,value2);
	}
}
