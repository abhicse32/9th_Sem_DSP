#include "SparseMatrix.h"
#include <stdlib.h>

//Addition Routine
Matrix add(Matrix M1,Matrix M2)
{
        Matrix Add;
        //Allocate Memory
        Add.row_lst = (LList**)malloc(sizeof(LList*)*M1.n_rows) ;
        //Check compatibility for addition
        if(M1.n_rows == M2.n_rows)
        {
                int i=0;
                for(i=0;i<M1.n_rows;i++)
                {
                        //Create space for every row LL
                        Add.row_lst[i] = llist_new();
                        //Trivial Case --> one of the matrix row has all 0s
                        if(M1.row_lst[i]->head == NULL)
                                Add.row_lst[i]->head = M2.row_lst[i]->head ;
                        else if(M2.row_lst[i]->head == NULL)
                                Add.row_lst[i]->head = M1.row_lst[i]->head ;
                        //Maintain pointer to LL of both matices and add in order of increasing col_ind
                        else
                        {                        
                                Node *temphead1 = M1.row_lst[i]->head ;
                                Node *temphead2 = M2.row_lst[i]->head ; 
                                while(temphead1!= NULL || temphead2 != NULL)
                                {
                                        //If 1 list is exhausted directly append other remaining list to answer
                                        if(temphead1 == NULL)
                                        {
                                                while(temphead2!=NULL)
                                                {
                                                        llist_append(Add.row_lst[i],temphead2->col_ind,temphead2->val);
                                                        temphead2 = temphead2->next ;
                                                }    
                                        }
                                        else if(temphead2 == NULL)
                                        {
                                                while(temphead1!=NULL)
                                                {
                                                        llist_append(Add.row_lst[i],temphead1->col_ind,temphead1->val);
                                                        temphead1 = temphead1->next ;
                                                }
                                        }
                                        //Add elements to resulting LL in order of col_ind 
                                        else
                                        {
                                                if(temphead1->col_ind < temphead2->col_ind)
                                                {       
                                                        llist_append(Add.row_lst[i],temphead1->col_ind,temphead1->val);
                                                        temphead1 = temphead1->next ;
                                                }
                                                else if(temphead1->col_ind > temphead2->col_ind) 
                                                {
                                                        llist_append(Add.row_lst[i],temphead2->col_ind,temphead2->val);
                                                        temphead2 = temphead2->next ;
                                                }
                                                else
                                                {
                                                        llist_append(Add.row_lst[i],temphead1->col_ind,temphead2->val + temphead1->val) ;
                                                        temphead2 = temphead2->next ;
                                                        temphead1 = temphead1->next ; 
                                                }                                                                                             
                                        }
                                }
                        }        
                }
        } 
        return Add ;        
}

//Subtraction Routine
Matrix subtract(Matrix M1, Matrix M2)
{
        Matrix Subtract;
        Subtract.row_lst = (LList**)malloc(sizeof(LList*)*M1.n_rows) ;

        //Check compatibility
        if(M1.n_rows == M2.n_rows)       
        {
                int i=0;
                //Turn M2 into (-1) * M2 and then add M1 and -M2
                for(i=0;i<M2.n_rows;i++)
                {
                        Node *temphead2 = M2.row_lst[i]->head ;
                        while(temphead2 != NULL)
                        {
                                temphead2->val = (-1)*temphead2->val ;
                                temphead2 = temphead2->next ;
                        }
                                 
                }
                Subtract = add(M1,M2) ;       
        }
        return Subtract;        
}


//Matrix Vector Multiplication
Matrix matrix_vect_multiply(Matrix mat, Matrix vect)
{
        Matrix Mult ;
        int sum = 0,flag=0;
        int i;
        //Allocate Memory to array of LL
        Mult.row_lst = (LList**)malloc(sizeof(LList*)*mat.n_rows) ;
        Mult.n_rows = mat.n_rows ;
        for(i=0;i<mat.n_rows;i++)
        {
                //Allocate memory to each LL
                Mult.row_lst[i] = llist_new();
                Node *temphead1 = mat.row_lst[i]->head ;
                
                sum = 0 ;
                flag=0;
                //Traverse row list of matrix and check for element in vector whose row no. is same as column index of curr ele in row LL
                while(temphead1 != NULL)
                {                        
                        if(vect.row_lst[temphead1->col_ind]->head != NULL)
                        {                                
                                //Accumulate answer value in sum
                                sum = sum + vect.row_lst[temphead1->col_ind]->head->val * temphead1->val ;                 
                        }
                        temphead1 = temphead1->next ;                         
                }
                //Add element to resultant m x 1 vector
                llist_append(Mult.row_lst[i],0,sum) ;                               
        }
        return Mult ;                        
}
