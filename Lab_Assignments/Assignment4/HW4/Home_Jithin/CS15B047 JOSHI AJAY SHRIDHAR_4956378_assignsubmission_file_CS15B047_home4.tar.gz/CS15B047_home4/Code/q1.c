#include<stdio.h>
#include<stdlib.h>
#include "SparseMatrix.h"

int main()
{
        int option ;
        scanf("%d",&option);
        // -1 is termination of input
        while(option != -1)
        {        
                int m,n;
                int i,j;
                int data;
                scanf("%d%d",&m,&n);
                
                Matrix M1,M2,Result;
                //Allocate memory for array of LL
                M1.row_lst = (LList**)malloc(sizeof(LList*)*m);
                M1.n_rows = m ;                                                 
                
                //Take input and convert to sparsematrix
                for(i=0;i<m;i++)
                {                
                        M1.row_lst[i] = llist_new() ;
                        for(j=0;j<n;j++)
                        {
                                scanf("%d",&data);
                                if(data!=0)
                                {                                
                                        llist_append(M1.row_lst[i],j,data);                                
                                }
                        }
                }
                if(option == 1 || option == 2)
                {                
                        //Take input and convert to sparsematrix        
                        M2.row_lst = (LList**)malloc(sizeof(LList*)*m);
                        M2.n_rows = m ; 
                        for(i=0;i<M2.n_rows;i++)
                        {                
                                M2.row_lst[i] = llist_new() ;
                                for(j=0;j<n;j++)
                                {
                                        scanf("%d",&data);
                                        if(data!=0)
                                        {                                
                                                llist_append(M2.row_lst[i],j,data);                                
                                        }
                                }
                        }
                        //Add 2 sparsematrices
                        if(option == 1)
                        {
                                Result = add(M1,M2) ;
                        }
                        //Subtract 2 sparsematrices M1-M2
                        else if(option == 2)
                        {
                                Result = subtract(M1,M2) ;
                        }
                }
                else
                {
                                        
                        M2.row_lst = (LList**)malloc(sizeof(LList*)*n);
                        M2.n_rows = n ;
                        //Take vector as input with n rows in form of sparse matrix
                        for(i=0;i<M2.n_rows;i++)
                        {                
                                M2.row_lst[i] = llist_new() ;
                                for(j=0;j<1;j++)
                                {
                                        scanf("%d",&data);
                                        if(data!=0)
                                        {                                
                                                llist_append(M2.row_lst[i],j,data);                                
                                        }
                                }
                        }
                        Result = matrix_vect_multiply(M1,M2) ;
                }
                //Print Resultant Matrix 
                Node *temphead;
                for(i=0;i<m;i++)
                {
                        temphead = Result.row_lst[i]->head ;                                               
                        {                        
                                while(temphead!=NULL)
                                {
                                        printf("%d ",temphead->val);        
                                        temphead = temphead->next ;
                                }
                                
                                //Change made for printing \n
                                if(Result.row_lst[i]->head != NULL)
                                        printf("\n");   
                        }
                }                
                //Take next operation as input
                scanf("%d",&option);
        }        
        return 0;
}
