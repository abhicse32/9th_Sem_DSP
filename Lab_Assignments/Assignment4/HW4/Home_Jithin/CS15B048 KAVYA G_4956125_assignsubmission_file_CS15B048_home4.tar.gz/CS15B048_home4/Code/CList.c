#include "CList.h"
#include<stdio.h>
#include<stdlib.h>

// Create a new node with next set to NULL
CNode* cnode_new( int data){
  CNode* new = (CNode*) malloc(sizeof(CNode));
  new->data = data;
  new->next = NULL;
  return new;
}

// Create an empty list (head shall be NULL)
CList* clist_new(){
  CList* new = (CList*) malloc(sizeof(CList));
  new->head = NULL;
  return new;
}

// Traverse the linked list and return its size
int clist_size( CList* lst ){
  CNode* np = (CNode*) malloc(sizeof(CNode));
  np = lst->head;
  if(np == NULL){
	return 0;
  }
  int count = 0;
  do{
	np = np->next;
	count++;
  }while(np != lst->head);

  return count;
}

// Traverse the linked list and print each element
void clist_print( CList* lst ){
  if(lst->head == NULL){
	printf("\n");
	return;
  }
  CNode* np = (CNode*) malloc(sizeof(CNode));
  np = lst->head;
  do{
	printf("%d ", np->data);
	np = np->next;
  }while(np != lst->head);
  printf("\n");
}

//get the element at position @idx
int clist_get( CList* lst, int idx ){
  if(idx < 0 || idx >= clist_size(lst)){
	return -1;
  }
  int count = 0;
  CNode* np = (CNode*) malloc(sizeof(CNode));
  np = lst->head;
  for(; count < idx; count++){
	np = np->next;
  }
  return np->data;
}

// Add a new element at the beginning of the list
void clist_prepend( CList* lst, int data ){
  CNode* temp = (CNode*) malloc(sizeof(CNode));
  temp = cnode_new(data);
  if(lst->head == NULL){
	lst->head = temp;
	lst->head->next = lst->head;
	return;
  }
  CNode* np = (CNode*) malloc(sizeof(CNode));
  np = lst->head;
  temp->next = np;
  // to make last element point to current this new head as its next
  while(np->next != lst->head)
	np = np->next;
  lst->head = temp;
  np->next = lst->head;
}

// Add a new element at the end of the list
void clist_append( CList* lst, int data ){
  CNode* temp = (CNode*) malloc(sizeof(CNode));
  temp = cnode_new(data);
  if(lst->head == NULL){
	lst->head = temp;
	lst->head->next = lst->head;
	return;
  }
  CNode* np = (CNode*) malloc(sizeof(CNode));
  np = lst->head;
  while(np->next != lst->head)
	np = np->next;
  np->next = temp;
  // Link it to the first element
  temp->next = lst->head;
}

// Add a new element at the @idx index
void clist_insert( CList* lst, int idx, int data ){
  int size = clist_size(lst);
  if(idx < 0 || idx > size)
	return;
  if(idx == 0){
	clist_prepend(lst, data);
	return;
  }
  if(idx == size){
	clist_append(lst, data);
	return;
  }
  CNode* temp = (CNode*) malloc(sizeof(CNode));
  temp = cnode_new(data);
  int count = 0;
  CNode* np = (CNode*) malloc(sizeof(CNode));
  np = lst->head;
  for(; count < idx-1; count++){
	np = np->next;
  }
  temp->next = np->next;
  np->next = temp;
}

// Remove an element from the end of the list
void clist_remove_last( CList* lst ){
  CNode* np = (CNode*) malloc(sizeof(CNode));
  np = lst->head;
  if(np == NULL)
	return;
  if(lst->head->next == lst->head){
	free(np);
	lst->head = NULL;
	return;
  }
  // np is the one previous to the one to be deleted
  while(np->next->next != lst->head){
	np = np->next;
  }
  CNode* temp = (CNode*) malloc(sizeof(CNode));
  temp = np->next;
  // Link the previous element to head
  np->next = lst->head;
  free(temp);
}

// Remove an element from the beginning of the list
void clist_remove_first( CList* lst ){
  CNode* np = (CNode*) malloc(sizeof(CNode));
  np = lst->head;
  if(np == NULL)
	return;
  if(lst->head->next == lst->head){
	free(np);
	lst->head = NULL;
	return;
  }
  // Make last point to the new head
  while(np->next != lst->head)
	np = np->next;
  np->next = lst->head->next;
  CNode* temp = (CNode*) malloc(sizeof(CNode));
  temp = lst->head;
  lst->head = temp->next;
  free(temp);
}

// Remove an element from an arbitrary @idx position in the list
void clist_remove( CList* lst, int idx ){
  CNode* np = (CNode*) malloc(sizeof(CNode));
  np = lst->head;
  int size = clist_size(lst);
  if(np == NULL || idx < 0 || idx > size)
	return;
  if(idx == 0){
	clist_remove_first(lst);
	return;
  }
  if(idx == size - 1){
	clist_remove_last(lst);
	return;
  }
  int count = 0;
  //np now points to the node before the one to be deleted
  for(; count < idx-1; count++){
	np = np->next;
  }
  CNode* temp = (CNode*) malloc(sizeof(CNode));
  temp = np->next;
  np->next = np->next->next;
  free(temp);
}

// reverse the list
void clist_reverse(CList* lst){
  CNode* np = (CNode*) malloc(sizeof(CNode));
  np = lst->head;
  // Special case of 0 or 1 elements
  if(np == NULL || np == np->next)
	return;
  // Special case of 2 elements : only head has to be changed, links can remain as such
  if(np->next->next == np){
	lst->head = np->next;
	return;
  }
  np = np->next;
  CNode* prev = (CNode*) malloc(sizeof(CNode));
  CNode* next = (CNode*) malloc(sizeof(CNode));
  prev = lst->head;
  do{
	next = np->next;// Storing next node for next iteration
	np->next = prev;// Linking current node to its previous node
	prev = np;// Calling current node as prev node for next iteration
	np = next;

  }while(next != lst->head);
  np->next = prev;
  lst->head = prev;
}
