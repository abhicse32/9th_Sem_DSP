#include "DList.h"
#include<stdlib.h>
#include<stdio.h>
#include<limits.h>

// Create a new node with next set to NULL
DNode* dnode_new( int data){
  DNode* new = (DNode*) malloc(sizeof(DNode));
  new->data = data;
  new->prev = NULL;
  new->next = NULL;
  return new;
}

// Create an empty list (head shall be NULL)
DList* dlist_new(){
  DList* new = (DList*) malloc(sizeof(DList));
  new->head = NULL;
  return new;
}

// Traverse the linked list and return its size
int dlist_size( DList* lst ){
  DNode* np = (DNode*) malloc(sizeof(DNode));
  np = lst->head;
  int count = 0;
  while(np != NULL){
	np = np->next;
	count++;
  }
  return count;
}

// Traverse the linked list and print each element
void dlist_print( DList* lst ){
  DNode* np = (DNode*) malloc(sizeof(DNode));
  np = lst->head;
  while(np != NULL){
	printf("%d ", np->data);
	np = np->next;
  }
  printf("\n");
  return;
}

//get the element at position @idx
int dlist_get( DList* lst, int idx ){
  if(idx < 0 || idx >= dlist_size(lst)){
	return -1;
  }
  DNode* np = (DNode*) malloc(sizeof(DNode));
  np = lst->head;
  int count = 0;
  for(; count < idx && np != NULL; count++){
	np = np->next;
  }
  return np->data;
}

// Add a new element at the beginning of the list
void dlist_prepend( DList* lst, int data ){
  //DNode* np = (DNode*) malloc(sizeof(DNode));
  DNode* temp = (DNode*) malloc(sizeof(DNode));
  //np = lst->head;
  temp = dnode_new(data);
  //temp->data = data;

  if(lst->head == NULL){
	temp->prev = temp->next = NULL;
	lst->head = temp;
	return;
  }
  temp->next = lst->head;
  lst->head->prev = temp;
  temp->prev = NULL;
  lst->head = temp;
}

// Add a new element at the end of the list
void dlist_append( DList* lst, int data ){
  DNode* np = (DNode*) malloc(sizeof(DNode));
  np = lst->head;
  DNode* temp = (DNode*) malloc(sizeof(DNode));
  temp = dnode_new(data);
  //temp->data = data;

  if(lst->head == NULL){
	temp->prev = temp->next = NULL;
	lst->head = temp;
	return;
  }
  while(np->next != NULL){
	np = np->next;
  }
  temp->next = NULL;
  np->next = temp;
  temp->prev = np;
}

// Add a new element at the @idx index
void dlist_insert( DList* lst, int idx, int data ){
  if(idx < 0 || idx > dlist_size(lst))
	return;
  if(idx == 0){
	dlist_prepend(lst, data);
	return;
  }
  if(idx == dlist_size(lst)){
	dlist_append(lst, data);
	return;
  }
  DNode* np = (DNode*) malloc(sizeof(DNode));
  np = lst->head;
  DNode* temp = (DNode*) malloc(sizeof(DNode));
  temp = dnode_new(data);
  //temp->data = data;
  //temp->prev = temp->next = NULL;
  int count = 0;
  for(; count < idx; count++){
	np = np->next;
  }
  // Change links of both the previous and the next element
  np->prev->next = temp;
  temp->prev = np->prev;
  np->prev = temp;
  temp->next = np;
}

// Remove an element from the end of the list
void dlist_remove_last( DList* lst ){
  DNode* np = (DNode*) malloc(sizeof(DNode));
  np = lst->head;
  if(lst->head->next == NULL){
	free(np);
	lst->head = NULL;
  }
  while(np->next != NULL){
	np = np->next;
  }
  np->prev->next = NULL;
  free(np);
}

// Remove an element from the beginning of the list
void dlist_remove_first( DList* lst ){
  DNode* np = (DNode*) malloc(sizeof(DNode));
  np = lst->head;
  if(lst->head->next == NULL){
	free(np);
	lst->head = NULL;
  }
  np->next->prev = NULL;
  lst->head = np->next;
  free(np);
}

// Remove an element from an arbitrary @idx position in the list
void dlist_remove( DList* lst, int idx ){
  if(idx < 0 || idx >= dlist_size(lst))
	return;
  if(idx == 0){
	dlist_remove_first(lst);
	return;
  }
  if(idx == dlist_size(lst) - 1){
	dlist_remove_last(lst);
	return;
  }
  DNode* np = (DNode*) malloc(sizeof(DNode));
  np = lst->head;
  int count = 0;
  for(; count < idx; count++){
	np = np->next;
  }
  np->prev->next = np->next;
  np->next->prev = np->prev;
  free(np);
}

void dlist_reverse(DList* lst){
  if(lst->head == NULL || lst->head->next == NULL)
	return;
  //DNode* np = (DNode*) malloc(sizeof(DNode));
  //if(lst->head->next->next == NULL){

  DNode* np = (DNode*) malloc(sizeof(DNode));
  DNode* prevp = (DNode*) malloc(sizeof(DNode));
  //DNode* nextp = (DNode*) malloc(sizeof(DNode));
  np = lst->head->next;
  lst->head->next = NULL;
  lst->head->prev = np;
  prevp = lst->head;// Contains the previous node
  while(np != NULL){
	// last node
	if(np->next == NULL){
	  np->next = np->prev;
	  np->prev = NULL;
	  lst->head = np;// Make this node as the head
	  break;
	}
	prevp = np->prev;
	np->prev = np->next;
	np->next = prevp;
	np = np->prev;// Since previous next is currently prev
  }
}
