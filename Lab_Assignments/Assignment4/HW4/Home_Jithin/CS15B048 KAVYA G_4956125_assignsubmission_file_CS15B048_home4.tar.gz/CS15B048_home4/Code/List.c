#include "List.h"
#include<stdlib.h>
#include<stdio.h>
#include<limits.h>

// Create a new node with next set to NULL
Node* node_new(int data1, int data2){
  Node *np = (Node*) malloc(sizeof(Node));
  np->col_ind = data1;
  np->val = data2;
  np->next = NULL;
  return np;
}

// Create an empty list (head shall be NULL)
LList* llist_new(){
  LList* list = (LList*) malloc(sizeof(LList));
  list->head = NULL;
  return list;
}

// Traverse the linked list and return its size
int llist_size( LList* lst ){
  Node *np = (Node*) malloc(sizeof(Node));
  np = lst->head;
  int count = 0;
  for(; np != NULL; np = np->next)
	count++;
  return count;
}

// Traverse the linked list and print each element
void llist_print( LList* lst ){
  if(llist_size(lst) == 0)
	return;
  Node *np = (Node*) malloc(sizeof(Node));
  np = lst->head;
  for(; np != NULL; np = np->next)
	printf("%d ", np->val);
  printf("\n");
}

//get the element at position @idx
Node* llist_get( LList* lst, int idx ){
  if(idx < 0 || idx > llist_size(lst))
	return NULL;
  Node *np = (Node*) malloc(sizeof(Node));
  np = lst->head;
  if(idx == 0)
	return np;
  int count = 0;
  for(; count < idx && np->next != NULL; count++){
	np = np->next;
  }
  return np;
}

// Add a new element at the end of the list
void llist_append( LList* lst, int data1, int data2 ){
  Node *np = (Node*) malloc(sizeof(Node));
  Node *temp = (Node*) malloc(sizeof(Node));
  np = lst->head;
  temp = node_new(data1, data2);
  if(np == NULL){
	temp->next = NULL;
	lst->head = temp;
	return;
  }
  else {
	while(np->next != NULL){
	  np = np->next;
	}
	np->next = temp;
	np = temp;
	np->next = NULL;
  }
}

// Add a new element at the beginning of the list
void llist_prepend( LList* lst, int data1, int data2 ){
  Node *np = (Node*) malloc(sizeof(Node));
  Node *temp = (Node*) malloc(sizeof(Node));
  np = lst->head;
  temp = node_new(data1, data2);

  if(np == NULL){
	np = temp;
	lst->head = temp;
	return;
  }
  temp->next = np;
  lst->head = temp;
}

// Add a new element at the @idx index
void llist_insert( LList* lst, int idx, int data1, int data2 ){
  if(idx < 0 || idx > llist_size(lst))
	return;
  Node *np = (Node*) malloc(sizeof(Node));
  Node *prev = (Node*) malloc(sizeof(Node));
  Node *temp = (Node*) malloc(sizeof(Node));
  np = lst->head;
  temp = node_new(data1, data2);

  if(idx == 0){
	// Special case of prepending
	llist_prepend(lst, data1, data2);
	return;
  }
  if(idx == llist_size(lst)){
	//Special case of appending
	llist_append(lst, data1, data2);
	return;
  }
  int count = 0;
  for(; count < idx && np->next != NULL; count++){
	prev = np;
	np = np->next;
  }

  prev->next = temp;
  temp->next = np;
}
