#include "SparseMatrix.h"
#include<stdlib.h>

/*Add two matrices*/
Matrix add(Matrix M1, Matrix M2){
  Matrix result;
  result.n_rows = M1.n_rows;
  result.row_lst = (LList**) malloc(result.n_rows*sizeof(LList*));
  Node* np1 = (Node*) malloc(sizeof(Node));
  Node* np2 = (Node*) malloc(sizeof(Node));
  int i;
  for(i = 0; i < M1.n_rows; i++){
	result.row_lst[i] = (LList*) malloc(sizeof(LList));
	result.row_lst[i] = llist_new();
	np1 = M1.row_lst[i]->head;
	np2 = M2.row_lst[i]->head;
	int col1, col2;
	while(np1 != NULL && np2 != NULL){
	  col1 = np1->col_ind;
	  col2 = np2->col_ind;
	  // If both belong to same column add corresponding values and increment both pointers
	  if(col1 == col2){
		llist_append(result.row_lst[i], col1, np1->val + np2->val);
		np1 = np1->next;
		np2 = np2->next;
	  }
	  // If first occurs before fill its value and increment it alone
	  else if(col1 < col2){
		llist_append(result.row_lst[i], col1, np1->val);
		np1 = np1->next;
	  }
	  // Likewise for the other
	  else if(col1 > col2){
		llist_append(result.row_lst[i], col2, np2->val);
		np2 = np2->next;
	  }
	}
	// Fill up the remaining elements if one ends before the other does
	while(np1 != NULL){
	  col1 = np1->col_ind;
	  llist_append(result.row_lst[i], col1, np1->val);
	  np1 = np1->next;
	}
	while(np2 != NULL){
	  col2 = np2->col_ind;
	  llist_append(result.row_lst[i], col2, np2->val);
	  np2 = np2->next;
	}
  }
  return result;
}

/* Subtract one matrix from another */
Matrix subtract(Matrix M1, Matrix M2){
  Matrix result;
  result.n_rows = M1.n_rows;
  result.row_lst = (LList**) malloc(result.n_rows*sizeof(LList*));
  Node* np1 = (Node*) malloc(sizeof(Node));
  Node* np2 = (Node*) malloc(sizeof(Node));
  int i;

  for(i = 0; i < M1.n_rows; i++){
	result.row_lst[i] = (LList*) malloc(sizeof(LList));
	np1 = M1.row_lst[i]->head;
	np2 = M2.row_lst[i]->head;
	int col1, col2;
	while(np1 != NULL && np2 != NULL){
	  col1 = np1->col_ind;
	  col2 = np2->col_ind;
	  // If first occurs before fill its value and increment it alone
	  if(col1 < col2){
		llist_append(result.row_lst[i], col1, np1->val);
		np1 = np1->next;
	  }
	  // Likewise for the other
	  else if(col1 > col2){
		llist_append(result.row_lst[i], col2, -1*np2->val);
		np2 = np2->next;
	  }
	  // If both belong to same column add corresponding values and increment both pointers
	  else{
		llist_append(result.row_lst[i], col1, np1->val - np2->val);
		np1 = np1->next;
		np2 = np2->next;
	  }
	}
	// Fill up the remaining elements if one ends before the other does
	while(np1 != NULL){
	  col1 = np1->col_ind;
	  llist_append(result.row_lst[i], col1, np1->val);
	  np1 = np1->next;
	}
	while(np2 != NULL){
	  col2 = np2->col_ind;
	  llist_append(result.row_lst[i], col2, -1*np2->val);
	  np2 = np2->next;
	}
  }
  return result;
}

/*Multiply an M x N matrix with N X 1 vector*/
Matrix matrix_vect_multiply(Matrix mat, Matrix vect){
  Matrix result;
  //result.row_lst = (LList**) malloc(sizeof(LList*));
  result.n_rows = mat.n_rows;
  result.row_lst = (LList**) malloc(result.n_rows*sizeof(LList*));

  Node* matnp = (Node*) malloc(sizeof(Node));
  int i;
  for(i = 0; i < mat.n_rows; i++){
	// Multiply each element in column number c by vect's element in row c
	result.row_lst[i] = (LList*) malloc(sizeof(LList));
	result.row_lst[i] = llist_new();
	matnp = mat.row_lst[i]->head;
	int sum = 0;

	while(matnp != NULL){
	  int colno = matnp->col_ind;// Column number of entry
	  // Default value is 0 in case there is no corresponding element in vect
	  int rowval = 0;
	  if(vect.n_rows && vect.row_lst[colno]->head != NULL)
		rowval = vect.row_lst[colno]->head->val;// Corresponding entry in vect
	  sum += matnp->val*rowval;
	  matnp = matnp->next;
	}

	llist_append(result.row_lst[i], 0, sum);
  }
  return result;
}
