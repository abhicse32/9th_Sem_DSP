#include "SparseMatrix.h"
#include "List.h"
#include<stdio.h>
#include<stdlib.h>

int main(){
  int choice;
  scanf("%d", &choice);
  // Addition of 2 matrices
  while(choice != -1){
	if(choice == 1 || choice == 2){
	  int rows, columns;
	  scanf("%d %d", &rows, &columns);
	  Matrix M1, M2, M3;
	  M1.n_rows = rows;
	  M2.n_rows = rows;
	  M1.row_lst = (LList**) malloc(M1.n_rows*sizeof(LList*));
	  M2.row_lst = (LList**) malloc(M1.n_rows*sizeof(LList*));
	  M3.row_lst = (LList**) malloc(sizeof(LList*));
	  int i = 0, j;

	  // Input for the first matrix
	  for(i = 0; i < rows; i++){

		M1.row_lst[i] = (LList*) malloc(sizeof(LList));
		M1.row_lst[i] = llist_new();
		
		for(j = 0; j < columns; j++){
		  int data;// It is the value to be stored at row = i and col = j
		  scanf("%d", &data);
		  if(data != 0) // Only these values need to be stored
			llist_append(M1.row_lst[i], j ,data);
		}
		//llist_print(M1.row_lst[i]);
	  }

	  // input for the second matrix
	  for(i = 0; i < rows; i++){

		M2.row_lst[i] = (LList*) malloc(sizeof(LList));
		M2.row_lst[i] = llist_new();
		
		for(j = 0; j < columns; j++){
		  int data;// It is the value to be stored at row = i and col = j
		  scanf("%d", &data);
		  if(data != 0) // Only these values need to be stored
			llist_append(M2.row_lst[i], j ,data);
		}
		//llist_print(M2.row_lst[i]);
	  }

	  if(choice == 1)
		M3 = add(M1, M2);
	  else
		M3 = subtract(M1, M2);
	  for(i = 0; i < M1.n_rows; i++)
		llist_print(M3.row_lst[i]);
	}
	if(choice == 3){
	  int rows, columns;
	  scanf("%d %d", &rows, &columns);
	  Matrix M1, M2, M3;
	  //M1.row_lst = (LList**) malloc(sizeof(LList*));
	  //M2.row_lst = (LList**) malloc(sizeof(LList*));
	  M1.n_rows = rows;
	  M2.n_rows = columns;
	  M1.row_lst = (LList**) malloc(M1.n_rows*sizeof(LList*));
	  M2.row_lst = (LList**) malloc(M2.n_rows*sizeof(LList*));
	  M3.row_lst = (LList**) malloc(sizeof(LList*));
	  int i = 0, j;

	  // Input for the matrix
	  for(i = 0; i < rows; i++){

		M1.row_lst[i] = (LList*) malloc(sizeof(LList));
		M1.row_lst[i] = llist_new();
		
		for(j = 0; j < columns; j++){
		  int data;// It is the value to be stored at row = i and col = j
		  scanf("%d", &data);
		  if(data != 0) // Only these values need to be stored
			llist_append(M1.row_lst[i], j ,data);
		}
		//llist_print(M1.row_lst[i]);
	  }

	  // input for the vector
	  for(i = 0; i < columns; i++){

		M2.row_lst[i] = (LList*) malloc(sizeof(LList));
		M2.row_lst[i] = llist_new();
		
		int data;// It is the value to be stored at row = i and col = 0 since it is a vector
		scanf("%d", &data);
		if(data != 0) // Only these values need to be stored
		  llist_append(M2.row_lst[i], 0 ,data);
	  }

	  M3 = matrix_vect_multiply(M1, M2);
	  for(i = 0; i < M1.n_rows; i++)
		llist_print(M3.row_lst[i]);
	}

	scanf("%d", &choice);
  }

  return 0;
}
