#include "CList.h"
#include <stdio.h>
#include <stdlib.h>
CNode* cnode_new( int data)										//Creates a new node with data as info and next pointing to itself
{
	CNode* new;
	new=(CNode*)malloc(sizeof(CNode));							//Dynamic allocation
	new->data=data;
	new->next=new;
	return new;
}

CList* clist_new()												//Declares a new list
{
	CList* lst;
	lst=(CList*)malloc(sizeof(CList));							//Dynamic allocation
	lst->head=NULL;
	return lst;
}

int clist_size( CList* lst )									//Finds the size of the list
{
	CNode* cur;
	cur=lst->head;
	int size=0;
	do
	{
		size++;
		cur=cur->next;
	}while(cur!=lst->head);
	return size;												//Returns the size
}

void clist_print( CList* lst )									//Prints the list		
{
	CNode* cur;
	cur=lst->head;
	if(cur==NULL) return;
	do
	{
		printf("%d ",cur->data);
		cur=cur->next;
	}while(cur!=lst->head);
	printf("\n");
}

int clist_get( CList* lst, int idx )							//Returns the element at index
{
	if(idx>=clist_size(lst)) return -1;							//Checking bound condition
	CNode* cur;
	cur=lst->head;
	int temp=0;
	while(temp<(idx))											//Traverse till temp is equal to index
	{
		temp++;
		cur=cur->next;
	}
	return cur->data;
}

void clist_append( CList* lst, int data )						//Adds a node to the end of list
{
	CNode* cur;
	cur=lst->head;
	CNode* new;
	new=cnode_new(data);
	if(cur==NULL) 												//If list is empty
	{
		lst->head=new;
		return;
	}
	while(cur->next!=lst->head) cur=cur->next;
	new->next=lst->head;										//Last node points to the first node
	cur->next=new;
}

void clist_prepend( CList* lst, int data )						//Inserts a node to the beginning of the list
{
	CNode* cur;
	cur=lst->head;
	CNode* new;
	new=cnode_new(data);
	if(cur==NULL) 												//If list is empty
	{
		lst->head=new;
		return;
	}
	while(cur->next!=lst->head) cur=cur->next;
	new->next=lst->head;
	cur->next=new;												//Last node points to the new node
	lst->head=new;												//Changing the list head
}

void clist_insert( CList* lst, int idx, int data )				//Inserts a node at index position
{
	CNode* cur;
	cur=lst->head;
	CNode* new;
	new=cnode_new(data);
	if(idx==0) 													//If element is to inserted in the beginning
	{
		clist_prepend(lst,data);
		return;
	}
	int size=clist_size(lst);
	if(idx==size)												//If element is to inserted in the last
	{
		clist_append(lst,data);
		return;
	}
	if(idx>size) return;										//Out of bound
	int temp=0;
	while(temp<idx-1)											//Traverse till temp is equal to index-1
	{
		cur=cur->next;
		temp++;
	}
	new->next=cur->next;
	cur->next=new;
}

void clist_remove_last( CList* lst )							//Removes the last element from the list
{
	CNode* cur;
	cur=lst->head;
	CNode* del;
	if(cur==NULL) return;										//If list is empty
	if(cur->next==lst->head) 
	{
		lst->head=NULL;
		free(cur);
		return;
	}
	while(cur->next->next!=lst->head) cur=cur->next;
	del=cur->next;
	cur->next=lst->head;										//As last node is removed second last node now becomes last
	free(del);
}


void clist_remove_first( CList* lst )							//Removes the first element of the list
{
	CNode* cur;
	cur=lst->head;
	CNode* del;
	if(cur==NULL) return;										//If list is empty
	if(cur->next==lst->head) 
	{
		lst->head=NULL;
		free(cur);
		return;
	}
	while(cur->next!=lst->head) cur=cur->next;
	del=lst->head;
	lst->head=(lst->head)->next;								//As first node is deleted second node now becomes first
	cur->next=lst->head;
	free(del);
}

void clist_remove( CList* lst, int idx) 						//Removes the element from index 
{
	CNode* cur;
	cur=lst->head;
	CNode* del;
	if(idx==0) 													//Removing first element
	{
		clist_remove_first(lst);
		return;
	}
	int size=clist_size(lst);
	if(idx==size-1)												//Removing last element
	{
		clist_remove_last(lst);
		return;
	}
	if(idx>=size) return;
	int temp=0;
	while(temp<idx-1)
	{
		cur=cur->next;
		temp++;
	}
	del=cur->next;
	cur->next=cur->next->next;
	free(del);													//Deleting the node
}

void clist_reverse(CList* lst)									//Reverses the list
{
	CNode* cur;
	cur=lst->head;
	CNode* last;
	last=lst->head;
	CNode* temp;
	temp=lst->head;												//First element of unchanged list will now be last of reversed list
	if(cur==NULL || cur->next==lst->head) return;
	while(cur->next!=lst->head) cur=cur->next;
	lst->head=cur;												//The last node is now the list head
	temp=temp->next;
	cur=temp;
	while(last->next!=lst->head)
	{
		temp=temp->next;										
		last->next=temp;										 
		cur->next=(lst->head)->next;							
		lst->head->next=cur;
		cur=temp;		
	}
}
