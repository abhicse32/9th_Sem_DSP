#include"DList.h"
#include <stdio.h>
#include <stdlib.h>
DNode* dnode_new( int value)									//Creating a node with prev and next as pointers
{
	DNode* new;
	new=(DNode*)malloc(sizeof(DNode));							//Dynamic allocation
	new->data=value;
	new->next=NULL;
	new->prev=NULL;
	return new;
}

DList* dlist_new()												//Declares a new list
{
	DList* cur;
	cur=(DList*)malloc(sizeof(DList));							//Dynamic allocation
    cur->head=NULL;
    return cur;
}

int dlist_size( DList* lst )									//Finds the size of the list
{
	DNode* cur;
	cur=lst->head;
	int size=0;
	while(cur!=NULL)
	{
		size++;
		cur=cur->next;
	}
	return size;												//Returns the size
}

void dlist_print( DList* lst )									//Prints the list
{
	DNode* cur;
	cur=lst->head;
	while(cur!=NULL)
	{
		printf("%d ",cur->data);
		cur=cur->next;
	}
	printf("\n");
}

int dlist_get( DList* lst, int idx )							//Returns the element at index
{
	if (idx>=dlist_size(lst)) return -1;						//Checking bound condition
	int temp=0;
	DNode* cur;
	cur=lst->head;
	while(temp!=idx)											//Traverse till temp is equal to index
	{
		temp++;
		cur=cur->next;
	}
	return cur->data;
}

void dlist_append( DList* lst, int data )						//Adds a node to the end of list
{
	DNode* new;
	new=dnode_new(data);
	DNode* cur;
	cur=lst->head;
	if(cur==NULL) lst->head=new;								//If list is empty
	else
	{
		while(cur->next!=NULL) cur=cur->next;
		cur->next=new;
		new->prev=cur;
	}
}

void dlist_prepend( DList* lst, int data )						//Inserts a node to the beginning of the list
{
	DNode* new;
	new=dnode_new(data);
	if(lst->head==NULL)											//If list is empty
	{
		lst->head=new;
		new->next=NULL;
	}
	else
	{
		new->next=lst->head;
		(lst->head)->prev=new;
		lst->head=new;											//List head changes to new which is the first node
	}
}

void dlist_insert( DList* lst, int idx, int data )				//Inserts a node at index position
{
	if(idx==0)													//If element is to inserted in the beginning
	{
		dlist_prepend(lst,data);
		return;
	}
	int size=dlist_size(lst);
	if(idx==size)												//If element is to inserted in the last
	{
		dlist_append(lst,data);
		return;
	}
	if(idx>size) return;										//Out of bound
	DNode* new;
	new=dnode_new(data);
	DNode* cur;
	cur=lst->head;
	int temp=0;
	while(temp<(idx-1))											//Traverse till temp is equal to index-1
	{
		cur=cur->next;
		temp++;
	}
	new->next=cur->next;
	cur->next=new;
	new->prev=cur;
	(new->next)->prev=new;
}

void dlist_remove_last( DList* lst )							//Removes the last element from the list
{
	if(lst->head==NULL) return;									//If list is empty
	DNode* cur;
	cur=lst->head;
	if(cur->next==NULL)
	{
		lst->head=NULL;
		free(cur);
		return;
	}
	while((cur->next)->next!=NULL) cur=cur->next;
	free(cur->next);
	cur->next=NULL;
}

void dlist_remove_first( DList* lst )							//Removes the first element of the list
{
	if(lst->head==NULL) return;									//If list is empty
	DNode* cur;
	cur=lst->head;
	if(cur->next==NULL)
	{
		lst->head=NULL;
		free(cur);
		return;
	}
	(cur->next)->prev=NULL;
	lst->head=(lst->head)->next;
}

void dlist_remove( DList* lst, int idx )						//Removes the element from index 
{
	if(lst->head==NULL) return;									//If list is empty
	if(idx==0)													//Removing first element
	{
		dlist_remove_first(lst);
		return;
	}
	int size=dlist_size(lst);
	if(idx==size-1)												//Removing last element
	{
		dlist_remove_last(lst);
		return;
	}
	if(idx>=size) return;										//Out of bound
	DNode* cur;
	DNode* del;
	cur=lst->head;
	int temp=0;
	while(temp<(idx-1))
	{
		cur=cur->next;
		temp++;
	}
	del=cur->next;
	cur->next=(cur->next)->next;
	(cur->next)->prev=cur;
	free(del);
}

void dlist_reverse(DList* lst)									//Reverses the list
{
	if(lst->head==NULL || (lst->head)->next==NULL) return;		//Do nothing if list is empty or it contains only 1 node
	DNode* temp;
	while(1)
	{
		temp=(lst->head)->next;									//Swapping list head's next
		(lst->head)->next=(lst->head)->prev;					//and 
		(lst->head)->prev=temp;									//list head's prev
		lst->head=temp;										
		if((lst->head)->next==NULL) break;						//Loop condition
	}
	temp=(lst->head)->next;										//These statements are not inside 
	(lst->head)->next=(lst->head)->prev;						//the loop because list head 
	(lst->head)->prev=temp;										//will change
}

