#include "List.h"
#include<stdio.h>
#include<stdlib.h>
Node* node_new( int data1, int data2)										//Creates a new node with data1 as column index and data2 as value 
{
	Node* new;
	new=(Node*)malloc(sizeof(Node));										//Dynamic allocation
	new->col_ind=data1;
	new->val=data2;
	new->next=NULL;
}

LList* llist_new()															//Declares a new list							
{
	LList* lst;
	lst=(LList*)malloc(sizeof(LList));										//Dynamic allocation
	lst->head=NULL;
	return lst;
}

int llist_size( LList* lst )												//Finds the size of the list
{
	Node* cur;
	cur=lst->head;
	int size=0;
	while(cur!=NULL)
	{
		cur=cur->next;
		size++;
	}
	return size;															//Returns the size
}

void llist_print( LList* lst)												//Prints the list
{
	Node* cur;
	cur=lst->head;
	while(cur!=NULL)
	{
		printf("%d ",cur->val);
		cur=cur->next;
	}
	printf("\n");
}

Node* llist_get( LList* lst, int idx )										//Returns the element at index							
{
	Node* node;
	node=(Node*)malloc(sizeof(Node));
	if (idx>=llist_size(lst)) return node;    
    Node* cur = lst->head;
    int temp=0;
    while (temp!=idx)														//Traverse till temp is equal to index
    {
        cur = cur->next;
        temp++;
    }
    return cur;
}

void llist_append( LList* lst, int col, int val)							//Adds a node to the end of list
{
	Node* cur;
	cur=lst->head;
	Node* new;
	new=node_new(col,val);
	if(cur == NULL)															//If list is empty
    {
        lst->head = new;
		return;
	}
	while(cur->next!=NULL) cur=cur->next;
	cur->next=new;
}

void llist_prepend( LList* lst, int col, int val)							//Inserts a node to the beginning of the list
{
	Node* new;
	new=node_new(col,val);
	if(lst->head == NULL)													//If list is empty
    {
        lst->head = new;
		return;
	}
	new->next=lst->head;
	lst->head=new;
}

void llist_insert( LList* lst, int idx, int col, int val)					//Inserts a node at index position
{
	if(idx == 0)															//If element is to inserted in the beginning
    {
        llist_prepend(lst,col,val);
        return;
    }
	int size=llist_size(lst);
    if(idx==size)															//If element is to inserted in the last
    {
    	llist_append(lst,col,val);
    	return;
    }
    if(idx > size) return;													//Out of bound
	int temp=0;
	Node* cur;
	cur=lst->head;
	Node* new;
	new=node_new(col,val);
	while(temp<idx-1)
	{
		cur=cur->next;
		temp++;
	}
	new->next=cur->next;
	cur->next=new;
}
