#include "SparseMatrix.h"
#include<stdio.h>
#include<stdlib.h>
Matrix add(Matrix A, Matrix B)
{
	Matrix C;
	int n=A.n_rows;
	C.row_lst=(LList**)malloc(n*sizeof(LList*));										//Dynamic memory allocation
	int i;
	for(i=0;i<n;i++)
	{
		C.row_lst[i]=llist_new();
		Node* temp1;
		temp1=(A.row_lst[i])->head;
		Node* temp2;
		temp2=(B.row_lst[i])->head;
		while(temp1!=NULL && temp2!=NULL)												//Exit if either of them become NULL
		{
			if(temp1->col_ind < temp2->col_ind)											//If their column indices don't match append accordingly
			{
				llist_append(C.row_lst[i],temp1->col_ind,temp1->val);
				temp1=temp1->next;
			}
			else if(temp1->col_ind > temp2->col_ind)									//If their column indices don't match append accordingly
			{
				llist_append(C.row_lst[i],temp2->col_ind,temp2->val);
				temp2=temp2->next;
			}
			else																		//Column indices are equal
			{
				llist_append(C.row_lst[i],temp1->col_ind,(temp1->val + temp2->val));	//Append the value of the sum
				temp1=temp1->next;
				temp2=temp2->next;
			}
		}
		while(temp1!=NULL)																//Appending remaing elemnts if any
		{
			llist_append(C.row_lst[i],temp1->col_ind,temp1->val);
			temp1=temp1->next;
		}
		while(temp2!=NULL)																//Appending remaing elemnts if any
		{
			llist_append(C.row_lst[i],temp2->col_ind,temp2->val);
			temp2=temp2->next;
		}
	}
	return C;
}

Matrix subtract(Matrix A, Matrix B)
{
	int i;
	for(i=0;i<B.n_rows;i++)
	{
		Node* temp;
		temp=B.row_lst[i]->head;
		while(temp!=NULL)
		{
			temp->val=(temp->val)*(-1);													//Changing Matrix B as -B
			temp=temp->next;
		}
	}
	return add(A,B);																	//A - B = A + (-B)
}

Matrix matrix_vect_multiply(Matrix A, Matrix vect)
{
	Matrix C;																			//Output Matrix
	int m=A.n_rows;
	C.row_lst=(LList**)malloc(m*sizeof(LList*));										//Dynamic memory allocation
	int i;
	int sum=0;
	int j;
	int n=vect.n_rows;
	Node* temp1;
	for(i=0;i<m;i++)
	{
		C.row_lst[i]=llist_new();
		temp1 = (A.row_lst[i])->head;
		while(temp1!=NULL)																//Till each row is traversed
		{
			if(vect.row_lst[temp1->col_ind]->head!=NULL)	
			{
				sum=sum+(temp1->val)*((vect.row_lst[temp1->col_ind]->head)->val);		//Calculating sum if value in Vector is not 0
			}
			temp1=temp1->next;
		}			
		llist_append(C.row_lst[i],0,sum);												//Appending the sum of product of each row
		sum=0;
	}
	return C;
}
