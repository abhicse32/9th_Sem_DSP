#include<stdio.h>
#include<stdlib.h>
#include"List.h"
#include"SparseMatrix.h"
int main()
{
	int choice;
	scanf("%d",&choice);													//Choices can be only 1 or 2 or 3 or -1
	while(choice!=-1)														//It will kepp looping till choice is entered as -1
	{
		Matrix Output;														//Result Matrix of each operation
		int row,col;
		int m,n;
		int i;
		scanf("%d %d",&m,&n);												//m:No. of rows , n:No.of columns
		Matrix A;
		A.n_rows=m;
		A.row_lst=(LList**)malloc(m*sizeof(LList*));						//Dynamic memory allocation
		int value;
		for(row=0;row<m;row++)
		{
			A.row_lst[row]=llist_new();
			for(col=0;col<n;col++)
			{
				scanf("%d",&value);
				if(value!=0) llist_append(A.row_lst[row],col,value);		//Append it if value is not 0
			}
		}
		if(choice==1 || choice==2)
		{
			Matrix B;
			B.row_lst=(LList**)malloc(m*sizeof(LList*));					//Dynamic Memory allocation
			B.n_rows=m;
			int value;
			for(row=0;row<m;row++)
			{
				B.row_lst[row]=llist_new();
				for(col=0;col<n;col++)
				{
					scanf("%d",&value);
					if(value!=0) llist_append(B.row_lst[row],col,value);	//Append it if value is not 0
				}
			}
			if(choice==1)
			{
				Output=add(A,B);											//Add returns Matrix C after addition
				for(i=0;i<m;i++) 
				{
					if(Output.row_lst[i]->head==NULL) continue;
					llist_print(Output.row_lst[i]);			//Printing each line of matrix
				}
			}
			else
			{
				Output=subtract(A,B);										//Subtract returns Matrix C after subtraction
				for(i=0;i<m;i++) 
				{
					if(Output.row_lst[i]->head==NULL) continue;
					llist_print(Output.row_lst[i]);			//Printing each line of matrix
				}
			}
		}
		else
		{
			Matrix vect;
			vect.row_lst=(LList**)malloc(n*sizeof(LList*));					//Dynamic Memory allocation
			vect.n_rows=n;			
			for(col=0;col<n;col++)
			{
				vect.row_lst[col]=llist_new();
				scanf("%d",&value);
				if(value!=0) llist_append(vect.row_lst[col],0,value);		//Append it if value is not 0
			}
			Output=matrix_vect_multiply(A,vect);							//matrix_vect_multiply returns Matrix C after multiplication
			for(i=0;i<m;i++) llist_print(Output.row_lst[i]);
		}
		scanf("%d",&choice);												//Reading choice after every operation
	}
}
