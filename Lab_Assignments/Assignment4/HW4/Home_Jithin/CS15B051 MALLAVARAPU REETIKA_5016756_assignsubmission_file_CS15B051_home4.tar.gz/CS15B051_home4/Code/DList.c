#include "DList.h"
#include<stdio.h>
#include<stdlib.h>

// Create a new node with next set to NULL
DNode* dnode_new( int data)
{
  DList* p;
  DNode *newnode;
  newnode= (DNode*)malloc(sizeof(DNode));
  if(newnode==NULL)
    printf("MALLOC ERROR");
  else
  {
  newnode -> data =data;
  newnode -> prev=NULL;
  newnode -> next =NULL;
// if(p->head==NULL)
//   {
//     p->head=newnode;
//   }
  }
   return (newnode);
}
// Create an empty list (head shall be NULL)
DList* dlist_new()
{
   DList* p;
   p= (DList*)malloc(sizeof(DList));
   p-> head =NULL;
   return p;
}

// Traverse the linked list and return its size
int dlist_size( DList* lst )
{
  DNode* p= lst -> head;
  int count=0;
  while(p!= NULL)
  {
     count++;
     p=p -> next;
  }
  return count;  
}

// Traverse the linked list and print each element
void dlist_print( DList* lst )
{
   DNode* p;
   p = lst->head;
   while(p != NULL)
   { 
      printf("%d ", p -> data);
      p=p->next;
fflush(stdout);
   }
   printf("\n");
   
}

//get the element at position @idx
int dlist_get( DList* lst, int idx )
{
   int i,e;
   DNode *temp;
   temp=lst -> head;
   if(idx==0)
   {
     return temp->data;
   }
   int n=dlist_size(lst );
   if(idx>=n)
   {
     return -1;
   }
   for(i=0;i<idx;i++)
   {
     temp=temp -> next;
   }
   
   e= temp -> data;
   return e; 
}

// Add a new element at the end of the list
void dlist_append( DList* lst, int data )
{
  DNode *newnode;
  DNode *prenode;
  newnode=dnode_new(data);
  if(lst->head==NULL)
  {
	lst->head = newnode;
        newnode->next=NULL;
        newnode->prev=NULL;
	return ;	
  }

   prenode=lst -> head;
   while(prenode -> next != NULL)
   {
      prenode = prenode -> next;
   }
   newnode -> prev=prenode;
   prenode -> next =newnode; 
}

// Add a new element at the beginning of the list
void dlist_prepend( DList* lst, int data )
{
  DNode *newnode;
  newnode=dnode_new(data);
  if(lst->head==NULL)
  {
     lst->head = newnode;
     newnode->next=NULL;
     newnode->prev=NULL;
      return ;
  }
  lst->head->prev=newnode;
  newnode->next=lst->head;
  lst->head=newnode;
  newnode->prev=NULL;
}

// Add a new element at the @idx index
void dlist_insert( DList* lst, int idx, int data )
{
  DNode *newnode, *prenode;
  int i;
  newnode=dnode_new(data);
  int n = dlist_size(lst );
  if(lst->head==NULL)
  {
	lst->head = newnode;
        newnode->next=NULL;
        newnode->prev=NULL;
	return ;	
  }
  if (idx==0)
  {
  dlist_prepend(lst,data);
  return;
  }
    if(idx>n)
   {
     return;
   }
  if (idx==n)
  {
  dlist_append(lst,data);
  return;
  }
  prenode=lst -> head;
  for(i=0;i<idx-1;i++)
  {
     prenode=prenode ->next;
  }
  prenode->next->prev=newnode;
  newnode -> next = prenode -> next;
  newnode-> prev=prenode;
  prenode -> next = newnode;
}

// Remove an element from the end of the list
void dlist_remove_last( DList* lst )
{
  DNode *temp, *prenode;
  if(lst -> head==NULL)
  return;
  temp=lst -> head;
  while (temp -> next != NULL)
  {
      prenode=temp;
      temp = temp -> next;
  }
   temp->prev=NULL;
   prenode -> next = NULL;
   free(temp);
}

// Remove an element from the beginning of the list
void dlist_remove_first( DList* lst )
{
  DNode *temp;
  if(lst -> head== NULL)
   return;
  temp=lst -> head;
  temp->next->prev=NULL;
  lst -> head=temp->next;
  free(temp);
}

// Remove an element from an arbitrary @idx position in the list
void dlist_remove( DList* lst, int idx )
{
  int i;
   if(lst->head==NULL)
	return ;
   DNode *temp, *prenode;
   if(idx==0)
   {
     dlist_remove_first(lst);
     return;
   }
   prenode=lst -> head;
   for(i=0;i<idx-1;i++)
   {
      prenode=prenode ->next;
   }
   temp=prenode -> next;
   prenode -> next = temp -> next;
   temp->next->prev=prenode;
   temp -> next = NULL;
   free(temp);
}

void dlist_reverse(DList* lst)
{
   if(lst->head==NULL||lst->head->next==NULL)
   {
     return;
   }
   DNode *p=lst->head;
   DNode *temp=NULL;
   while(p!=NULL)
   {
     temp=p->prev;
     p->prev=p->next;
     p->next=temp;
     p=p->prev;
   }
   if(temp!=NULL)
   p=temp->prev;
   lst->head=p;
   
}     
 
