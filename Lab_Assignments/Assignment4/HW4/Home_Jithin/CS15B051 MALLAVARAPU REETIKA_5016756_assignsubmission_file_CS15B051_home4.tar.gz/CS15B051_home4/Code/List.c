#include "List.h"
#include<stdio.h>
#include<stdlib.h>

// Create a new node with next set to NULL
Node* node_new( int data)
{
   Node *newnode;
  newnode= ( Node*)malloc(sizeof( Node));
  if(newnode==NULL)
    printf("MALLOC ERROR");
  else
  {
  newnode -> data =data;
  newnode -> next =NULL;
  }
   return (newnode);
}

// Create an empty list (head shall be NULL)
LList* llist_new()
{
   LList* p;
   p= (LList*)malloc(sizeof(LList));
   p-> head =NULL;
   return p;
}

// Traverse the linked list and return its size
int llist_size( LList* lst )
{
  Node* p= lst -> head;
  int count=0;
  while(p!= NULL)
  {
     count++;
     p=p -> next;
  }
  return count;
}

// Traverse the linked list and print each element
void llist_print( LList* lst )
{
 Node* p;
 p = lst->head;
 while(p != NULL)
 {
    printf("%d ", p -> data);
	p=p->next;
 }
printf("\n");
fflush(stdout);
}

//get the element at position @idx
int llist_get( LList* lst, int idx )
{
   int i,e;
   Node *temp;
   temp=lst -> head;
   for(i=0;i<idx;i++)
   {
     temp=temp -> next;
   }
   e= temp -> data;
   return e;
}

// Add a new element at the end of the list
void llist_append( LList* lst, int data )
{
   Node *newnode,*prenode;
   newnode=node_new(data);

	if(lst->head==NULL){
	lst->head = newnode;
	return ;	
	}

   prenode=lst -> head;
   while(prenode -> next != NULL)
   {
      prenode = prenode -> next;
   }
   prenode -> next =newnode;
  
}
// Add a new element at the beginning of the list
void llist_prepend( LList* lst, int data )
{
  Node *newnode = node_new(data);
  
  newnode -> next =lst->head;
lst->head = newnode;
}

// Add a new element at the @idx index
void llist_insert( LList* lst, int idx, int data )
{
  Node *newnode, *prenode;
  int i;
  newnode= node_new(data);

	if(lst->head==NULL){
	lst->head = newnode;
	return ;	
	}
  if (idx==0)
  {
  llist_prepend(lst,data);
  return;
  }
  int n=llist_size( lst );
  if(idx>=n)
  return;
  prenode=lst -> head;
  for(i=0;i<idx-1;i++)
  {
     prenode=prenode ->next;
  }
  newnode -> next = prenode -> next;
  prenode -> next = newnode;
}

// Remove an element from the end of the list
void llist_remove_last( LList* lst )
{
  Node *temp, *prenode;
  if(lst -> head==NULL)
  return;
  temp=lst -> head;
  while (temp -> next != NULL)
  {
      prenode=temp;
      temp = temp -> next;
  }
   prenode -> next = NULL;
   //free(temp);
}

// Remove an element from the beginning of the list
void llist_remove_first( LList* lst )
{
  Node *temp;
  if(lst -> head== NULL)
   return;

  temp=lst -> head;
  lst -> head=lst->head->next;
  //free(temp);
}

// Remove an element from an arbitrary @idx position in the list
void llist_remove( LList* lst, int idx )
{
   int i;
   if(lst->head==NULL)
	return ;
   Node *temp, *prenode;
   if(idx==0)
   {
     llist_remove_first(lst);
     return;
   }
   prenode=lst -> head;
   for(i=0;i<idx-1;i++)
   {
      prenode=prenode ->next;
   }
   temp=prenode -> next;
   prenode -> next = temp -> next;
   temp -> next = NULL;
   free(temp);
}
 
