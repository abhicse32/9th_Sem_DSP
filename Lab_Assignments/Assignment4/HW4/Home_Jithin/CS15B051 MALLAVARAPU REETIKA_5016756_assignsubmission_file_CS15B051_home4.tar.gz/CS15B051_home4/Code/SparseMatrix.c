#include "SparseMatrix.h"
#include<stdio.h>
#include<stdlib.h>
#include "List.h"



Matrix matrix_vect_multiply(Matrix mat, Matrix vect)
{				
   Matrix* result = (Matrix*)malloc(sizeof(Matrix));			
   result->row_lst = (LList**)malloc(sizeof(LList*)*(mat.n_rows));
   int i,j,k=0;
   while(k<matrix1.n_rows)
   {
       *(result->row_lst + i) = (LList*)malloc(sizeof(LList));
        (*(result->row_lst + i))->head = NULL;
   }				
   for(i = 0; i < mat.n_rows; i++)
   {
	int sum = 0;
	int a = 0;	
	if((*(mat.row_lst + i))->head == NULL) 
            continue;		
	for(j = 0; j < vect.n_rows; j++)
         {	
             Node* n=llist_get(*(mat.row_lst + i),a);
             Node* m =llist_get(*(vect.row_lst + j),0);
		if(n != NULL){	
			if(j == (n)->col_ind)
                        {	
			    if((*(vect.row_lst + j))->head != NULL)		
			    sum = sum + ((n->val) * (m->val));
			      a++;	
			}
					
	         }          	
         }
		
		llist_append(*(result->row_lst + i),0,sum);	
	}
	
	return *(result);
	
}
Matrix add(Matrix matrix1, Matrix matrix2, int n)
{				
	int i,j,k=0;
	Matrix* result = (Matrix*)malloc(sizeof(Matrix));		
	result->row_lst = (LList**)malloc(sizeof(LList*)*(matrix1.n_rows));
				
	while(k<matrix1.n_rows)
        {
            *(result->row_lst + i) = (LList*)malloc(sizeof(LList));
	    (*(result->row_lst + i))->head = NULL;
        }			

	for(i = 0; i < matrix1.n_rows; i++)
        {				
	     int a = 0,b=0;
	     for(j = 0; j < n; j++)
             {
		int m=llist_size(*(matrix1.row_lst + i));
                 int n=llist_size(*(matrix2.row_lst + i)));
                  if((a <m&&b<n){
                    Node* p=llist_get(*(matrix1.row_lst + i),a);
                    Node*q =llist_get(*(matrix2.row_lst + i),b);
		if((j == (p)->col_ind)&&((p))->col_ind == (q)->col_ind)){
		llist_append(*(result->row_lst + i),j,p->val +q->val);
						a++; b++;
						continue ;
					}
				}
				
			}	
                if(a<m){			
				if(j == (p->col_ind){
						llist_append(*(result->row_lst + i),j,p->val);
						a++;
						continue ;
					}
				}
                   
			
				if(b < llist_size(*(matrix2.row_lst + i))){
					if(j == q->col_ind){
						llist_append(*(result->row_lst + i),j,q->val);
						b++;
					}
				}	
		
		}	
	
	}

	return *(result);
}

Matrix subtract(Matrix matrix1, Matrix matrix2, int n){		
int i,j,k=0;
	Matrix* result = (Matrix*)malloc(sizeof(Matrix));		
	result->row_lst = (LList**)malloc(sizeof(LList*)*(matrix1.n_rows));
				
	while(k<matrix1.n_rows)
        {
            *(result->row_lst + i) = (LList*)malloc(sizeof(LList));
	    (*(result->row_lst + i))->head = NULL;
        }			

	for(i = 0; i < matrix1.n_rows; i++)
        {				
	     int a = 0,b=0;
	     for(j = 0; j < n; j++)
             {
		int m=llist_size(*(matrix1.row_lst + i));
                 int n=llist_size(*(matrix2.row_lst + i)));
                  if((a <m&&b<n){
                    Node* p=llist_get(*(matrix1.row_lst + i),a);
                    Node*q =llist_get(*(matrix2.row_lst + i),b);
		if((j == (p)->col_ind)&&((p))->col_ind == (q)->col_ind)){
		llist_append(*(result->row_lst + i),j,p->val - q->val);
						a++; b++;
						continue ;
					}
				}
				
			}	
                if(a<m){			
				if(j == (p->col_ind){
						llist_append(*(result->row_lst + i),j,p->val);
						a++;
						continue ;
					}
				}
                   
			
				if(b < llist_size(*(matrix2.row_lst + i))){
					if(j == q->col_ind){
						llist_append(*(result->row_lst + i),j,-q->val);
						b++;
					}
				}	
		
		}	
	
	}

	return *(result);
}


