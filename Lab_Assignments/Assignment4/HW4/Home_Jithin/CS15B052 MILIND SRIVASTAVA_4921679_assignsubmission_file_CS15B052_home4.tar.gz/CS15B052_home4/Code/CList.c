// Home Assignment 4 Question 2
// Implements a circular singly linked list
// Author : Milind Srivastava
// Date : 3 Sep 2016

#include "CList.h"
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

CNode* cnode_new(int data)
{
	CNode* temp = (CNode*)malloc(sizeof(CNode)); // dyanmic allocation of new cnode
	temp->data = data;
	temp->next = temp;
	return;
}

CList* clist_new()
{
	CList* temp = (CList*)malloc(sizeof(CList)); // dynamic allocation of list
	temp->head = NULL;
	return temp;
}

int clist_size(CList* lst)
{
	CNode* temp = lst->head;
	if (temp == NULL)
	{
		return 0;
	}
	temp = temp->next;
	int size = 1;
	while(temp != lst->head) // traversing till the end of clist i.e. when we reach lst->head again
	{
		size++;
		temp = temp->next;
	}
	return size;
}

void clist_print(CList* lst)
{
	CNode* temp = lst->head;
	if(temp == NULL)
	{
		printf("\n");
		return;
	}
	printf("%d ", temp->data);
	temp = temp->next;
	while(temp != lst->head) // traversing and printing clist
	{
		printf("%d ", temp->data);
		temp = temp->next;
	}
	printf("\n");
}

int clist_get(CList* lst, int idx)
{
	if(idx < 0 || idx >= clist_size(lst) || lst == NULL) // bound checking
	{
		return -1;
	}
	idx = idx%(clist_size(lst));
	CNode* temp = lst->head;
	int i = 0;
	while(i != idx) // traversing till we reach node with index = idx
	{
		temp = temp->next;
		i++;
	}
	return temp->data;
}

void clist_append(CList* lst, int data)
{
	CNode* newNode = cnode_new(data);
	CNode* temp = lst->head;
	if(temp == NULL) // if list is empty, modify lst->head
	{
		lst->head = newNode;
		newNode->next = newNode;
		return;
	}
	while(temp->next != lst->head) // find last node
	{
		temp = temp->next;
	}
	temp->next = newNode; // append
	newNode->next = lst->head;
}

void clist_prepend(CList* lst, int data)
{
	CNode* newNode = cnode_new(data);
	CNode* temp = lst->head;
	if(temp == NULL)
	{
		clist_append(lst, data);
		return;
	}
	while(temp->next != lst->head) // finding last node
	{
		temp = temp->next;
	}
	temp->next = newNode;
	newNode->next = lst->head;
	lst->head = newNode;
}

void clist_insert(CList* lst, int idx, int data)
{
	CNode* newNode = cnode_new(data);
	CNode* temp = lst->head;
	if(idx == 0) // idx = 0, means prepend
	{
		clist_prepend(lst, data);
		return;
	}
	if(idx > clist_size(lst)) // invalid idx
	{
		return;
	}
	if(idx == clist_size(lst)) // idx = size, means append
	{
		clist_append(lst, data);
		return;
	}
	int i=1;
	while(i != idx)
	{
		temp = temp->next;
		i++;
	}
	newNode->next = temp->next;
	temp->next = newNode;
}

void clist_remove_last(CList* lst)
{
	CNode* temp = lst->head;
	if(temp == NULL)
	{
		return;
	}
	if(temp->next == lst->head)
	{
		free(temp);
		return;
	}
	while(temp->next->next != lst->head)
	{
		temp = temp->next;
	}
	CNode* toDelete = temp->next;
	temp->next = lst->head;
	free(toDelete); // deallocate memory
}

void clist_remove_first(CList* lst)
{
	CNode* temp = lst->head;
	if(temp == NULL)
	{
		return;
	}
	if(temp->next == lst->head)
	{
		free(temp);
		lst->head = NULL;
		return;
	}
	CNode* newHead = lst->head->next;
	while(temp->next->next != lst->head)
	{
		temp = temp->next;
	}
	temp->next->next = newHead;
	CNode* toDelete = lst->head;
	lst->head = newHead;
	free(toDelete); // deallocate memory
}

void clist_remove(CList* lst, int idx)
{
	// special conditions

	if(idx == 0)
	{
		clist_remove_first(lst);
		return;
	}
	if(idx == (clist_size(lst)-1))
	{
		clist_remove_last(lst);
		return;
	}
	if(idx >= clist_size(lst))
	{
		return;
	}
	int i=1;
	CNode* temp = lst->head;
	while(i != idx)
	{
		i++;
		temp = temp->next;
	}
	CNode* toDelete = temp->next;
	temp->next = temp->next->next;
	free(toDelete); // deallocate memory
}

void clist_reverse(CList* lst)
{
	if(lst->head == NULL) // empty list
	{
		return;
	}
	lst->head = reverse(lst, lst->head);
}

CNode* reverse(CList* lst, CNode* head) // recursive reverse routine
{
	CNode* temp = head;
	if(temp->next == lst->head)
	{
		return temp;
	}
	CNode* revHead = reverse(lst, temp->next);
	temp->next->next = temp;
	temp->next = revHead;
	return revHead;
}