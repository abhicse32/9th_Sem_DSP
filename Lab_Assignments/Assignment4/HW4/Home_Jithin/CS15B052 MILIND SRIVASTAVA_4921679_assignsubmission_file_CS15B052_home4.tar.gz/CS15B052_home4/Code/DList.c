// Home Assignment 4 Question 3
// Implements a doubly linked list
// Author : Milind Srivastava
// Date : 3 Sep 2016

#include "DList.h"
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

DNode* dnode_new(int data)
{
	DNode* temp = (DNode*)malloc(sizeof(DNode)); // dynamic allocation of dnode
	temp->next = NULL;
	temp->prev = NULL;
	temp->data = data;
	return temp;
}

DList* dlist_new()
{
	DList* temp = (DList*)malloc(sizeof(DList)); // dynamic allocation of dlist
	temp->head = NULL;
	return temp;
}

int dlist_size(DList* lst)
{
	DNode* temp = lst->head;
	int count = 0;
	while(temp != NULL) // traversing till end of list
	{
		count++;
		temp = temp->next;
	}
	return count;
}

void dlist_print(DList* lst)
{
	DNode* temp = lst->head;
	while(temp != NULL) // traversing and printing till end of list
	{
		printf("%d ", temp->data);
		temp = temp->next;
	}
	printf("\n");
}

int dlist_get(DList* lst, int idx)
{
	if(idx < 0 || idx >= dlist_size(lst) || lst == NULL) // special cases
	{
		return -1;
	}

	int i = 0;
	DNode* temp = lst->head;
	while(i != idx)
	{
		temp = temp->next;
		i++;
	}
	return temp->data;
}

void dlist_append(DList* lst, int data)
{
	DNode* newNode = dnode_new(data);
	DNode* temp = lst->head;
	if(temp == NULL) // empty list
	{
		lst->head = newNode;
		lst->head->next = NULL;
		lst->head->prev = NULL;
		return;
	}
	while(temp->next != NULL)
	{
		temp = temp->next;
	}
	if(temp == lst->head)
	{
		lst->head->next = newNode;
	}
	temp->next = newNode;
	newNode->prev = temp;
	newNode->next = NULL;
}

void dlist_prepend(DList* lst, int data)
{
	DNode* newNode = dnode_new(data);
	if(lst->head != NULL)
	{
		newNode->next = lst->head;
		lst->head->prev = newNode;
		lst->head = newNode;
	}
	else // empty list
	{
		lst->head = newNode;
	}
}

void dlist_insert(DList* lst, int idx, int data)
{
	//special cases

	if(idx == 0)
	{
		dlist_prepend(lst, data);
		return;
	}
	if(idx > dlist_size(lst))
	{
		return;
	}
	if(idx == dlist_size(lst))
	{
		dlist_append(lst, data);
		return;
	}
	int i=1;
	DNode* newNode = dnode_new(data);
	DNode* temp = lst->head;
	while(i != idx)
	{
		i++;
		temp = temp->next;
	}
	newNode->next = temp->next;
	temp->next = newNode;
	newNode->prev = temp;
	newNode->next->prev = newNode;
}

void dlist_remove_last(DList* lst)
{
	DNode* temp = lst->head;
	if(temp == NULL) // can't remove from empty list
	{
		return;
	}
	if(temp->next == NULL)
	{
		free(temp);
		lst->head = NULL;
		return;
	}
	while(temp->next->next != NULL)
	{
		temp = temp->next;
	}
	free(temp->next);
	temp->next = NULL;
}

void dlist_remove_first(DList* lst)
{
	DNode* temp = lst->head;
	if(temp == NULL) // can't remove from empty list
	{
		return;
	}
	if(temp->next != NULL)
	{
		lst->head = lst->head->next;
		lst->head->prev = NULL;
	}
	else
	{
		lst->head = NULL;
	}
	free(temp);
}

void dlist_remove(DList* lst, int idx)
{
	if(idx >= dlist_size(lst))
	{
		return;
	}
	if(idx == 0)
	{
		dlist_remove_first(lst);
		return;
	}
	int i = 1;
	DNode* temp = lst->head;
	while(i != idx)
	{
		i++;
		temp = temp->next;
	}
	DNode* toDelete = temp->next;
	temp->next = temp->next->next;
	temp->next->prev = temp;
	free(toDelete);
}

void dlist_reverse(DList* lst) // iterative reverse : switching next and prev of every node and incrementing lst->head
{
	DNode* current = lst->head;
	DNode* temp;
	while(current != NULL)
	{
		lst->head = current;
		temp = current->next;
		current->next = current->prev;
		current->prev = temp;
		current = temp;
	}
}