// Home Assignment 4 Question 1
// Implements a singly linked list
// Author : Milind Srivastava
// Date : 3 Sep 2016

#include "List.h"
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

Node* node_new(int data1, int data2)
{
	Node* temp = (Node*)malloc(sizeof(Node)); // dynamic allocation of ndde
	temp->col_ind = data1;
	temp->val = data2;
	temp->next = NULL;
	return temp;
}

LList* llist_new()
{
	LList* temp = (LList*)malloc(sizeof(LList)); // dynamic allocation of list
	temp->head = NULL;
	return temp;
}

int llist_size(LList* lst)
{
	Node* temp = lst->head;
	int count = 0;
	while(temp != NULL) // traversing list
	{
		temp = temp->next;
		count++;
	}
	return count;
}

void llist_print(LList* lst)
{
	Node* temp = lst->head;
	while(temp != NULL) // traversing and printing list
	{
		printf("%d %d ", temp->col_ind, temp->val);
		temp = temp->next;
	}
	printf("\n");
}

Node* llist_get(LList* lst, int idx)
{
	if(idx < 0 || idx >= llist_size(lst) || lst == NULL) // invalid index
	{
		return NULL;
	}

	int i = 0;

	Node* temp = lst->head;
	while(i!=idx)
	{
		temp = temp->next;
		i++;
	}
	return temp;
}

void llist_append(LList* lst, int data1, int data2)
{
	Node* newNode = node_new(data1, data2);
	Node* temp = lst->head;

	if(temp == NULL) // apending to empty list
	{
		lst->head = newNode;
		lst->head->next = NULL;
		return;
	}

	while(temp->next != NULL)
	{
		temp=temp->next;
	}
	temp->next = newNode;
}

void llist_prepend(LList* lst, int data1, int data2)
{
	Node* newNode = node_new(data1, data2);
	newNode->next = lst->head;
	lst->head = newNode;
}

void llist_insert(LList* lst, int idx, int data1, int data2)
{
	// special cases

	if(idx == 0)
	{
		llist_prepend(lst, data1, data2);
		return;
	}
	if(idx > llist_size(lst))
	{
		return;
	}
	int i=1;
	Node* temp = lst->head;
	Node* newNode = node_new(data1, data2);
	while(i != idx)
	{
		i++;
		temp = temp->next;
	}
	newNode->next = temp->next;
	temp->next = newNode;
}