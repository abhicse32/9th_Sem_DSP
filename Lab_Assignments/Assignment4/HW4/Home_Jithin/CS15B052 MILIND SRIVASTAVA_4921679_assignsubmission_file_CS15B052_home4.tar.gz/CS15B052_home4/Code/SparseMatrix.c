// Home Assignment 4 Question 1
// Implements a sparse matrix using 1 linked list for each row
// Author : Milind Srivastava
// Date : 3 Sep 2016

#include "SparseMatrix.h"
#include <stdio.h>
#include <stdlib.h>

/*Multiply an M x N matrix with N X 1 vector*/
Matrix matrix_vect_multiply(Matrix mat, Matrix vect)
{
	int m,n;
	scanf("%d", &m);
	scanf("%d", &n);

	// allocate memory

	allocate(&mat, m);
	allocate(&vect, n);

	// take input

	matrixInput(&mat, m, n);
	vectorInput(&vect, n);

	Matrix c;
	allocate(&c, m); // allocate memory

	int i;

	// nodes for traversing through matrix and vector

	Node* matTraversal;
	Node* vectTraversal;

	for (i = 0; i < m; i++)
	{
		int vectIndex = 0;
		int tempSum = 0;

		matTraversal = mat.row_lst[i]->head;		
 
		while((vectIndex < n) && (matTraversal != NULL))
		{
			vectTraversal = vect.row_lst[vectIndex]->head;

			if(vectTraversal == NULL) // if particular row linked list is NULL i.e. input to that row of the vector was 0
			{
				if(matTraversal->col_ind == vectIndex) // tempSum += 0, incrementing matTraversal
				{
					matTraversal = matTraversal->next;
				}
				vectIndex++;
				continue;
			}

			if(matTraversal->col_ind == vectIndex) // if col_ind of matrixNode and vectIndex match, then we multiply them and add the sum to tempSum
			{
				tempSum += ((matTraversal->val)*(vectTraversal->val));
				matTraversal = matTraversal->next;
			}
			vectIndex++;			
		}

		llist_append(c.row_lst[i], 0, tempSum); // appending tempSum to final matrix
	}

	print(&c, m, 1); // printing matrix

	return c;

}

/*Add two matrices*/
Matrix add(Matrix a, Matrix b)
{
	int m,n;
	scanf("%d", &m);
	scanf("%d", &n);

	// allocating memory

	allocate(&a, m);
	allocate(&b, m);

	// taking input

	matrixInput(&a, m, n);
	matrixInput(&b, m, n);

	Matrix c;
	allocate(&c, m); // allocating memory

	int i;

	// nodes for traversing through "a" and "b" matrices

	Node* aTraversal;
	Node* bTraversal; 

	for (i = 0; i < m; i++)
	{
		aTraversal = a.row_lst[i]->head;
		bTraversal = b.row_lst[i]->head;

		while(aTraversal != NULL && bTraversal != NULL)
		{
			if(aTraversal->col_ind == bTraversal->col_ind) // if same col_ind, add values and append to "c"; increment both pointers
			{
				llist_append(c.row_lst[i], aTraversal->col_ind, aTraversal->val + bTraversal->val);
				aTraversal = aTraversal->next;
				bTraversal = bTraversal->next;
			}
			else if(aTraversal->col_ind < bTraversal->col_ind) // append value of "a" ndoe and increment pointer
			{
				llist_append(c.row_lst[i], aTraversal->col_ind, aTraversal->val);
				aTraversal = aTraversal->next;
			}
			else // append value of "b" ndoe and increment pointer
			{
				llist_append(c.row_lst[i], bTraversal->col_ind, bTraversal->val);
				bTraversal = bTraversal->next;
			}
		}
		if(aTraversal != NULL)
		{
			while(aTraversal != NULL)
			{
				llist_append(c.row_lst[i], aTraversal->col_ind, aTraversal->val);
				aTraversal = aTraversal->next;
			}
		}
		else
		{
			if(bTraversal != NULL)
			{
				while(bTraversal != NULL)
				{
					llist_append(c.row_lst[i], bTraversal->col_ind, bTraversal->val);
					bTraversal = bTraversal->next;
				}
			}
		}
	}
	
	print(&c, m, n); // print

	return c;
}

/*Subtract Matrix b from a*/
Matrix subtract(Matrix a, Matrix b)
{
	int m,n;
	scanf("%d", &m);
	scanf("%d", &n);

	// allocate memory

	allocate(&a, m);
	allocate(&b, m);

	// taking input

	matrixInput(&a, m, n);
	matrixInput(&b, m, n);

	Matrix c;
	allocate(&c, m); // allocate memory

	int i;

	// nodes for traversing through "a" and "b" matrices

	Node* aTraversal;
	Node* bTraversal; 

	for (i = 0; i < m; i++)
	{
		aTraversal = a.row_lst[i]->head;
		bTraversal = b.row_lst[i]->head;

		// same logic as "add" except we consider negative of the "b" node values

		while(aTraversal != NULL && bTraversal != NULL)
		{
			if(aTraversal->col_ind == bTraversal->col_ind)
			{
				llist_append(c.row_lst[i], aTraversal->col_ind, aTraversal->val - bTraversal->val);
				aTraversal = aTraversal->next;
				bTraversal = bTraversal->next;
			}
			else if(aTraversal->col_ind < bTraversal->col_ind)
			{
				llist_append(c.row_lst[i], aTraversal->col_ind, aTraversal->val);
				aTraversal = aTraversal->next;
			}
			else
			{
				llist_append(c.row_lst[i], bTraversal->col_ind, bTraversal->val*(-1));
				bTraversal = bTraversal->next;
			}
		}
		if(aTraversal != NULL)
		{
			while(aTraversal != NULL)
			{
				llist_append(c.row_lst[i], aTraversal->col_ind, aTraversal->val);
				aTraversal = aTraversal->next;
			}
		}
		else
		{
			if(bTraversal != NULL)
			{
				while(bTraversal != NULL)
				{
					llist_append(c.row_lst[i], bTraversal->col_ind, bTraversal->val*(-1));
					bTraversal = bTraversal->next;	
				}
			}
		}

	}

	print(&c, m, n); // print

	return c;
}

void allocate(Matrix* temp, int m) // allocate memory for all the linked lists
{
	temp->n_rows = m;
	temp->row_lst = (LList**)malloc(m*sizeof(LList*));
	int i;
	for(i = 0; i < m; i++)
	{
		temp->row_lst[i] = llist_new();
	}
}

void matrixInput(Matrix* input, int m, int n) // taking input from user for matrix
{
	int i,j;
	int temp;
	for (i = 0; i < m; i++)
	{
		for (j = 0; j < n; j++)
		{
			scanf("%d", &temp);
			if(temp != 0)
			{
				llist_append(input->row_lst[i], j, temp);
			}
		}
	}
}

void vectorInput(Matrix* input, int n) // taking input from user for vector
{
	int i;
	int temp;
	for(i = 0; i < n; i++)
	{
		scanf("%d", &temp);
		if(temp != 0)
		{
			llist_append(input->row_lst[i], 0, temp);
		}
	}
}

void print(Matrix* a, int m, int n) // printing matrix
{
	int i;
	for(i = 0; i < m; i++)
	{
		Node* aTraversal = a->row_lst[i]->head;
		int newLine = 1;
		if(aTraversal == NULL)
		{
			newLine = 0;
		}
		while(aTraversal != NULL)
		{
			printf("%d ", aTraversal->val);
			aTraversal = aTraversal->next;
		}
		if(newLine)
		{
			printf("\n");
		}
	}

}

// helper functions

void addHelper()
{
	Matrix a,b;

	Matrix c = add(a, b);
}

void subtractHelper()
{
	Matrix a,b;

	Matrix c = subtract(a, b);	
}

void multiplyHelper()
{
	Matrix a,b;

	Matrix c = matrix_vect_multiply(a,b);
}