 // Home Assignment 4 Question 1
// Implements main function for calling SparseMatrix functions
// Author : Milind Srivastava
// Date : 3 Sep 2016

#include "SparseMatrix.h"
#include <stdio.h>
#include <stdlib.h>

int main()
{
	int choice = -1;
	do{
		scanf("%d", &choice);
		switch(choice)
		{
			case 1:addHelper();
			break;

			case 2:subtractHelper();
			break;

			case 3:multiplyHelper();
			break;

			default:choice = -1;
			break;
		}
	}while(choice!=-1);
	//printf("\n");
	return 0;
}