#include "CList.h"

#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

CList* clist_new()
{
	CList *newhead;
	newhead=(CList *)malloc(sizeof(CList));
	newhead->head = NULL;
	
	return newhead;
}


int clist_size( CList* lst )
{
	CNode *current;
	current = (CNode *)malloc(sizeof(CNode));		
	current = lst->head;
	
	int length=0;
	if(current==NULL)
		return length;
	else
	{
		while(current->next!=lst->head)
		{
		length++;
		current = current->next;
		}
	return (length+1);	
	}	
}


void clist_print( CList* lst )
{
	CNode *current;
	current=(CNode *)malloc(sizeof(CNode));		
	current = lst->head;

	int i;
	for(i=0; i<clist_size(lst); i++)
	{
		printf("%d ", current->data );
		current = current->next;
	}

	printf("\n");
}


int clist_get( CList* lst, int idx )
{
	CNode *current;
	current=(CNode *)malloc(sizeof(CNode));		
	current->next = lst->head;
	
	if(current->next == NULL || idx>(clist_size(lst)-1))
		return INT_MIN;
		
	int i;
	for(i=0; i<=idx; i++)
		current = current->next;		
	return current->data;
}

void clist_append( CList* lst, int data )
{
	CNode *current;
	current=(CNode *)malloc(sizeof(CNode));		
	current = lst->head;
	CNode *newnode;
	newnode=(CNode *)malloc(sizeof(CNode));	
	newnode->data = data;

	int i;
	
	if(lst->head==NULL)
		lst->head = newnode;
	else
	{
		for(i=1; i<clist_size(lst); i++)
			current = current->next;
		current->next = newnode;
	}
	newnode->next = lst->head;
}


void clist_prepend( CList* lst, int data )
{
	CNode *current;
	current=(CNode *)malloc(sizeof(CNode));		
	current = lst->head;
	CNode *newnode;
	newnode=(CNode *)malloc(sizeof(CNode));	
	newnode->data = data;

	int i;

	if(lst->head==NULL)
	{
		lst->head = newnode;
		newnode->next = lst->head;
	}
	else
	{
		for(i=1; i<clist_size(lst); i++)
			current = current->next;
		current->next = newnode;
		newnode->next = lst->head;
		lst->head = newnode;
	}	
}


void clist_insert( CList* lst, int idx, int data )
{
	CNode *current;
	current=(CNode *)malloc(sizeof(CNode));		
	current = lst->head;	
	CNode *newnode;
	newnode=(CNode *)malloc(sizeof(CNode));		
	newnode->data = data;
	
	int i;
	if(idx==0)
	{
		clist_prepend(lst, data);
	}
	else
	{
		for(i=1; i<idx; i++)
			current = current->next;
		newnode->next = current->next;
		current->next= newnode;
	}
}


void clist_remove_last( CList* lst )
{
	CNode *current;
	current=(CNode *)malloc(sizeof(CNode));		
	current = lst->head;

	int i;
	
	if(current!=NULL)
	{
		
		if(current->next==lst->head)
			lst->head=NULL;
		else
		{
			for(i=1; i<clist_size(lst)-1; i++)
				current = current->next;
			current->next=lst->head;
		}
	}
}

void clist_remove_first( CList* lst )
{
	CNode *current;
	current=(CNode *)malloc(sizeof(CNode));		
	current = lst->head;	

	int i;

	if(current!=NULL)
	{
		
		if(current->next==lst->head)
			lst->head=NULL;
		else
		{
			for(i=1; i<clist_size(lst); i++)
				current = current->next;
			current->next=lst->head->next;
			lst->head = current->next;
		}
	}
}

void clist_remove( CList* lst, int idx )
{
	CNode *current;
	current=(CNode *)malloc(sizeof(CNode));		
	current->next = lst->head;

	int i;
	if(lst->head!=NULL)
	{
		
		if(idx==0)
		{
			clist_remove_first(lst);
		}
		else
		{
			for(i=0; i<idx; i++)
				current = current->next;
			current->next = current->next->next;
		}
	}
}

void clist_reverse(CList* lst)
{
	CNode *prev;
	prev=(CNode *)malloc(sizeof(CNode));		
	prev = NULL;	
	CNode *current;
	current=(CNode *)malloc(sizeof(CNode));		
	current = lst->head;	
	CNode *nextn;
	nextn=(CNode *)malloc(sizeof(CNode));

	while (nextn != lst->head)
    {
        nextn  = current->next;  
        current->next = prev; 
        prev = current;
        current = nextn;

        if(current->next == lst->head)
        	lst->head->next = current;       
    }
    lst->head = prev;

}
