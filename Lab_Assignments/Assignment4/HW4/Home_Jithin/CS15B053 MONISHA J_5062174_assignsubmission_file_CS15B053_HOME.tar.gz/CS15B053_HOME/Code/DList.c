#include "DList.h"

#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

DNode* dnode_new( int data)
{
	DNode *newnode;
	newnode=(DNode*)malloc(sizeof(DNode));	
	newnode->data = data;
	newnode->next = NULL;
	
	return newnode;
}


DList* dlist_new()
{
	DList *newhead;
	newhead=(DList *)malloc(sizeof(DList));
	newhead->head = NULL;
	
	return newhead;
}


int dlist_size( DList* lst )
{
	DNode *current;
	current=(DNode *)malloc(sizeof(DNode));		
	current->next = lst->head;
	
	int length=0;
	while(current->next!=NULL)
	{
		length++;
		current = current->next;
	}
	return length;
}


void dlist_print( DList* lst )
{
	DNode *current;
	current=(DNode *)malloc(sizeof(DNode));		
	current->next = lst->head;
	
	while(current->next!=NULL)
	{
		current = current->next;	
		printf("%d ", current->data);
	}
	printf("\n");
}


int dlist_get( DList* lst, int idx )
{
	DNode *current;
	current=(DNode *)malloc(sizeof(DNode));		
	current->next = lst->head;
	
	if(current->next == NULL || idx>(dlist_size(lst)-1))
		return -1;

		
	int i;
	for(i=0; i<=idx; i++)
		current = current->next;		
	return current->data;
}


void dlist_append( DList* lst, int data )
{
	DNode *current;
	current=(DNode *)malloc(sizeof(DNode));		
	current->next = lst->head;
	DNode *newnode;
	newnode=(DNode *)malloc(sizeof(DNode));	
	newnode->data = data;
	newnode->next = NULL;
	
	if(lst->head==NULL)
		lst->head = newnode;
	else
	{
		while(current->next!=NULL)
			current = current->next;
		current->next = newnode;
		newnode->prev = current;
	}
}


void dlist_prepend( DList* lst, int data )
{
	DNode *newnode;
	newnode=(DNode *)malloc(sizeof(DNode));		
	newnode->data = data;
	newnode->next = lst->head;	
	lst->head->prev = newnode;
	lst->head = newnode;
}


void dlist_insert( DList* lst, int idx, int data )
{
	DNode *current;
	current=(DNode *)malloc(sizeof(DNode));		
	current->next = lst->head;	
	DNode *newnode;
	newnode=(DNode *)malloc(sizeof(DNode));		
	newnode->data = data;
	
	int i;
	if(idx==0)
	{
		if(lst->head==NULL)
			lst->head=newnode;
		else
		{
			newnode->next=lst->head;
			lst->head->prev = newnode;
			lst->head=newnode;
		}
	}

	else if(idx>dlist_size(lst)-1)
		return;
	else if(lst->head!=NULL)
	{
		for(i=0; i<idx; i++)
			current = current->next;
		newnode->next = current->next;
		current->next= newnode;
		newnode->prev = current;
	}
}


void dlist_remove_last( DList* lst )
{
	DNode *current;
	current=(DNode *)malloc(sizeof(DNode));		
	current->next = lst->head;
	
	if(lst->head!=NULL)
	{
		
		if(current->next->next==NULL)
			lst->head=NULL;
		else
		{
			while(current->next->next!=NULL)
				current = current->next;
			current->next=NULL;
		}
	}
}


void dlist_remove_first( DList* lst )
{
	lst->head=lst->head->next;
	lst->head->prev = NULL;
}


void dlist_remove( DList* lst, int idx )
{
	DNode *current;
	current=(DNode *)malloc(sizeof(DNode));		
	current->next = lst->head;
	
	int i;
	if(lst->head!=NULL)
	{
		
		if(idx==0)
			dlist_remove_first(lst);
		else
		{
			for(i=0; i<idx; i++)
				current = current->next;
			current->next = current->next->next;
			current->next->next->prev = current;
		}
	}
}


void dlist_reverse(DList* lst)
{
	DNode *prev;
	prev=(DNode *)malloc(sizeof(DNode));		
	prev = NULL;	
	DNode *current;
	current=(DNode *)malloc(sizeof(DNode));		
	current = lst->head;	
	DNode *nextn;
	nextn=(DNode *)malloc(sizeof(DNode));

	while (current != NULL)
    {
        nextn  = current->next;  
        current->next = prev;  
        current->prev = nextn; 
        prev = current;
        current = nextn;
    }
    lst->head = prev;
}