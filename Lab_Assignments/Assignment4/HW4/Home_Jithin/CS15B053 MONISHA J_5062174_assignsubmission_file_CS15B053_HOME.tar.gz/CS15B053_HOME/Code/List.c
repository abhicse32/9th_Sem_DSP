#include "List.h"

#include <stdio.h>
#include <stdlib.h>
#include <limits.h>


Node* node_new(int data1, int data2)
{
	Node *newnode;
	newnode=(Node*)malloc(sizeof(Node));	
	newnode->col_ind = data1;
	newnode->val = data2;
	newnode->next = NULL;
	
	return newnode;
}


LList* llist_new()
{
	LList *newhead;
	newhead=(LList *)malloc(sizeof(LList));
	newhead->head = NULL;
	
	return newhead;
}


int llist_size( LList* lst )
{
	Node *current;
	current=(Node *)malloc(sizeof(Node));		
	current->next = lst->head;
	
	int length=0;
	while(current->next!=NULL)
	{
		length++;
		current = current->next;
	}
	return length;

}


void llist_print( LList* lst )
{
	Node *current;
	current=(Node *)malloc(sizeof(Node));		
	current = lst->head;
	
	if(lst->head!=NULL)
	{
		while(current!=NULL)
		{
			printf("%d ", current->val);
			current = current->next;	
		}
		printf("\n");
	}
}


Node* llist_get( LList* lst, int idx )
{
	Node *current;
	current=(Node *)malloc(sizeof(Node));		
	current->next = lst->head;
	
	if(current->next == NULL || idx>(llist_size(lst)-1))
		return NULL;
		
	int i;
	for(i=0; i<=idx; i++)
		current = current->next;		
	return current;
}


void llist_append( LList* lst, int data1, int data2 )
{
	Node *current;
	current=(Node *)malloc(sizeof(Node));		
	
	Node *newnode;
	newnode=(Node *)malloc(sizeof(Node));	
	newnode->col_ind = data1;
	newnode->val = data2;
	newnode->next = NULL;
	
	if(lst->head==NULL)
		lst->head = newnode;
	else
	{
		current = lst->head;
		while(current->next!=NULL)
			current = current->next;
		current->next = newnode;
	}
}


void llist_prepend( LList* lst, int data1, int data2 )
{
	Node *newnode;
	newnode=(Node *)malloc(sizeof(Node));		
	newnode->col_ind = data1;
	newnode->val = data2;
	newnode->next = lst->head;	
	lst->head = newnode;
}


void llist_insert( LList* lst, int idx, int data1, int data2 )
{
	Node *current;
	current=(Node *)malloc(sizeof(Node));		
	current->next = lst->head;	
	Node *newnode;
	newnode=(Node *)malloc(sizeof(Node));		
	newnode->col_ind = data1;
	newnode->val = data2;

	int i;
	if(idx==0)
	{
		if(lst->head==NULL)
			lst->head=newnode;
		else
		{
			newnode->next=lst->head;
			lst->head=newnode;
		}
	}
	else if(lst->head!=NULL)
	{
		for(i=0; i<idx; i++)
			current = current->next;
		newnode->next = current->next;
		current->next= newnode;
	}
}



