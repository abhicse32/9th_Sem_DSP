#include "SparseMatrix.h"

#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

int llist_getfromcol( LList* lst, int col )
{
	Node *current;
	current=(Node *)malloc(sizeof(Node));		
	current = lst->head;
	
	while(current!=NULL)
	{
		if(current->col_ind == col)
		{
			return current->val;
		}
			
		current = current->next;
	}
	return INT_MIN;
}


Matrix add(Matrix m1, Matrix m2)
{
	Matrix m;
	m.n_rows = m1.n_rows;
	m.row_lst = malloc(m.n_rows * sizeof(LList *));

	Node *current1;
	current1=(Node *)malloc(sizeof(Node));		
	Node *current2;
	current2=(Node *)malloc(sizeof(Node));	

	int i,j, temp;
	for(i=0; i<m1.n_rows; i++)
	{
		m.row_lst[i] = llist_new();
		current1 = m1.row_lst[i]->head;
		current2 = m2.row_lst[i]->head;

		while(current1!=NULL && current2!=NULL)
		{
			if(current1->col_ind == current2->col_ind)
			{
				temp = (llist_getfromcol(m1.row_lst[i], current1->col_ind)) + (llist_getfromcol(m2.row_lst[i], current2->col_ind));
				llist_append(m.row_lst[i], j, temp);
				current1 = current1->next;
				current2 = current2->next;	

			}
			else if(current1->col_ind < current2->col_ind)
			{
				temp = (llist_getfromcol(m1.row_lst[i], current1->col_ind));
				llist_append(m.row_lst[i], current1->col_ind, temp);
				current1 = current1->next;
				
			}
			else if(current1->col_ind > current2->col_ind)
			{
				temp = (llist_getfromcol(m2.row_lst[i], current2->col_ind));
				llist_append(m.row_lst[i], current1->col_ind, temp);
				current2 = current2->next;	
			}		
			
		}

		while(current1!=NULL)
		{
			temp = (llist_getfromcol(m1.row_lst[i], current1->col_ind));
			llist_append(m.row_lst[i], current1->col_ind, temp);
			current1 = current1->next;	
		}
		while(current2!=NULL)
		{
			temp = (llist_getfromcol(m2.row_lst[i], current2->col_ind));
			llist_append(m.row_lst[i], current2->col_ind, temp);
			current2 = current2->next;	
		}
	}
	return m;
}


Matrix subtract(Matrix m1, Matrix m2)
{
	Matrix m;
	m.n_rows = m1.n_rows;
	m.row_lst = malloc(m.n_rows * sizeof(LList *));

	Node *current1;
	current1=(Node *)malloc(sizeof(Node));		
	Node *current2;
	current2=(Node *)malloc(sizeof(Node));		
	
	int i,j, temp;
	for(i=0; i<m1.n_rows; i++)
	{
		m.row_lst[i] = llist_new();
		current1 = m1.row_lst[i]->head;
		current2 = m2.row_lst[i]->head;

		while(current1!=NULL && current2!=NULL)
		{
			if(current1->col_ind == current2->col_ind)
			{
				temp = (llist_getfromcol(m1.row_lst[i], current1->col_ind)) - (llist_getfromcol(m2.row_lst[i], current2->col_ind));
				llist_append(m.row_lst[i], j, temp);
				current1 = current1->next;
				current2 = current2->next;	

			}
			else if(current1->col_ind < current2->col_ind)
			{
				temp = (llist_getfromcol(m1.row_lst[i], current1->col_ind));
				llist_append(m.row_lst[i], current1->col_ind, temp);
				current1 = current1->next;
				
			}
			else if(current1->col_ind > current2->col_ind)
			{
				temp = -(llist_getfromcol(m2.row_lst[i], current2->col_ind));
				llist_append(m.row_lst[i], current1->col_ind, temp);
				current2 = current2->next;	
			}		
			
		}

		while(current1!=NULL)
		{
			temp = (llist_getfromcol(m1.row_lst[i], current1->col_ind));
			llist_append(m.row_lst[i], current1->col_ind, temp);
			current1 = current1->next;	
		}
		while(current2!=NULL)
		{
			temp = -(llist_getfromcol(m2.row_lst[i], current2->col_ind));
			llist_append(m.row_lst[i], current2->col_ind, temp);
			current2 = current2->next;	
		}
	}
	return m;
}

Matrix matrix_vect_multiply(Matrix m1, Matrix v)
{
	Matrix m;
	m.n_rows = m1.n_rows;
	m.row_lst = malloc(m.n_rows * sizeof(LList *));

	Node *current1;
	current1=(Node *)malloc(sizeof(Node));		
	
	int i,j, temp, sum, vectorvalue;
	for(i=0; i<m1.n_rows; i++)
	{
		m.row_lst[i] = llist_new();
		
		sum=0;
		for(j=0; j<v.n_rows; j++)
		{
			temp = llist_getfromcol(m1.row_lst[i], j);
			if( temp!= INT_MIN)
			{
				vectorvalue = v.row_lst[j]->head->val;
				sum = sum + vectorvalue * temp;
			}
		}
		llist_append(m.row_lst[i], 0, sum);
	}
	return m;
}

void print_matrix(Matrix m)
{
	int i, j, temp;
	for(i=0; i<m.n_rows; i++)
	{
		for(j=0; j<llist_size(m.row_lst[i]); j++)
		{
			temp = (llist_get(m.row_lst[i], j))->val;
			printf("%d ", temp);			
		}
		printf("\n");
	}
}