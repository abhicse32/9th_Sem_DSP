#include "SparseMatrix.h"

//#include "SparseMatrix.c"
//#include "List.c"

#include <stdio.h>
#include <stdlib.h>

void main()
{
	int choice;	
	
	
	Matrix m1;	
	Matrix m2;
	Matrix sum, diff, product;

	int m,n;
	int i,j, temp;

	scanf("%d", &choice);
	do
	{
		
		switch(choice)
		{
			case 1:	scanf("%d %d", &m, &n);

					m1.n_rows = m;
					(m1.row_lst) = malloc(m * sizeof(LList*));
					m2.n_rows = m;
					(m2.row_lst) = malloc(m * sizeof(LList*));

					for(i=0; i<m; i++)
					{
						m1.row_lst[i] = llist_new();
						for(j=0; j<n; j++)
						{
							scanf("%d", &temp);

							if(temp!=0)
								llist_append(m1.row_lst[i], j, temp);
						}							
					}

					for(i=0; i<m; i++)
					{
						m2.row_lst[i] = llist_new();
						for(j=0; j<n; j++)
						{
							scanf("%d", &temp);

							if(temp!=0)
								llist_append(m2.row_lst[i], j, temp);
						}	
					}				
				
					sum = add(m1, m2);
					
					print_matrix(sum);
					break;
				
			case 2:	scanf("%d %d", &m, &n);

					m1.n_rows = m;
					(m1.row_lst) = malloc(m * sizeof(LList*));
					m2.n_rows = m;
					(m2.row_lst) = malloc(m * sizeof(LList*));

					for(i=0; i<m; i++)
					{
						m1.row_lst[i] = llist_new();
						for(j=0; j<n; j++)
						{
							scanf("%d", &temp);

							if(temp!=0)
								llist_append(m1.row_lst[i], j, temp);
						}							
					}

					for(i=0; i<m; i++)
					{
						m2.row_lst[i] = llist_new();
						for(j=0; j<n; j++)
						{
							scanf("%d", &temp);

							if(temp!=0)
								llist_append(m2.row_lst[i], j, temp);
						}	
					}				
				
					diff = subtract(m1, m2);
					
					print_matrix(diff);
					break;
				
			case 3: scanf("%d %d", &m, &n);

					m1.n_rows = m;
					(m1.row_lst) = malloc(m * sizeof(LList*));
					m2.n_rows = n;
					(m2.row_lst) = malloc(n * sizeof(LList*));

					for(i=0; i<m; i++)
					{
						m1.row_lst[i] = llist_new();
						for(j=0; j<n; j++)
						{
							scanf("%d", &temp);

							if(temp!=0)
								llist_append(m1.row_lst[i], j, temp);
						}							
					}

					for(i=0; i<n; i++)
					{
						m2.row_lst[i] = llist_new();
						scanf("%d", &temp);
						llist_append(m2.row_lst[i], 0, temp);
					}				
				
					product = matrix_vect_multiply(m1, m2);
					
					print_matrix(product);
					break;
		}
			
			scanf("%d", &choice);
	}while(choice!=-1);
}			
