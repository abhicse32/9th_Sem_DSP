#include "CList.h"
#include<stdlib.h>
#include<stdio.h>
#include<limits.h>

CNode* cnode_new( int data)
{
	CNode *cnode_new;
	cnode_new = (CNode*)malloc(sizeof(CNode));
	cnode_new->data = data;
	cnode_new->next = NULL;
	return cnode_new;
}

CList* clist_new()
{
	CList *clist_new;
	clist_new = (CList*)malloc(sizeof(CList));
	clist_new->head = NULL;
	return clist_new;
}

int clist_size( CList* lst )
{

	CNode *head1 = lst->head;
	CNode*head2 = lst->head;
	if(head1 == NULL)
	{
		return 0;
	}
	else
	{
		int k = 1;
		while(head1->next != head2)
		{
			head1 = head1->next;
			k++;
		}
		return k;
	}
}
void clist_print( CList* lst )
{
	CNode *head1 = lst->head;
	CNode *head2 = lst->head;
	if(head1 == NULL)
	{
		return ;
	}
	else
	{
		int k = clist_size(lst);
		if(k == 1)
		{
			printf("%d ",head1->data);
			printf("\n");
			return;
		}
		else if(k > 1)
		{	
			printf("%d ",head1->data);
			head1 = head1->next;
			while(head1 != head2)
			{
				printf("%d ",head1->data);
				head1 = head1->next;
			}
			printf("\n");
		}
	}
}
int clist_get( CList* lst, int idx )
{
	int k = clist_size(lst);
	if(idx > k-1)
	{
		return -1;  
	}
	else
	{
		CNode *head1 = lst->head;
		CNode *head2 = lst->head;
		if(head1 == NULL)
		{
			return -1; 
		
		}
		int j = 0;
		if(idx == 0)
		{
			return head1->data;
		}
		head1 = head1->next;j = 1;
		while(head1 != head2)
		{
			if(j == idx)
			{
				return head1->data;
			}
			head1 = head1->next;
			j++;
		}
	}
}
void clist_append( CList* lst, int data )
{
	CNode *newnode;
	newnode = (CNode*)malloc(sizeof(CNode));
	CNode *head1 = lst->head;
	CNode *head2 = lst->head;
	if(head1 == NULL)
	{
		lst->head = newnode;
		newnode->next = newnode;
		newnode->data = data;
	}
	else 
	{
		while(head1->next != head2)
		{
			head1 = head1->next;
		}
		head1->next = newnode;
		newnode->next = head2;
		newnode->data = data;
	}
}
void clist_prepend( CList* lst, int data )
{
	CNode *newnode;
	newnode = (CNode*)malloc(sizeof(CNode));
	CNode *head1 = lst->head;
	CNode *head2 = lst->head;
	if(head1 == NULL)
	{
		lst->head = newnode;
		newnode->next = newnode;
		newnode->data = data;
	}
	else
	{
		while(head1->next != head2)
		{
			head1 = head1->next;
		}
		newnode->next = head2;
		lst->head = newnode;
		head1->next = newnode;
		newnode->data = data;
	}
}
void clist_remove_last( CList* lst )
{
	CNode *head1 = lst->head;
	CNode *head2 = lst->head;
	if(head1 == NULL)
	{
		return;
	}
	int k = clist_size(lst);
	if(k == 1)
	{
		lst->head = NULL;
	}
	else
	{
		while((head1->next)->next != head2)
		{
			head1 = head1->next;
		}
		head1->next = head2;
	}
}
void clist_remove_first( CList* lst )
{
	CNode *head1 = lst->head;
	CNode *head2 = lst->head;
	if(head1 == NULL)
	{
		return;
	}
	int k = clist_size(lst);
	if(k == 1)
	{
		lst->head = NULL;
	}
	else
	{
		while(head1->next != head2)
		{
			head1 = head1->next;
		}
		head2 = head2->next;
		(lst->head) = head2;
		head1->next = head2;
	}
}
void clist_reverse(CList*lst)
{
	CNode *head1 = lst->head;
	CNode *head2 = lst->head;
	if(head1 == NULL)
	{
		return;
	}
	int k = clist_size(lst);
	if(k == 1)
	{
		return;
	}
	else
	{
		
		int array[1000];
		int l = 1;
		array[0] = head1->data;
		head1 = head1->next;
		while(head1 != head2)
		{
		 array[l] = head1->data;
		 head1 = head1->next;
		 l++;
		}
		int j ;
		head2->data = array[k-1];
		head2 = head2->next;
		for(j = k-2;(head2 != lst->head)&&j>=0;j--)
		{
			head2->data = array[j];
			head2 = head2->next;
		}
	   }
}
void clist_remove( CList* lst, int idx )
{
	if(lst->head == NULL)
	{
		return;
	}
	else
	{
		int k = clist_size(lst);
		if(idx > k-1)
		{
			return;
		}
		else
		{
			if(idx == 0)
			{
				clist_remove_first(lst);
				return;
			}
			if(idx == k-1)
			{
				clist_remove_last(lst);
				return;
			}
			CNode *head1 = lst->head;
			int j = 0;
			while(j != idx-1)
			{
				head1 = head1->next;
				j++;
			}
			head1->next = (head1->next)->next;
		}
	}
}
void clist_insert( CList* lst, int idx, int data )
{
	if(idx == 0)
	{
		clist_prepend(lst,data);  										
		return;
	}
	int k = clist_size(lst);
	if(idx > k)
	{
		return;
	}
	if(idx == 0)
	{
		clist_prepend(lst,data);  
		return;
	}
	if(idx == k)
	{
		clist_append(lst,data);
		return;
	}
	CNode *new; 
	new = (CNode*)malloc(sizeof(CNode));
	CNode *head1 = lst->head;
	int j = 0;
	while(j != idx-1)
	{
		head1 = head1->next;
		j++;
	}
	new->data = data;
	new->next = head1->next;
	head1->next = new;
}

	
	
			
					

	
