#include "SparseMatrix.h"
#include<stdio.h>
#include<stdlib.h>
#include "List.h"
Matrix add(Matrix m1, Matrix m2)
{
	Matrix m3;
	m3.n_rows = m1.n_rows;
	LList **matrix3;
	matrix3 = (LList**)malloc((m1.n_rows)*sizeof(LList*));
	int j;
	for(j = 0;j < m1.n_rows;j++)
	{
		matrix3[j] = llist_new();
	}
		int i;
		Node*head1;
		Node*head2 ;
		for(i = 0;i<m1.n_rows;i++)
		{
			head1 = (m1.row_lst[i])->head;
			head2 = (m2.row_lst[i])->head;
			
			while((head1 != NULL) && (head2 != NULL))
			{
				if(head1->col_ind == head2->col_ind)
				{
					llist_append(matrix3[i],head1->col_ind,((head1->val) + (head2->val)));
					head1 = head1->next;
					head2 = head2->next;
			
				}
				else if(head1->col_ind > head2->col_ind)
						{
							llist_append(matrix3[i],head2->col_ind,head2->val);
							head2 = head2->next;
							
						}
				else
						
							if(head1->col_ind < head2->col_ind)
							{
								llist_append(matrix3[i],head1->col_ind,head1->val);
								head1 = head1->next;
							
								
							}
						
					
				}
				if(head1 == NULL && head2 == NULL)
				{
					
				}
					if(head1 != NULL && head2 == NULL)
					{
						while(head1 != NULL)
						{
							llist_append(matrix3[i],head1->col_ind,head1->val);
							head1 = head1->next;
						}
					}
					
					
						if(head1 == NULL && head2 != NULL)
						{
							while(head2 != NULL)
							{
									llist_append(matrix3[i],head2->col_ind,head2->val);
									head2 = head2->next;
							}
						}
					
				
			}		
			m3.row_lst = matrix3;
			return m3;
	}

Matrix subtract(Matrix m1, Matrix m2)
{
		LList **matrix1 = m1.row_lst;
	LList **matrix2 = m2.row_lst;
	Matrix m3;
	LList **matrix3;
	m3.n_rows = m1.n_rows;
	matrix3 = (LList**)malloc((m1.n_rows)*sizeof(LList*));
	int j;
	for(j =0;j < m1.n_rows;j++)
	{
		matrix3[j] = llist_new();
	}
	
	if(m1.n_rows == m2.n_rows)
	{
		int i;
		Node*head1;
		Node*head2 ;
		for(i = 0;i<m1.n_rows;i++)
		{
			head1 = matrix1[i]->head;
			head2 = matrix2[i]->head;
			
			while(head1 != NULL && head2 != NULL)
			{
				if(head1->col_ind == head2->col_ind)
				{
					llist_append(matrix3[i],head1->col_ind,(head1->val) - (head2->val));
					head1 = head1->next;
					head2 = head2->next;
				}
				else 
					{
						if(head1->col_ind > head2->col_ind)
						{
							llist_append(matrix3[i],head2->col_ind,-(head2->val));
							head2 = head2->next;
						}
						else
						{
							if(head1->col_ind < head2->col_ind)
							{
								llist_append(matrix3[i],head1->col_ind,head1->val);
								head1 = head1->next;
							}
						}
					}
				}
				if(head1 == NULL && head2 == NULL)
				{
					
				}
				else
				{
					if(head1 != NULL && head2 == NULL)
					{
						while(head1 != NULL)
						{
							llist_append(matrix3[i],head1->col_ind,head1->val);
							head1 = head1->next;
						}
					}
					else
					{
						if(head1 == NULL && head2 != NULL)
						{
							while(head2 != NULL)
							{
									llist_append(matrix3[i],head2->col_ind,-(head2->val));
									head2 = head2->next;
							}
						}
					}
				}
			}		
			m3.row_lst = matrix3;
			return m3;
	}
}										
Matrix matrix_vect_multiply(Matrix mat, Matrix vect)
{
	LList **matrix = mat.row_lst;
	LList **vector = vect.row_lst;
	Matrix mans;
	mans.n_rows = mat.n_rows;
	LList **matrixans = (LList**)malloc((mat.n_rows)*sizeof(LList*));
	
	int i ;
	for(i =0;i < mat.n_rows;i++)
	{
		matrixans[i] = llist_new();
	}
	
	Node *head1 ;
	int sum;
	for(i = 0;i<mat.n_rows;i++)
	{	
		
		head1 = matrix[i]->head;
		 sum = 0;
		while(head1 != NULL)
		{
			sum = sum + (head1->val)*(((vector[head1->col_ind])->head)->val);
			head1 = head1->next;
		}
		llist_append(matrixans[i],1,sum);
	}					 
	mans.row_lst = matrixans;
	return mans;
}
