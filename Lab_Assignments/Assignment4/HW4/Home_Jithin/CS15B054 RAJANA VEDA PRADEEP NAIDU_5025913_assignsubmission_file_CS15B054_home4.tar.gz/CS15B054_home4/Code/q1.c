#include<stdio.h>
#include<stdlib.h>
#include "SparseMatrix.h"
#include "List.h"
void main()
{
	int x = 1;
	while(x == 1)
	{
		int option;
		scanf("%d",&option);
		if(option == 1)
		{
			int m,n;
			scanf("%d",&m);
			scanf("%d",&n);
			Matrix m1;
			Matrix m2;
			m1.n_rows = m;
			m2.n_rows = m;
			LList **matrix1 ;
			matrix1 = (LList**)malloc((m)*sizeof(LList*));
			LList **matrix2 ;
			matrix2 = (LList**)malloc((m)*sizeof(LList*));
			
			int i;
			int j;
			int k;
			for(i = 0;i<m;i++)
			{
				matrix1[i] = llist_new();
				matrix2[i] = llist_new();
			}
			for(i = 0;i<m;i++)
			{
				for(j = 0;j<n;j++)
				{
					scanf("%d",&k);
					if(k != 0)
					{
						llist_append(matrix1[i],j+1,k);
					}
				}
			}
			m1.row_lst = matrix1;
		
			int l;
			for(i = 0;i<m;i++)
			{
				for(j = 0;j<n;j++)
				{
					scanf("%d",&l);
					if(l != 0)
					{
						llist_append(matrix2[i],j+1,l);
					}
				}
			}
			m2.row_lst = matrix2;
		
			Matrix m3 = add(m1,m2);
			LList **matrix3 = m3.row_lst;
			for(i = 0;i<m;i++)
			{
				llist_print(matrix3[i]);
			}
		}
		if(option == 2)
		{
			int m,n;
			scanf("%d",&m);
			scanf("%d",&n);
			Matrix m1;
			Matrix m2;
			m1.n_rows = m;
			m2.n_rows = m;
			LList **matrix1 ;
			matrix1 = (LList**)malloc((m1.n_rows)*sizeof(LList*));
			LList **matrix2 ;
			matrix2 = (LList**)malloc((m2.n_rows)*sizeof(LList*));
			int i;
			for(i = 0;i < m1.n_rows;i++)
			{
				matrix1[i] = llist_new();
				matrix2[i] = llist_new();
			}
			
			int j;
			int k;
			for(i = 0;i<m;i++)
			{
				for(j = 0;j<n;j++)
				{
					scanf("%d",&k);
					if(k != 0)
					{
						llist_append(matrix1[i],j+1,k);
					}
				}
			}
			m1.row_lst = matrix1;
			int l;
			for(i = 0;i<m;i++)
			{
				for(j = 0;j<n;j++)
				{
					scanf("%d",&l);
					if(l != 0)
					{
						llist_append(matrix2[i],j+1,l);
					}
				}
			}
			m2.row_lst = matrix2;
			Matrix m3 = subtract(m1,m2);
			LList **matrix3 = m3.row_lst;
			for(i = 0;i<m;i++)
			{
				llist_print(matrix3[i]);
			}
		}
		if(option == 3)
		{
			int m,n;
			scanf("%d",&m);
			scanf("%d",&n);
			Matrix m1;
			Matrix m2;
			m1.n_rows = m;
			m2.n_rows = n;
			LList **matrix1 ;
			matrix1 = (LList**)malloc((m1.n_rows)*sizeof(LList*));
			LList **matrix2 ;
			matrix2 = (LList**)malloc((m2.n_rows)*sizeof(LList*));
			int i;
			for(i = 0;i<m;i++)
			{
				matrix1[i] = llist_new();
			}
			for(i = 0;i<n;i++)
			{
				matrix2[i] = llist_new();
			}
			int j;
			int k;
			for(i = 0;i<m;i++)
			{
				for(j = 0;j<n;j++)
				{
					scanf("%d",&k);
					if(k != 0)
					{
						llist_append(matrix1[i],j,k);
					}
				}
			}
			m1.row_lst = matrix1;
			int l;
			for(i = 0;i<n;i++)
			{
				for(j = 0;j<1;j++)
				{
					scanf("%d",&l);
					
					
						llist_append(matrix2[i],j+1,l);
					
				}
			}
			m2.row_lst = matrix2;
			Matrix m3 = matrix_vect_multiply(m1,m2);
			LList **matrix3 = m3.row_lst;
			for(i = 0;i<m;i++)
			{
				llist_print(matrix3[i]);
			}
		}
		if(option == -1)
		{
			break;
		}
	}
}

