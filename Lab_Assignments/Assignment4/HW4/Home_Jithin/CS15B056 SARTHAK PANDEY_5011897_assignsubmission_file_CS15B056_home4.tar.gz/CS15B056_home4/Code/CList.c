/* CIRCULAR LINKED LIST FUNCTION IMPLEMENTATIONS
   AUTHOR -SARTHAK PANDEY
           CS15B056 */

#include "CList.h"
#include <stdlib.h>
#include <stdio.h>
#define int_min -50

CNode* cnode_new( int data)
{
	CNode *new;
	new=(CNode *)malloc(sizeof(CNode));                  //Allocates memory to the new node
	new->data=data;
	new->next=NULL;
	return new;
}

CList* clist_new()
{
	CList *newll;
	newll=(CList *)malloc(sizeof(CList));                //allocates memory to the new linked list pointer newll
	newll->head=NULL;
	return newll;
}

int clist_size( CList* lst )
{
	CNode *curr;
	int i=1;                                            // i is the counter which stores the number of elements in the list
	curr=lst->head;
	if (curr==NULL)
		return 0;
	for (;lst->head!=curr->next;curr=curr->next,i++)    //the increment in the value of i is done in this line   
		;
	return i;
}

void clist_print( CList* lst )
{
	CNode *curr;
	curr=lst->head;
	if (curr==NULL)
		printf("\n");                              // If list is empty , then does nothing and prints a newline
	else
	{
		printf("%d ",curr->data);
		for (;lst->head!=curr->next;curr=curr->next)        // Loop goes on till the curr->next==lst->head and prints all the values it encounters in the process 
			printf ("%d ",curr->next->data);;
		printf ("\n");
	}
}

int clist_get( CList* lst, int idx )
{
	CNode *curr;
	curr=lst->head;
	int i;
	if (idx>=clist_size(lst))
		return -1;
	else 
	{
		for (i=0;i<idx;i++)
			curr=curr->next;                     //gets the pointer to the idx index
		return curr->data;                           //returns the value stored in that list element
	}
}

void clist_append( CList* lst, int data )
{
	CNode *new,*curr;
	curr=lst->head;
	
	new=cnode_new(data);
	if (lst->head==NULL)
	{
		new->next=new;                               //For the case when the list is initially empty
		lst->head=new;
	}
	else
	{
		for(;curr->next!=lst->head;curr=curr->next)
			;
		curr->next=new;
		new->next=lst->head;
	}
}

void clist_prepend( CList* lst, int data )
{
	CNode *new,*curr;
	if (lst->head==NULL)
		clist_append(lst,data);                     //For the case when list is empty , append and prepend have the same meaning
	else
	{
		new=cnode_new(data);
		new->next=lst->head;
		curr=lst->head;
		for(;curr->next!=lst->head;curr=curr->next)
			;
		lst->head=new;
		curr->next=new;
	}
}

void clist_insert( CList* lst, int idx, int data )
{
	if (idx>clist_size(lst))
		;
	else if (idx==0)
		clist_prepend(lst,data);
	else if (idx==clist_size(lst))
		clist_append(lst,data);
	else
	{
		int i;
		CNode *curr=lst->head;
		for (i=0;i<idx-1;i++,curr=curr->next)
			;
			CNode *new=cnode_new(data);               //inserts an element at the idx index
			new->next=curr->next;
			curr->next=new;
	}
}

void clist_remove_last( CList* lst )
{
	if (lst->head==NULL)
		;
	else if ((lst->head)->next==lst->head)
	{
		lst->head=NULL;                                    //if list contains just one element
		
	}
	else
	{
		CNode *curr;
		curr=lst->head;
		
		for (;curr->next->next!=lst->head;curr=curr->next)
			;
		CNode *a=curr->next;
		free (a);
		curr->next=lst->head;                            //removes last element
	}
}

void clist_remove_first( CList* lst )
{
	if (lst->head==NULL)
		;
	else if (lst->head->next==lst->head)
		clist_remove_last(lst);
	else
	{
		CNode *curr=lst->head;
		for (;curr->next!=lst->head;curr=curr->next)       //removes first element
			;
		curr->next=lst->head->next;
		CNode *c=lst->head;
		lst->head=lst->head->next;
		free (c);
	}
}

void clist_remove( CList* lst, int idx )
{
	if (idx>=clist_size(lst))
		return ;
	if (idx==0)                                             //Remove first
		clist_remove_first(lst);
	else if (idx==clist_size(lst)-1)                        // Remove last
		clist_remove_last(lst);
	else 
	{
		int i;
		CNode *curr=lst->head;
		for (i=0;i<idx-1;curr=curr->next,i++)
			;
		CNode *c=curr->next;
		curr->next=curr->next->next;                   //Removes at index idx
		free (c);
	}
}

void clist_reverse(CList* lst)                                 //this function calls reverseclist which is a recursive function and to which the initial head pointer is passed as a constant
{
	if (lst->head==NULL||lst->head->next==lst->head)
		;
	else
	{
		CNode *con=lst->head;
		reverseclist(lst,con);
	}
}

void reverseclist(CList *lst,CNode *con)                      //this function is called recursively and reverses the list
{
	if (lst->head->next==con)
		;
	else
	{
		CNode *curr=lst->head;
		lst->head=lst->head->next;
		reverseclist(lst,con);
		curr->next->next=curr;
		curr->next=lst->head;
	}
}
		
		
		
		
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
		
	
		
	
		
		
		

		
		
	
	
	
	
	
	
	
	
	
	
	
	
						
						
