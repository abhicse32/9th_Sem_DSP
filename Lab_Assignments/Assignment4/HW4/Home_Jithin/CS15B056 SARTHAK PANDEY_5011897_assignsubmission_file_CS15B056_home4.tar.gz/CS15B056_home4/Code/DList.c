/* DOUBLE LINKED LIST FUNCTION IMPLEMENTATIONS
   AUTHOR -SARTHAK PANDEY
           CS15B056 */

#include "DList.h"
#include <stdio.h>
#include <stdlib.h>

DNode* dnode_new( int data)                   // Creates a new node with next and prev set to NULL
{
	DNode *new;
	new=(DNode *)malloc(sizeof(DNode));
	new->data=data;
	new->next=NULL;
	new->prev=NULL;
	return new;
}

DList* dlist_new()                             // Creates a new double linked list
{
	DList *new;
	new=(DList *)malloc(sizeof(DList));
	new->head=NULL;
	return new;
}

int dlist_size( DList* lst )                   // Gets the size of double linked list the same way as the single linked list
{
	if (lst->head==NULL)
		return 0;
	else
	{
		int i=0;
		DNode *curr=lst->head;
		for (;curr!=NULL;curr=curr->next,i++)
			;
		return i;
	}
}

void dlist_print( DList* lst )                  // Prints the elements of the double linked list
{
	if (lst->head==NULL)
		printf("\n");
	else
	{
		DNode *curr=lst->head;
		for (;curr!=NULL;curr=curr->next)
			printf ("%d ",curr->data);
		printf ("\n");
	}
}

int dlist_get( DList* lst, int idx )             //gets the element at the index idx
{
	if (idx>dlist_size(lst)-1)
		return -1;
	else
	{
		int i;
		DNode *curr=lst->head;
		for (i=0;i<idx;i++,curr=curr->next)
			;
		return curr->data;
	}
}

void dlist_append( DList* lst, int data )         //appends in a linked list taking care of the previous pointer
{
	if (lst->head==NULL)
		lst->head=dnode_new(data);
	else
	{
		DNode *curr=lst->head;
		for(;curr->next!=NULL;curr=curr->next)
			;
		DNode *new=dnode_new(data);
		curr->next=new;
		new->prev=curr;
	}
}

void dlist_prepend( DList* lst, int data )        //prepends taking care of the previous pointer
{
	if (lst->head==NULL)
		lst->head=dnode_new(data);
	else
	{
		DNode *new=dnode_new(data);
		new->next=lst->head;
		lst->head=new;
	}
}

void dlist_insert( DList* lst, int idx, int data )      // Inserts an element at idx index
{
	if (idx>dlist_size(lst))
		;
	else if (idx==0)
		dlist_prepend(lst,data);
	else if (idx==dlist_size(lst))
		dlist_append(lst,data);
	else
	{
		DNode *curr=lst->head;
		int i;
		for (i=0;i<idx-1;i++)
			curr=curr->next;
		DNode *new=dnode_new(data);
		new->prev=curr;
		new->next=curr->next;
		curr->next=new;
		(new->next)->prev=new;
	}
}

void dlist_remove_last( DList* lst )           // Removes the last element
{
	if (lst->head==NULL)
		;
	else if (lst->head->next==NULL)
		lst->head=NULL;
	else
	{
		DNode *curr=lst->head,*d;
		for(;curr->next->next!=NULL;curr=curr->next)
			;
		d=curr->next;
		curr->next=NULL;
		free (d);
	}
}

void dlist_remove_first( DList* lst )              //removes the first element
{
	if(lst->head==NULL)
		;
	else if (lst->head->next==NULL)
		lst->head=NULL;
	else
	{
		DNode *d=lst->head;
		lst->head=lst->head->next;
		free (d);
	}
}

void dlist_remove( DList* lst, int idx )           //removes element at idx index
{
	if (idx>dlist_size(lst)-1)
		return;
	if (lst->head==NULL)
		;
	else if (idx==0)
		dlist_remove_first(lst);
	else if (idx==dlist_size(lst)-1)
		dlist_remove_last(lst);
	else
	{
		int i;
		DNode *curr=lst->head;
		for (i=0;i<idx-1;i++,curr=curr->next)
			;
		curr->next=curr->next->next;
		curr->next->prev=curr;
	}
}

void dlist_reverse(DList* lst)                    //this function is recursively called to reverse the list
{
	if (lst->head==NULL||lst->head->next==NULL)      //recursion ending condition
		;
	else
	{
		DNode *curr=lst->head;
		lst->head=lst->head->next;
		dlist_reverse(lst);
		curr->next->next=curr;
		curr->prev=curr->next;
		curr->next=NULL;
	}
}


















		
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
		
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	


		
		
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
