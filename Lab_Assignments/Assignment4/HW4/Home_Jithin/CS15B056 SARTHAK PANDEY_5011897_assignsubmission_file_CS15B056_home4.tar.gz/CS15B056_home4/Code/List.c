/* LINKED LIST FUNCTION IMPLEMENTATIONS
   AUTHOR -SARTHAK PANDEY
           CS15B056
   THIS CODE IS SIMILAR TO LIST.C IN LAB4 , JUST THE COLUMN INDEX IS ALSO SAVED IN THE SAME LIST  */

#include "List.h"
#include <stdlib.h>
#include <stdio.h>
Node* node_new( int data1, int data2)
{
	Node *new;
	new=(Node *)malloc(sizeof(Node));
	new->next=NULL;
	new->col_ind=data1;
	new->val=data2;
	return new;
}

LList* llist_new()
{
	LList *new;
	new=(LList *)malloc(sizeof(LList));
	new->head=NULL;
	return new;
}

int llist_size( LList* lst )
{
	int i=0;
	Node *curr;
	curr=lst->head;
	for(;curr!=NULL;)
	{
		i++;
		curr=curr->next;                          //stops when null is reached
	}
	return i;
}

void llist_print( LList* lst)
{
	if (lst->head==NULL)
		;
	else
	{
	Node *curr;
	curr=lst->head;
	for (;curr!=NULL;curr=curr->next)
		printf("%d ",curr->val);                   //prints elements till list end is reached
	printf ("\n");
	}
}

Node* llist_get( LList* lst, int idx )
{
	int i;
	Node *curr;
	curr=lst->head;
	if (idx>llist_size(lst)-1)
		return NULL;
	curr=lst->head;
	for (i=0;i<idx;i++)
		curr=curr->next;                            //finds the element at idx index
	return curr;
}

void llist_append( LList* lst, int col, int data)
{
	Node *curr;
	curr=lst->head;
	if (curr==NULL)
		lst->head=node_new(col,data);                   //if initially no element present
	else
	{	
	for (;curr->next!=NULL;curr=curr->next)              //places an element at list end
		;
	curr->next=node_new(col,data);
	}
}

void llist_prepend( LList* lst, int col, int data)
{
	Node *new;
	new=node_new(col,data);
	new->next=lst->head;
	lst->head=new;
}

void llist_insert( LList* lst, int idx, int col, int data)
{
	Node *curr;
	int i;
	Node *new;
	new=node_new(col,data);
	curr=lst->head;
	if (idx==llist_size(lst))
		llist_append (lst,col,data);                      //if insertion point is at the end
	else if (idx>llist_size(lst))
	 return;
	else if (idx==0)
		llist_prepend(lst,col,data);                    // if insertion point is the start
	else {
		
	for(i=0;i<idx-1;i++)
		curr=curr->next;
	new->next=curr->next;
	curr->next=new;
	}
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
