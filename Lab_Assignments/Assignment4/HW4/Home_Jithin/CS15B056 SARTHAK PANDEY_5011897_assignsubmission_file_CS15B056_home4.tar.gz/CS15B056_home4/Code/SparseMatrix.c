/* SPARSE MATRIX FUNCTION IMPLEMENTATIONS
   AUTHOR -SARTHAK PANDEY
           CS15B056 */

#include "SparseMatrix.h"
#include <stdio.h>
#include <stdlib.h>

Matrix add(Matrix a, Matrix b,int m)                   //matrix a and b are added and the sum is stored in matrix a
{
	int i;
	for (i=0;i<m;i++)
	{
		Node *curra=a.row_lst[i]->head,*currb=b.row_lst[i]->head;
		int j=0;
		for (;curra!=NULL&&currb!=NULL;)                // If the end of none of the lists has been reached
		{
			
			if (curra->col_ind==currb->col_ind)     //if column indexes equal,then add
			{
				curra->val=curra->val+currb->val;
				curra=curra->next;
				currb=currb->next;
				j++;
			}
			else if (curra->col_ind>currb->col_ind)    //if this the case ,the the element of b is placed before the current element of a
			{
				llist_insert( a.row_lst[i],j, currb->col_ind, currb->val);
				currb=currb->next;
				j++;
			}
			else if (currb->col_ind>curra->col_ind)    //if such case , then the pointer of a is moved one step forward
			{
				curra=curra->next;
				j++;
			}
		}
		for (;curra==NULL&&currb!=NULL;currb=currb->next)     //if a ends but b matrix still left ,then elements of b are put into a  
		{
			llist_append(a.row_lst[i],currb->col_ind,currb->val);
		}
	}
	return a;
}

Matrix subtract(Matrix a, Matrix b,int m)                //this function too is more or less like a.The final answer is stored in a
{
	int i;
	for (i=0;i<m;i++)
	{
		Node *curra=a.row_lst[i]->head,*currb=b.row_lst[i]->head;
		int j=0;
		for (;curra!=NULL&&currb!=NULL;)
		{
			
			if (curra->col_ind==currb->col_ind)
			{
				curra->val=curra->val-currb->val;
				curra=curra->next;
				currb=currb->next;
				j++;
			}
			else if (curra->col_ind>currb->col_ind)
			{
				llist_insert( a.row_lst[i],j, currb->col_ind, -currb->val);
				currb=currb->next;
				j++;
			}
			else if (currb->col_ind>curra->col_ind)
			{
				curra=curra->next;
				j++;
			}
		}
		for (;curra==NULL&&currb!=NULL;currb=currb->next)
		{
			llist_append(a.row_lst[i],currb->col_ind,-currb->val);
		}
	}
	return a;
}

Matrix matrix_vect_multiply(Matrix a, Matrix b,int m,int n)             // The final answer is stored in matrix c
{
	Matrix c;
	int temp,d,i;
	c.row_lst=(LList **)malloc(sizeof(LList *)*m);                  //malloc for c
	for (i=0;i<m;i++)
		c.row_lst[i]=llist_new();                               //creates new linked lists
	for (i=0;i<m;i++)
	{
		temp=0;
		
		Node *curr=a.row_lst[i]->head;
		for (;curr!=NULL;curr=curr->next)
		{
			d=curr->col_ind;
			if (b.row_lst[d]->head!=NULL)                  //if it is null ,it means value is zero thus no change in temp
			{
				temp=temp+(b.row_lst[d]->head->val)*(curr->val);          //temp stores the value of matrix multiplication of each row
				
			}
		}
		
			llist_append(c.row_lst[i],0,temp);                                //once multiplication is done for one row,it stores the value in matrix c
	}
	return c;                                                           //the matrix c is returned
}

			
		
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
		
				
			
				
