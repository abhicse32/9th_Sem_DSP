/* THIS CODE CALLS THE VARIOUS FUNCTIONS FROM SparseMatrix.h  
   AUTHOR -SARTHAK PANDEY
           CS15B056 */


#include <stdio.h>
#include <stdlib.h>
#include "SparseMatrix.h"

int main ()
{
	int choice;
	scanf ("%d",&choice);           //Scans the choice of input
	for(;choice!=-1;)               //LOOPS UNTIL CHOICE IS ENTERED AS -1
	{
		if (choice==1||choice==2)
		{
			Matrix a,b;
			int m,n,i,j,val;
			scanf ("%d%d",&m,&n);
			a.row_lst=(LList **)malloc(sizeof(LList *)*m);                 // ERROR PRONE :THIS MALLOC IS IMPORTANT AS IT ALLOCATES THE MEMORY TO THE ARRAY AND CAN BE EASILY MISSED . 
			b.row_lst=(LList **)malloc(sizeof(LList *)*m);
			
			for (i=0;i<m;i++)                                              //GETS THE INPUT FOR THE MATRIX A
			{
				a.row_lst[i]=llist_new();
				for (j=0;j<n;j++)
				{
					int value;
					scanf("%d",&value);
					if (value!=0)
						llist_append (a.row_lst[i],j,value);
				}
			}
			for (i=0;i<m;i++)                                              //GETS THE INPUT FOR MATRIX B
			{
				b.row_lst[i]=llist_new();
				for (j=0;j<n;j++)
				{
					int value;
					scanf("%d",&value);
					if (value!=0)
						llist_append (b.row_lst[i],j,value);
				}
			}
			
			if (choice==1)
			{
				
					a=add(a,b,m);                                  //CALLS ADD FUNCTION AND STORES OUTPUT IN A
				for (i=0;i<m;i++)
					llist_print (a.row_lst[i]);
			}
			
			else 
			{
				a=subtract(a,b,m);                                      //CALLS SUBTRACT FUNCTION AND STORES VALUE IN A
				for (i=0;i<m;i++)
					llist_print (a.row_lst[i]);
			}
			free (a.row_lst);                                               //FREES MEMORY ONCE PRINTING IS DONE
			free (b.row_lst);
			scanf("%d",&choice);
		}
		
		else if (choice==3)
		{
			
			Matrix a,b,c;
			int m,n,i,j,value;
			scanf ("%d%d",&m,&n);
			a.row_lst=(LList **)malloc(sizeof(LList *)*m);
			b.row_lst=(LList **)malloc(sizeof(LList *)*n);
			for (i=0;i<m;i++)
			{
				a.row_lst[i]=llist_new();
				for (j=0;j<n;j++)
				{
					int value;
					scanf("%d",&value);
					if (value!=0)
						llist_append (a.row_lst[i],j,value);       //GETS ELEMENTS OF MATRIX A
				}
			}
			for (i=0;i<n;i++)
			{
				b.row_lst[i]=llist_new();
				scanf ("%d",&value);
				if (value!=0)
					llist_append (b.row_lst[i],0,value);              //GETS ELEMENTS OF VECTOR B
			}
			c=matrix_vect_multiply(a,b,m,n);                                  //CALLS MULTIPLY FUNCTION AND STORES ANSWER IN MATRIX C
			for (i=0;i<m;i++)
				if(c.row_lst[i]->head!=NULL)
					printf ("%d \n",c.row_lst[i]->head->val);          //PRINTS THE ANSWER MATRIX
			scanf ("%d",&choice);
		}
	}
}
			
			
			
				
				
			
		
					
	   
	   
	   
	   
	   
	   
	   
	   
	   
