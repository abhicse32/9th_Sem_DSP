/*
 * Author:G.Kavitha
 * Roll No. CS15B057
 * Circular linked List
 */
#include "CList.h"
# include <stdio.h>
# include <stdlib.h>
# include <limits.h>

// Create a new node with next set to NULL
CNode* cnode_new( int data){
	CNode* temp=(CNode*)malloc(sizeof(CNode));
	temp->data=data;
	temp->next=NULL;
	return temp;
}

// Create an empty list (head shall be NULL)
CList* clist_new(){
	CList* temp=(CList*)malloc(sizeof(CList));
	temp->head=NULL;
	return temp;
}

// Traverse the linked list and return its size
int clist_size( CList* lst ){
	CNode* head=lst->head;
	if(head==NULL) return 0;
	CNode* save=lst->head;
	int len=1;
	while(head->next!=save){
		len++;
		head=head->next;
	}
	return len;
}

// Traverse the linked list and print each element
void clist_print( CList* lst ){
	if(lst==NULL) return;
	CNode* head=lst->head;
	if(head==NULL) return;
	CNode* save=head;
	printf("%d ",head->data);
	while(head->next!=save){
		head=head->next;
		printf("%d ",head->data);
	}
	printf("\n");

}

//get the element at position @idx
int clist_get( CList* lst, int idx ){
	if(clist_size(lst)-1<idx||idx<0) return -1;//INT_MIN;
	CNode* head=lst->head;
	while(idx--){	
		head=head->next;
	}
	return head->data;

}

// Add a new element at the end of the list
void clist_append( CList* lst, int data ){
	CNode* head=NULL;	
	if(lst!=NULL)
		head=lst->head;
	CNode* temp=cnode_new(data);
	if(head==NULL){
		lst->head=temp;
		temp->next=temp;
	}
	else{
		CNode* save=head;		
		while(head->next!=save){
			head=head->next;
		}
		head->next=temp;
		temp->next=save;
	}
}

// Add a new element at the beginning of the list
void clist_prepend( CList* lst, int data ){
	CNode* head=lst->head;
	CNode* temp=cnode_new(data);
	if(head==NULL){
		lst->head=temp;
		temp->next=temp;
	}
	else{
		lst->head=temp;
		temp->next=head;
		CNode* save=head;
		while(head->next!=save){
			head=head->next;
		}
		head->next=temp;
	}	
}

// Add a new element at the @idx index
void clist_insert( CList* lst, int idx, int data ){
	if(clist_size(lst)<idx||idx<0) return;
	CNode* temp=cnode_new(data);	
	CNode* head=lst->head;
	if(idx==0){
		lst->head=temp;
		temp->next=head;
		CNode* save=head;
		while(head!=NULL&&head->next!=save){
			head=head->next;
		}
		if(head==NULL) temp->next=temp;
		else head->next=temp;
	}
	else{
		idx--;
		while(idx--){
			head=head->next;
		}
		CNode* save=head->next;
		head->next=temp;
		temp->next=save;
	}
}

// Remove an element from the end of the list
void clist_remove_last( CList* lst ){
	int s=clist_size(lst);	
	if(s==0) return ;
	CNode* head=lst->head;
	if(s==1) {
		CNode* save=lst->head;
		free(save);
		lst->head=NULL;
		return ;
	}	
	CNode* temp=head;
	while(head->next->next!=temp){
		head=head->next;
	}
	CNode* save=head->next;	
	head->next=temp;
	free(save);	
}

// Remove an element from the beginning of the list
void clist_remove_first( CList* lst ){
	int s=clist_size(lst);	
	if(s==0) return ;
	CNode* save=lst->head;
	lst->head=save->next;
	CNode* head=save;
	while(head->next!=save){
		head=head->next;
	}
	head->next=save->next;
	free(save);	
}

// Remove an element from an arbitrary @idx position in the list
void clist_remove( CList* lst, int idx ){
	if(clist_size(lst)-1<idx||idx<0) return;
	if(idx==0){
		CNode* head=lst->head;
		lst->head=head->next;
		CNode* save=head;
		while(head->next!=save){
			head=head->next;
		}
		head->next=save->next;
		free(save);
		return;
	}
	idx--;
	CNode* head=lst->head;
	while(idx--){
		head=head->next;
	}
	CNode* save=head->next;
	head->next=save->next;
	free(save);
}

// reverse the list
void clist_reverse(CList* lst){
	int s=clist_size(lst);
	if(s==0||s==1) return;
	CNode* save=lst->head;
	CNode* head=save;
	CNode* temp=head;
	CNode* sav;
	head=head->next;
	while(head!=save){
		sav=head->next;
		head->next=temp;
		temp=head;
		head=sav;
		if(head->next==save) lst->head=head;
	}
	head->next=temp;
}
