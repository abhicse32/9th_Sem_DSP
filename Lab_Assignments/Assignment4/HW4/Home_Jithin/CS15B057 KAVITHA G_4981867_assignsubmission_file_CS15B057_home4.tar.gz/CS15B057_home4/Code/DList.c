/*
 * Author:G.Kavitha
 * Roll No. CS15B057
 * Doubly Linked List
 */
#include "DList.h"
# include<stdio.h>
# include<stdlib.h>
# include<limits.h>

// Create a new node with next set to NULL
DNode* dnode_new( int data){
	DNode* temp=(DNode*)malloc(sizeof(DNode));
	temp->data=data;
	temp->next=NULL;
	temp->prev=NULL;
	return temp;
}

// Create an empty list (head shall be NULL)
DList* dlist_new(){
	DList* temp=(DList*)malloc(sizeof(DList));
	temp->head=NULL;
	return temp;
}

// Traverse the linked list and return its size
int dlist_size( DList* lst ){
	DNode* head=lst->head;
	int len=0;
	while(head!=NULL){
		len++;
		head=head->next;
	}
	return len;
}

// Traverse the linked list and print each element
void dlist_print( DList* lst ){
	if(lst==NULL) return;
	DNode* head=lst->head;
	while(head!=NULL){
		printf("%d ",head->data);
		head=head->next;
	}
	printf("\n");
}

//get the element at position @idx
int dlist_get( DList* lst, int idx ){
	if(dlist_size(lst)-1<idx||idx<0) return -1;//INT_MIN;//Returning -1 if the index is invalid
	DNode* head=lst->head;
	while(idx--){	
		head=head->next;
	}
	return head->data;
}

// Add a new element at the end of the list
void dlist_append( DList* lst, int data ){
	DNode* head=NULL;	
	if(lst!=NULL)
		head=lst->head;
	DNode* temp=dnode_new(data);
	if(head==NULL){
		lst->head=temp;
//printf("1\n");
	}
	else{
//	printf("2\n");		
		while(head->next!=NULL){
			head=head->next;
		}
//		printf("%d\n",head->data);
		head->next=temp;		
		temp->prev=head;
		temp->next=NULL;
//		printf("%d\n",head->next->prev->data);		
		//head->next=temp;
	}
//	printf("%d\n\n",dlist_size(lst));
}

// Add a new element at the beginning of the list
void dlist_prepend( DList* lst, int data ){
	DNode* head=lst->head;
	DNode* temp=dnode_new(data);
	if(head==NULL){
		lst->head=temp;
	}
	else{
		lst->head=temp;
		temp->next=head;
		head->prev=temp;
	}
}

// Add a new element at the @idx index
void dlist_insert( DList* lst, int idx, int data ){
	if(dlist_size(lst)<idx||idx<0) return;
	DNode* temp=dnode_new(data);
	DNode* head=lst->head;
	if(head==NULL){
		lst->head=temp;
		return;
	}
	if(idx==0){
	//	printf("1\n");
		head->prev=temp;
	//	printf("1\n");
		lst->head=temp;
	//	printf("1\n");
		temp->next=head;
	//	printf("%d\n",dlist_size(lst));
	}
	else{
		idx--;
		while(idx--){
			head=head->next;
		}
		DNode* save=head->next;
		head->next=temp;
		temp->prev=head;
		temp->next=save;
		if(save!=NULL) save->prev=temp;
	}
}

// Remove an element from the end of the list
void dlist_remove_last( DList* lst ){
	int s=dlist_size(lst);	
	if(s==0) return ;
	DNode* head=lst->head;
	if(s==1) {
		DNode* save=lst->head;
		free(save);
		lst->head=NULL;
		return ;
	}	
	while(head->next->next!=NULL){
		head=head->next;
	}
	DNode* save=head->next;	
	head->next=NULL;
	free(save);
}

// Remove an element from the beginning of the list
void dlist_remove_first( DList* lst ){
	int s=dlist_size(lst);	
	if(s==0) return;
	if(s==1) {
		DNode* save=lst->head;
		lst->head=save->next;	
		free(save);
		return;
	}
	DNode* save=lst->head;
	lst->head=save->next;
	lst->head->prev=NULL;	
	free(save);
}

// Remove an element from an arbitrary @idx position in the list
void dlist_remove( DList* lst, int idx ){
	if(dlist_size(lst)-1<idx||idx<0) return;
	if(idx==0){
		DNode* head=lst->head;
		lst->head=head->next;
		lst->head->prev=NULL;		
		free(head);
		return;
	}
	idx--;
	DNode* head=lst->head;
	while(idx--){
		head=head->next;
	}
	DNode* save=head->next;
	head->next=save->next;
	save->next->prev=head;
	free(save);
}

void dlist_reverse(DList* lst){
	if(lst==NULL) return;
	DNode* head=lst->head;
	while(head!=NULL){
		if(head->next==NULL) lst->head=head;
		DNode* save=head->prev;
		head->prev=head->next;
		head->next=save;
		head=head->prev;
	} 
}

