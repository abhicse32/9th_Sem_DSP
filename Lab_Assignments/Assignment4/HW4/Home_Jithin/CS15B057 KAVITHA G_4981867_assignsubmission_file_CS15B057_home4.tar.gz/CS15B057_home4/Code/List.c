/*
 * Author:G.Kavitha
 * Roll No. CS15B057
 * Linked List for Sparse Matrix
 */
#include "List.h"
# include<stdio.h>
# include<stdlib.h>
# include<limits.h>

// Create a new node with next set to NULL
Node* node_new( int data1, int data2){
	Node* temp=(Node*)malloc(sizeof(Node));
	temp->col_ind=data1;
	temp->val=data2;
	temp->next=NULL;
	return temp; 
}

// Create an empty list (head shall be NULL)
LList* llist_new(){
	LList* temp=(LList*)malloc(sizeof(LList));
	temp->head=NULL;
	return temp;
}

// Traverse the linked list and return its size
int llist_size( LList* lst ){
	Node* head=lst->head;
	int len=0;
	while(head!=NULL){
		len++;
		head=head->next;
	}
	return len;
}

// Traverse the linked list and print each element
void llist_print( LList* lst){
	if(lst==NULL) return;
	Node* head=lst->head;
	while(head!=NULL){
		printf("%d ",head->val);
		head=head->next;
	}
	printf("\n");
}

//get the element at position @idx
Node* llist_get( LList* lst, int idx ){
	if(llist_size(lst)-1<idx||idx<0) return NULL;
	Node* head=lst->head;
	while(idx--){	
		head=head->next;
	}
	return head;
}

// Add a new element at the end of the list
void llist_append( LList* lst, int col, int val){
	Node* head=NULL;	
	if(lst!=NULL)
		head=lst->head;
	Node* temp=node_new(col,val);
	if(head==NULL){
		lst->head=temp;
	}
	else{		
		while(head->next!=NULL){
			head=head->next;
		}
		head->next=temp;
	}
}

// Add a new element at the beginning of the list
void llist_prepend( LList* lst, int col, int val){
	Node* head=lst->head;
	Node* temp=node_new(col,val);
	if(head==NULL){
		lst->head=temp;
	}
	else{
		lst->head=temp;
		temp->next=head;
	}
}

// Add a new element at the @idx index
void llist_insert( LList* lst, int idx, int col, int val){
	if(llist_size(lst)<idx||idx<0) return;
	Node* temp=node_new(col,val);
	Node* head=lst->head;
	if(idx==0){
		lst->head=temp;
		temp->next=head;
	}
	else{
		idx--;
		while(idx--){
			head=head->next;
		}
		Node* save=head->next;
		head->next=temp;
		temp->next=save;
	}
}



