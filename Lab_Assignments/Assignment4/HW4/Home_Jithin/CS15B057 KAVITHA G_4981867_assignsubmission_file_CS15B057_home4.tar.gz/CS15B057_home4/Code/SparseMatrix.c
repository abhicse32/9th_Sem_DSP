/*
 * Author:G.Kavitha
 * Roll No. CS15B057
 * Sparse Matrix
 */
#include "SparseMatrix.h"
# include<stdio.h>
# include<stdlib.h>
# include<limits.h>

/*Multiply an M x N matrix with N X 1 vector*/
Matrix matrix_vect_multiply(Matrix mat, Matrix vect){
	Matrix res;
	int i;
	LList** r;
	r=(LList**)malloc(mat.n_rows*sizeof(LList*));
	for(i=0;i<mat.n_rows;i++){
		LList* lst=llist_new();
		Node* v1=mat.row_lst[i]->head;
		Node* v2=NULL;
		if(vect.n_rows>0) v2=vect.row_lst[0]->head;
		int ans=0;
		int j=1;
		while(v2==NULL&&j<vect.n_rows) {v2=vect.row_lst[j]->head; j++;}
		while(v1!=NULL&&v2!=NULL&&j<=vect.n_rows){
			if(v1->col_ind==(j-1)) {
				ans+=v1->val*v2->val;
				v1=v1->next;
				if(j<vect.n_rows) {v2=vect.row_lst[j]->head; j++;}
				else v2=NULL;
				while(v2==NULL&&j<vect.n_rows) {v2=vect.row_lst[j]->head; j++;}	
			}
			else if(v1->col_ind>(j-1)){
				if(j<vect.n_rows) {v2=vect.row_lst[j]->head; j++;}
				else v2=NULL;
				while(v2==NULL&&j<vect.n_rows) {v2=vect.row_lst[j]->head; j++;}	
			}  
			else{
				v1=v1->next;
			}
		}
		llist_append(lst,0,ans);
		r[i]=lst;	
	}
	res.row_lst=r;
	res.n_rows=mat.n_rows;
	return res;
}
		
/*Add two matrices*/
Matrix add(Matrix a, Matrix b){
	Matrix res;
	int i;
	LList** r;
	r=(LList**)malloc(a.n_rows*sizeof(LList*));
	for(i=0;i<a.n_rows;i++){
		LList* lst=llist_new();
		Node* v1=a.row_lst[i]->head;
		Node* v2=b.row_lst[i]->head;
		while(v1!=NULL&&v2!=NULL){
			if(v1->col_ind==v2->col_ind) {
				llist_append(lst,v1->col_ind,v1->val+v2->val);
				v1=v1->next;
				v2=v2->next;
			}
			else if(v1->col_ind>v2->col_ind){
				llist_append(lst,v2->col_ind,v2->val);
				v2=v2->next;
			}  
			else{
				llist_append(lst,v1->col_ind,v1->val);
				v1=v1->next;
			}
		}
		while(v1!=NULL){
			llist_append(lst,v1->col_ind,v1->val);
			v1=v1->next;
		}
		while(v2!=NULL){
			llist_append(lst,v2->col_ind,v2->val);
			v2=v2->next;
		}
		r[i]=lst;		
	}
	res.row_lst=r;
	res.n_rows=a.n_rows;
	return res;
}

/*Subtract Matrix b from a*/
Matrix subtract(Matrix a, Matrix b){
	Matrix res;
	int i;
	LList** r;
	r=(LList**)malloc(a.n_rows*sizeof(LList*));
	for(i=0;i<a.n_rows;i++){
		LList* lst=llist_new();
		Node* v1=a.row_lst[i]->head;
		Node* v2=b.row_lst[i]->head;
		while(v1!=NULL&&v2!=NULL){
			if(v1->col_ind==v2->col_ind) {
				llist_append(lst,v1->col_ind,v1->val-v2->val);
				v1=v1->next;
				v2=v2->next;
			}
			else if(v1->col_ind>v2->col_ind){
				llist_append(lst,v2->col_ind,-v2->val);
				v2=v2->next;
			}  
			else{
				llist_append(lst,v1->col_ind,v1->val);
				v1=v1->next;
			}
		}
		while(v1!=NULL){
			llist_append(lst,v1->col_ind,v1->val);
			v1=v1->next;
		}
		while(v2!=NULL){
			llist_append(lst,v2->col_ind,-v2->val);
			v2=v2->next;
		}
		r[i]=lst;		
	}
	res.row_lst=r;
	res.n_rows=a.n_rows;
	return res;
}

