/*
 * Author:G.Kavitha
 * Roll No. CS15B057
 * Sparse Matrix
 */
#include "SparseMatrix.h"
#include <stdio.h>
#include <stdlib.h>
int inp1(Matrix* a, Matrix* b){
	int m,n;
	scanf("%d %d",&m,&n);
	int i,j,k;
	LList** lsta;
	lsta=(LList**)malloc(m*sizeof(LList*));
	for(i=0;i<m;i++){
		LList* temp=llist_new();
		lsta[i]=temp;
		for(j=0;j<n;j++){
			scanf("%d",&k);
			if(k!=0)
				llist_append(lsta[i],j,k);
		} 
	}
	(*a).row_lst=lsta;
	(*a).n_rows=m;
	LList** lstb;
	lstb=(LList**)malloc(m*sizeof(LList*));
	for(i=0;i<m;i++){
		LList* temp=llist_new();
		lstb[i]=temp;
		for(j=0;j<n;j++){
			scanf("%d",&k);
			if(k!=0)
				llist_append(lstb[i],j,k);
		} 
	}
	(*b).row_lst=lstb;
	(*b).n_rows=m;
	return n;
}
void inp2(Matrix* a, Matrix* b){
	int m,n;
	scanf("%d %d",&m,&n);
	int i,j,k;
	LList** lsta;
	lsta=(LList**)malloc(m*sizeof(LList*));
	for(i=0;i<m;i++){
		LList* temp=llist_new();
		lsta[i]=temp;
		for(j=0;j<n;j++){
			scanf("%d",&k);
			if(k!=0)
				llist_append(lsta[i],j,k);
		} 
	}
	(*a).row_lst=lsta;
	(*a).n_rows=m;
	LList** lstb;
	lstb=(LList**)malloc(n*sizeof(LList*));
	for(i=0;i<n;i++){
		LList* temp=llist_new();
		lstb[i]=temp;
		scanf("%d",&k);
		if(k!=0)
			llist_append(lstb[i],0,k); 
	}
	(*b).row_lst=lstb;
	(*b).n_rows=n;
}
void disp(Matrix a,int n){
	int i;
	for(i=0;i<a.n_rows;i++){
		Node* v=a.row_lst[i]->head;
		int j=0;
		while(v!=NULL){
			printf("%d ",v->val);
			v=v->next;
			if(v==NULL) printf("\n");
		}
//		printf("\n");
	}
}
int main(){
	int op;
	scanf("%d",&op);
	while(op!=-1){
		Matrix a,b,res;
		int n;
		switch(op){
			case 1:	n=inp1(&a,&b);
					res=add(a,b);
					disp(res,n);
					break;
			case 2: n=inp1(&a,&b);
					res=subtract(a,b);
					disp(res,n);
					break;
			case 3: inp2(&a,&b);
					res=matrix_vect_multiply(a,b);
					disp(res,1);
					break;
		}
		scanf("%d",&op);
	}
	return 0;
}
