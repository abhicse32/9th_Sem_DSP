/*File that contains function definitiones for Xircular Linked List operations, Author:B Arjun,CS15B058*/
#include "CList.h"
#include<stdio.h>
#include<stdlib.h>

// Create a new node with next set to NULL
CNode* cnode_new( int data)
{
	CNode* nd=(CNode*)malloc(sizeof(CNode));
	if(nd!=NULL)
	{
		nd->data=data;
		nd->next=NULL;
		return nd;
	}
	return nd;
}

// Create an empty list (head shall be NULL)
CList* clist_new()
{
	CList* list=(CList*)malloc(sizeof(CList));
	list->head=NULL;
	return list;
}

// Traverse the linked list and return its size
int clist_size( CList* lst )
{
	CNode* np=lst->head;
	if(np==NULL)
		return 0;
	int size=1;
	np=np->next;
	while(np!=lst->head)			//to reach last element
	{
		size++;
		np=np->next;
	}
	return size;
}

// Traverse the linked list and print each element
void clist_print( CList* lst )
{
	CNode* np=lst->head;
	if(np!=NULL)
	{
		while(np->next!=lst->head)			//to reach last element
		{
			printf("%d ",np->data);
			np=np->next;
		}
		printf("%d ",np->data);			//to print last element
		printf("\n");
	}
}

//get the element at position @idx
int clist_get( CList* lst, int idx )
{
	CNode* np=lst->head;
	int counter=0;
	if(np!=NULL)			//if list is non empty
	{	
		do
		{
			if(counter==idx)		
			{
				return np->data;
			}
			else
			{
				np=np->next;
				counter++;
			}
		}while(np!=lst->head);		
	}
	return -1;		//if element is not found we return -1
}

// Add a new element at the end of the list
void clist_append( CList* lst, int data )
{
	CNode* np=lst->head;
	if(np==NULL)						//If the list is empty
	{
		lst->head=cnode_new(data);
		lst->head->next=lst->head;
	}
	else
	{
		while(np->next!=lst->head)			//To reach last element
		{
			np=np->next;
		}
		np->next=cnode_new(data);		
		np->next->next=lst->head;
	}
}

// Add a new element at the beginning of the list
void clist_prepend( CList* lst, int data )
{
	
	if(lst->head!=NULL)
	{
		CNode* np=cnode_new(data);
		np->next=lst->head;
		lst->head=np;
		CNode *temp=lst->head->next;
		while(temp->next!=lst->head->next)			//To reach last element
			temp=temp->next;
		temp->next=lst->head;					//to make next of last element point to new head
	}
	else										//if list is empty
		clist_append(lst,data);
}

// Add a new element at the @idx index
void clist_insert( CList* lst, int idx, int data )
{
	int counter=0;
	CNode* np=lst->head;
	if(np==NULL&&idx==0)							//If the list is empty and idx=0
	{
		lst->head=cnode_new(data);
		lst->head->next=lst->head;
	}
	else
	{
		if(idx==0)			//If we have to add element at 0th index
		{
			clist_prepend(lst,data);				
		}
		else
		{
			do
			{
				if(counter==idx-1)		//To find element just before required index
				{
					CNode* temp=np->next;
					np->next=cnode_new(data);
					np->next->next=temp;
					break;
				}
				counter++;
				np=np->next;
			}while(np!=lst->head);
		}
	}
}

// Remove an element from the end of the list
void clist_remove_last( CList* lst )
{
	CNode* np=lst->head;
	if(np!=NULL)
	{
		if(np->next!=lst->head)			//if theres more than 1 element
		{
			while(np->next->next!=lst->head)	//till 2nd last element
			{
				np=np->next;
			}
			CNode* del=np->next;
			np->next=lst->head;
			free(del);
		}
		else						//if theres only 1 element
		{
			CNode* del=np;
			free(np);
			lst->head=NULL;
		}
	}
}

// Remove an element from the beginning of the list
void clist_remove_first( CList* lst )
{
	CNode* del=lst->head;
	if(del!=NULL)
	{
		if(del->next==lst->head)		//if theres only 1 element
			clist_remove_last(lst);
		else
		{
			lst->head=lst->head->next;
			CNode *temp=lst->head->next;
			while(temp->next!=del)			//To reach last element
				temp=temp->next;
			temp->next=lst->head;
			free(del);
		}
	}
	
}

// Remove an element from an arbitrary @idx position in the list
void clist_remove( CList* lst, int idx )
{
	if(lst->head!=NULL)			//if list is not empty
	{
		
		int counter=0;
		CNode* np=lst->head;
		if(idx==0)				//if we have to delete at 0th index
		{
			clist_remove_first(lst);
		}
		else if(np->next!=lst->head)	//if theres more than one element
		{
			do
			{
				if(counter==idx-1&&np->next!=lst->head)	//If we reach element just before index or till we reach last element
				{
					CNode* del=np->next;
					np->next=np->next->next;
					free(del);
					break;
				}
				counter++;
				np=np->next;
			}while(np!=lst->head);		
		}	
	}	
}

// reverse the list
void clist_reverse(CList* lst)
{
	
	CNode* npp=lst->head;			//to store previous element
	CNode* npn;						//to store next element
	CNode* newhead;					//to store head after reversing

	if(npp!=NULL)					//to check if list is empty
	{
		CNode* np=lst->head->next;			//to store current element
		if(np!=NULL)				//to check if list has more than one element
		{
			do
			{	
				npn=np->next;		//to store next element in npn
				if(npn==lst->head)		//to store the new head when we reach last element
					newhead=np;
				np->next=npp;		//to make next point to previous element
				npp=np;
				np=npn;
			}while(npp!=lst->head);			//iterate till previous element becomes old head
			lst->head=newhead;
		}
	}
}
