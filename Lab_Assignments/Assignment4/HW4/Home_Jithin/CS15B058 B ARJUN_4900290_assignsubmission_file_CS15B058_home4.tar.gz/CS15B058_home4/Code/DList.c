/*File that contains function definitiones for Double Linked List operations, Author:B Arjun,CS15B058*/
#include "DList.h"
#include<stdio.h>
#include<stdlib.h>

/*Function to create a new node*/
DNode* dnode_new(int data)
{
	DNode* nd=(DNode*)malloc(sizeof(DNode));
	if(nd!=NULL)
	{
		nd->data=data;
		nd->next=NULL;
		nd->prev=NULL;
		return nd;
	}
	return nd;
}


// Create an empty list (head shall be NULL)
DList* dlist_new()
{
	DList* list=(DList*)malloc(sizeof(DList));
	list->head=NULL;
	return list;
}

// Traverse the linked list and return its size
int dlist_size( DList* lst )
{
	int size=0;
	DNode* np=lst->head;
	while(np!=NULL)
	{
		size++;
		np=np->next;
	}
	return size;
}

// Traverse the linked list and print each element
void dlist_print( DList* lst )
{
	DNode* np=lst->head;
	while(np!=NULL)
	{
		printf("%d ",np->data);
		np=np->next;
	}
	printf("\n");
}

//get the element at position @idx
int dlist_get( DList* lst, int idx )
{
	DNode* np=lst->head;
	int counter=0;
	while(np!=NULL)
	{
		if(counter==idx)
		{
			return np->data;
		}
		else
		{
			np=np->next;
			counter++;
		}
	}
	return -1;	
}

// Add a new element at the end of the list
void dlist_append( DList* lst, int data )
{
	DNode* np=lst->head;
	if(np==NULL)
	{
		lst->head=dnode_new(data);
	}
	else
	{
		while(np->next!=NULL)
		{
			np=np->next;
		}
		np->next=dnode_new(data);
		np->next->prev=np;
	}

}

// Add a new element at the beginning of the list
void dlist_prepend( DList* lst, int data )
{

	DNode* np=dnode_new(data);
	np->next=lst->head;
	if(lst->head!=NULL)					//only if the list is not empty
		lst->head->prev=np;
	lst->head=np;
}

// Add a new element at the @idx index
void dlist_insert( DList* lst, int idx, int data )
{
	int counter=0;
	DNode* np=lst->head;
	if(np==NULL&&idx==0)							//If the list is empty and idx=0
	{
		dlist_append(lst,data);
	}
	else
	{
		if(idx==0)			//If we hav to add element at 0th index
		{
			dlist_prepend(lst,data);				
		}
		else
		{
			while(np!=NULL)
			{
				if(counter==idx-1)		//To find element just before required index
				{
					DNode* ins=dnode_new(data);
					if(np->next!=NULL)	//If its not the last element
					{
						np->next->prev=ins;
						ins->next=np->next;
					}
					np->next=ins;
					ins->prev=np;
					break;
				}
				counter++;
				np=np->next;
			}
		}
	}

}

// Remove an element from the end of the list
void dlist_remove_last( DList* lst )
{
	DNode* np=lst->head;
	if(np!=NULL)
	{
		while(np->next!=NULL)	//to get last element
			np=np->next;
		DNode* del=np;
		if(np->prev!=NULL)		//if theres more than one element
			np->prev->next=NULL;
		else
			lst->head=NULL;
		free(del);
	}
}

// Remove an element from the beginning of the list
void dlist_remove_first( DList* lst )
{
	DNode* del=lst->head;
	if(del!=NULL)
	{
		if(lst->head->next!=NULL)
			lst->head->next->prev=NULL;
		lst->head=lst->head->next;
		free(del);
	}
}

// Remove an element from an arbitrary @idx position in the list
void dlist_remove( DList* lst, int idx )
{
	if(lst->head!=NULL)			//if list is not empty
	{
		
		int counter=0;
		DNode* np=lst->head;
		if(idx==0)				//if we have to delete at 0th index
			dlist_remove_first(lst);
		else
		{
			while(np!=NULL)		
			{
				if(counter==idx-1)	//If we reach element just before index
				{
					DNode* del=np->next;
					np->next=del->next;
					if(np->next!=NULL)			//if its not the last element
						np->next->prev=np;
					free(del);
					break;
				}
				counter++;
				np=np->next;
			}
		}	
	}	
}

void dlist_reverse(DList* lst)
{
	DNode* np=lst->head;
	while(np!=NULL)
	{
	  	DNode* temp=np->next;
		np->next=np->prev;
		np->prev=temp;
		if(np->prev==NULL)			//if we reach last element
			lst->head=np;
		np=np->prev;

	}
}


