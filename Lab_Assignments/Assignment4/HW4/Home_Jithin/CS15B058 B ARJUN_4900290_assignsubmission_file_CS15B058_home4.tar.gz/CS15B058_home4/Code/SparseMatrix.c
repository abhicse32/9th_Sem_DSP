/*File containing Function definitions for Matrix operations, Author: B Arjun, CS15B058*/
#include "SparseMatrix.h"
#include<stdio.h>
#include<stdlib.h>

/*Multiply an M x N matrix with N X 1 vector*/
Matrix matrix_vect_multiply(Matrix mat, Matrix vect)
{
	Matrix C;
	C.n_rows=mat.n_rows;
	int i,j;
	C.row_lst=(LList**)malloc(C.n_rows*sizeof(LList*));					//To allocate memory for new matrix
	for(i=0;i<mat.n_rows;i++)
	{
		C.row_lst[i]=llist_new();							//to initialise head in each list to NULL
		int sum=0;
		Node* npmat=mat.row_lst[i]->head;
		
		j=0;
		while(j<vect.n_rows&&npmat!=NULL)					//Multiply till npmat==NULL or j=no. of rows of vector
		{
			if(vect.row_lst[j]->head==NULL)					//If a row of vector is empty we skip it
				j++;
			else
			{
				int vectval=vect.row_lst[j]->head->val;
				if(npmat->col_ind==j)						//when both elements are in the same column
				{
					sum+=(npmat->val)*(vectval);
					npmat=npmat->next;
					j++;
				}
				else if(npmat->col_ind<j)					
					npmat=npmat->next;
				else
					j++;
			}			
		}
		
		llist_append(C.row_lst[i],0,sum);			//the sum which is found is to be appended
	}
	return C;
}

/*Add two matrices*/
Matrix add(Matrix A, Matrix B)
{
	Matrix C;
	C.n_rows=A.n_rows;
	int i,j;
	C.row_lst=(LList**)malloc(C.n_rows*sizeof(LList*));	
	for(i=0;i<A.n_rows;i++)
	{
		C.row_lst[i]=llist_new();
		Node* npa=A.row_lst[i]->head;
		Node* npb=B.row_lst[i]->head;
		while(npa!=NULL||npb!=NULL)				//Till both the rows end for each matrix
		{
			if(npa==NULL)						//if row of matrix A is already traversed
			{
				llist_append(C.row_lst[i],npb->col_ind,npb->val);
				npb=npb->next;
			}
			else if(npb==NULL)					//if row of matrix B is already traversed
			{
				llist_append(C.row_lst[i],npa->col_ind,npa->val);
				npa=npa->next;
			}
			else
			{
				if(npa->col_ind==npb->col_ind)		//if the col indices are equal we add the values
				{
					int val=npa->val+npb->val;
					llist_append(C.row_lst[i],npa->col_ind,val);
					npa=npa->next;
					npb=npb->next;
				}
				else if(npa->col_ind<npb->col_ind)
				{
					llist_append(C.row_lst[i],npa->col_ind,npa->val);
					npa=npa->next;
				}
				else
				{
					llist_append(C.row_lst[i],npb->col_ind,npb->val);
					npb=npb->next;
				}
			}
		}
	}
	return C;
}

/*Subtract Matrix b from a*/
Matrix subtract(Matrix A, Matrix B)
{
	Matrix C;
	C.n_rows=A.n_rows;
	int i,j;
	C.row_lst=(LList**)malloc(C.n_rows*sizeof(LList*));
	for(i=0;i<A.n_rows;i++)
	{
		C.row_lst[i]=llist_new();
		Node* npa=A.row_lst[i]->head;
		Node* npb=B.row_lst[i]->head;
		while(npa!=NULL||npb!=NULL)					//Till both the rows end for each matrix
		{
			if(npa==NULL)							//if row of Matrix A is already traversed
			{
				llist_append(C.row_lst[i],npb->col_ind,-(npb->val));
				npb=npb->next;
			}
			else if(npb==NULL)						//if row of Matrix B is already traversed
			{
				llist_append(C.row_lst[i],npa->col_ind,npa->val);
				npa=npa->next;
			}
			else
			{
				if(npa->col_ind==npb->col_ind)			//if col indices are euqal we subtract the values
				{
					int val=npa->val-npb->val;
					llist_append(C.row_lst[i],npa->col_ind,val);
					npa=npa->next;
					npb=npb->next;
				}
				else if(npa->col_ind<npb->col_ind)
				{
					llist_append(C.row_lst[i],npa->col_ind,npa->val);
					npa=npa->next;
				}
				else
				{
					llist_append(C.row_lst[i],npb->col_ind,-(npb->val));
					npb=npb->next;
				}
			}
		}
	}
	return C;
}