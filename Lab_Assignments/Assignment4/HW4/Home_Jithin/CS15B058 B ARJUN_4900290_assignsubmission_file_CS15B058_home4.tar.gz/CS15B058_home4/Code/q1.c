#include<stdio.h>
#include<stdlib.h>
#include "SparseMatrix.h"
#include "List.h"

int main(void)
{
	int option=1;
	while(option!=-1)
	{
		scanf("%d",&option);
		switch(option)
		{
			case 1:
				{
					int m,n;
					scanf("%d %d",&m,&n);
					int i,j;
					Matrix A,B;
					A.n_rows=m;
					B.n_rows=m;
					A.row_lst=(LList**)malloc(m*sizeof(LList*));			//To allocate memory for the matrix A
					for(i=0;i<m;i++)									//To take input for matrix A
					{
						A.row_lst[i]=llist_new();
						for(j=0;j<n;j++)
						{
							int val;
							scanf("%d",&val);
							if(val!=0)
								llist_append(A.row_lst[i],j,val);
						}
					}

					B.row_lst=(LList**)malloc(m*sizeof(LList*));
					for(i=0;i<m;i++)								//To take input for matrix B
					{
						B.row_lst[i]=llist_new();
						for(j=0;j<n;j++)
						{
							int val;
							scanf("%d",&val);
							if(val!=0)
								llist_append(B.row_lst[i],j,val);
						}
					}
					
					Matrix C=add(A,B);
					for(i=0;i<m;i++)
					{
						if(llist_size(C.row_lst[i])!=0)
						{
							llist_print(C.row_lst[i]);
						}
					}
					break;
				}
			case 2:
				{
					int m,n;
					scanf("%d %d",&m,&n);
					int i,j;
					Matrix A,B;
					A.n_rows=m;
					B.n_rows=m;
					A.row_lst=(LList**)malloc(m*sizeof(LList*)); 
					for(i=0;i<m;i++)	
					{
						A.row_lst[i]=llist_new();
						for(j=0;j<n;j++)
						{
							int val;
							scanf("%d",&val);
							if(val!=0)
								llist_append(A.row_lst[i],j,val);
						}
					}
					B.row_lst=(LList**)malloc(m*sizeof(LList*));
					for(i=0;i<m;i++)
					{
						B.row_lst[i]=llist_new();
						for(j=0;j<n;j++)
						{
							int val;
							scanf("%d",&val);
							if(val!=0)
								llist_append(B.row_lst[i],j,val);
						}
					}
					
					Matrix C=subtract(A,B);
					for(i=0;i<m;i++)
					{
						if(llist_size(C.row_lst[i])!=0)
						{
							llist_print(C.row_lst[i]);
						}
					}
					break;
				}
			case 3:
				{
					int m,n;
					scanf("%d %d",&m,&n);
					int i,j;
					Matrix A,B;
					A.n_rows=m;
					B.n_rows=n;
					A.row_lst=(LList**)malloc(m*sizeof(LList*));
					for(i=0;i<m;i++)						//To take input for Matrix A
					{	
						A.row_lst[i]=llist_new();
						for(j=0;j<n;j++)
						{
							int val;
							scanf("%d",&val);
							if(val!=0)
								llist_append(A.row_lst[i],j,val);
						}
					}
					B.row_lst=(LList**)malloc(n*sizeof(LList*));
					for(i=0;i<n;i++)						//To take input for Vector B
					{
						B.row_lst[i]=llist_new();
						int val;
						scanf("%d",&val);
						if(val!=0)
							llist_append(B.row_lst[i],0,val);
					}
					
					Matrix C=matrix_vect_multiply(A,B);
					for(i=0;i<m;i++)
					{
						if(llist_size(C.row_lst[i])!=0)
						{
							llist_print(C.row_lst[i]);
						}
					}
					break;
				}	
		}
	}
	return 0;
}