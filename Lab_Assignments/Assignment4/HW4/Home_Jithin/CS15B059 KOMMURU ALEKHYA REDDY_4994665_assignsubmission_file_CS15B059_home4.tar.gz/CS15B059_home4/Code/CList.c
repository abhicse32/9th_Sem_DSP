/* KOMMURU ALEKHYA REDDY
   CS15B059
   4SEPT2016
   OPERATIONS ON A CIRCULAR LINKED LIST
*/     
#include "CList.h"
#include<stdio.h>
#include<limits.h>
#include<stdlib.h>

//to create a new node and point its next pointer to NULL
CNode* cnode_new( int data)
{
        CNode * temp=(CNode *)malloc(sizeof(CNode));
        temp->data=data;
        temp->next=temp;
        return(temp);
}

//to create a new list by pointing the head pointer to NULL
CList* clist_new()
{
        CList * lst=(CList *)malloc(sizeof(CList));
        lst->head=NULL;
        return(lst);
}

//to get the size of the list by incrementing the pointer till it is equal to head
int clist_size( CList* lst )
{
        int size=1;
        CNode * temp=lst->head;
        if(lst->head==NULL)
                return 0;
        while(temp->next!=lst->head)
        {
                temp=temp->next;//if it is equal to head then stop
                size++;
        }        
        return size;
}

//to print all the elements in the circular list till the pointer points back to head again
void clist_print( CList* lst )
{
        CNode * temp=lst->head;
        if(temp->next==lst->head)//only one element
                {
                printf("%d ",temp->data);
                printf("\n");
                }
        else//print the remaining elements
        {
        printf("%d ",temp->data);
        temp=temp->next;
        while(temp!=lst->head)
        {
                printf("%d ",temp->data);//print the element
                temp=temp->next;//increment the pointer
        }
        printf("\n");
        }
}

//to get an element at the index idx
int clist_get( CList* lst, int idx )
{
        int s=clist_size(lst);
        if(idx > s)
            return -1;
        int element;
        CNode *temp=lst->head;
        int count=0;//have a variabe which gets incremented till the index
        while(count<idx)
        {
                temp=temp->next;//increment the temp variable
                count++;
        }
        element=temp->data;//element stores the data
        return element;//returns the element
        
}

//to add an element at the end of the list
void clist_append( CList* lst, int data )
{
        CNode * newnode=(CNode *)malloc(sizeof(CNode));
        newnode->data=data;
        if(lst->head==NULL)//if it is an empty list
                {
                lst->head=newnode;
                newnode->next=lst->head;
                }
        else
        {        
        CNode * temp=lst->head;
        while(temp->next!=lst->head)//if temp of next doesnt point to the head 
                temp=temp->next;//increment the temp pointer
        temp->next=newnode;//store the address of newnode in temp->next
        newnode->next=lst->head;//make the new node point to the head
        }
}

//to add an element at the beginning of the list
void clist_prepend( CList* lst, int data )
{
        CNode * newnode=(CNode *)malloc(sizeof(CNode));
        newnode->data=data;//create a new node and store data
        CNode * temp=lst->head;
        if(temp!=NULL)
        {    
        while(temp->next!=lst->head)
        {
                temp=temp->next;//increment temp variable
        }
        newnode->next=lst->head;//make the new node point to where the head was pointing before
        lst->head=newnode;//the head is now made to point to the newnode
        temp->next=newnode;//the last node now points to newnode to complete the cycle
        }
        else
        {
            lst->head=newnode;
            newnode->next=newnode;
        }        

}

//to insert an element at any index
void clist_insert( CList* lst, int idx, int data )
{
        int size= clist_size( lst );
       if(idx ==0)
       {
         clist_prepend( lst, data ); //if the index is 0,you have to prepend it       
       }  
        else if(idx != size && idx < size)//if it is not the last element but anywhere in between
        {     
        CNode * newnode=(CNode *)malloc(sizeof(CNode));
        newnode->data=data;
        CNode *temp=lst->head;
        int count=0;
        while(count<idx-1)//increment the pointer till it points to the element after which you have to insert the element
        {
               temp=temp->next; 
               count++; 
        }
        newnode->next=temp->next;//insert the node
        temp->next=newnode;
        }
        else if(idx == size)//if it is the last element
        {
                clist_append( lst, data );       
        }
        else;
       
}

//remove the last node of the list
void clist_remove_last( CList* lst )
{
        CNode * temp=lst->head;
        if(temp->next==lst->head)//only single element in the list
         {
                free(temp);//free the node
                lst->head=NULL;//point head to NULL
         }      
        else
        {       
        while(temp->next->next!=lst->head)//go to the last but one element
                temp=temp->next;
        CNode * p=temp->next;// make a new pointer point to the element we have to delete
        temp->next=lst->head;//make the present pointer's next point to head
        free(p);  //free the new pointer
        }       
}

//to remove the first element of the list
void clist_remove_first( CList* lst )
{
        CNode * temp=lst->head;
         if(temp->next==lst->head)//if there is only one element in the list
        lst->head=NULL;//make the head pointer point to NULL
        else
        {
        while(temp->next!=lst->head)//increment temp till its next points to head again
                temp=temp->next;
        CNode * del=lst->head;//make the delete pointer point to head     
        lst->head=lst->head->next;//point head to its next
        temp->next=lst->head;//now point temp back head
        free(del);//free the delete pointer
        }                
}

//to remove any node when the index is given
void clist_remove( CList* lst, int idx )
{
        int s=clist_size(lst);
        int count=0;
        if(idx==0)//if its the first element do as we did in the previous function
        {     
                CNode * temp=lst->head;
                while(temp->next!=lst->head)
                temp=temp->next;
                lst->head=lst->head->next;
                temp->next=lst->head;     
        }
        else
        {//increment count till its next element id the one which should be deleted
        CNode * temp=lst->head;
        if(idx<s)
        {
        while(count<(idx-1))
        {
                temp=temp->next;            
                count++;
        }   
        CNode * p=temp->next;//make a new pointer point to the next element of temp
        temp->next=temp->next->next;//make temp point to the next to next element
        free(p); //free the new pointer
        }
        }
}

// to reverse a circular list
void clist_reverse(CList* lst)
{
        CNode * temp=lst->head->next;
        CNode * prev=lst->head;
        CNode *nextp;
        lst->head->next=NULL;//first make the next of the first element point to NULL
        while(temp)
        {
                nextp=temp->next;//while temp is not NULL
                temp->next=prev;//temp of next points to the prev pointer
                lst->head=temp;//change the head pointer and make it point to temp
                prev=temp;//increment the prev and temp pointers
                temp=nextp;
        }
      lst->head=prev->next;//when temp becomes NULL prev is the last element and it points to the first element ,hence the head pointer must be made to point to the next of the previous pointer which is nothing but the first element
}



