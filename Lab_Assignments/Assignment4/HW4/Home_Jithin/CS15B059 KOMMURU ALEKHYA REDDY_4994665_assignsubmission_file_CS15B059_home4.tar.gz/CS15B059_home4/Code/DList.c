/* KOMMURU ALEKHYA REDDY
   CS15B059
   4SEPT2016
   OPERATIONS ON A DOUBLE LINKED LIST
*/
 #include "DList.h"
#include<stdio.h>
#include<limits.h>
#include<stdlib.h>

//to create a new node  by making both its pointers NULL
DNode* dnode_new( int data)
{
        DNode * newnode=(DNode *)malloc(sizeof(DNode));
        newnode->data=data;
        newnode->prev=NULL;
        newnode->next=NULL;
}

//to  create a new list by pointing its head to NULL and allocating space using malloc
DList* dlist_new()
{
        DList * newlst=(DList *)malloc(sizeof(DList));
        newlst->head=NULL;
}
//to get the size of a list
int dlist_size( DList* lst )
{
        int size=0;//initialise it to 0
        DNode * temp=lst->head;
        while(temp!=NULL)//increment temp till it is equal to NULL
        {
                size++;//increment size 
                temp=temp->next;//make temp point to the next element
        }     
        return size;//return size
}

//to print all the elements of the linked list
void dlist_print( DList* lst )
{
        DNode * temp=lst->head;
        while(temp!=NULL)
        {
                printf("%d ",temp->data);//print the element
                temp=temp->next;//increment the temp pointer
        }
        printf("\n");//go to a new line after printing all the elements of a list
}

//to get an element at a given index 
int dlist_get( DList* lst, int idx )
{
        int count=0;
        DNode * temp=lst->head;//point temp to the head
        int size=dlist_size(lst );//to get the size of the list
        if(idx<size-1)
        {
        while(count<idx)
        {
                count++;//increment count
                temp=temp->next;//make it point to the next element
        }
        return temp->data;//returns the data
        }
        else
                return -1;//else returns -1 if index is not in bounds
        
}

//to add an element at the end of the double linked list
void dlist_append( DList* lst, int data )
{
        DNode * newnode=(DNode *)malloc(sizeof(DNode));
        newnode->data=data;
        newnode->next=NULL;
        DNode *temp=lst->head;
        if(temp==NULL)//if there is no element then we have to make all the links
        {                        
         lst->head=newnode;//make the head point to that element
         newnode->prev=NULL;//make the prev pointer of the newnode NULL       
        }
        else
        {
        while(temp->next!=NULL)
                temp=temp->next;//increment temp till its the last but one element
        temp->next=newnode;//temp now points to newnode
        newnode->prev=temp;//make the prev of the newnode point to temp          
        }
}

//to add an element at the starting of the list
void dlist_prepend( DList* lst, int data )
{
        if(lst->head==NULL)//if it is NULL
        {
        DNode * newnode=(DNode *)malloc(sizeof(DNode));
        newnode->data=data;
        newnode->prev=NULL;
        newnode->next=NULL;
        lst->head=newnode;
        }
         else//if it is not NULL, then you have to add an element using head directly
        {
        DNode * newnode=(DNode *)malloc(sizeof(DNode));
        DNode * temp=lst->head;
        newnode->data=data;
        newnode->prev=NULL;
        newnode->next=temp;//newnodes next points to the previous first element
        temp->prev=newnode;//temp's prev pointer points to newnode
        lst->head=newnode;//head pointer points to the newnode
        }
}

//insert an element at any given index 
void dlist_insert( DList* lst, int idx, int data )
{
        int size;
        size=dlist_size( lst );
        if(idx==0)//if the index is 0 then prepend the element
                dlist_prepend( lst,data );
        else if(idx==size)//if it is the last element then append it
        {
              dlist_append(lst,data);   
        }
        else if(idx < 0 || idx > size){//if index is invalid then just return nothing,to avoid a segmentation fault
                return;
        }
        else 
        {
                DNode * newnode=(DNode *)malloc(sizeof(DNode));
                DNode * temp=lst->head;//initialise temp to head 
                newnode->data=data;
                int count=0;
                while(count< idx-1)//increment count till you reach the prev index 
                {
                        count++;
                        temp=temp->next;
                }
                newnode->next=temp->next;//insert the newnode 
                temp->next=newnode;
                newnode->prev=temp;
                newnode->next->prev=newnode;
        }        
}

//remove the last element of the list
void dlist_remove_last( DList* lst )
{
        if(lst->head == NULL)
                return;
        else if(lst->head->next==NULL)
                lst->head=NULL;
        else{                
        DNode * temp=lst->head;
        while(temp->next->next!=NULL)
                temp=temp->next;//increment temp till it points 
        DNode * del=temp->next;
        del->prev=NULL;//remove the links
        temp->next=NULL;//make temp the last pointer
        free(del);//free the last pointer   
        }     
}

//remove the first element 
void dlist_remove_first( DList* lst )
{
        DNode * temp=lst->head;
        lst->head=temp->next;//make the head point to the next of temp
        temp->next->prev=NULL;//the second element's prev is set to NULL
        temp->next=NULL;//the first element's next is set to NULL
        free(temp);//free the first node
}

//to remove the node at a given index
void dlist_remove( DList* lst, int idx )
{
        int size;
        size=dlist_size( lst );//get the size of the list
        if(idx==0)
        {
                dlist_remove_first(lst);
        }
        else if(idx==size-1)
        {
                dlist_remove_last(lst);
        }
        else if(idx> 0 && idx < size -1)
        {
                DNode * temp=lst->head;
                int count =0;
                
                while(count<idx-1)
                {
                        count++;
                        temp=temp->next;
                }
                temp->next=temp->next->next;//remove the element by adjusting the pointers 
                temp->next->prev=temp;
        }
        else ;        
                
}


//to reverse the list
void dlist_reverse(DList* lst)
{
        DNode * current=lst->head;//current points to the first node
        DNode * prevp;
        while(current!=NULL)
        {
                prevp=current->prev;//prevp pointers to the prev node of current
                current->prev=current->next;//current of previous points to the next node
                current->next=prevp;//currents next points to the previous pointer
                current=current->prev;//current points to its previous
        }
        if(prevp!=NULL)
        {
                lst->head=prevp->prev;//to check  the boundary conditions
        }
}       








