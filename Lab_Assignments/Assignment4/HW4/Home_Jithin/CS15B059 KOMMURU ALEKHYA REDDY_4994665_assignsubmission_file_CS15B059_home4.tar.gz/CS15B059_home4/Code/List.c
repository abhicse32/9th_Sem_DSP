/* KOMMURU ALEKHYA REDDY
   CS15B059
   4SEPT2016
   BASIC OPERATIONS ON A LINKED LIST
*/ 
#include "List.h"
#include<stdio.h>
#include<stdlib.h>

//to create a new node and inserting two values into it and making the next pointer point to NULL
Node* node_new( int data1, int data2)
{
        Node * newnode=(Node *)malloc(sizeof(Node));//dynamic memory allocation
        newnode->col_ind=data1;
        newnode->val=data2;
        newnode->next=NULL;
        return newnode;//returns the node that has been created
}

//to create a new list and making the head pointer point to NULL
LList* llist_new()
{
        LList * lst=(LList *)malloc(sizeof(LList));
        lst->head=NULL;
        return lst;//returns the list
}

//to get the size of a list
int llist_size( LList* lst )
{
        int size=0;
        Node * temp=lst->head;
        while(temp!=NULL)//increment size till temp points to null
        {
                temp=temp->next;
                size++;
        }        
        return size;//returns size
}

//to print all the elements of a list
void llist_print( LList* lst)
{
        Node * temp=lst->head;
        while(temp!=NULL)//till temp is not null
        {
        printf("%d ",temp->val);//prints the value
        temp=temp->next;//increments temp
        }
        printf("\n");
}

//to get the element at a given index
Node* llist_get( LList* lst, int idx )
{
	Node *temp=lst->head;
	Node * val=NULL;
	int size= llist_size( lst );
	if(idx==0)
	        return temp;//if it is the first element then return the node which is being pointed at by head
	  
	else if(idx<0||idx>size)
	        return val; //returns NULL if index is invalid    
	else
	{
	        int count=0;
	        while(count<idx)
	        {
	        temp=temp->next;
	        count++;//increment count till it is less then index
	        }
	        return temp;//returns temp
	}        
	
}

//adds a node at the end of the list 
void llist_append( LList* lst, int col, int value)
{
        
	Node *last=(Node *)malloc(sizeof(Node));
	last->val=value;
	last->col_ind=col;
	last->next=NULL;//creates memory dynamically and allots values to it
	if(lst->head==NULL)
	{
		lst->head=last;//make head point to last
	}
	else
	{
	Node * temp=lst->head;
	while(temp->next!=NULL)
		temp=temp->next;//increment temp till it becomes NULL
	temp->next=last;//make temp point to last
	}

}

//add an element at the beginning of the list
void llist_prepend( LList* lst, int col , int value)
{
        Node * first=(Node *)malloc(sizeof(Node));
	first->val=value;
	first->col_ind=col;
	first->next=lst->head;//create a node dynamically and insert values into it
	lst->head=first;
}

//to insert an element at the given index
void llist_insert( LList* lst, int idx, int col, int value)
{
        Node *element=(Node *)malloc(sizeof(Node));
	element->val=value;
	element->col_ind=col;//to create memory dynamically
	Node * temp=lst->head;
	int size=llist_size( lst );//get the size of the list
	int count=0;
	if(idx==0)
	{
		element->next=lst->head;
		lst->head=element;
	}//if index is 0 prepend the element	
	else if(idx<0 || idx>=size);
	else{
	while(count<(idx-1))
	{
		temp=temp->next;
		count++;
	}//if count is less than index then keep incrementing it
	element->next=temp->next;
	temp->next=element;//finally add the node
	}


}







