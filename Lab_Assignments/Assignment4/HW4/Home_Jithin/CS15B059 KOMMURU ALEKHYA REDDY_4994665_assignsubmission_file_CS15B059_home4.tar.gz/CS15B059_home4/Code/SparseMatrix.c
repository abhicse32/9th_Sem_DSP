/* KOMMURU ALEKHYA REDDY
   CS15B059
   4SEPT2016
   DEFINING ADDITION, MULTIPLICATION AND SUBTRACTION OPERATIONS ON MATRICES
*/
#include "SparseMatrix.h"
#include<stdio.h>
#include<stdlib.h>

//function which adds two matrices by taking two matrices as input
Matrix add(Matrix m1, Matrix m2)
{
        Matrix addition;
        addition.row_lst=(LList **)malloc(sizeof(LList)*m1.n_rows);
        int i;
        for(i=0;i<m1.n_rows;i++)
        {
        addition.row_lst[i]=llist_new();
        Node *a=llist_get(m1.row_lst[i],0);
        Node *b=llist_get(m2.row_lst[i],0);//making a and b point to the first nodes of each list
        while(a!=NULL && b!=NULL)
        {
        if(a->col_ind==b->col_ind)//add elements if the col index is the same
        {
                llist_append(addition.row_lst[i],a->col_ind,(a->val)+(b->val));
                a=a->next;
                b=b->next;
        }
        else if(a->col_ind<b->col_ind)//else increase the a or b pointer
        {
                llist_append(addition.row_lst[i],a->col_ind,a->val);
                a=a->next;
        }
        else
        {
                llist_append(addition.row_lst[i],b->col_ind,b->val);
                b=b->next;
        }
        }
        
        while(a!=NULL)//then append all the elements till we reach the end of one pointer
        {
                llist_append(addition.row_lst[i],a->col_ind,a->val);
                a=a->next;
        }
        
        while(b!=NULL)//repeat the same for the second pointer as well
        {
                llist_append(addition.row_lst[i],b->col_ind,b->val);
                b=b->next;
        }
        
        }
        return addition;//return the new matrix formed
}


Matrix subtract(Matrix m1, Matrix m2)
{
        Matrix sub;
        sub.row_lst=(LList **)malloc(sizeof(LList)*m1.n_rows);
        int i,ind =0;
       for(i=0;i<m1.n_rows;i++)
        {
        sub.row_lst[i]=llist_new();
        Node *a=llist_get(m1.row_lst[i],0);
        Node *b=llist_get(m2.row_lst[i],0);//making a and b point to the first nodes of two lists
         while(a!=NULL && b!=NULL)
        {
        if(a->col_ind==b->col_ind)//if the indices are equal then subtract the values
        {
                llist_append(sub.row_lst[i],a->col_ind,(a->val)-(b->val));
                a=a->next;
                b=b->next;
        }
        else if(a->col_ind<b->col_ind)
        {
                llist_append(sub.row_lst[i],a->col_ind,a->val);
                a=a->next;
        }
        else
        {
                llist_append(sub.row_lst[i],b->col_ind,-1*b->val);
                b=b->next;
        }
        }
        
        while(a!=NULL)//then append all the elements till we reach the end of one pointer
        {
                llist_append(sub.row_lst[i],a->col_ind,a->val);
                a=a->next;
        }
        
        while(b!=NULL)//repeat the same for the second pointer as well
        {
                llist_append(sub.row_lst[i],b->col_ind,-1*b->val);
                b=b->next;
        }
        }
        return sub;//return the new matrix formed
}

//to multiply two matrices
Matrix matrix_vect_multiply(Matrix mat, Matrix vect)
{
        int value=0;
        int value1=0;
        int data=0;
        int i,j;
        Matrix prod;
        prod.row_lst=(LList **)malloc(sizeof(LList)*mat.n_rows);
        for(i=0;i<mat.n_rows;i++)
        {
                prod.row_lst[i]=llist_new();//initialise the list
                Node * temp=mat.row_lst[i]->head;
                if(temp==NULL)
                    llist_append(prod.row_lst[i],0,data);//if it is a NULL pointer
                else{        
                for(j=0;j<vect.n_rows && temp!=NULL;j++)
                {
                        if(j==temp->col_ind)//if the col index is equal to the row index then multiply and store the sum
                        {
                               value=temp->val;
                               Node* a=llist_get(vect.row_lst[j],0);
                               value1=a->val; 
                               data += value * value1;
                               temp=temp->next;//increment the temp pointer
                        }
                        
                       
                }
                 llist_append(prod.row_lst[i],0,data);//append the data 
                        data=0;//initialise data to 0
                }
        }
        return prod;//return the new matrix formed
}


