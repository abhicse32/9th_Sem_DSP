/* KOMMURU ALEKHYA REDDY
   CS15B059
   4SEPT2016
   TO INPUT TWO MATRICES AND PERFORM OPERATIONS ON THEM
*/
#include"SparseMatrix.h"
#include<stdio.h>
#include<stdlib.h>
void main()
{
        int option,m,n,i,j,elm;
        scanf("%d",&option);
        Matrix matrix1,matrix2;
        while(option !=-1)//terminating condition
        {
        if(option==1)
        {
                scanf("%d %d",&m,&n);
                matrix1.row_lst=(LList **)malloc(sizeof(LList)*m);
                matrix2.row_lst=(LList **)malloc(sizeof(LList)*m);//allocate space for the matrices
                
                for(i=0;i<m;i++)//input elements into matrix 1
                {
                        matrix1.row_lst[i]=llist_new();
                        Node * temp=matrix1.row_lst[i]->head;
                        for(j=0;j<n;j++)
                        {
                                scanf("%d",&elm);
                                if(elm!=0)
                                llist_append(matrix1.row_lst[i],j,elm);//if the element is not zero then append it
                               
                        }
                
                }
                matrix1.n_rows=m;
                
                for(i=0;i<m;i++)//input value for matrix 2
                {
                        matrix2.row_lst[i]=llist_new();
                        Node * temp=matrix2.row_lst[i]->head;
                        for(j=0;j<n;j++)
                        {
                                scanf("%d",&elm);
                                if(elm!=0)
                                llist_append(matrix2.row_lst[i],j,elm);
                               
                        }
                
                }
                matrix2.n_rows=m;
                
                Matrix addition=add(matrix1,matrix2);//call the adition function 
                
                for(i=0;i<m;i++)
                {
                     if(addition.row_lst[i]->head!=NULL)
                        llist_print(addition.row_lst[i]);//to print the rows
                       
                               
                }
                scanf("%d",&option);//input the option again      
        }
        
        else if(option==2)
         {
                scanf("%d %d",&m,&n);
                matrix1.row_lst=(LList **)malloc(sizeof(LList)*m);
                matrix2.row_lst=(LList **)malloc(sizeof(LList)*m);//allocate memory space to the matrices
                
                for(i=0;i<m;i++)
                {
                        matrix1.row_lst[i]=llist_new();
                        Node * temp=matrix1.row_lst[i]->head;//initialise temp to head
                        for(j=0;j<n;j++)
                        {
                                scanf("%d",&elm);
                                if(elm!=0)
                                llist_append(matrix1.row_lst[i],j,elm);//append the element if it is not NULL
                                
                        }
                
                }
                matrix1.n_rows=m;
                
                for(i=0;i<m;i++)
                {
                        matrix2.row_lst[i]=llist_new();
                        Node * temp=matrix2.row_lst[i]->head;
                        for(j=0;j<n;j++)
                        {
                                scanf("%d",&elm);
                                if(elm!=0)
                                llist_append(matrix2.row_lst[i],j,elm);
                              
                        }
                
                }
                matrix2.n_rows=m;//do the same for the second matrix
                
                Matrix sub=subtract(matrix1,matrix2);//call the subtract function which subtracts two matrices 1 and 2
                
                for(i=0;i<m;i++)
                {
                    if(sub.row_lst[i]->head!=NULL)
                        llist_print(sub.row_lst[i]);//print the  rows of the matrix
                }
                scanf("%d",&option);//input option again
        }
        else if(option ==3)
          {
                scanf("%d %d",&m,&n);
                matrix1.row_lst=(LList **)malloc(sizeof(LList)*m);
                matrix2.row_lst=(LList **)malloc(sizeof(LList)*n);//allocate memory space for the 2 matrices
                
                for(i=0;i<m;i++)
                {
                        matrix1.row_lst[i]=llist_new();
                        Node * temp=matrix1.row_lst[i]->head;
                        for(j=0;j<n;j++)
                        {
                                scanf("%d",&elm);
                                if(elm!=0)//append the element if it is not 0
                                llist_append(matrix1.row_lst[i],j,elm);
                                
                        }
                
                }
                matrix1.n_rows=m;
                
                for(i=0;i<n;i++)
                {
                        matrix2.row_lst[i]=llist_new();
                        Node * temp=matrix2.row_lst[i]->head;
                        for(j=0;j<1;j++)
                        {
                                scanf("%d",&elm);
                                llist_append(matrix2.row_lst[i],j,elm);
                                
                        }
                
                }
                matrix2.n_rows=n;//do the same for matrix 2 as well
                
                Matrix mult=matrix_vect_multiply(matrix1,matrix2);//multiply the matrix with a vector
                
                for(i=0;i<m;i++)
                {
                        llist_print(mult.row_lst[i]);//print each row of the new matrix
                }
                scanf("%d",&option);//input the option to continue the process again
        }
        else
        {
                printf("Enter 1,2,3 to cont else enter -1"); 
                scanf("%d",&option);//if they enter anything else
        }
              
        }





}
