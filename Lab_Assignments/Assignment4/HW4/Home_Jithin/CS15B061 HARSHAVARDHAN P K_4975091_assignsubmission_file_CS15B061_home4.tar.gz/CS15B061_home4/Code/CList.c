/*-----------------------------------------------------------------------------
 *  Title: Program to implement operations on Circular linked list ADT
 *  Author: Harshavardhan.P.K.
 *  Roll No.: CS15B061
 *  Date: 4 September, 2016.	   
 *-----------------------------------------------------------------------------*/
#include "CList.h"
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>

// Create a new node with next set to NULL
CNode* cnode_new( int data){
	CNode* newNode = (CNode *)malloc(sizeof(CNode));
	newNode->next=NULL;
	newNode->data=data;
	return newNode;
}



// Create an empty list (head shall be NULL)
CList* clist_new(){
	CList* newList=(CList*)malloc(sizeof(CList));
	newList->head=NULL;
	return newList;
}

// Traverse the linked list and return its size
int clist_size( CList* lst ){
	CNode* cur = lst->head;
	if(cur==NULL) return 0;
	int ct=1;
	while((cur=cur->next)!=lst->head) ct++;
	return ct;
}

/*
dlist_print to print a Given dlist
Input: dlist* lst: the list to be printed.
Output: prints lst and return nothing.
*/
void clist_print( CList* lst ){
	CNode* cur = lst->head;
	if(cur==NULL) return ;
	printf("%d ",cur->data);

	//Transeverse the lst and prints cur->data till it reaches tail
	while((cur=cur->next)!=lst->head)
		printf("%d ",cur->data);
	putchar('\n');
}

/*
dlist_get : to get a specific elment of index idx in list
Input: dlist* lst: the list to find elemet
int idx: input index
Output: Returns the element in given index.
*/
int clist_get( CList* lst, int idx ){
	CNode* cur = lst->head;
	if(cur==NULL || idx<0) return -1;	//Invalid index
	int t=1;
	if(idx==0) return cur->data;
	while(t<=idx && (cur=cur->next)!=lst->head)
		t++;
	if(cur==lst->head) return -1;		// reached end of list
	return cur->data;
}

/*
dlist_prepend - to prepend an element to list
Input: dlist* lst - the list to prepend to
int data - the data of prepend node
*/
void clist_prepend( CList* lst, int data ){
	if(lst->head == NULL){ //if initially a empty list

		CNode* newNode=cnode_new(data);
		lst->head=newNode;
		newNode->next=newNode;
		return;
	}

	//insert newNode node
	int temp=lst->head->data;
	lst->head->data=data;
	CNode* newNode=cnode_new(temp);
	newNode->next=lst->head->next;//insert newNode in beginning
	lst->head->next=newNode;	//change value of head to point to newNode.
}

/*
function llist_append - append to end of list
Input: LList* lst - the to append to
int data - the elemnt to append
*/
void clist_append( CList* lst, int data ){
	if(lst->head==NULL) {clist_prepend(lst,data); return;}
	CNode *cur=lst->head;

	while((cur=cur->next)->next!=lst->head);	//find end of list
	//insert newNode node
	CNode* newNode = cnode_new(data);
	newNode->next=lst->head;
	cur->next=newNode;

}

/*
dlist_insert - to insert given element in index idx
Input: dlist* lst - the to append to
int data - the elemnt to append
int idx - index of inserted element

*/
void clist_insert( CList* lst, int idx, int data ){
	CNode* cur=lst->head;
	if(idx==0) {clist_prepend(lst,data); return;} // idx - 0 prepend
	int ct=1;
	while(idx>ct && (cur=cur->next)!=lst->head) ct++;	//find the idx-1 node

	//if out of bound return from function.
	if(cur==lst->head && idx!=1) return;

	//create newNode node and insert
	CNode* newNode=cnode_new(data);
	newNode->next=cur->next;
	cur->next=newNode;
}

/*
dlist_remove_last - to remove last elemnt of list
Input dlist* lst - the list input.
*/
void clist_remove_last( CList* lst ){
	if(lst->head==NULL) return;

	if(lst->head->next==lst->head){	//if list of length 1.
		CNode* temp=lst->head;
		lst->head=NULL;
		free(temp);
		return;
	}

	CNode* cur=lst->head;
	// find last node.
	while((cur=cur->next)->next->next!=lst->head);

	//delete the last node
	CNode* temp=cur->next;
	cur->next=lst->head;
	free(temp);
}

/*
dlist_remove_first - to remove first element of list
Input: dlist* lst
*/
void clist_remove_first( CList* lst ){
	CNode* cur=lst->head;
	CNode* temp=cur;
	if(cur==NULL) return;
	if(cur->next==cur){lst->head=NULL; free(temp); return;}

	while((cur=cur->next)->next!=lst->head);	//find last node
	//change pointer head to head->next
	cur->next=cur->next->next;
	lst->head=cur->next;
	free(temp);	//delete head

}

/*
dlist_remove - to remove element of index idx of list.
Input: dlist* lst - the to append to
int idx - index of delete element
*/
void clist_remove( CList* lst, int idx ){
	// if idx =0 call dlist_remove_first
	if(idx==0) {clist_remove_first(lst); return;}


	CNode* cur=lst->head;
	if(cur==NULL) return;
	int ct=1;
	if(cur==cur->next){
		if(idx==0) clist_remove_last(lst);
		else return;
	}
	//Transeverse array to idx-1 element
	while((ct++)<idx && (cur=cur->next)->next!=lst->head);
	if(cur->next==lst->head) return;
	//delete the idx node
	CNode* temp=cur->next;
	cur->next=cur->next->next;
	free(temp);
}

/*
dlist_reverse - to reverse doulbly linked list
Input: dlist* lst: input list
*/
void clist_reverse(CList* lst){
	//if list has size 1 or 0
	if(lst->head==NULL || lst->head->next==NULL) return;

	//cur holds current node, prev points node before cur, temp ponts to next node to cur
	CNode *cur,*prev,*temp,*temp2;
	cur=lst->head->next;
	prev=lst->head;
	temp=cur->next;

	do{
		temp=cur->next;
		cur->next=prev;
		temp2=prev;				//reverse the pointer of cur to previous node and traverse further
		prev=cur;
		cur=temp;
	}while(prev!=lst->head);
	//the tail node is new head
	lst->head=temp2;
}
