/*-----------------------------------------------------------------------------
 *  Title: Program to implement operations on Double linked list ADT
 *  Author: Harshavardhan.P.K.
 *  Roll No.: CS15B061
 *  Date: 4 September, 2016.	   
 *-----------------------------------------------------------------------------*/
#include "DList.h"
#include <stdio.h>
#define INT_MIN -1
#include <stdlib.h>


/*
node_newNode- creates a newNode node and returns a poniter to it.
If allcation not possible returns NULL

*/
DNode* dnode_new( int data){
	DNode* newNode=(DNode*)malloc(sizeof(DNode));
	newNode->data=data;
	newNode->prev=newNode->next=NULL;
	return newNode;
}




/*
dlist_newNode - create a newNode dlist and returns pointer to it else returns NULL.
*/
DList* dlist_new(){
	DList* newList = (DList*)malloc(sizeof(DList));
	newList->head=NULL;
	return newList;
}

// Traverse the linked list and return its size
int dlist_size( DList* lst ){
	DNode* cur=lst->head;
	if(cur == NULL) return 0;
	int ct=1;
	while((cur=cur->next)!=NULL) ct++;
	return ct;
}

/*
dlist_print to print a Given dlist
Input: dlist* lst: the list to be printed.
Output: prints lst and return nothing.
*/
void dlist_print( DList* lst ){
	DNode* cur = lst->head;
	if(cur==NULL) return;
	printf("%d ",cur->data);
	//Transeverse the lst and prints cur->data till it reaches end
	while((cur=cur->next)!=NULL)
		printf("%d ",cur->data);
	putchar('\n');
}

/*
dlist_get : to get a specific elment of index idx in list
Input: dlist* lst: the list to find elemet
int idx: input index
Output: Returns the element in given index.
*/
int dlist_get( DList* lst, int idx ){
	DNode* cur = lst->head;
	if(cur==NULL || idx<0) return -1;//Invalid index
	int t=1;
	if(idx==0) return cur->data;
	while(t<=idx && (cur=cur->next)!=NULL)
		t++;
	if(cur==NULL) return -1;// reached end of list
	return cur->data;
}

/*
function llist_append - append to end of list
Input: LList* lst - the to append to
int data - the elemnt to append
*/
void dlist_append( DList* lst, int data ){
	DNode* cur = lst->head;
	if(cur==NULL) {dlist_prepend(lst,data);return;
	}
	while(cur->next!=NULL) cur=cur->next;//find end of list
	DNode* newNode = dnode_new(data);
	//insert newNode node
	cur->next=newNode;
	newNode->prev=cur;
	newNode->next=NULL;
}

/*
dlist_prepend - to prepend an element to list
Input: dlist* lst - the list to prepend to
int data - the data of prepend node
*/
void dlist_prepend( DList* lst, int data ){
	DNode* newNode = dnode_new(data);
	if(lst->head==NULL){
		lst->head=newNode;
		return;
	}

	//insert newNode node
	newNode->next=lst->head;
	lst->head->prev=newNode;//insert newNode in beginning
	newNode->prev=NULL;
	lst->head=newNode;//change value of head to point to newNode.
}

/*
dlist_insert - to insert given element in index idx
Input: dlist* lst - the to append to
int data - the elemnt to append
int idx - index of inserted element

*/
void dlist_insert( DList* lst, int idx, int data ){
	if(idx==0) {dlist_prepend(lst,data);return;}//if element is to be prepended
	int ct=1;
	DNode* cur = lst->head;
	while(idx>ct++ && (cur=cur->next)!=NULL);//find the idx-1 node


	if(cur==NULL) return;//if out of bound return from function.

	DNode* newNode = dnode_new(data);//create newNode node
	newNode->next = cur->next;
	cur->next=newNode;
	newNode->prev=cur;
	if(newNode->next!=NULL)
	newNode->next->prev=newNode;
	
}

/*
dlist_remove_last - to remove last elemnt of list
Input dlist* lst - the list input.
*/
void dlist_remove_last( DList* lst ){
	if(lst->head==NULL) return;
	DNode* cur = lst->head;
	if(cur->next==NULL){
		DNode* temp = cur;//if list of length 1.
		lst->head = NULL;
		free(temp);
		return;
	}
	while((cur=cur->next)->next!=NULL);	// find last node.
	DNode* temp = cur;
	cur=cur->prev;	//delete the last node
	cur->next=NULL;
	free(temp);
}

/*
dlist_remove_first - to remove first element of list
Input: dlist* lst
*/
void dlist_remove_first( DList* lst ){
	if(lst->head == NULL) return;
	DNode* temp = lst->head;
	lst->head=lst->head->next;	//change pointer head to head->next
	lst->head->prev = NULL;
	free(temp);					//delete head
}

/*
dlist_remove - to remove element of index idx of list.
Input: dlist* lst - the to append to
int idx - index of delete element
*/
void dlist_remove( DList* lst, int idx ){
	if(idx==0) {dlist_remove_first(lst); return;	// if idx =0 call dlist_remove_first
	}


	int ct=1;
	DNode* cur = lst->head;
	while(idx>ct++ && (cur=cur->next)->next!=NULL);	//Transeverse array to idx-1 element

	
	DNode* temp = cur->next; if(cur->next==NULL) return;
	cur->next=cur->next->next;
	if(cur->next!=NULL)	//delete the idx node
	cur->next->prev=cur;
	free(temp);
}

/*
dlist_reverse - to reverse doulbly linked list
Input: dlist* lst: input list
*/
void dlist_reverse(DList* lst){
	if(lst->head == NULL || lst->head->next == NULL) return; //if list has 0 or 1 element

	DNode* cur = lst->head;
	DNode* temp1,*temp = cur->next; //temp stores next pointer to cur, temp1 stores prev to cur
	do{
		temp = cur->next;
		temp1= cur;
		cur->next=cur->prev;		//intechanging cur->next and cur->prev
		cur->prev=temp;
		cur=temp;
	}while(cur!=NULL);
	lst->head=temp1;
}
