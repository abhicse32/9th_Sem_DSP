/*-----------------------------------------------------------------------------
 *  Title: Program to implement operations on SparseMatrix ADT
 *  Author: Harshavardhan.P.K.
 *  Roll No.: CS15B061
 *  Date: 4 September, 2016.	   
 *-----------------------------------------------------------------------------*/
#include "SparseMatrix.h"
#include <stdlib.h>
#include <stdio.h>
/*
add -- Adds two matrices
Inputs: Matrix a,b: input matrices
Output : Matrix c: sum matrix

*/

Matrix add(Matrix a, Matrix b){
	int t=a.n_rows,i;
	Matrix c;
	c.row_lst=(LList**)malloc(sizeof(LList*)*t);//initialise Matrix c
	c.n_rows=t;
	for(i=0;i<t;i++){
		LList* aList = (a.row_lst)[i];
		LList* bList = (b.row_lst)[i];
		(c.row_lst)[i]=llist_new();
		LList* cList = (c.row_lst)[i];
		// idex to track col_ind of a,b
		int ida=0,idb=0;
		Node* aNode,* bNode;

		while((aNode=llist_get(aList,ida))!=NULL && (bNode=llist_get(bList,idb))!=NULL){

			if(aNode->col_ind==bNode->col_ind){//if both nodes are same column
				if(/*(aNode->val+bNode->val)*/1){
					llist_append(cList,aNode->col_ind,aNode->val+bNode->val);
				}
				ida++; idb++;
			}

			//if nodes are of different columns the smaller is evaluated first
			if(aNode->col_ind<bNode->col_ind){
				llist_append(cList,aNode->col_ind,aNode->val);
				ida++;
			}
			if(bNode->col_ind<aNode->col_ind){
				llist_append(cList,bNode->col_ind,bNode->val);
				idb++;
			}
		}
		//add remainind nodes
		while((aNode=llist_get(aList,ida))!=NULL){
			llist_append(cList,aNode->col_ind,aNode->val);
			ida++;
		}

		while((bNode=llist_get(bList,idb))!=NULL){
			llist_append(cList,bNode->col_ind,bNode->val);
			idb++;
		}
	}
	return c;
}


/*
subtract -- Subtracts two matrices
Inputs: Matrix a,b: input matrices
Output : Matrix c: sum matrix

*/
Matrix subtract(Matrix a, Matrix b){
	int t=a.n_rows,i;
	Matrix c;

	//initialise c
	c.row_lst=(LList**)malloc(sizeof(LList*)*t);
	c.n_rows=t;
	for(i=0;i<t;i++){
		LList* aList = (a.row_lst)[i];
		LList* bList = (b.row_lst)[i];
		(c.row_lst)[i]=llist_new();
		LList* cList = (c.row_lst)[i];
		int ida=0,idb=0;
		Node* aNode,* bNode;

		while((aNode=llist_get(aList,ida))!=NULL && (bNode=llist_get(bList,idb))!=NULL){
			//if same columns
			if(aNode->col_ind==bNode->col_ind){
				if(/*(aNode->val-bNode->val)*/1){
					llist_append(cList,aNode->col_ind,aNode->val-bNode->val);
				}
				ida++; idb++;
			}
			//if columns are different
			if(aNode->col_ind<bNode->col_ind){
				llist_append(cList,aNode->col_ind,aNode->val);
				ida++;
			}
			if(bNode->col_ind<aNode->col_ind){
				llist_append(cList,bNode->col_ind,-bNode->val);
				idb++;
			}
		}
		//insert rest of column values
		while((aNode=llist_get(aList,ida))!=NULL){
			llist_append(cList,aNode->col_ind,aNode->val);
			ida++;
		}

		while((bNode=llist_get(bList,idb))!=NULL){
			llist_append(cList,bNode->col_ind,-bNode->val);
			idb++;
		}
	}
	return c;
}

/*
matrix_vect_multiply -- Adds two matrices
Inputs: Matrix mat,vect: input matrices(vect is vector)
Output : Matrix c: product matrix

*/
Matrix matrix_vect_multiply (Matrix mat, Matrix vect){
	int t=mat.n_rows;
	Matrix c;
	//initialise c
	c.row_lst=(LList**)malloc(sizeof(LList*)*t);
	int n = vect.n_rows,i;
	c.n_rows=t;

	//Mutiplication
	for(i=0;i<t;i++){
		(c.row_lst)[i] = llist_new();
		LList* cList = (c.row_lst)[i];
		int sum=0;
		LList* matList = (mat.row_lst)[i];
		int j,idx=0; Node *tm; //tm to point next node of matList
		j=0;


		while(j<n){
			//set tm to next value
			while((tm=llist_get(matList,idx))!=NULL && tm->col_ind<j) 
				{idx++;}
			//if end of list
			if(!tm) break;

			//set vector element to right index
			while(j<n && j<tm->col_ind) {j++;}

			//if vector element is NULL or 0
			if(!(llist_get(vect.row_lst[j],0))) {
				j++; idx++;
				continue;
			}

			//multiply individual term
			if(j<n && tm && llist_get(vect.row_lst[j],0)){
				sum+=tm->val*(llist_get(vect.row_lst[j],0)->val);
				idx++; j++;
			}

			if(!tm) break;
		}
		
		printf("%d \n",sum);
		if(sum!=0) {llist_append(cList, 0,sum);}

	}
	return c;
}
