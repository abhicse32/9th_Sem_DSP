/*-----------------------------------------------------------------------------
 *  Title: Program to test on SparseMatrix ADT
 *  Author: Harshavardhan.P.K.
 *  Roll No.: CS15B061
 *  Date: 4 September, 2016.	   
 *-----------------------------------------------------------------------------*/
#include "SparseMatrix.h"
#include <stdio.h>
#include <stdlib.h>
void getMatrix(Matrix* ap, int m, int n);
void printmatrix(Matrix);

/*
getMatrix - to input matrix elemnts and create matrix
Inputs: m- no. or rows
		n - no of columns.
		Matrix* ap : pointer to matrix to create
*/
void getMatrix(Matrix* ap, int m, int n){

	Matrix a=*ap;
	if(m<=0 || n<=0) return;
	//initialise matrix
	a.row_lst=(LList**)malloc(sizeof(LList*)*m);
	a.n_rows=m;
	int i;

	//input values and append
	for(i=0;i<m;i++){
		(a.row_lst)[i]=llist_new();
		
		int j,val;
		for(j=0;j<n;j++){
			scanf("%d",&val);
			if(val) llist_append(((a.row_lst)[i]),j,val);
		}
	}
	*ap=a;
}

/*
printmatrix - function to print matrix
Input: Matrix a - the matrix to print
*/
void printmatrix(Matrix a){
	int m = a.n_rows;
	int i;

	//print each row on al line
	for(i=0;i<m;i++){
		LList* lst = (a.row_lst)[i];

		//if row is empty 0 is printed
		if(lst->head == NULL) ;
		else llist_print(lst);
	}
}

/*
main - function to drive the Sparse matrix.c implementation
opt - to input user options
*/
int main(void){
	int opt;
	do{
		//input options
		scanf("%d",&opt);

		Matrix a,b,c;
		int row,col;
		switch(opt){
			//addition
			case 1: scanf("%d%d",&row,&col);
				getMatrix(&a,row,col); getMatrix(&b,row,col);
				c=add(a,b);
			       	printmatrix(c);

				break;
			//subtraction	
			case 2: scanf("%d%d",&row,&col);
				getMatrix(&a,row,col); getMatrix(&b,row,col);
				c=subtract(a,b);
			       	printmatrix(c);
				break;
			//mutiplication	
			case 3: scanf("%d%d",&row,&col);
				getMatrix(&a,row,col); getMatrix(&b,col,1);
				c=matrix_vect_multiply(a,b); 
				
				break;	
		}
	}while(opt!=-1); //continue until -1 is entered

	return 0;
}
