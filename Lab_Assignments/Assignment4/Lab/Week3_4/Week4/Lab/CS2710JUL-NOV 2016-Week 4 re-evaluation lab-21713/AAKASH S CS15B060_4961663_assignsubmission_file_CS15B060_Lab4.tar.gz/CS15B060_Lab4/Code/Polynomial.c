/* note:in this program,i have used List.h,List.c,Polynomial.h,q2.c also*/
#include"Polynomial.h"
#include<stdio.h>
#include<stdlib.h>    
#include<string.h>
#include<math.h>


     int get_degree(Polynomial p)                  //function to get maximum exponent in polynomial
      {        int i=  llist_size( p.exponents);
   
            return llist_get(p.exponents ,i-1 );
       }
   
        void print_polynomial(Polynomial p)       //function for printing the polynomial
        {
           int a,b,i;
          
         for(i=0;i< llist_size( p.exponents)-1;i++)       //running the loop from 0 to no of elements in list-1
          { a=  llist_get(p.exponents ,i);
            b= llist_get(p.coeffs ,i);
              if(b!=0)
              {  if(i==0)                                  //printing the data as per form required and testing some case for   corner                                                                               printing
                   { 
                      if(a!=0)
                        printf("%dx^%d",b,a);
                       else
                          printf("%d",b);

                        if(llist_get(p.coeffs ,i+1)<0)
                          printf(" - "); 
                          else if(llist_get(p.coeffs ,i+1)>0)
                           printf(" + ");}
                         else{if(a!=0)
                          printf("%dx^%d",abs(b),a);
                               else
                                 printf("%d",abs(b));
                   
                    
                         if(llist_get(p.coeffs ,i+1)<0)
                           printf(" - "); 
                          else if(llist_get(p.coeffs ,i+1)>0)
                             printf(" + ");}
                             }
                             else
                             { if(i!=llist_size( p.exponents)-1)
                                { if(llist_get(p.coeffs ,i+1)<0)
                          printf(" - "); 
                          else if(llist_get(p.coeffs ,i+1)>0)
                           printf(" + ");}
                           }
                             
                             
                             
                             
                             
             
                }
                      a=llist_get(p.exponents ,i);
                        b= llist_get(p.coeffs ,i);
                        if(b!=0)
                      {  if(i!=0 &&i!=1)
                      if(a!=0)
                       printf("%dx^%d ",abs(b),a);
                       else
                         printf("%d ",abs(b));
                         else if(i==1)
                        { 
                            printf("%dx^%d ",abs(b),a);
                             }
                             else
                               printf("%dx^%d ",b,a);}
                               
                       printf("\n");
                       

             }
             
             
        Polynomial add(Polynomial p1, Polynomial p2)              //adding polynomials and storing it in asc. order of exponents
        {    int i,j,k,a,b,c,d;
           i=j=k=0; 
          Polynomial p;
           p.exponents= llist_new();
               p.coeffs= llist_new();
           
        
           while(i<llist_size( p1.exponents)&&j<llist_size( p2.exponents))   //because exponents are sorted,weimplement can                                                                                      similar to merging 
            { a=  llist_get(p1.exponents ,i);
              b= llist_get(p2.exponents ,j);
              c=llist_get(p1.coeffs ,i);
              d=llist_get(p2.coeffs ,j);
              if(a==b)
              {llist_append(p.coeffs,c+d); i++;
               llist_append(p.exponents,a);j++;
               }
               else if(a<b)
               {llist_append(p.coeffs,c);  i++;
               llist_append(p.exponents,a);
               }
               else                                                             //comparing elements and implementing addition
               {llist_append(p.coeffs,d);  j++;
               llist_append(p.exponents,b);
                }
                }
                
                while(i<llist_size( p1.exponents))
                {a=  llist_get(p1.exponents ,i);
                 c=llist_get(p1.coeffs ,i);
                 llist_append(p.coeffs,c);  i++;
               llist_append(p.exponents,a);      
               }
                while(j<llist_size( p2.exponents))
                {b= llist_get(p2.exponents ,j);
                d=llist_get(p2.coeffs ,j);
                llist_append(p.coeffs,d);  j++;
               llist_append(p.exponents,b);
               
               }
               return p;
               }
               
               
               Polynomial subtract(Polynomial p1, Polynomial p2)     //subtraction can be considered as adding with -p2
        { int i,j,k,a,b,c,d;
           i=j=k=0; 
          Polynomial p;
            p.exponents= llist_new();
               p.coeffs= llist_new();
        
           while((i<llist_size( p1.exponents)&&j<llist_size( p2.exponents)))
            { a=  llist_get(p1.exponents ,i);
              b= llist_get(p2.exponents ,j);
              c=llist_get(p1.coeffs ,i);
              d=-1*llist_get(p2.coeffs ,j);
              if(a==b)
              {llist_append(p.coeffs,c+d); i++;
               llist_append(p.exponents,a);j++;
               }
               else if(a<b)
               {llist_append(p.coeffs,c);  i++;
               llist_append(p.exponents,a);
               }
               else
               {llist_append(p.coeffs,d);  j++;
               llist_append(p.exponents,b);
                }
                }
                
                while(i<llist_size( p1.exponents))
                {a=  llist_get(p1.exponents ,i);
                 c=llist_get(p1.coeffs ,i);
                 llist_append(p.coeffs,c);  i++;
               llist_append(p.exponents,a);
               }
                while(j<llist_size( p2.exponents))
                {b= llist_get(p2.exponents ,j);
                d=-1*llist_get(p2.coeffs ,j);
                llist_append(p.coeffs,d);  j++;
               llist_append(p.exponents,b);
               
               }
               return p;
               }
               
               
               Polynomial multiply(Polynomial p1, Polynomial p2)  //in multiplication,we iteratively add each of multiplied terms
               {Polynomial p3;
                 p3.exponents= llist_new();
               p3.coeffs= llist_new();
                Polynomial p;
                  p.exponents= llist_new();
               p.coeffs= llist_new(); 
                int m=llist_size( p1.exponents);
                int n=llist_size( p2.exponents);
                 int i,j,a,b,c,d;
                 
                 for(i=0;i<m;i++)
                {a=  llist_get(p1.exponents ,i);
                   b= llist_get(p1.coeffs ,i);
                    for(j=0;j<n;j++)
                    {c=llist_get(p2.exponents,j) ;           
                     d=llist_get(p2.coeffs ,j);
                     
                      llist_append( p3.exponents,c+a );       
                      llist_append(p3.coeffs,b*d);             
                     }
                    
                        
                      p=add(p,p3); 
                       

                         p3.exponents= llist_new();
               p3.coeffs= llist_new();                          
                  } 
                return p;
                   }   
                long long powe(long long a,long long b)       //power function for computing in evaluate fn
                {if(b==0)
                   return 1;
                   else if(b==1)
                    return a;
                    else if(b%2)
                      return a*powe(a*a,b/2);
                    else
                     return powe(a*a,b/2);
                  }        



                long long evaluate(Polynomial p, int k)        //fn to evaluate polynomial at a number k
                
                { int i=0;long long sum=0;int l=llist_get(p.coeffs ,0);
                   int m,a;
                 a=llist_size( p.exponents);
                 m=llist_get(p.exponents ,0);
                     
            
                while(i<a)
                {sum+=l*powe(k,m);
                   if(i+1<a)
                  {l=llist_get(p.coeffs ,i+1);
                 m=llist_get(p.exponents ,i+1);}
                  i++;
                  }
                    return sum;
                  }


 


               
