/*
 * Author: S.Aakash
 * Polynomial ADT Linked test program
 */

#include "Polynomial.h"
#include <string.h>
#include <stdio.h>
#include <string.h>  

void main()
         {  int c;int z=0;
              
          while(1)                   //a dummy while loop(of course do while could also be used)
          {   scanf("%d",&c);
             Polynomial p1,p3;       //creating polynomial variables
             
              p1.exponents= llist_new();
               p1.coeffs= llist_new();
                 int n,a[100],b[100],i,n1,k;
           Polynomial p2;
              p2.exponents= llist_new();      //initialising each of components to null
               p2.coeffs= llist_new();
            p3.exponents= llist_new();
               p3.coeffs= llist_new();
             long long val;
             
          

          if(c==1)                           //instead of switch case,i have used if else as each option has considerable lines of prg
             {  scanf("%d",&n);
            for(i=0;i<n;i++)
           scanf("%d",&a[i]);                              
             for(i=0;i<n;i++)
              scanf("%d",&b[i]);
              for(i=0;i<n;i++)
             {llist_append( p1.coeffs, b[i]);
                llist_append( p1.exponents, a[i]);}
          print_polynomial(p1);
             }
            else if(c==2)
          {  
               scanf("%d",&n);
            for(i=0;i<n;i++)
           scanf("%d",&a[i]);                              
             for(i=0;i<n;i++)        
            scanf("%d",&b[i]);
             for(i=0;i<n;i++)
             {llist_append( p1.coeffs, b[i]);
                llist_append( p1.exponents, a[i]);}
                                                               /*within each  case i am accepting input from user for ease of  clearity*/
               
                i=get_degree(p1);                                 
               printf("%d\n",i); 
           }

          else if(c==6)
         {
               scanf("%d",&n);
            for(i=0;i<n;i++)
           scanf("%d",&a[i]);                              
             for(i=0;i<n;i++)       
            scanf("%d",&b[i]);
             for(i=0;i<n;i++)
            { llist_append( p1.coeffs, b[i]);
                llist_append( p1.exponents, a[i]);}
               scanf("%d",&k);
                val=evaluate(p1,k);
               printf("%lld\n",val);
           }


           else if(c==3)
           { scanf("%d",&n);
            for(i=0;i<n;i++)
           scanf("%d",&a[i]);                              
             for(i=0;i<n;i++)       
            scanf("%d",&b[i]);
             for(i=0;i<n;i++)
            { llist_append( p1.coeffs, b[i]);            //performing instructions as per question
                llist_append( p1.exponents, a[i]);}
             
              scanf("%d",&n1);
            for(i=0;i<n1;i++)
           scanf("%d",&a[i]);                              
             for(i=0;i<n1;i++)       
            scanf("%d",&b[i]);
             for(i=0;i<n1;i++)
            { llist_append( p2.coeffs, b[i]);
                llist_append( p2.exponents, a[i]);}
               
              p3=add(p1,p2);

              print_polynomial(p3);

              }



               else if(c==4)
           { scanf("%d",&n);
            for(i=0;i<n;i++)
           scanf("%d",&a[i]);                              
             for(i=0;i<n;i++)       
            scanf("%d",&b[i]);
             for(i=0;i<n;i++)
            { llist_append( p1.coeffs, b[i]);
                llist_append( p1.exponents, a[i]);}
             
              scanf("%d",&n1);
            for(i=0;i<n1;i++)
           scanf("%d",&a[i]);                              
             for(i=0;i<n1;i++)       
            scanf("%d",&b[i]);
             for(i=0;i<n1;i++)
            { llist_append( p2.coeffs, b[i]);
                llist_append( p2.exponents, a[i]);}
               
              p3=subtract(p1,p2);

              print_polynomial(p3);

              }

              else if(c==5)
           { scanf("%d",&n);
            for(i=0;i<n;i++)
           scanf("%d",&a[i]);                              
             for(i=0;i<n;i++)       
            scanf("%d",&b[i]);
             for(i=0;i<n;i++)
            { llist_append( p1.coeffs, b[i]);
                llist_append( p1.exponents, a[i]);}
             
              scanf("%d",&n1);
            for(i=0;i<n1;i++)
           scanf("%d",&a[i]);                              
             for(i=0;i<n1;i++)       
            scanf("%d",&b[i]);
             for(i=0;i<n1;i++)
            { llist_append( p2.coeffs, b[i]);
                llist_append( p2.exponents, a[i]);}
               
              p3=multiply(p1,p2);

              print_polynomial(p3);}

              if(c==-1)                  //jump out of the loop if input value is -1
               break;
             
           }


}
