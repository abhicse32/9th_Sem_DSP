#include "Polynomial.h"
#include<stdio.h>
#include<math.h>
void print_polynomial(Polynomial p)
{
	Node* a; Node* c;
	int b,d,x=0;
	a=(p.coeffs)->head;
	c=(p.exponents)->head;
	while (a!=NULL)
	{
		b=a->data;
		d=c->data;
		if(b==0) {a=a->next;c=c->next;continue;}
		if(x==0) x++;
		else if(b<0)
		{	
			printf(" - ");
			b=-b;
		}
		else printf(" + ");
		if(d==0) printf("%d",b);
		else printf("%dx^%d",b,d);
		a=a->next;
		c=c->next;
	}
	printf(" \n");
	fflush(stdout);
}
int get_degree(Polynomial p)
{
	Node* c;
	int deg,s;
	s=llist_size(p.exponents);
	deg=llist_get(p.exponents,s-1);
	return deg;
}
long long int evaluate(Polynomial p, int k)
{
	long long int ans=0;long long int t;
	Node* a; Node* c;
	int b,d;
	a=(p.coeffs)->head;
	c=(p.exponents)->head;
	while (a!=NULL)
	{
		b=a->data;
		d=c->data;	
		t=(long long int)pow(k,d);
		ans= ans+(b*t);
		a=a->next;
		c=c->next;

	}
	return ans;
}
Polynomial add(Polynomial p1, Polynomial p2)
{
	Node* a1; Node* c1;Node* a2;Node* c2;
	int b1,d1,b2,d2,x=0;
	a1=(p1.coeffs)->head;
	c1=(p1.exponents)->head;
	a2=(p2.coeffs)->head;
	c2=(p2.exponents)->head; 
	while (c1!=NULL && c2!=NULL)
	{
		b1=a1->data;
		d1=c1->data;
		b2=a2->data;
		d2=c2->data;
		if(d2<d1) 
		{			
			llist_insert((p1.coeffs),x,b2); 
			llist_insert((p1.exponents),x,d2);
			c2=c2->next;
			a2=a2->next;
			x++;
			continue ;
		}		
		else if(d2==d1) 
		{		
			a1->data=b1+b2;
			c2=c2->next;
			a2=a2->next;
		}
		c1=c1->next;
		a1=a1->next;
		x++;
	}
	while (c2!=NULL)
	{
		b2=a2->data;
		d2=c2->data;
		llist_append((p1.exponents),d2);
		llist_append((p1.coeffs),b2);
		c2=c2->next;
		a2=a2->next;
	}
	return p1;
}
Polynomial subtract(Polynomial p1, Polynomial p2)
{
	Node* a;
	a=(p2.coeffs)->head;
	while (a != NULL)
	{
		a->data = -(a->data) ;
		a=a->next;
	}
	add(p1,p2);
	return p1;
}
Polynomial multiply(Polynomial p1,Polynomial p2)
{
	Polynomial p3;
 	p3.coeffs = llist_new();
	p3.exponents = llist_new();
	Polynomial p4;
	p4.coeffs = llist_new();
	p4.exponents = llist_new();
	Node* a1; Node* c1;Node* a2;Node* c2;
	int b1,d1,b2,d2,x,y;
	a1=(p1.coeffs)->head;
	c1=(p1.exponents)->head;
	a2=(p2.coeffs)->head;
	c2=(p2.exponents)->head;
	while (c1!=NULL)
	{
		while(c2!=NULL)
		{
			x=(c2->data)+(c1->data) ;
			y=(a2->data)*(a1->data)	;
			llist_append(p3.coeffs,y);
			llist_append(p3.exponents,x);
			a2=a2->next;
			c2=c2->next;
		}
		add(p4,p3);
		a1=a1->next;		
		c1=c1->next;
		(p3.coeffs)->head = NULL;
		(p3.exponents)->head = NULL;
		a2=(p2.coeffs)->head;
		c2=(p2.exponents)->head;
	}
	return p4;
}
