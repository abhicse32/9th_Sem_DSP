#include "Polynomial.h"
#include<stdio.h>
#include "List.h"
void print();
void degree();
void add1();
void subtract1();
void multiply1();
void evaluate1();
int main()
{
	int n;
	while(1)
	{
		scanf("%d",&n);							// Takes inputs for the choice of operation 
		if(n==-1) return -1;
		else if(n==1) print();
		else if(n==2) degree();
		else if(n==3) add1();
		else if(n==4) subtract1();
		else if(n==5) multiply1();
		else if(n==6) evaluate1();	
	}
	return 0;
}												// Takes specific inputs for the operations
void print()
{
	Polynomial p;
 	p.coeffs = llist_new();
	p.exponents = llist_new();
	int t,i,x;
	scanf("%d",&t);
	for(i=0;i<t;i++)
	{
		scanf("%d",&x);
		llist_append((p.exponents),x);
	}
	for(i=0;i<t;i++)
	{
		scanf("%d",&x);
		llist_append((p.coeffs),x);
	}
	print_polynomial(p);
}
void degree()
{
	Polynomial p;
 	p.coeffs = llist_new();
	p.exponents = llist_new();
	int deg,t,i,x;
	scanf("%d",&t);
	for(i=0;i<t;i++)
	{
		scanf("%d",&x);
		llist_append((p.exponents),x);
	}
	for(i=0;i<t;i++)
	{
		scanf("%d",&x);
		llist_append((p.coeffs),x);
	}
	deg=get_degree(p);
	printf("%d\n",deg);
	fflush(stdout);
}
void add1()
{
	Polynomial p1;
 	p1.coeffs = llist_new();
	p1.exponents = llist_new();
	Polynomial p2;
	p2.coeffs = llist_new();
	p2.exponents = llist_new();
	int t1,t2,i,x;
	scanf("%d",&t1);
	for(i=0;i<t1;i++)
	{
		scanf("%d",&x);
		llist_append((p1.exponents),x);
	}
	for(i=0;i<t1;i++)
	{
		scanf("%d",&x);
		llist_append((p1.coeffs),x);
	}
	scanf("%d",&t2);
	for(i=0;i<t2;i++)
	{
		scanf("%d",&x);
		llist_append((p2.exponents),x);
	}
	for(i=0;i<t2;i++)
	{
		scanf("%d",&x);
		llist_append((p2.coeffs),x);
	}
	p1=add(p1,p2);
	print_polynomial(p1);
}
void subtract1()
{
	Polynomial p1;
 	p1.coeffs = llist_new();
	p1.exponents = llist_new();
	Polynomial p2;
	p2.coeffs = llist_new();
	p2.exponents = llist_new();
	int t1,t2,i,x;
	scanf("%d",&t1);
	for(i=0;i<t1;i++)
	{
		scanf("%d",&x);
		llist_append((p1.exponents),x);
	}
	for(i=0;i<t1;i++)
	{
		scanf("%d",&x);
		llist_append((p1.coeffs),x);
	}
	scanf("%d",&t2);
	for(i=0;i<t2;i++)
	{
		scanf("%d",&x);
		llist_append((p2.exponents),x);
	}
	for(i=0;i<t2;i++)
	{
		scanf("%d",&x);
		llist_append((p2.coeffs),x);
	}
	p1=subtract(p1,p2);
	print_polynomial(p1);
}
void multiply1()
{
	Polynomial p1;
 	p1.coeffs = llist_new();
	p1.exponents = llist_new();
	Polynomial p2;
	p2.coeffs = llist_new();
	p2.exponents = llist_new();
	int t1,t2,i,x;
	scanf("%d",&t1);
	for(i=0;i<t1;i++)
	{
		scanf("%d",&x); 
		llist_append((p1.exponents),x);
	}
	for(i=0;i<t1;i++)
	{
		scanf("%d",&x);
		llist_append((p1.coeffs),x);
	}
	scanf("%d",&t2);
	for(i=0;i<t2;i++)
	{
		scanf("%d",&x);
		llist_append((p2.exponents),x);
	}
	for(i=0;i<t2;i++)
	{
		scanf("%d",&x);
		llist_append((p2.coeffs),x);
	}
	p1=multiply(p1,p2);
	print_polynomial(p1);
}
void evaluate1()
{
	Polynomial p;
 	p.coeffs = llist_new();
	p.exponents = llist_new();
	int t,i,k,x;
	long long int ans;
	scanf("%d",&t);
	for(i=0;i<t;i++)
	{
		scanf("%d",&x);
		llist_append((p.exponents),x);
	}
	for(i=0;i<t;i++)
	{
		scanf("%d",&x);
		llist_append((p.coeffs),x);
	}
	scanf("%d",&k);
	ans=evaluate(p,k);
	printf("%lld\n",ans);
}
