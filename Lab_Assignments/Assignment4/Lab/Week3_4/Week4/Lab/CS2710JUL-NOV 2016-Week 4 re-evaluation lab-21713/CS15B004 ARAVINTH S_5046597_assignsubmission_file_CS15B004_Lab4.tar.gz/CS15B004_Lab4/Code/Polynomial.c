#include "Polynomial.h"
#include <stdlib.h>
#include <stdio.h>
//#include <math.h>
#include "List.h"


#define INT_MIN -1

long long int powe(int k, int a)
{
if(a==0)
return 1;
else if(a>0)
return k*powe(k,a-1);
else
return 0;
}
/*function to return the degree of the polynomial*/
int get_degree(Polynomial poly)
{
	int size = llist_size( poly.exponents );
	return llist_get( poly.exponents, size-1 );
}

// poly3int Polynomial
void print_polynomial(Polynomial poly)
{
	//poly3intf("reached");

	if( poly.exponents -> head == NULL)
		{
			printf("0");
			return;
		}

	int a,b;
	
	int idx = 0, idx1;
	int size = llist_size( poly.exponents );


	
	if(llist_search( poly.exponents, 0 ) == 0)
		  {
			int f = llist_get( poly.coeffs,0);
			if(f != 0 )		  	
				printf("%d ", f );
		  	idx++;
		  }
	else{
			int f = llist_get( poly.coeffs,0);
			if(f!=0)
			printf("%dx^%d ", llist_get( poly.coeffs, 0 ),llist_get( poly.exponents, 0 ) );
		  	idx++;

	}
/*
	if(llist_search( poly.exponents, 1 ) != INT_MIN)
		{
			idx1 = llist_search( poly.exponents, 1 );
			a = llist_get( poly.coeffs, idx1 );
            
			if(idx == 0)
            {
                if( a<0 ) poly3intf("-");   
            }

            if(idx != 0)
            {
                if( a<0 ) poly3intf(" - ");
                else if( a>0 ) poly3intf(" + ");
            }
			poly3intf("%dx", abs(a) );
			idx++;
		}
*/	
	while( idx < size)
	{	a = llist_get( poly.coeffs, idx );
		b = llist_get( poly.exponents, idx );
		
	if(a != 0 )	
	{
		if(idx == 0)
            {
                if( a<0 ) printf("-");   
            }

        if(idx != 0)
        {
            if( a<0 ) printf("- ");
            else if( a>0 ) printf("+ ");
        }
		printf("%dx^%d ",abs(a), b);
		idx++;

	}

	}

	printf("\n");

}

/*Multiply two polynomials and return the result*/
Polynomial multiply(Polynomial poly1, Polynomial poly2)
{

	int a,b;
	
	int idx1 = 0, idx2 = 0;
	int size1 = llist_size( poly1.exponents );
	int size2 = llist_size( poly2.exponents );
	int exp1, exp2, exp3;
	int coeff1, coeff2, coeff3;
	int idx_check;

	
	Polynomial poly3;
	poly3.exponents = llist_new();				// initialize the lists
	poly3.coeffs = llist_new();

	while(idx1 < size1)
	{
		idx2 = 0;
		while(idx2 < size2)
		{
			exp1 = llist_get( poly1.exponents, idx1 );
	        exp2 = llist_get( poly2.exponents, idx2 );

	        coeff1 = llist_get( poly1.coeffs, idx1 );
	        coeff2 = llist_get( poly2.coeffs, idx2 );

	        exp3 = exp1 + exp2;
	        coeff3 = coeff1 * coeff2;

	        idx_check = llist_search( poly3.exponents, exp3 );
	        //poly3intf("idx_check = %d \n", idx_check);

	        if(idx_check == INT_MIN)				// exp3 not found
	        {
	        	int pos = llist_getpos( poly3.exponents, exp3);
	        	if(pos == INT_MIN)
	        	{
	        		llist_append( poly3.exponents, exp3 );
	        		llist_append( poly3.coeffs, coeff3 );
	        	}
				else
				{
					llist_insert( poly3.exponents, pos, exp3 );
					llist_insert( poly3.coeffs, pos, coeff3 );
				}

	        	idx2++;
	        }	

	        else 									// exp3 found at pos idx_check
	        {
	        	int cur_val = llist_get( poly3.coeffs, idx_check );
	        	
	        	int result = cur_val + coeff3;
	        	// poly3intf("coeff3= %d \n", coeff3);
	        	// poly3intf("result = %d \n", result);
	        	if( result != 0)
	        		llist_changeval( poly3.coeffs, idx_check, result);
	        	else
	        		{
	        			llist_remove( poly3.exponents, idx_check );
	        			llist_remove( poly3.coeffs, idx_check );
	        		}

	        	idx2++;
	        }

		}

		idx1++;
	}

	return poly3;


}

// ADDING POLYNOMIALS AND RETURNING RESULT
Polynomial add(Polynomial poly1, Polynomial poly2)
{
	Polynomial poly3;
	poly3.coeffs=llist_new();
	poly3.exponents=llist_new();

	Node* coeff1, *coeff2;
	Node* exp1, *exp2;

	coeff1 = poly1.coeffs->head;
	coeff2 = poly2.coeffs->head;
	exp1   = poly1.exponents->head;
	exp2   = poly2.exponents->head;
	
	while(( coeff1 !=NULL)&& (coeff2 !=NULL))
	{
		if(exp1->data==exp2->data)
		{	
			int sum = (coeff1->data)+(coeff2->data);
			if(sum!=0)
			{
				llist_append( poly3.coeffs, (coeff1->data) + (coeff2->data));
				llist_append( poly3.exponents, exp1->data );
				
				coeff1 =coeff1->next;
				exp1   =exp1->next;
				
				coeff2 = coeff2->next;
				exp2   = exp2->next;
			}
			else
			{
				coeff1 =coeff1->next;
				exp1   =exp1->next;
				
				coeff2 =coeff2->next;
				exp2   =exp2->next;
			}
		}
		else if((exp1->data)>(exp2->data))
		{
			llist_append( poly3.coeffs, coeff2->data );
			llist_append( poly3.exponents, exp2->data );
			
			coeff2 = coeff2->next;
			exp2   = exp2->next;
		}
		else if((exp1->data)<(exp2->data))
		{
			llist_append( poly3.coeffs,coeff1->data );
			llist_append( poly3.exponents, exp1->data );
			
			coeff1 =coeff1->next;
			exp1   =exp1->next;
		}
	}

	while(coeff1!=NULL)
	{
		llist_append( poly3.coeffs, coeff1->data );
		llist_append( poly3.exponents, exp1->data );
			
		coeff1 =coeff1->next;
		exp1   =exp1->next;
	}

	while(coeff2!=NULL)
	{
		llist_append( poly3.coeffs, coeff2->data );
		llist_append( poly3.exponents, exp2->data );
						
		coeff2 =coeff2->next;
		exp2   =exp2->next;
	}
	
	return poly3;
}


// Subtracting second Polynomial from first and returning result
Polynomial subtract(Polynomial poly1, Polynomial poly2)
{
	Polynomial poly3;
	poly3.coeffs=llist_new();
	poly3.exponents=llist_new();

	Node* coeff1, *coeff2;
	Node* exp1, *exp2;

	coeff1 = poly1.coeffs->head;
	coeff2 = poly2.coeffs->head;
	exp1   = poly1.exponents->head;
	exp2   = poly2.exponents->head;


	while((coeff1 !=NULL)&& (coeff2!=NULL))
	{
		if(exp1->data==exp2->data)
		{	
			int x = (coeff1->data)-(coeff2->data);
			if(x!=0)
			{
				llist_append( poly3.coeffs, (coeff1->data)-(coeff2->data));
				llist_append( poly3.exponents, exp1->data );
				
				coeff1=coeff1->next;
				exp1=exp1->next;
				
				coeff2=coeff2->next;
				exp2=exp2->next;
			}
			else
			{
				coeff1=coeff1->next;
				exp1=exp1->next;
				
				coeff2=coeff2->next;
				exp2=exp2->next;
			}
		}
		else if((exp1->data)>(exp2->data))
		{
			llist_append( poly3.coeffs, -(coeff2->data));
			llist_append( poly3.exponents, exp2->data );
			
			coeff2=coeff2->next;
			exp2=exp2->next;
		}
		else if((exp1->data)<(exp2->data))
		{
			llist_append( poly3.coeffs,coeff1->data );
			llist_append( poly3.exponents, exp1->data );
			
			coeff1=coeff1->next;
			exp1=exp1->next;
		}
	}

	while(coeff1!=NULL)
	{
		llist_append( poly3.coeffs, coeff1->data );
		llist_append( poly3.exponents, exp1->data );
			
		coeff1=coeff1->next;
		exp1=exp1->next;
	}

	while(coeff2!=NULL)
	{
		llist_append( poly3.coeffs, -(coeff2->data));
		llist_append( poly3.exponents, exp2->data );
						
		coeff2=coeff2->next;
		exp2=exp2->next;
	}
	
	return poly3;
}


/*Evaluate Polynomial at var=k and return the result*/
long long evaluate(Polynomial poly, int k)
{
	int a,b;

	int idx = 0;
	long long val = 0;
	int size = llist_size( poly.exponents );
	
	while( idx < size)
	{
		a = llist_get( poly.exponents, idx );
		b = llist_get( poly.coeffs, idx );
		val += b * powe(k, a);
		idx++;
	}
	return val;

}





