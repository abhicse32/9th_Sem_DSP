#include "Polynomial.h"
// driver function for polynomials

#include <stdio.h>
#include <stdlib.h>

Polynomial getpolynomial()
{

	Polynomial poly ;
	poly.exponents = llist_new();
	poly.coeffs    = llist_new();				// initialize polynomial


	int i, size;
	int val;
	scanf("%d", &size);

	for(i = 0; i < size; i++)					// get exponents
	{
		scanf("%d", &val );
		llist_append( poly.exponents, val );
	}


	for(i = 0; i < size; i++)					// get coeffs
	{
		scanf("%d", &val);
		llist_append( poly.coeffs, val );
	}


return poly;
}


int main()
{

Polynomial poly1, poly2, poly3;

int choice = 0, at_x ;

while(choice != -1)
{
	scanf("%d", &choice);
	switch(choice)
	{
		case 1:	
		{
			poly1 = getpolynomial();
			print_polynomial(poly1);
			break;
		}
					

		case 2: 
		{
			poly1 = getpolynomial();
			int degree = get_degree( poly1 );
			printf( "%d\n", degree);
			break;
		}

		case 3:	
		{
		    poly1 = getpolynomial();
			poly2 = getpolynomial();
            poly3 = add( poly1, poly2 );
			print_polynomial( poly3 );
			break;
		}

		case 4: 	
		{
			poly1 = getpolynomial();
			poly2 = getpolynomial();
			poly3 = subtract( poly1, poly2 );

			print_polynomial( poly3 );
			break;
		}

		case 5: 	
		{
			poly1 = getpolynomial();
			poly2 = getpolynomial();
			//print_polynomial( poly1 );
			//print_polynomial( poly2 );
			poly3 = multiply( poly1, poly2 );
			//printf("before print\n");
			print_polynomial( poly3 );
			//printf("after print\n\n");
			break;
		}

		case 6:		
		{
			poly1 = getpolynomial();
			scanf("%d", &at_x);
			long long val = evaluate( poly1, at_x );
			printf("%lld\n", val);
			break;
		}

	}
}
return 0;
}
