#include "Polynomial.h"
#include "List.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

/*function to return the degree of the polynomial*/
int get_degree(Polynomial p1)
{
	Node* current;
	current=p1.exponents->head;
	while(current->next!=NULL)
	{
		current=current->next;
	}
	return(current->data);
}

/* print Polynomial*/
void print_polynomial(Polynomial p)
{
	Node* exp;
	Node* cof;
	exp=p.exponents->head;
	cof=p.coeffs->head;
	while(cof!=NULL)
	{
		if(cof==p.coeffs->head)
			if(exp->data==0)
				printf("%d",cof->data);
			else
				printf("%dx^%d", cof->data, exp->data);
		else if(cof->data>0)
			printf(" + %dx^%d", cof->data, exp->data);
		else
			printf(" - %dx^%d",-1*(cof->data), exp->data);
		
		exp=exp->next;
		cof=cof->next;
	}
	printf(" \n");
	return;
}

/*MULTIPLYING 2 POLYNOMIALS*/
Polynomial multiply(Polynomial p1, Polynomial p2)
{
	Polynomial pr;
	pr.coeffs=llist_new();
	pr.exponents=llist_new();
	
	Polynomial p3;
	p3.coeffs=llist_new();
	p3.exponents=llist_new();

	Node* cof1;
	Node* cof2;
	Node* cof3;
	Node* exp1;
	Node* exp2;
	Node* exp3;
	
	cof3=p3.coeffs->head;
	exp3=p3.exponents->head;

	Node* cofr=pr.coeffs->head;
	Node* expr=pr.exponents->head;
	
	cof1=p1.coeffs->head;
	cof2=p2.coeffs->head;
	exp1=p1.exponents->head;
	exp2=p2.exponents->head;
	
	while(cof1!=NULL)
	{
		while(cof2!=NULL)
		{
			llist_append(p3.exponents, exp2->data + exp1->data);
			llist_append(p3.coeffs, cof2->data*cof1->data);
			cof2=cof2->next;
			exp2=exp2->next;
		}
		pr=add(pr, p3);
		p3.coeffs=llist_new();
		p3.exponents=llist_new();
		cof2=p2.coeffs->head;
		exp2=p2.exponents->head;
		cof1=cof1->next;
		exp1=exp1->next;
	}
	return pr;
}

/*ADDING POLYNOMIALS*/
Polynomial add(Polynomial p1, Polynomial p2)
{
	Polynomial pr;
	pr.coeffs=llist_new();
	pr.exponents=llist_new();
	
	Node* cof1;
	Node* cof2;
	Node* exp1;
	Node* exp2;
	
	cof1=p1.coeffs->head;
	cof2=p2.coeffs->head;
	exp1=p1.exponents->head;
	exp2=p2.exponents->head;
	
	while((cof1!=NULL)&&(cof2!=NULL))
	{
		if(exp1->data==exp2->data)
		{	
			int x = (cof1->data)+(cof2->data);
			if(x!=0)
			{
				llist_append( pr.coeffs, (cof1->data)+(cof2->data));
				llist_append( pr.exponents, exp1->data );
				
				cof1=cof1->next;
				exp1=exp1->next;
				
				cof2=cof2->next;
				exp2=exp2->next;
			}
			else
			{
				cof1=cof1->next;
				exp1=exp1->next;
				
				cof2=cof2->next;
				exp2=exp2->next;
			}
		}
		else if((exp1->data)>(exp2->data))
		{
			llist_append( pr.coeffs, cof2->data );
			llist_append( pr.exponents, exp2->data );
			
			cof2=cof2->next;
			exp2=exp2->next;
		}
		else if((exp1->data)<(exp2->data))
		{
			llist_append( pr.coeffs,cof1->data );
			llist_append( pr.exponents, exp1->data );
			
			cof1=cof1->next;
			exp1=exp1->next;
		}
	}
	while(cof2!=NULL)
	{
		llist_append( pr.coeffs, cof2->data );
		llist_append( pr.exponents, exp2->data );
						
		cof2=cof2->next;
		exp2=exp2->next;
	}
	while(cof1!=NULL)
	{
		llist_append( pr.coeffs, cof1->data );
		llist_append( pr.exponents, exp1->data );
			
		cof1=cof1->next;
		exp1=exp1->next;
	}
	return pr;
}


/*Subtracting second Polynomial from first*/
Polynomial subtract(Polynomial p1, Polynomial p2)
{
	Polynomial pr;
	pr.coeffs=llist_new();
	pr.exponents=llist_new();
	
	Node* cof1;
	Node* cof2;
	Node* exp1;
	Node* exp2;
	
	cof1=p1.coeffs->head;
	cof2=p2.coeffs->head;
	exp1=p1.exponents->head;
	exp2=p2.exponents->head;
	
	while((cof1!=NULL)&&(cof2!=NULL))
	{
		if(exp1->data==exp2->data)
		{	
			int x = (cof1->data)-(cof2->data);
			if(x!=0)
			{
				llist_append( pr.coeffs, (cof1->data)-(cof2->data));
				llist_append( pr.exponents, exp1->data );
				
				cof1=cof1->next;
				exp1=exp1->next;
				
				cof2=cof2->next;
				exp2=exp2->next;
			}
			else
			{
				cof1=cof1->next;
				exp1=exp1->next;
				
				cof2=cof2->next;
				exp2=exp2->next;
			}
		}
		else if((exp1->data)>(exp2->data))
		{
			llist_append( pr.coeffs, -(cof2->data));
			llist_append( pr.exponents, exp2->data );
			
			cof2=cof2->next;
			exp2=exp2->next;
		}
		else if((exp1->data)<(exp2->data))
		{
			llist_append( pr.coeffs,cof1->data );
			llist_append( pr.exponents, exp1->data );
			
			cof1=cof1->next;
			exp1=exp1->next;
		}
	}
	while(cof2!=NULL)
	{
		llist_append( pr.coeffs,-(cof2->data));
		llist_append( pr.exponents, exp2->data );
						
		cof2=cof2->next;
		exp2=exp2->next;
	}
	while(cof1!=NULL)
	{
		llist_append( pr.coeffs, cof1->data );
		llist_append( pr.exponents, exp1->data );
			
		cof1=cof1->next;
		exp1=exp1->next;
	}
	return pr;
}

/*Evaluating Polynomial and returning the result*/
long long int evaluate(Polynomial p, int k)
{
	Node* cof;
	Node* exp;
	cof=p.coeffs->head;
	exp=p.exponents->head;
	long long int val=0;
	while(cof!=NULL)
	{
		val = val + (cof->data)*pow( k, exp->data);
		cof=cof->next;
		exp=exp->next;
	}
	return val;
}


