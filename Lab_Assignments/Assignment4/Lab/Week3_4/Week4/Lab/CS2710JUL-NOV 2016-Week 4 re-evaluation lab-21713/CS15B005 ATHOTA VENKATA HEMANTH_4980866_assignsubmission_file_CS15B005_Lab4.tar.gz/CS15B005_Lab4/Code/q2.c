#include "List.h"
#include"Polynomial.h"
#include<stdlib.h>
#include<stdio.h>
int main()
{
	int i, n, data;
	scanf("%d ",&i);
	while(i!=-1)  //to stop taking input
	{
		switch(i) //to select the function to perform
		{
			case 1:
			{
				Polynomial *p1=(Polynomial*)malloc(sizeof(Polynomial));
    			p1->exponents=llist_new();
    			p1->coeffs=llist_new();
    			
				scanf("%d",&n); //size of the polynomial
				
				for (i=0;i<n;i++) //list of exponenets
				{
					scanf("%d",&data);
					llist_append(p1->exponents,data);
				}
				
				for (i=0;i<n;i++) //list of coeffs
				{
					scanf("%d",&data);
					llist_append(p1->coeffs,data);
				}
				print_polynomial(*p1);
				break;

			}
			case 2:
			{
				Polynomial *p1 = (Polynomial*)malloc(sizeof(Polynomial));
    			p1->exponents = llist_new();
    			p1->coeffs = llist_new();
    			
				scanf("%d",&n);	//size of the polynomial
				
				for (i=0;i<n;i++)	//list of exponenets
				{
					scanf("%d",&data);
					llist_append(p1->exponents,data);
				}
				for (i=0;i<n;i++)	//list of coeffs
				{
					scanf("%d",&data);
					llist_append(p1->coeffs,data);
				}
				
				int deg=get_degree(*p1);
				
				printf("%d\n",deg);
				break;
			}
			case 3:
			{
				Polynomial *p1 = (Polynomial*)malloc(sizeof(Polynomial));
    			p1->exponents = llist_new();
    			p1->coeffs = llist_new();
    			
    			Polynomial *p2 = (Polynomial*)malloc(sizeof(Polynomial));
    			p2->exponents = llist_new();
    			p2->coeffs = llist_new();
				
				scanf("%d",&n);	//size of the polynomials
				
				for (i=0;i<n;i++) //list of exponenets
				{
					scanf("%d",&data);
					llist_append(p1->exponents,data);
				}
				for (i=0;i<n;i++)	//list of coeffs
				{
					scanf("%d",&data);
					llist_append(p1->coeffs,data);
				}
				
				scanf("%d",&n);	//size of the polynomials
				
				for (i=0;i<n;i++)	//list of exponenets
				{
					scanf("%d",&data);
					llist_append(p2->exponents,data);
				}
				for (i=0;i<n;i++)	//list of coeffs
				{
					scanf("%d",&data);
					llist_append(p2->coeffs,data);
				}

				Polynomial pa = add(*p1,*p2);
				print_polynomial(pa);
				break;

			}
			case 4:
			{
				Polynomial *p1 = (Polynomial*)malloc(sizeof(Polynomial));
    			p1->exponents = llist_new();
    			p1->coeffs = llist_new();
    			
    			Polynomial *p2 = (Polynomial*)malloc(sizeof(Polynomial));
    			p2->exponents = llist_new();
    			p2->coeffs = llist_new();
    			
				scanf("%d",&n);
				
				for (i=0;i<n;i++)	//list of exponenets
				{
					scanf("%d",&data);
					llist_append(p1->exponents,data);
				}
				for (i=0;i<n;i++) //list of coeffs
				{
					scanf("%d",&data);
					llist_append(p1->coeffs,data);
				}
				
				scanf("%d",&n);
				
				for (i=0;i<n;i++)	//list of exponenets
				{
					scanf("%d",&data);
					llist_append(p2->exponents,data);
				}
				for (i=0;i<n;i++)	//list of coeffs
				{
					scanf("%d",&data);
					llist_append(p2->coeffs,data);
				}
				Polynomial pb = subtract(*p1,*p2);
				print_polynomial(pb);
				break;
			}
			case 5:
			{
				Polynomial *p1 = (Polynomial*)malloc(sizeof(Polynomial));
    			p1->exponents = llist_new();
    			p1->coeffs = llist_new();
    			
    			Polynomial *p2 = (Polynomial*)malloc(sizeof(Polynomial));
    			p2->exponents = llist_new();
    			p2->coeffs = llist_new();
				
				scanf("%d",&n);
				
				for (i=0;i<n;i++)	//list of exponenets
				{
					scanf("%d",&data);
					llist_append(p1->exponents,data);
				}
				for (i=0;i<n;i++)	//list of coeffs
				{
					scanf("%d",&data);
					llist_append(p1->coeffs,data);
				}
				scanf("%d",&n);
				for (i=0;i<n;i++)	//list of exponenets
				{
					scanf("%d",&data);
					llist_append(p2->exponents,data);
				}
				for (i=0;i<n;i++)	//list of coeffs
				{
					scanf("%d",&data);
					llist_append(p2->coeffs,data);
				}
				
				Polynomial pm = multiply(*p1,*p2);
				
				print_polynomial(pm);
				
				break;
			}
			case 6:
			{
				Polynomial *p1 = (Polynomial*)malloc(sizeof(Polynomial));
    			p1->exponents = llist_new();
    			p1->coeffs = llist_new();
    			
    			Polynomial *p2 = (Polynomial*)malloc(sizeof(Polynomial));
    			p2->exponents = llist_new();
    			p2->coeffs = llist_new();
				
				scanf("%d",&n);
				
				for (i=0;i<n;i++)	//list of exponenets
				{
					scanf("%d",&data);
					llist_append(p1->exponents,data);
				}
				for (i=0;i<n;i++)	//list of coeffs
				{
					scanf("%d",&data);
					llist_append(p1->coeffs,data);
				}
				scanf("%d",&n);
				
				long long int val= evaluate(*p1, n);
				printf("%lld\n",val);
				break;
			}
		}
		scanf("%d",&i);
	}
}
