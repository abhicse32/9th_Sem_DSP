#include "Polynomial.h"
#include "List.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <limits.h>

int get_degree(Polynomial a){								  // Function for highest degree
	
	Node* p;
	p = a.exponents->head;
	if( p == NULL ) return INT_MIN;							 //	Last element contains highest degree
	
	while( p->next != NULL ){
		p = p->next;	
	}
	return (p->data);
}


void print_polynomial(Polynomial a){
	
	Node *p, *q;
	p = a.exponents->head;
	q = a.coeffs->head;
	
	if( p == NULL || q == NULL ) return ;
	
	if(p->data != 0){
		
		if(q->data > 0){
			printf("%dx^%d", q->data, p->data);					// Printing initial element
		}
		else if(q->data < 0){
			printf("-%dx^%d", -1*q->data, p->data);		
		}
	}
	else{
		if(q->data > 0){										
			printf("%d", q->data);		
		}
		else if(q->data < 0){
			printf("-%d", -1*q->data);		
		}
	}
	
	if( q->next == NULL) {
		printf("\n");
		return;
	}
	
	p = p->next;
	q = q->next;
	
	while( p != NULL){										// Printning according to required sign convention
		if(p->data != 0 ){
			if(q->data > 0)printf(" + %dx^%d",q->data, p->data); 	
			else if(q->data < 0) printf(" - %dx^%d", -1*q->data, p->data); 
		}
		p = p->next;
		q = q->next;
	}
	printf(" \n");
	
	return;	
}
Polynomial add(Polynomial a, Polynomial b){
	
	LList *p1, *q1;
	LList *p2, *q2;
	
	Polynomial c;
	
	c.exponents = llist_new();												// Initializing list
	c.coeffs = llist_new();
	
	p1 = a.exponents;
	q1 = a.coeffs;
	
	p2 = b.exponents;
	q2 = b.coeffs;
	
	while(p1->head != NULL && p2->head != NULL){
		if(p1->head->data < p2->head->data){								// Taking lower degree of both terms and appending it to the result file
			llist_append( c.exponents, p1->head->data); 
			llist_append( c.coeffs, q1->head->data); 		
			p1->head = p1->head->next;
			q1->head = q1->head->next;
		}	
		else if( p1->head->data > p2->head->data){
			llist_append( c.exponents, p2->head->data); 
			llist_append( c.coeffs, q2->head->data);
			p2->head = p2->head->next;
			q2->head = q2->head->next;
		}
		else if( p1->head->data == p2->head->data){
			llist_append( c.exponents, p2->head->data); 
			llist_append( c.coeffs, q2->head->data + q1->head->data);
			p2->head = p2->head->next;
			q2->head = q2->head->next;
			p1->head = p1->head->next;
			q1->head = q1->head->next;
		}
	}
	if(p1->head == NULL){														// Appending the remaining terms from one containing highest degree polynomial
		while(p2->head != NULL){
			llist_append( c.exponents, p2->head->data); 
			llist_append( c.coeffs, q2->head->data);
			p2->head = p2->head->next;
			q2->head = q2->head->next;		
		}	
	}
	if(p2->head == NULL){
		while(p1->head != NULL){												
			llist_append( c.exponents, p1->head->data); 
			llist_append( c.coeffs, q1->head->data); 		
			p1->head = p1->head->next;
			q1->head = q1->head->next;
		}
	}

	return c;
}

Polynomial subtract(Polynomial a, Polynomial b){
	
	LList *p1, *q1;
	LList *p2, *q2;
	Polynomial c;
	
	c.exponents = llist_new();
	c.coeffs = llist_new();																	// initailizing list
	
	p1 = a.exponents;
	q1 = a.coeffs;																					 
	
	p2 = b.exponents;
	q2 = b.coeffs;
	
	while(p1->head != NULL && p2->head != NULL){												
		if(p1->head->data < p2->head->data){												// Taking lower degree of both terms and appending it to the result file
			llist_append( c.exponents, p1->head->data); 
			llist_append( c.coeffs, q1->head->data); 		
			p1->head = p1->head->next;
			q1->head = q1->head->next;
		}	
		else if( p1->head->data > p2->head->data){
			llist_append( c.exponents, p2->head->data); 
			llist_append( c.coeffs, -1*q2->head->data);
			p2->head = p2->head->next;
			q2->head = q2->head->next;
		}
		else if( p1->head->data == p2->head->data){
			llist_append( c.exponents, p2->head->data); 
			llist_append( c.coeffs, -1*q2->head->data + q1->head->data);
			p2->head = p2->head->next;
			q2->head = q2->head->next;
			p1->head = p1->head->next;
			q1->head = q1->head->next;
		}
	}
	if(p1->head == NULL){																			
		while(p2->head != NULL){
			llist_append( c.exponents, p2->head->data); 
			llist_append( c.coeffs, -1*q2->head->data);											// Appending the remaining terms from one containing highest degree polynomial
			p2->head = p2->head->next;
			q2->head = q2->head->next;		
		}	
	}
	if(p2->head == NULL){
		while(p1->head != NULL){
			llist_append( c.exponents, p1->head->data); 
			llist_append( c.coeffs, q1->head->data); 		
			p1->head = p1->head->next;
			q1->head = q1->head->next;
		}
	}

	return c;
}

Polynomial multiply(Polynomial a, Polynomial b)
{

	int i, j, temp1, temp2; 
	int n = llist_size(a.exponents);   
	int m = llist_size(b.exponents);
	
	Polynomial c, d;   
	
	c.exponents = llist_new();  
	c.coeffs = llist_new();  
	
	d.coeffs = llist_new();  
	d.exponents = llist_new(); 
	
	
	for(i =0 ; i < n; i++){    
	
		for(j = 0 ;j < m ; j++){
		
		   	temp1 = llist_get(a.exponents,i)+llist_get(b.exponents,j);							// Multiplying all of 2nd poly with one of the term of 1st poly
		  
		   	temp2 = (llist_get(a.coeffs,i))*(llist_get(b.coeffs,j));													
		  
			if(temp2 != 0){
				llist_append(d.exponents, temp1);
				llist_append(d.coeffs,temp2);
			}
		}
		c = add( d, c);																			// Adding the sum obtained by to the rest
		
		d.exponents = llist_new();  															
		d.coeffs = llist_new();     
	}
	  return c;
}

long long int evaluate(Polynomial a, int k){
	
	Node *p, *q; 
	p = a.exponents->head;																		
	q = a.coeffs->head;
	
	long long int sum = 0;
	long long int temp;
	
	while( p != NULL || q != NULL ){
		
		temp = power( k, p->data);															// Finding value of each terms and adding them to the total sum			
		sum = q->data*temp + sum;
		p = p->next;
		q = q->next;
	}
	return sum;
}
long long int power(int a, int n){
	int i;
	long long int product = 1;
	
	for(i = 0; i < n; i++){
		product = product*a;
	}
	return product;
}
