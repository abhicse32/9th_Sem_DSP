#include <stdio.h>
#include "Polynomial.h"
#include "List.h"
#include <stdlib.h>
#include <math.h>

int main(){

	int n, m, temp, option;														
	int i; //Counter
	
	scanf("%d", &option);
	while( option != -1 ){						// Terminating condition
	
	switch(option){
		case 1: {
			Polynomial a;							// New variables and memory for its pointers
			a.exponents = llist_new();
			a.coeffs = llist_new();
			
			scanf("%d", &n);
													//Imput data
			for( i = 0; i < n; i++){
				scanf("%d", &temp);
				llist_append(a.exponents, temp);
			}
	
			for( i = 0; i < n; i++){
				scanf("%d", &temp);
				llist_append(a.coeffs, temp);
			}
			print_polynomial(a);
			break;	
		}
		case 2: {
			Polynomial a;							// New variables and memory for its pointers
			a.exponents = llist_new();
			a.coeffs = llist_new();	
			scanf("%d", &n);
	
			for( i = 0; i < n; i++){
				scanf("%d", &temp);
				llist_append(a.exponents, temp);
			}
	
			for( i = 0; i < n; i++){
				scanf("%d", &temp);
				llist_append(a.coeffs, temp);
			}
			temp = get_degree(a);
			printf("%d\n", temp);
		
			break;
			}
		
		
		case 3: {
		
			Polynomial a, b, c;
			a.exponents = llist_new();				// New variables and memory for its pointers
			a.coeffs = llist_new();	
	
			b.exponents = llist_new();
			b.coeffs = llist_new();
	
			c.exponents = llist_new();
			c.coeffs = llist_new();
	
			scanf("%d", &n);
			
			for( i = 0; i < n; i++){
				scanf("%d", &temp);
				llist_append(a.exponents, temp);
			}
	
			for( i = 0; i < n; i++){
				scanf("%d", &temp);						// input data
				llist_append(a.coeffs, temp);
			}
			scanf("%d", &m);
			for( i = 0; i < m; i++){
				scanf("%d", &temp);
				llist_append(b.exponents, temp);
			}
	
			for( i = 0; i < m; i++){
				scanf("%d", &temp);
				llist_append(b.coeffs, temp);
			}
			c = add( a, b);
			print_polynomial(c);
			break;
			}
			
		
		
		case 4: {
		
			Polynomial a, b, c;
			
			a.exponents = llist_new();
			a.coeffs = llist_new();				// New variables and memory for its pointers
	
			b.exponents = llist_new();
			b.coeffs = llist_new();
	
			c.exponents = llist_new();
			c.coeffs = llist_new();

			scanf("%d", &n);
	
			for( i = 0; i < n; i++){
				scanf("%d", &temp);
				llist_append(a.exponents, temp);
			}
	
			for( i = 0; i < n; i++){
				scanf("%d", &temp);
				llist_append(a.coeffs, temp);
			}
			scanf("%d", &m);
			for( i = 0; i < m; i++){
				scanf("%d", &temp);
				llist_append(b.exponents, temp);
			}
	
			for( i = 0; i < m; i++){
				scanf("%d", &temp);
				llist_append(b.coeffs, temp);
			}
			
			c = subtract( a, b );
			print_polynomial(c);
			break;
			}
		
	
		case 5: {
		
			Polynomial a, b, c;
			
			a.exponents = llist_new();
			a.coeffs = llist_new();					// New variables and memory for its pointers
	
			b.exponents = llist_new();
			b.coeffs = llist_new();
	
			c.exponents = llist_new();
			c.coeffs = llist_new();
			scanf("%d", &n);
	
			for( i = 0; i < n; i++){
				scanf("%d", &temp);
				llist_append(a.exponents, temp);
			}
	
			for( i = 0; i < n; i++){
				scanf("%d", &temp);
				llist_append(a.coeffs, temp);
			}
			scanf("%d", &m);
			for( i = 0; i < m; i++){
				scanf("%d", &temp);
				llist_append(b.exponents, temp);
			}
	
			for( i = 0; i < m; i++){
				scanf("%d", &temp);
				llist_append(b.coeffs, temp);
			}
			
			c = multiply(a, b);
			print_polynomial(c);
			
			break;
		
		
		case 6: {
			
			Polynomial a;
			
			a.exponents = llist_new();
			a.coeffs = llist_new();				// New variables and memory for its pointers
			scanf("%d", &n);
			
			for( i = 0; i < n; i++){
				scanf("%d", &temp);
				llist_append(a.exponents, temp);
			}
	
			for( i = 0; i < n; i++){
				scanf("%d", &temp);
				llist_append(a.coeffs, temp);
			}
			int k;
			scanf("%d", &k);
			
			long long int m = evaluate(a, k);
			printf("%lld\n", m);
			
			break;
				}
		
	}
		
	}
	scanf("%d", &option);
	}
	return 0;
}
