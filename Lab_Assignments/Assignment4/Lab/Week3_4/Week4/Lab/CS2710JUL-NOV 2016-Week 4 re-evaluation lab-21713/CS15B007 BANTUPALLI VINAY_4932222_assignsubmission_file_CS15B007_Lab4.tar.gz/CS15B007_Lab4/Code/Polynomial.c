#include "Polynomial.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int get_degree(Polynomial p){

	LList *con;
	Node *exp;
	Node *coef;
	
	con=p.exponents;
	exp=con->head;
	
	con=p.coeffs;
	coef=con->head;

	if(exp==NULL){							
		return 0;
	}	
	for( ; exp->next!=NULL ; ){
		exp=exp->next;
	}
	return exp->data;						//returning the highest exponent
}

void print_polynomial(Polynomial p){
	
	LList *con;
	Node *exp;
	Node *coef;
	
	con=p.exponents;
	exp=con->head;
	
	con=p.coeffs;
	coef=con->head;
	int t=0,k;

	for( ; exp!=NULL ; t++){
		
		k=coef->data;
		if(exp->data > 1){
			if(t!=0){
				if(coef->data > 0){
					printf("+ ");
					k=coef->data;	
				}
				else if(coef->data < 0){
					printf("- ");
					k=(-1)*coef->data;
				}
				else if(coef->data == 0){
					continue;
				}
			}
			printf("%dx^%d ",k,exp->data);
		}
		else if(exp->data==0){
			if(coef->data == 0){
				t--;
				continue;
			}
			printf("%d ",coef->data);
		}
		else if(exp->data==1){
			if(t!=0){
				if(coef->data > 0){
					printf("+ ");
					k=coef->data;	
				}
				else if(coef->data < 0){
					printf("- ");
					k=(-1)*coef->data;
				}
				else if(coef->data == 0){
					continue;
				}
			}	
			printf("%dx^1 ",k);
		}
		exp = exp->next ;
		coef=coef->next ;
	}
	printf("\n");	
	return;
}

Polynomial add(Polynomial p1, Polynomial p2){

	LList *con;
	
	Node *exp1;
	Node *coef1;
	con=p1.exponents;
	exp1=con->head;
	con=p1.coeffs;
	coef1=con->head;

	Node *exp2;
	Node *coef2;
	con=p2.exponents;
	exp2=con->head;
	con=p2.coeffs;
	coef2=con->head;	

	Polynomial p;
	p.exponents=llist_new();
	p.coeffs=llist_new();
	LList *con1,*con2;
	con1=p.exponents;
	con2=p.coeffs;
	Node *exp,*coef,*q1,*q2;
	
	int t=0,flag=0;
	
	for( ; exp1!=NULL && exp2!=NULL ; ){
	
		q1=(Node *)malloc(sizeof(Node));
		q2=(Node *)malloc(sizeof(Node));
	
		if(t==0){
			exp=q1;
			coef=q2;
			con1->head=exp;
			con2->head=coef;
			exp->next=NULL;
			coef->next=NULL;
			t++;
		}

		if(flag == 0){
			exp->next=q1;
			q1=exp;
			exp=exp->next;
			coef->next=q2;
			q2=coef;
			coef=coef->next;
			exp->next=NULL;
			coef->next=NULL;
		}
		flag=0;

		if(exp1->data == exp2->data ){
			if(coef1->data + coef2->data != 0){
				coef->data=coef1->data + coef2->data;
				exp->data=exp1->data;
			}
			else flag=1;
			exp1=exp1->next;
			exp2=exp2->next;
			coef1=coef1->next;
			coef2=coef2->next;	
		}
		
		else if(exp1->data < exp2->data){
			coef->data=coef1->data;
			exp->data = exp1->data;
			exp1=exp1->next;
			coef1=coef1->next;		
		}
		
		else {
			coef->data=coef2->data;
			exp->data=exp2->data;
			exp2=exp2->next;
			coef2=coef2->next;		
		}
	}
	if(exp1==NULL && exp2 == NULL){
		if(flag==1){
			q1->next=NULL;
			q2->next=NULL;
		}
	}	
		
	if(exp1==NULL){
		for( ; exp2!=NULL ; ){
			
			q1=(Node *)malloc(sizeof(Node));
			q2=(Node *)malloc(sizeof(Node));
		
			if(t==0){
				exp=q1;
				coef=q2;
				exp->next=NULL;
				coef->next=NULL;
				t++;
			}
			if(flag == 0){
			exp->next=q1;
			exp=exp->next;
			coef->next=q2;
			coef=coef->next;
			exp->next=NULL;
			coef->next=NULL;
			}
			flag=0;
			
			coef->data=coef2->data;
			exp->data=exp2->data;
			exp2=exp2->next;
			coef2=coef2->next;		
		}
	}
	
	else if(exp2==NULL){
		for( ; exp1!=NULL ; ){
			
			q1=(Node *)malloc(sizeof(Node));
			q2=(Node *)malloc(sizeof(Node));
		
			if(t==0){
				exp=q1;
				coef=q2;
				exp->next=NULL;
				coef->next=NULL;
				t++;
			}
			if(flag == 0){
			exp->next=q1;
			exp=exp->next;
			coef->next=q2;
			coef=coef->next;
			exp->next=NULL;
			coef->next=NULL;
			}
			flag=0;
			
			coef->data=coef1->data;
			exp->data = exp1->data;
			exp1=exp1->next;
			coef1=coef1->next;	
					
		}
	}
	
	
	p.exponents=con1;
	p.coeffs=con2;
	
	return p;
}	

Polynomial subtract(Polynomial p1, Polynomial p2){

	LList *con;
	
	Node *exp1;
	Node *coef1;
	con=p1.exponents;
	exp1=con->head;
	con=p1.coeffs;
	coef1=con->head;

	Node *exp2;
	Node *coef2;
	con=p2.exponents;
	exp2=con->head;
	con=p2.coeffs;
	coef2=con->head;	

	Polynomial p;
	p.exponents=llist_new();
	p.coeffs=llist_new();
	LList *con1,*con2;
	con1=p.exponents;
	con2=p.coeffs;
	Node *exp,*coef,*q1,*q2;
	int t=0,flag=0;
	

	for( ; exp1!=NULL && exp2!=NULL ; ){
	
		q1=(Node *)malloc(sizeof(Node));
		q2=(Node *)malloc(sizeof(Node));
	
		if(t==0){
			exp=q1;
			coef=q2;
			con1->head=exp;
			con2->head=coef;
			exp->next=NULL;
			coef->next=NULL;
			t++;
		}
		if(flag==0){
			exp->next=q1;
			q1=exp;
			exp=exp->next;
			coef->next=q2;
			q2=coef;
			coef=coef->next;
			exp->next=NULL;
			coef->next=NULL;
		}
		flag=0;

		if(exp1->data == exp2->data ){
			if(coef1->data - coef2->data != 0){
				coef->data=coef1->data - coef2->data;
				exp->data=exp1->data;
			}
			else flag=1;
			exp1=exp1->next;
			exp2=exp2->next;
			coef1=coef1->next;
			coef2=coef2->next;	
		}
		
		else if(exp1->data < exp2->data){
			coef->data=coef1->data;
			exp->data = exp1->data;
			exp1=exp1->next;
			coef1=coef1->next;		
		}
		
		else {
			coef->data=(-1)*coef2->data;
			exp->data=exp2->data;
			exp2=exp2->next;
			coef2=coef2->next;		
		}
	}
	
	if(exp1==NULL && exp2 == NULL){
		if(flag==1){
			q1->next=NULL;
			q2->next=NULL;
		}
	}
	
	if(exp1==NULL){
		for( ; exp2!=NULL ; ){
			
			q1=(Node *)malloc(sizeof(Node));
			q2=(Node *)malloc(sizeof(Node));
		
			if(t==0){
				exp=q1;
				coef=q2;
				exp->next=NULL;
				coef->next=NULL;
				t++;
			}
			
			if(flag==0){
			exp->next=q1;
			exp=exp->next;
			coef->next=q2;
			coef=coef->next;
			exp->next=NULL;
			coef->next=NULL;
			}
			flag=0;
			
			coef->data=(-1)*coef2->data;
			exp->data=exp2->data;
			exp2=exp2->next;
			coef2=coef2->next;		
		}
	}
	
	else if(exp2==NULL){
		for( ; exp1!=NULL ; ){
			
			q1=(Node *)malloc(sizeof(Node));
			q2=(Node *)malloc(sizeof(Node));
		
			if(t==0){
				exp=q1;
				coef=q2;
				exp->next=NULL;
				coef->next=NULL;
				t++;
			}
			if(flag==0){
			exp->next=q1;
			exp=exp->next;
			coef->next=q2;
			coef=coef->next;
			exp->next=NULL;
			coef->next=NULL;
			}
			flag=0;
			
			coef->data=coef1->data;
			exp->data = exp1->data;
			exp1=exp1->next;
			coef1=coef1->next;	
					
		}
	}
	
	p.exponents=con1;
	p.coeffs=con2;
	
	return p;

}



Polynomial multiply(Polynomial p1, Polynomial p2){

	LList *con,*con1,*con2;
	
	Node *exp1,*exp2;
	Node *coef1,*coef2;
	con=p1.exponents;
	exp1=con->head;
	con=p1.coeffs;
	coef1=con->head;
	
	con=p2.exponents;
	exp2=con->head;
	con=p2.coeffs;
	coef2=con->head;	

	Polynomial p;
	p.exponents=llist_new();
	p.coeffs=llist_new();
	con1=p.exponents;
	con2=p.coeffs;
	Node *exp,*coef,*dexp2,*dcoef2,*dexp,*dcoef;
	
	dexp2=exp2;
	dcoef2=coef2;	
	
	exp=(Node *)malloc(sizeof(Node));	
	coef=(Node *)malloc(sizeof(Node));
	exp->next=NULL;	
	coef->next=NULL;
	exp->data=exp1->data + exp2->data;
	coef->data=coef1->data * coef2->data;
	con1->head=exp;
	con2->head=coef;
	
	exp2=exp2->next;
	coef2=coef2->next;
	
	for( ; exp1!=NULL ; ){
		
		for( ; exp2!=NULL ;){
				
			int deg=exp1->data + exp2->data;
			int bef=coef1->data * coef2->data;
			
			int index=0 ,flag=0;
			
			exp=con1->head;
			coef=con2->head;
			int i;	
			for( i=0 ; exp!=NULL ;i++ ){						//if degree found adding coefficient  
				if(exp->data == deg){					//else creating a new node and appending it
					coef->data +=bef;
					if(coef->data==0){
						llist_remove(con1,i);
						llist_remove(con2,i);
					}
					flag++;
					break;
				}
				exp=exp->next;
				coef=coef->next;
			}
			if (flag==0){
				exp=con1->head;
				coef=con2->head;
				
				for( ; exp!=NULL ; index++){
					if(exp->data > deg){break;}
					exp=exp->next;
					coef=coef->next;
				}
				
				llist_insert (con1 ,index ,deg);
				llist_insert (con2 ,index ,bef);
			}
			exp2=exp2->next;
			coef2=coef2->next;
		}
		exp2=dexp2;
		coef2=dcoef2;
		coef1=coef1->next;
		exp1=exp1->next;
	}

	p.exponents=con1;
	p.coeffs=con2;	
	return p;
}


long int evaluate(Polynomial p, int k){
	
	LList *con;
	Node *exp,*coef;
	long int result=0;	
		
	con=p.exponents;
	exp=con->head;
	
	con=p.coeffs;
	coef=con->head;
	
	for( ; exp!=NULL ; ){
		result += ((coef->data) * pow( k , exp->data));
			
		exp = exp->next;
		coef= coef->next;	
	}	
	
	return result;
}



	
