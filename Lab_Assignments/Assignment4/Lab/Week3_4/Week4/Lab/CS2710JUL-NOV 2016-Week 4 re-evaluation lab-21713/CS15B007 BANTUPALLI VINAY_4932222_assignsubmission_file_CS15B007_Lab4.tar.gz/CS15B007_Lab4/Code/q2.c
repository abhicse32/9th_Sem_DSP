#include<stdio.h>
#include<stdlib.h>
#include"Polynomial.h"

int main(){

	int k,i;
	for( ; ; ){
		scanf("%d",&k);
	
		if(k==-1){break;}									//terminating the function if input =-1
		switch(k){
		
			case 1 :{
				Polynomial p;
				int t,temp;
				scanf("%d",&t);
				
				p.exponents=llist_new();
				p.coeffs=llist_new();
				
				for(i=0 ; i<t ; i++){							//scanning the exponent list
					scanf("%d",&temp);
					llist_append(p.exponents,temp);
					}
				for(i=0 ; i<t ; i++){							//scanning the coefficients list
					scanf("%d",&temp);
					llist_append(p.coeffs,temp);
				}
				print_polynomial(p);						//calling print function
				break;
			}
		
			case 2 :{
				Polynomial p;
				int t,temp,deg;
				scanf("%d",&t);
				
				p.exponents=llist_new();
				p.coeffs=llist_new();
				
				
				for(i=0 ; i<t ; i++){							//scanning the exponent list
					scanf("%d",&temp);
					llist_append(p.exponents,temp);
				}
				for(i=0 ; i<t ; i++){							//scanning the coefficients list
					scanf("%d",&temp);
					llist_append(p.coeffs,temp);
				}
			
				deg=get_degree(p);
				printf("%d\n",deg);
				break;
			}
		
			case 3 :{
				Polynomial p1,p2;
				int t1,t2,temp;
			
				p1.exponents=llist_new();
				p1.coeffs=llist_new();
				
				p2.exponents=llist_new();
				p2.coeffs=llist_new();
					
				scanf("%d",&t1);
			
				for(i=0 ; i<t1 ; i++){ 					//scanning the exponent list
					scanf("%d",&temp);
					llist_append(p1.exponents,temp);
				}
				for(i=0 ; i<t1 ; i++){					//scanning the coefficients list
					scanf("%d",&temp);
					llist_append(p1.coeffs,temp);
				}
			
				scanf("%d",&t2);
			
				for(i=0 ; i<t2 ; i++){					//scanning the exponent list
					scanf("%d",&temp);
					llist_append(p2.exponents,temp);
				}
				for(i=0 ; i<t2 ; i++){					//scanning the coefficients list
					scanf("%d",&temp);
					llist_append(p2.coeffs,temp);
				}
			
				Polynomial p=add(p1,p2);
				print_polynomial(p);
				break;
			}
		
			case 4 :{
				Polynomial p1,p2;
				int t1,t2,temp;
				p1.exponents=llist_new();
				p1.coeffs=llist_new();
				
				p2.exponents=llist_new();
				p2.coeffs=llist_new();
				
				scanf("%d",&t1);
			
				for(i=0 ; i<t1 ; i++){				//scanning the exponent list
					scanf("%d",&temp);
					llist_append(p1.exponents,temp);
				}
				for(i=0 ; i<t1 ; i++){				//scanning the coefficients list
					scanf("%d",&temp);
					llist_append(p1.coeffs,temp);
				}
			
				scanf("%d",&t2);
			
				for(i=0 ; i<t2 ; i++){
					scanf("%d",&temp);
					llist_append(p2.exponents,temp);
				}
				for(i=0 ; i<t2 ; i++){				//scanning the coefficients list
					scanf("%d",&temp);
					llist_append(p2.coeffs,temp);
				}
			
				Polynomial p=subtract(p1,p2);
				print_polynomial(p);
				break;
			}
		
		case 5 :{
			Polynomial p1,p2;
				int t1,t2,temp;
			
				p1.exponents=llist_new();
				p1.coeffs=llist_new();
				
				p2.exponents=llist_new();
				p2.coeffs=llist_new();
				
				scanf("%d",&t1);
			
				for(i=0 ; i<t1 ; i++){							//scanning the exponent list
					scanf("%d",&temp);
					llist_append(p1.exponents,temp);
				}
				for(i=0 ; i<t1 ; i++){							//scanning the coefficients list
					scanf("%d",&temp);
					llist_append(p1.coeffs,temp);
				}
			
				scanf("%d",&t2);
			
				for(i=0 ; i<t2 ; i++){							//scanning the exponent list
					scanf("%d",&temp);
					llist_append(p2.exponents,temp);
				}
				for(i=0 ; i<t2 ; i++){							//scanning the coefficients list
					scanf("%d",&temp);
					llist_append(p2.coeffs,temp);
				}
			
				Polynomial p=multiply(p1,p2);
				print_polynomial(p);
				break;
		}
	
		case 6 :{
				Polynomial p;
				int x,t,temp;
				p.exponents=llist_new();
				p.coeffs=llist_new();
				
				long int o;
				scanf("%d",&t);
			
				for(i=0 ; i<t ; i++){								//scanning the exponent list
					scanf("%d",&temp);
					llist_append(p.exponents,temp);
				}
				for(i=0 ; i<t ; i++){								//scanning the coefficients list
					scanf("%d",&temp);
					llist_append(p.coeffs,temp);
				}
				scanf("%d",&x);
				o=evaluate(p,x);
				printf("%ld\n",o);
				break;
			}
		}
	}
	return 0;
	
}
