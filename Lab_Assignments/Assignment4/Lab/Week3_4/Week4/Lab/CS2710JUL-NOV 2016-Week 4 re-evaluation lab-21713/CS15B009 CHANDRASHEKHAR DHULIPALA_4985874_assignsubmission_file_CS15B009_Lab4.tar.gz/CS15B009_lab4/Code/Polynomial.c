/*  Program to implement the polynomial ADT and its functions using linked lists 
	
	By  Chandrashekhar D --- Roll no.CS15B009 --- 29 Aug 2016 --- CS2710 Lab Assignment 4  */

#include "Polynomial.h"
#include "List.h"       // Importing functions from List.c and function prototypes, structures from Polynomial.h
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

/*  Function to find the degree of a given polynomial ;
	Input parameters : the polynomial P
	Returns : the degree of the polynomial  */
int get_degree(Polynomial P)
{
	Node* expo_head;
	expo_head = (P.exponents)->head;
	int deg = expo_head->data;
	while(expo_head->next != NULL)
	{
		expo_head = expo_head->next;
		if(expo_head->data > deg)
			deg = expo_head->data;
	}
	return deg;
}

/*  Function to print a given polynomial as an expression in 'x' :
	Input parameters : polynomial P
	Returns : nothing  */
void print_polynomial(Polynomial P)
{
	Node* exp_head;
	Node* coef_head;
	exp_head = (P.exponents)->head;
	coef_head = (P.coeffs)->head;
	
	int flag = 0;  // keeps track of the first term to be printed     
	
	while(coef_head->data == 0)  
	{
		exp_head = exp_head->next;
		coef_head = coef_head->next;
	}
	if(exp_head->data == 0)   // If exponent is 0
	{
		printf("%d ",coef_head->data);
		exp_head = exp_head->next;
		coef_head = coef_head->next;
		flag = 1;
	}
	while(exp_head != NULL)   // For other exponents
	{
		if(flag == 1)
		{
			if(coef_head->data > 0)      // positive coefficient
				printf("+ %dx^%d ",coef_head->data,exp_head->data);
			else if(coef_head->data < 0)                        // negative coefficient
				printf("- %dx^%d ",abs(coef_head->data),exp_head->data);
		}
		else 
		{
			if(coef_head->data != 0)
			{
				printf("%dx^%d ",coef_head->data,exp_head->data);
				flag = 1;
			}
		}
		exp_head = exp_head->next;
		coef_head = coef_head->next;
	}
	
}

/*  Function to add two polynomials :
	Input parameters : two polynomials P1,P2
	Returns : the polynomial sum P1+P2 */
Polynomial add(Polynomial P1, Polynomial P2)
{
	Node* ehead1 = (P1.exponents)->head;
	Node* chead1 = (P1.coeffs)->head;
	Node* ehead2 = (P2.exponents)->head;
	Node* chead2 = (P2.coeffs)->head;
	
	Polynomial sum;
	sum.exponents = llist_new();
	sum.coeffs = llist_new();
	int i = 0;

	// Traverse both lists and add coefficients in increasing order of exponents :
	while(ehead1 != NULL && ehead2 != NULL)
	{
		if(ehead1->data < ehead2->data)
		{
			llist_insert(sum.exponents,i,ehead1->data);
			llist_insert(sum.coeffs,i,chead1->data);
			ehead1 = ehead1->next;
			chead1 = chead1->next;
			i++;
		}
		else if(ehead1->data > ehead2->data)
		{
			llist_insert(sum.exponents,i,ehead2->data);
			llist_insert(sum.coeffs,i,chead2->data);
			ehead2 = ehead2->next;
			chead2 = chead2->next;
			i++;
		}
		else if(ehead1->data == ehead2->data)
		{
			llist_insert(sum.exponents,i,ehead1->data);
			llist_insert(sum.coeffs,i,chead1->data+chead2->data);
			ehead1 = ehead1->next;
			chead1 = chead1->next;
			ehead2 = ehead2->next;
			chead2 = chead2->next;
			i++;
		}
	}
	while(ehead1 != NULL) // End of list 2
	{
		llist_insert(sum.exponents,i,ehead1->data);
		llist_insert(sum.coeffs,i,chead1->data);
		ehead1 = ehead1->next;
		chead1 = chead1->next;
		i++;
	}
	while(ehead2 != NULL) // End of list 1
	{
		llist_insert(sum.exponents,i,ehead2->data);
		llist_insert(sum.coeffs,i,chead2->data);
		ehead2 = ehead2->next;
		chead2 = chead2->next;
		i++;
	}
	return sum;
}

/*  Function to multiply a polynomial by -1 :
	Input parameters : polynomial P
	Returns : nothing */
void negate(Polynomial P)
{
	Node* h = (P.coeffs)->head;
	while(h != NULL)
	{
		h->data = (-1)*(h->data);
		h = h->next;
	}	
}

/*  Function to subtract two polynomials :
	Input parameters : two polynomials P1,P2
	Returns : the polynomial difference P1-P2 */
Polynomial subtract(Polynomial P1, Polynomial P2)
{
	negate(P2);
	Polynomial diff = add(P1,P2);
	return diff;
}


/*  Function to multiply two polynomials :
	Input parameters : two polynomials P1,P2
	Returns : the polynomial product P1*P2 */
Polynomial multiply(Polynomial P1, Polynomial P2)
{
	Node* ehead1 = (P1.exponents)->head;
	Node* chead1 = (P1.coeffs)->head;
	Polynomial product,run;
	product.exponents = llist_new();
	product.coeffs = llist_new();

	// Multiply each term of P1 with whole of P2 and sum up the resulting expressions :
	while(ehead1 != NULL)
	{
		run.exponents = llist_new();
		run.coeffs = llist_new();
		
		int i = 0;
		Node* ehead2 = (P2.exponents)->head;
		Node* chead2 = (P2.coeffs)->head;
		while(ehead2 != NULL)
		{
			llist_insert(run.exponents,i,ehead2->data+ehead1->data);
			llist_insert(run.coeffs,i,chead2->data*chead1->data);
			i++;
			ehead2 = ehead2->next;
			chead2 = chead2->next; 
		}
		product = add(product,run);
		ehead1 = ehead1->next;
		chead1 = chead1->next;
	}
	
	return product;
}

/*  Function to evaluate a polynomial at a value x = k :
	Input parameters : polynomial P, integer k
	Returns : the value of P at k, long long integer  */
long long int evaluate(Polynomial P, int k)
{
	long long int sum = 0;
	Node* ehead = (P.exponents)->head;
	Node* chead = (P.coeffs)->head;
	while(ehead != NULL)
	{
		sum = sum + (chead->data)*pow(k,ehead->data);
		ehead = ehead->next;
		chead = chead->next;
	}
	return sum;
}


























