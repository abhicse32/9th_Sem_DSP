/*  Program to perform operations on the polynomial ADT according to user input.
	
	By  Chandrashekhar D --- Roll no.CS15B009 --- 29 August 2016 --- CS2710 lab Assignment 4  */

#include <stdio.h>
#include "Polynomial.h"  // Importing functions defined in Polynomial.h
#include "List.h"

int main()
{
	// Declaration of required variables : 
	int choice,i,inp;
	int t1,t2,k;
	Polynomial P1,P2,ans;
	long long int val;

	while(1)
	{
		scanf("%d",&choice);  // Taking input the user choice
		if(choice == -1)      // Termination condition - user enters -1
			break;
		
		switch(choice)        // switch case construct for choice
		{
			
			case 1:                          // Printing a polynomial
				P1.exponents = llist_new();
				P1.coeffs = llist_new();
				scanf("%d",&t1);             // No. of terms in polynomial

				for(i = 0;i < t1;i++)
				{
					scanf("%d",&inp);
					llist_insert(P1.exponents,i,inp);   // exponents list 
				}
				for(i = 0;i < t1;i++)
				{
					scanf("%d",&inp);
					llist_insert(P1.coeffs,i,inp);      // coefficients list
				}

				print_polynomial(P1);   // Printing the polynomial
				printf("\n");
				break;

			case 2:                         // Finding the degree of a polynomial
				P1.exponents = llist_new();
				P1.coeffs = llist_new();
				scanf("%d",&t1);            // No. of terms in polynomial
				
				for(i = 0;i < t1;i++)
				{
					scanf("%d",&inp);
					llist_insert(P1.exponents,i,inp);   // exponents list
				}
				for(i = 0;i < t1;i++)
				{
					scanf("%d",&inp);
					llist_insert(P1.coeffs,i,inp);      // coefficients list
				}
				
				printf("%d\n",get_degree(P1));  // Finding and printing the degree
				break;

			case 3:                         // Finding the sum of two polynomials
				P1.exponents = llist_new();
				P1.coeffs = llist_new();
				P2.exponents = llist_new();
				P2.coeffs = llist_new();
				scanf("%d",&t1);            // No. of terms in polynomial
				
				for(i = 0;i < t1;i++)
				{
					scanf("%d",&inp);
					llist_insert(P1.exponents,i,inp);   // exponents list
				}
				for(i = 0;i < t1;i++)
				{
					scanf("%d",&inp);
					llist_insert(P1.coeffs,i,inp);      // coefficients list
				}
				
				scanf("%d",&t2);           // No. of terms in polynomial
				
				for(i = 0;i < t2;i++)
				{
					scanf("%d",&inp);
					llist_insert(P2.exponents,i,inp);   // exponents list
				}
				for(i = 0;i < t2;i++)
				{
					scanf("%d",&inp);
					llist_insert(P2.coeffs,i,inp);      // coefficients list
				}
				
				ans = add(P1,P2);      // sum P!+P2
				print_polynomial(ans);
				printf("\n");
				break;

			case 4:                         // Finding the difference of two polynomials
				P1.exponents = llist_new();
				P1.coeffs = llist_new();
				P2.exponents = llist_new();
				P2.coeffs = llist_new();
				scanf("%d",&t1);
				for(i = 0;i < t1;i++)
				{
					scanf("%d",&inp);
					llist_insert(P1.exponents,i,inp);
				}
				for(i = 0;i < t1;i++)
				{
					scanf("%d",&inp);
					llist_insert(P1.coeffs,i,inp);
				}
				scanf("%d",&t2);
				for(i = 0;i < t2;i++)
				{
					scanf("%d",&inp);
					llist_insert(P2.exponents,i,inp);
				}
				for(i = 0;i < t2;i++)
				{
					scanf("%d",&inp);
					llist_insert(P2.coeffs,i,inp);
				}
				
				ans = subtract(P1,P2);  // difference P1-P2
				print_polynomial(ans);
				printf("\n");
				break;

			case 5:                          // Finding the product of two polynomials
				P1.exponents = llist_new();
				P1.coeffs = llist_new();
				P2.exponents = llist_new();
				P2.coeffs = llist_new();
				scanf("%d",&t1);
				for(i = 0;i < t1;i++)
				{
					scanf("%d",&inp);
					llist_insert(P1.exponents,i,inp);
				}
				for(i = 0;i < t1;i++)
				{
					scanf("%d",&inp);
					llist_insert(P1.coeffs,i,inp);
				}
				scanf("%d",&t2);
				for(i = 0;i < t2;i++)
				{
					scanf("%d",&inp);
					llist_insert(P2.exponents,i,inp);
				}
				for(i = 0;i < t2;i++)
				{
					scanf("%d",&inp);
					llist_insert(P2.coeffs,i,inp);
				}
				
				ans = multiply(P1,P2);  // product P1*P2 
				print_polynomial(ans);
				printf("\n");
				break;

			case 6:                          // Value of polynomial at x = k
				P1.exponents = llist_new();
				P1.coeffs = llist_new();
				
				scanf("%d",&t1);             // No. of terms in polynomial
				for(i = 0;i < t1;i++)
				{
					scanf("%d",&inp);
					llist_insert(P1.exponents,i,inp);    // exponents list
				}
				for(i = 0;i < t1;i++)
				{
					scanf("%d",&inp);
					llist_insert(P1.coeffs,i,inp);       // coefficients list
				}
				
				scanf("%d",&k);        // Element to evaluate P for
				
				val = evaluate(P1,k);
				printf("%lld\n",val);
				break;

			default:
				printf("Invalid choice\n"); 
		}	// End of switch construct
	
	}	// End of while loop
	
	return 0;
}
