#include "List.h"
#include<stdio.h>
#include<stdlib.h>
#include<limits.h>

Node* node_new(int data){
	Node *node;
	node=(Node *)malloc(sizeof(Node));
	if(node==NULL)
		printf("Malloc Error!");	//creating a node
	else{
		node->data = data;
		node->next = NULL;
	}
	return(node);
}

LList* llist_new(){
	LList* sll;
	sll=(LList *)malloc(sizeof(LList));	//allocating space for the new list
	sll->head = NULL;
	return sll;
}

int llist_size( LList* lst ){
	int count=0;
	Node *curr;
	if(lst->head!=NULL){ 
	    count++;
		for(curr=lst->head;curr->next!=NULL;curr=curr->next){	//inc counter till the last element
			count++;
		}
	}
	return count;
}

void llist_print( LList* lst ){
	Node *curr;
	curr = lst->head ;
	
	while( curr )
	{
		printf( "%d " , curr->data);	//printing current data and going for the next one till null
		curr = curr ->next ;
	} 
	printf("\n");
	return;
}

int llist_get( LList* lst, int idx ){
	int count=0;
	Node *curr;
	if(lst->head!=NULL){ 
		curr=lst->head;
		for(count=0;count<idx;count ++){
			if(curr->next==NULL){
				return INT_MIN; }	//using the counter for the no of steps
			else{
				curr=curr->next;
			}
		}
		return curr->data;
	}
	return INT_MIN;
}

void llist_append( LList* lst, int data ){
	Node *curr;
	if(lst->head!=NULL){ 
		for(curr=lst->head;curr->next!=NULL;curr=curr->next){
		}
		Node *node;
		node=node_new(data);
		curr->next = node;		
	}
	else{
		Node *node;	//check for single node list
		node=node_new(data);
		lst->head=node;		
	}
	return;
}

void llist_prepend( LList* lst, int data ){
	if(lst->head==NULL){ llist_append(lst,data); return;}
	Node *node;
	node=node_new(data);
	node->next = lst->head;
	lst->head = node;
	return;
}

void llist_insert( LList* lst, int idx, int data ){
	Node *node;
	node=node_new(data);
	Node *curr;
	int count;
	if(lst->head!=NULL){ 
		if(idx==0){ llist_prepend(lst,data); return; }	//using the pointer to keep the no of steps
		curr=lst->head;
		for(count=0;count<idx-1;count ++){
			if(curr->next==NULL){
				return; }
			else{
				curr=curr->next;
			}
		}
		node->data =data;
		node->next=curr->next;
		curr->next=node;
	}
}

void llist_remove_last( LList* lst ){
	Node *curr;
	if(lst->head!=NULL){ 
		if(lst->head->next==NULL) {  lst->head = NULL; return;} 	//for single node list
		for(curr=lst->head;curr->next!=NULL;curr=curr->next){
			if(curr->next->next==NULL){
				curr->next=NULL;
				break;
			}
		}
				
	}
	return;
}

void llist_remove_first( LList* lst ){
	if(lst->head!=NULL)
		lst->head=lst->head->next;
	return;
}

void llist_remove( LList* lst, int idx ){
	Node *curr;
	int count;
	if(lst->head!=NULL){ 
		if(idx==0){ llist_remove_first(lst);  return; }
		curr=lst->head;		//using a counter to check the no of steps
		for(count=0;count<idx-1;count ++){
			if(curr->next==NULL){
				return; }
			else{
				curr=curr->next;
			}
		}
		curr->next=curr->next->next;
	}
}
