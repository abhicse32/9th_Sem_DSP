#include "Polynomial.h"
#include<stdio.h>
#include<stdlib.h>
#include<limits.h>
#include"List.h"
#include <string.h>
#include<math.h>

void print_polynomial(Polynomial p){
	Node *currc;
	Node *curre;
    currc=(Node *)malloc(sizeof(Node));
    curre=(Node *)malloc(sizeof(Node));
    curre=p.exponents->head;
    currc=p.coeffs->head;
    int check=-1;
	while(curre){
		if(currc->data!=0){
				if(check==0){
					if(curre->data==0){	printf("%d",currc->data); }
					else {
						if(currc->data >0 ) printf(" + %dx^%d",currc->data,curre->data);		//for all other terms
						else printf(" - %dx^%d",-(currc->data),curre->data);
					}
				}
				else{ if(curre->data==0){	printf("%d",currc->data); }
					else { printf("%dx^%d",currc->data,curre->data);}		//for first term
				}
		check=0;
		}
		currc=currc->next;
		curre=curre->next;
	}
     printf("\n");
    free(curre);
    free(currc);
    return;
}

int get_degree(Polynomial p){
	     Node * temp=p.exponents->head;
	     if(temp->next==NULL) return 0;
	     while(temp->next!=NULL){
	     	temp=temp->next;		//checking for the last element
	     }
	     return temp->data;
}


Polynomial add(Polynomial p1, Polynomial p2){
    Node *cur1e;
    Node *cur1c;
    Node *cur2e;    
    Node *cur2c;
    cur1c=p1.coeffs->head;
    cur2e=p2.exponents->head;
    cur2c=p2.coeffs->head;    
    cur1e=p1.exponents->head;
    Polynomial p;
    p.exponents=(LList *) malloc(sizeof(LList));
    p.coeffs=(LList *) malloc(sizeof(LList));
    p.exponents->head=NULL;
    p.coeffs->head=NULL;
    while(cur1e!=NULL&&cur2e!=NULL){
		    if(cur1e->data==cur2e->data){ 
		        llist_append(p.exponents,cur1e->data);
		        llist_append(p.coeffs,(cur1c->data)+(cur2c->data));		//for equal degree appending the sum
		        cur1e=cur1e->next;
		        cur1c=cur1c->next;
		        cur2e=cur2e->next;
		        cur2c=cur2c->next;
		         } 
		         
				
		    else if(cur1e->data  < cur2e->data){
		        llist_append(p.exponents,cur1e->data);
		        llist_append(p.coeffs,cur1c->data);
		        cur1e=cur1e->next;
		        cur1c=cur1c->next;
		    }
		    else{
		        llist_append(p.exponents,cur2e->data);
		        llist_append(p.coeffs,cur2c->data);
		        cur2e=cur2e->next;
		        cur2c=cur2c->next;
		    }
    }
    while(cur2e!=NULL){
    		llist_append(p.exponents,cur2e->data);
            llist_append(p.coeffs,cur2c->data);
            cur2e=cur2e->next;
            cur2c=cur2c->next;
    	}
    	while(cur1e != NULL){
    		llist_append(p.exponents,cur1e->data);
            llist_append(p.coeffs,cur1c->data);
            cur1e=cur1e->next;
            cur1c=cur1c->next;
            
    	}
    free(cur1e);
    free(cur2e);
    free(cur1c);
    free(cur2c);
    return p;
}

Polynomial subtract(Polynomial p1, Polynomial p2){
    Node *cur1e;
    cur1e=(Node *)malloc(sizeof(Node));
    cur1e=p1.exponents->head;
    Node *cur1c;
    cur1c=(Node *)malloc(sizeof(Node));
    cur1c=p1.coeffs->head;    
    Node *cur2e;
    cur2e=(Node *)malloc(sizeof(Node));
    cur2e=p2.exponents->head;
    Node *cur2c;
    cur2c=(Node *)malloc(sizeof(Node));
    cur2c=p2.coeffs->head;
    Polynomial p;
    p.exponents=(LList *) malloc(sizeof(LList));
    p.coeffs=(LList *) malloc(sizeof(LList));
    p.exponents->head=NULL;
    p.coeffs->head=NULL;
    while(cur1e!=NULL&&cur2e!=NULL){
		    if(cur1e->data==cur2e->data){ 
		        llist_append(p.exponents,cur1e->data);		//for equal degree appending the difference
		        int res=(cur1c->data)-(cur2c->data);
		        llist_append(p.coeffs,res);
		        cur1e=cur1e->next;
		        cur1c=cur1c->next;
		        cur2e=cur2e->next;
		        cur2c=cur2c->next;
		         } 
		         
				
		    else if(cur1e->data  < cur2e->data){
		        llist_append(p.exponents,cur1e->data);
		        llist_append(p.coeffs,(cur1c->data));
		        cur1e=cur1e->next;
		        cur1c=cur1c->next;
		    }
		    else{
		        llist_append(p.exponents,cur2e->data);
		        llist_append(p.coeffs,-(cur2c->data));
		        cur2e=cur2e->next;
		        cur2c=cur2c->next;
		    }
    }
    while(cur2e!=NULL){
    		llist_append(p.exponents,cur2e->data);
            llist_append(p.coeffs,-(cur2c->data));
            cur2e=cur2e->next;
            cur2c=cur2c->next;
    	}
    	while(cur1e != NULL){
    		llist_append(p.exponents,cur1e->data);
            llist_append(p.coeffs,cur1c->data);
            cur1e=cur1e->next;
            cur1c=cur1c->next;
            
    	}
    free(cur1e);
    free(cur2e);
    free(cur1c);
    free(cur2c);
    return p;
}

Polynomial multiply(Polynomial p1, Polynomial p2){
    Node *cur1e;
    cur1e=(Node *)malloc(sizeof(Node));
    cur1e=p1.exponents->head;
    Node *cur1c;
    cur1c=(Node *)malloc(sizeof(Node));
    cur1c=p1.exponents->head;    
    Node *cur2e;
    cur2e=(Node *)malloc(sizeof(Node));
    cur2e=p2.exponents->head;
    Node *cur2c;
    cur2c=(Node *)malloc(sizeof(Node));
    cur2c=p2.coeffs->head;
    Polynomial p;
    Polynomial temp;
     p.exponents=(LList *) malloc(sizeof(LList));
    p.coeffs=(LList *) malloc(sizeof(LList));
    p.exponents->head=NULL;
    p.coeffs->head=NULL;
     temp.exponents=(LList *) malloc(sizeof(LList));
    temp.coeffs=(LList *) malloc(sizeof(LList));
    temp.exponents->head=NULL;
    temp.coeffs->head=NULL;
    for(cur1e=p1.exponents->head,cur1c=p1.coeffs->head;  cur1e!=NULL;  cur1e=cur1e->next){
        for(cur2e=p2.exponents->head,cur2c=p2.coeffs->head;  cur2e!=NULL;  cur2e=cur2e->next){
            llist_append(temp.exponents,(cur1e->data+cur2e->data));
            llist_append(temp.coeffs,(cur1c->data)*(cur2c->data));			//multiplying all the elements of one to all the elements of two
            p=add(p,temp);
            llist_remove_last(temp.exponents);
            llist_remove_last(temp.coeffs);
            cur2c=cur2c->next;
        }
    	cur1c=cur1c->next;
    }   
    
    free(cur1e);
    free(cur1c);
    free(cur2e);
    free(cur2c);
    return p;
}

long long int evaluate(Polynomial p, int k){
	long long int val=0;
	Node *curre;
	curre=p.exponents->head;
	Node *currc;
	currc=p.coeffs->head;
	
	while(curre!=NULL){
		val=val+(currc->data)*pow(k,curre->data);		//raising key to the value of exponent and multiplying it with the coeff
		currc=currc->next;
		curre=curre->next;
	}
	
    free(curre);
    free(currc);
	return val;
}
