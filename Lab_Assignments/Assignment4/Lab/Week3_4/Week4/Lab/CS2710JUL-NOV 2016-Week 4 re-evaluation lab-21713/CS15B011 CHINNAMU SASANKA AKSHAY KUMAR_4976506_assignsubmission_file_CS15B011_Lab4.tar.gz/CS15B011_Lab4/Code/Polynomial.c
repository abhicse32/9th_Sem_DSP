/*	Program to implement basic operations on polynomials using pre-defined linked list functions Akshay Kumar*/

#include "Polynomial.h"
#include <math.h>                                                               //including math library to use pow() function
#include <stdio.h>
#include <stdlib.h>

/*function to return the degree of the polynomial*/
int get_degree(Polynomial p)
{
	int x = llist_get( p.exponents, llist_size( p.exponents )-1 );
	return x;
}

/*	function to print the polynomial in the given format*/
void print_polynomial(Polynomial p)
{
	Node* n = p.exponents->head;
	Node* m = p.coeffs->head;
	int x=0;
	if(n == NULL || m == NULL) return;



	while(n != NULL && m != NULL)
	{
		if(n->data == 0)
		{
			if(m->next->data < 0) printf("%d ",m->data );
			else printf("%d + ",m->data );
			n = n->next;
			m = m->next;
			x=1;
		}
		if(m->data < 0)
		{
			if(x==0)
			{
				printf("-%dx^",-m->data);
				x=1;
			} 
			else
			printf("- %dx^",-m->data);
			if(n->next != NULL && (m->next)->data >= 0)
			printf("%d + ",n->data );
			else printf("%d ",n->data );
			m = m->next;
			n = n->next;
		}
		else if(m->data == 0) 
		{
			m = m->next;
			n = n->next;
		}
		else
		{
			printf("%dx^",m->data);
			if(n->next != NULL && (m->next)->data >= 0)
			printf("%d + ",n->data );
			else printf("%d ",n->data );
			m = m->next;
			n = n->next;
			x=1;
		}
	}
	printf("\n");

}


/* 	Function to Multiply two polynomials and return the result*/
Polynomial multiply(Polynomial p, Polynomial q)
{
	Node* n1 = p.exponents->head;
	Node* m1 = p.coeffs->head;
	Node* n2 = q.exponents->head;
	Node* m2 = q.coeffs->head;
	int x,y,i=0,j=0;

	Polynomial *a = (Polynomial*) malloc(sizeof(Polynomial));


	LList* l = llist_new();
	LList* k = llist_new();
	a->exponents = l;
	a->coeffs = k;

	int size = 0,ab = 0;


	while(n1 != NULL)
	{
		while(n2 != NULL)
		{
			x = n1->data + n2->data;
			y = m1->data * m2->data;
			
			while(size < llist_size( l ))
			{
				
				if(x == llist_get( l , i ))
				{
					y = y + llist_get( k , i);
					
					llist_remove( k, i );
					llist_insert( k , i , y);
					
					j++;
					break;
				}
				if(x < llist_get( l , i)) 
				{	
					
					llist_insert( l , i ,x);
					llist_insert( k , i , y);
					j++;
					break;
				}
				i++;
				size++;
			}
			if(ab == 0) 
			{
				llist_insert( l, 0, x );
				llist_insert( k, 0, y );
				ab++;
				
			}
			if(size == llist_size(l)) 
			{
				llist_append( l, x );
				llist_append( k, y );
			}
			
			n2 = n2->next;
			m2 = m2->next;
			size = 0;
			i = 0;
		}

		n1 = n1->next;
		m1 = m1->next;
		n2 = q.exponents->head;
		m2 = q.coeffs->head;
	}
	return *a;

}

/* 	Function to Add two polynomials and return the result*/
Polynomial add(Polynomial p, Polynomial q)
          {
           LList * l1=p.coeffs;
	  	   LList * k1=p.exponents;

           LList * l2=q.coeffs;
       	   LList * k2=q.exponents;

           Node * n1=l1->head;
           Node * m1=k1->head;

           Node * n2=l2->head;
           Node * m2=k2->head;

           Polynomial a;

           a.exponents=(LList *)malloc(sizeof(LList)*1);
           a.coeffs=(LList *)malloc(sizeof(LList)*1);

           (a.coeffs)->head=NULL;
           (a.exponents)->head=NULL;

           LList * l=a.coeffs;
           LList * k=a.exponents;
         
           while(n1!=NULL && n2!=NULL)
             {
              if((m1->data)<(m2->data))
                {
                 llist_append(l,n1->data);
                 llist_append(k,m1->data);
                 m1=m1->next;
                 n1=n1->next;
                }
              else
                if((m2->data)<(m1->data))
             
                {
                 llist_append(l,n2->data);
                 llist_append(k,m2->data);
                 m2=m2->next;
                 n2=n2->next;
                }
               else
                if((m2->data)==(m1->data))
                {
                 llist_append(l,(n2->data+n1->data));
                 llist_append(k,m2->data);
                 m2=m2->next;
                 n2=n2->next;
                 m1=m1->next;
                 n1=n1->next;
                }


             }
         
            while(n1!=NULL)
             {
                 llist_append(l,n1->data);
                 llist_append(k,m1->data);
                 m1=m1->next;
                 n1=n1->next;

             }
           while(n2!=NULL)
             {
                 llist_append(l,n2->data);
                 llist_append(k,m2->data);
                 m2=m2->next;
                 n2=n2->next;
             }
           return a;
          }

/*	Function to Subtract second Polynomial from first*/
Polynomial subtract(Polynomial p, Polynomial q)
          {
           LList * l1=p.coeffs;
	  	   LList * k1=p.exponents;

           LList * l2=q.coeffs;
       	   LList * k2=q.exponents;

           Node * n1=l1->head;
           Node * m1=k1->head;

           Node * n2=l2->head;
           Node * m2=k2->head;

           Polynomial a;

           a.exponents=(LList *)malloc(sizeof(LList)*1);
           a.coeffs=(LList *)malloc(sizeof(LList)*1);

           (a.coeffs)->head=NULL;
           (a.exponents)->head=NULL;

           LList * l=a.coeffs;
           LList * k=a.exponents;
         
           while(n1!=NULL && n2!=NULL)
             {
              if((m1->data)<(m2->data))
                {
                 llist_append(l,n1->data);
                 llist_append(k,m1->data);
                 m1=m1->next;
                 n1=n1->next;
                }
              else
                if((m2->data)<(m1->data))
             
                {
                 llist_append(l,-(n2->data));
                 llist_append(k,m2->data);
                 m2=m2->next;
                 n2=n2->next;
                }
               else
                if((m2->data)==(m1->data))
                {
                 llist_append(l,(n1->data-n2->data));
                 llist_append(k,m2->data);
                 m2=m2->next;
                 n2=n2->next;
                 m1=m1->next;
                 n1=n1->next;
                }


             }
         
            while(n1!=NULL)
             {
                 llist_append(l,n1->data);
                 llist_append(k,m1->data);
                 m1=m1->next;
                 n1=n1->next;

             }
           while(n2!=NULL)
             {
                 llist_append(l,-(n2->data));
                 llist_append(k,m2->data);
                 m2=m2->next;
                 n2=n2->next;
             }
           return a;
          }
          
/*	Function to Evaluate Polynomial at var=k and return the result*/
long long int evaluate(Polynomial p, int k)
{
	Node* n = p.exponents->head;
	Node* m = p.coeffs->head;

	long long int x = 0;

	while(n != NULL && m != NULL)
	{
		x = x + (m->data)*pow(k , n->data);
		n = n->next;
		m = m->next;
	}
	return x;
} 
