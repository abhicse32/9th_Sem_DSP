#include "Polynomial.h"
#include "List.h"
#include <stdlib.h>
#include <math.h>
#include <limits.h>
#include <stdio.h>


int get_degree(Polynomial p1)/*finding degree of polynomial*/
{
	Node* cur;
	cur=(Node*)malloc(sizeof(Node));/* create current space*/
 	
 	cur=p1.exponents->head;
 	int max;
 	max=cur->data;
 	
 	while(cur!=NULL)
 	{ 	
 	 	if(cur->data>max) {
 	 	max=cur->data;
 	 	
 	    }
 	 	cur=cur->next;
 	}
 	return max; 	
}

void print_polynomial(Polynomial p1)/*printing the polynomial*/
{
	Node* expo;
	Node* coff;
	
	
    expo=p1.exponents->head;
    coff=p1.coeffs->head;
    int i;
    while(expo!=NULL)
    {
      if(expo->data==0)
     { printf("%d ",coff->data);
          i++;   } 
      else
      { 
       
        if(i==0)
        {
        printf("%dx^%d ",coff->data,expo->data); 
         i++;fflush(stdout);
         }
      	else if(coff->data>0)
        {   
          	char a='+';
          	printf("%c %dx^%d ",a,coff->data,expo->data);
          fflush(stdout);	
        } else if(coff->data<0){
         printf("- %dx^%d ",abs(coff->data),expo->data); 
          fflush(stdout); 	
      	}
      	i++;
      	
      }
    
     expo=expo->next;
     coff=coff->next; 	
    }
      printf("\n");
}

Polynomial add(Polynomial p1, Polynomial p2)/*addition function*/
{
	Polynomial p3;
	p3.exponents=llist_new();
	p3.coeffs=llist_new();
    
    Node* coff1;
    Node* expo1;
    Node* coff2;
    Node* expo2;
    
  
 
    expo1=p1.exponents->head;
    coff1=p1.coeffs->head;
    expo2=p2.exponents->head;
    coff2=p2.coeffs->head;
while(expo2!=NULL&&expo1!=NULL)
{
   if((expo1->data)<(expo2->data)) {
   		llist_append(p3.exponents,expo1->data);
  		llist_append(p3.coeffs,coff1->data);

   		expo1=expo1->next;
   		coff1=coff1->next;  		
    } else  if(expo1->data>expo2->data) {
   
   		llist_append(p3.exponents,expo2->data);
  		llist_append(p3.coeffs,coff2->data);
		expo2=expo2->next;
		coff2=coff2->next;  		
    } else {
   		llist_append(p3.exponents,expo1->data);
 		llist_append(p3.coeffs,(coff1->data)+(coff2->data));

		expo2=expo2->next;
		coff2=coff2->next;  		
		expo1=expo1->next;
		coff1=coff1->next;
    }
 }   
while(expo2!=NULL)
{
   		llist_append(p3.exponents,expo2->data);
  		llist_append(p3.coeffs,coff2->data);
		expo2=expo2->next;
		coff2=coff2->next;  		
}

while(expo1!=NULL)
{
   		llist_append(p3.exponents,expo1->data);
  		llist_append(p3.coeffs,coff1->data);
		expo1=expo1->next;
		coff1=coff1->next;  		
}
return p3;
}

Polynomial subtract(Polynomial p1, Polynomial p2)
{
	Polynomial p3;
	p3.exponents=llist_new();
	p3.coeffs=llist_new();
    
    Node* coff1;
    Node* expo1;
    Node* coff2;
    Node* expo2;
    Node* coff3;
    Node* expo3;
    
  	expo1=(Node*)malloc(sizeof(Node));
	coff1=(Node*)malloc(sizeof(Node));
	expo2=(Node*)malloc(sizeof(Node));
	coff2=(Node*)malloc(sizeof(Node));
	expo3=(Node*)malloc(sizeof(Node));
	coff3=(Node*)malloc(sizeof(Node));
 
    expo1=p1.exponents->head;
    coff1=p1.coeffs->head;
    expo2=p2.exponents->head;
    coff2=p2.coeffs->head;
    expo3=p3.exponents->head;
    coff3=p3.coeffs->head;
while(expo2!=NULL&&expo1!=NULL)
/* similar to merge sort*/
   if(expo1->data<expo2->data) {
   
   		llist_append(p3.exponents,expo1->data);
  		llist_append(p3.coeffs,coff1->data);
   		expo1=expo1->next;
   		coff1=coff1->next;  		
    } else  if(expo1->data>expo2->data) {
   
   		llist_append(p3.exponents,expo2->data);
  		llist_append(p3.coeffs,-(coff2->data));
		expo2=expo2->next;
		coff2=coff2->next;  		
    } else {
    
   		llist_append(p3.exponents,expo1->data);
  		llist_append(p3.coeffs,coff1->data-(coff2->data));
		expo2=expo2->next;
		coff2=coff2->next;  		
		expo1=expo1->next;
		coff1=coff1->next;
    }
while(expo2!=NULL)
{
   		llist_append(p3.exponents,expo2->data);
  		llist_append(p3.coeffs,-(coff2->data));
		expo2=expo2->next;
		coff2=coff2->next;  		
}

while(expo1!=NULL)
{
   		llist_append(p3.exponents,expo1->data);
  		llist_append(p3.coeffs,coff1->data);
		expo1=expo1->next;
		coff1=coff1->next;  		
}
return p3;
}
Polynomial multiply(Polynomial p1, Polynomial p2)
  {/* creating new polynomial*/
	Polynomial p3;
	p3.exponents=llist_new();
	p3.coeffs=llist_new();
    
   Polynomial p4;
	 p4.exponents=llist_new();
     p4.coeffs=llist_new();
	int i=0;
	int j;
	while( i<llist_size(p1.exponents))
    {  
     while(j<llist_size(p2.exponents))
     	{ 
       int temp1 = (llist_get(p1.exponents,i))+(llist_get(p2.exponents,j));
       int temp2 = (llist_get(p1.coeffs,i))*(llist_get(p2.coeffs,j));
        if(temp2!=0)
           {
            llist_append(p4.exponents, temp1);
            llist_append(p4.coeffs,temp2);
           }      
	      j++; 		
		}
	  	
	  p3=add(p3,p4);
	  /*creating it again so that it becomes a clear one*/
	  p4.exponents=llist_new();
      p4.coeffs=llist_new();
	  i++;
	  j=0;	
	}
return p3;	
}
long long int power(long long int x,int y)
{	if(y==0)
   return 1;
   else
   {
	int a=x;
 	int i;
  for(i=1;i<y;i++)
  {
   x=x*a;
  }
  return x;}
}
long long int evaluate(Polynomial p1, int k)
{
	Node* expo;
	Node* coff;
	
	
    expo=p1.exponents->head;
    coff=p1.coeffs->head;
   long long int value=0;

	while(expo!=NULL)
	{ /* caluclating each term*/
	  value=value+(coff->data)*power(k,expo->data);
      expo=expo->next;
      coff=coff->next;
	}
	return value;
}

