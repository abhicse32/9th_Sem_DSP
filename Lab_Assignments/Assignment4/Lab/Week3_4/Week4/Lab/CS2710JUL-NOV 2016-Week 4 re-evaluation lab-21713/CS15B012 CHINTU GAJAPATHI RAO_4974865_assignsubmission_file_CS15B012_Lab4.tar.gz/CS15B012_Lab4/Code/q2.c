#include "List.h"
#include"Polynomial.h"
#include<stdlib.h>
#include<stdio.h>
int main(){
	int i,n,inp;
	scanf("%d",&i);
	while(i!=-1){
		switch(i){
 		case 1:
		case 2:{
		Polynomial *p1 = (Polynomial*)malloc(sizeof(Polynomial));//creating space for polynomial
    	p1->exponents = llist_new();
    	p1->coeffs = llist_new();
	
		scanf("%d",&n);
		for (int i = 0; i < n; ++i)
				{
					scanf("%d",&inp);
					llist_append(p1->exponents,inp);
				}
		for (int i = 0; i < n; ++i)
	        	{
					scanf("%d",&inp);
					llist_append(p1->coeffs,inp);
				}
		if(i==1)
		{print_polynomial(*p1);
		break;}
		if(i==2){
		int deg=get_degree(*p1);
		printf("%d\n",deg);
		break;}

			}
     	case 3:
		case 4:
		case 5:{
		Polynomial *p1 = (Polynomial*)malloc(sizeof(Polynomial));
   		p1->exponents = llist_new();
   		p1->coeffs = llist_new();
     	Polynomial *p2 = (Polynomial*)malloc(sizeof(Polynomial));
    	p2->exponents = llist_new();
    	p2->coeffs = llist_new();
	
		scanf("%d",&n);
				for (int i = 0; i < n; ++i)
				{
					scanf("%d",&inp);
					llist_append(p1->exponents,inp);
				}
				for (int i = 0; i < n; ++i)
				{
					scanf("%d",&inp);
					llist_append(p1->coeffs,inp);
				}
	
		scanf("%d",&n);
				for (int i = 0; i < n; ++i)
				{
					scanf("%d",&inp);
					llist_append(p2->exponents,inp);
				}
				for (int i = 0; i < n; ++i)
				{
					scanf("%d",&inp);
					llist_append(p2->coeffs,inp);
				}
    
        if(i==3){
	
		Polynomial pa = add(*p1,*p2);
	    print_polynomial(pa);
		break;}
	
		if(i==4){
	
		Polynomial pb = subtract(*p1,*p2);
		print_polynomial(pb);
		break;				
	    }
	
		if(i==5){
		Polynomial pm = multiply(*p1,*p2);
		print_polynomial(pm);
		break;				
		}
				
	}
			
	case 6:{/*to evaluate*/

	Polynomial *p1 = (Polynomial*)malloc(sizeof(Polynomial));
	p1->exponents = llist_new();
	p1->coeffs = llist_new();
	Polynomial *p2 = (Polynomial*)malloc(sizeof(Polynomial));
	p2->exponents = llist_new();
	p2->coeffs = llist_new();

	scanf("%d",&n);

	for (int i = 0; i < n; ++i)
		{
		scanf("%d",&inp);
		llist_append(p1->exponents,inp);
		}

	for (int i = 0; i < n; ++i)
		{
		scanf("%d",&inp);
		llist_append(p1->coeffs,inp);
		}
		scanf("%d",&n);
				
	long long int val= evaluate(*p1, n);
	printf("%lld\n",val);
	break;
	}
	}
		scanf("%d",&i);
	}
}
