//CS15B013
#include"Polynomial.h"
#include <stdio.h>
#include"List.h"
#include<stdlib.h>
#include<math.h>

	int get_degree(Polynomial p)
          {
	   LList * coef=p.exponents;
           Node * temp=coef->head;
           if(coef->head==NULL)
             return 0;                   //base case
           int degree;

           while(temp!=NULL)
               {
                degree=temp->data;
                temp=temp->next;
               }
            return degree;
          }

        void print_polynomial(Polynomial p)
          {
           LList * coef=p.coeffs;
	   LList * exp=p.exponents;

           Node * coeffs=coef->head;
           Node * exponent=exp->head;
           
           if(coeffs!=NULL)
             {if(exponent->data!=0)
              printf("%dx^%d ",coeffs->data,exponent->data);
              else
              printf("%d ",coeffs->data);
              }
              
           coeffs=coeffs->next;
           exponent=exponent->next;
              
           while(coeffs!=NULL)
             {if(exponent->data!=0)
              {if(coeffs->data>0)
               printf("+ %dx^%d ",coeffs->data,exponent->data);      //printing based on sign
               else
                if(coeffs->data<0)
               printf("- %dx^%d ",-(coeffs->data),exponent->data);
              }

              
              coeffs=coeffs->next;
              exponent=exponent->next;
             }
             
            if(coef->head!=NULL)
               printf("\n");
               
          }

	Polynomial add(Polynomial a, Polynomial b)
          {
           LList * laco=a.coeffs;
	   LList * laexp=a.exponents;

           LList * lbco=b.coeffs;
	   LList * lbexp=b.exponents;

           Node * Nodeacoeff=laco->head;
           Node * Nodeaexp=laexp->head;

           Node * Nodebcoeff=lbco->head;
           Node * Nodebexp=lbexp->head;

           Polynomial result;

          result.exponents=(LList *)malloc(sizeof(LList)*1);
          result.coeffs=(LList *)malloc(sizeof(LList)*1);

           (result.coeffs)->head=NULL;
           (result.exponents)->head=NULL;

           LList * rcoeffs=result.coeffs;
           LList * rexp=result.exponents;
         
           while(Nodeacoeff!=NULL && Nodebcoeff!=NULL)
             {
              if((Nodeaexp->data)<(Nodebexp->data))
                {
                 llist_append(rcoeffs,Nodeacoeff->data);
                 llist_append(rexp,Nodeaexp->data);
                 Nodeaexp=Nodeaexp->next;
                 Nodeacoeff=Nodeacoeff->next;
                }
              else
                if((Nodebexp->data)<(Nodeaexp->data))
             
                {
                 llist_append(rcoeffs,Nodebcoeff->data);
                 llist_append(rexp,Nodebexp->data);
                 Nodebexp=Nodebexp->next;
                 Nodebcoeff=Nodebcoeff->next;
                }
               else
                if((Nodebexp->data)==(Nodeaexp->data))
                {
                 llist_append(rcoeffs,(Nodebcoeff->data+Nodeacoeff->data));
                 llist_append(rexp,Nodebexp->data);
                 Nodebexp=Nodebexp->next;
                 Nodebcoeff=Nodebcoeff->next;
                 Nodeaexp=Nodeaexp->next;
                 Nodeacoeff=Nodeacoeff->next;
                }


             }
         
            while(Nodeacoeff!=NULL)
             {
                 llist_append(rcoeffs,Nodeacoeff->data);
                 llist_append(rexp,Nodeaexp->data);
                 Nodeaexp=Nodeaexp->next;
                 Nodeacoeff=Nodeacoeff->next;

             }
           while(Nodebcoeff!=NULL)
             {
                 llist_append(rcoeffs,Nodebcoeff->data);
                 llist_append(rexp,Nodebexp->data);
                 Nodebexp=Nodebexp->next;
                 Nodebcoeff=Nodebcoeff->next;
             }
           return result;
          }


	Polynomial subtract(Polynomial p1, Polynomial p2)                
         {
           Node * Nodeacoeff=p1.coeffs->head;
           Node * Nodeaexp=p1.exponents->head;

           Node * Nodebcoeff=p2.coeffs->head;
           Node * Nodebexp=p2.exponents->head;

           Polynomial result;

          result.exponents=(LList *)malloc(sizeof(LList)*1);
          result.coeffs=(LList *)malloc(sizeof(LList)*1);

           (result.coeffs)->head=NULL;
           (result.exponents)->head=NULL;

           LList * rcoeffs=result.coeffs;
           LList * rexp=result.exponents;

           while(Nodeacoeff!=NULL && Nodebcoeff!=NULL)
             {
              if((Nodeaexp->data)<(Nodebexp->data))
                {
                 llist_append(rcoeffs,Nodeacoeff->data);
                 llist_append(rexp,Nodeaexp->data);
                 Nodeaexp=Nodeaexp->next;
                 Nodeacoeff=Nodeacoeff->next;
                }
              else
                if((Nodebexp->data)<(Nodeaexp->data))
             
                {
                 llist_append(rcoeffs,-(Nodebcoeff->data));
                 llist_append(rexp,Nodebexp->data);
                 Nodebexp=Nodebexp->next;
                 Nodebcoeff=Nodebcoeff->next;
                }
               else
                if((Nodebexp->data)==(Nodeaexp->data))
                {
                 llist_append(rcoeffs,(Nodeacoeff->data)-(Nodebcoeff->data));
                 llist_append(rexp,Nodebexp->data);
                 Nodebexp=Nodebexp->next;
                 Nodebcoeff=Nodebcoeff->next;
                 Nodeaexp=Nodeaexp->next;
                 Nodeacoeff=Nodeacoeff->next;
                }


             }

            while(Nodeacoeff!=NULL)
             {
                 llist_append(rcoeffs,Nodeacoeff->data);
                 llist_append(rexp,Nodeaexp->data);
                 Nodeaexp=Nodeaexp->next;
                 Nodeacoeff=Nodeacoeff->next;

             }
           while(Nodebcoeff!=NULL)
             {
                 llist_append(rcoeffs,-(Nodebcoeff->data));
                 llist_append(rexp,Nodebexp->data);
                 Nodebexp=Nodebexp->next;
                 Nodebcoeff=Nodebcoeff->next;
             }
            return result;
         }


	Polynomial multiply(Polynomial p1, Polynomial p2)
         { 
           Node * Nodeacoeff=p1.coeffs->head;
           Node * Nodeaexp=p1.exponents->head;

           Node * Nodebcoeff=p2.coeffs->head;
           Node * Nodebexp=p2.exponents->head;
         
            Polynomial result;

          result.exponents=(LList *)malloc(sizeof(LList)*1);
          result.coeffs=(LList *)malloc(sizeof(LList)*1);

           (result.coeffs)->head=NULL;
           (result.exponents)->head=NULL;

           LList * rcoeffs=result.coeffs;
           LList * rexp=result.exponents;
           Node * checkexp=(result.exponents)->head;           
           Node * checkcoeff=(result.coeffs)->head; 
           Node * tempexp=(result.exponents)->head;
           Node * tempcoeff=(result.coeffs)->head;
           int a;Node * new;Node * new1;

           if(Nodebcoeff==NULL)
             {
              while(Nodeacoeff!=NULL)
                {
                 llist_append(result.exponents,Nodeaexp->data);
                 llist_append(result.coeffs,Nodeacoeff->data);
                }
             
             }
            else
             if(Nodeacoeff==NULL)
             {
              while(Nodebcoeff!=NULL)
                {
                 llist_append(result.exponents,Nodebexp->data);
                 llist_append(result.coeffs,Nodebcoeff->data);
                }
             
             }
          else  
          
           while(Nodebcoeff!=NULL)
           {
            Nodeacoeff=(p1.coeffs)->head;
            Nodeaexp=(p1.exponents)->head;
                      

            while(Nodeaexp!=NULL)
               {checkexp=(result.exponents)->head;checkcoeff=(result.coeffs)->head;a=0;
                while(checkexp!=NULL && a==0)
                  {
                   if((checkexp->data)==(Nodebexp->data)+(Nodeaexp->data))     //checking if exponent is present already
                     {
                      checkcoeff->data=checkcoeff->data+(Nodebcoeff->data) * (Nodeacoeff->data);a=1;
                     }
               
                   checkexp=checkexp->next;
                   checkcoeff=checkcoeff->next;
                  }

                  checkexp=(result.exponents)->head;
                  checkcoeff=(result.coeffs)->head;
 
                if(a==0)
                  { if(checkexp==NULL)
                      {
                          new = node_new(Nodeaexp->data+Nodebexp->data);
                          new1 = node_new(Nodeacoeff->data * Nodebcoeff->data);
                          (result.exponents)->head=new;
                          (result.coeffs)->head=new1;
                      }
                    else
                    if(checkexp->data>(Nodeaexp->data)+(Nodebexp->data))
                      {
                          new = node_new(Nodeaexp->data+Nodebexp->data);
                          new1 = node_new(Nodeacoeff->data * Nodebcoeff->data);
                          new->next=checkexp;
                          (result.exponents)->head=new;
                          new1->next=checkcoeff;
                          (result.coeffs)->head=new1;
                      }
                    else
                    while((checkexp->data)<(Nodeaexp->data)+(Nodebexp->data) && checkexp!=NULL) //finding index to insert
                      {
                        if(checkexp->next==NULL)
                          {
                           new = node_new(Nodeaexp->data+Nodebexp->data);
                           checkexp->next=new;
                           new1 = node_new(Nodeacoeff->data * Nodebcoeff->data);
                           checkcoeff->next=new1;
                          }
                        else
                          if((checkexp->next)->data>(Nodeaexp->data)+(Nodebexp->data))
                          {
                          new = node_new(Nodeaexp->data+Nodebexp->data);
                          new->next=checkexp->next;
                          checkexp->next=new;
                          new1 = node_new(Nodeacoeff->data * Nodebcoeff->data);
                          new1->next=checkcoeff->next;
                          checkcoeff->next=new1;
                         }
                       checkexp=checkexp->next;
                       checkcoeff=checkcoeff->next;
                      }
                  }                      
                 Nodeacoeff=Nodeacoeff->next;
                 Nodeaexp=Nodeaexp->next;
               }

             Nodebcoeff=Nodebcoeff->next;
             Nodebexp=Nodebexp->next;
           }

             return result;
         }
         
         
       long long  int evaluate(Polynomial p1, int k)
          {
           Node * Nodecoeff=p1.coeffs->head;
           Node * Nodeexp=p1.exponents->head;
           long long int sum=0,power=1;
           while(Nodeexp!=NULL)
            {
             power=pow(k,Nodeexp->data);
             sum=sum+(Nodecoeff->data)*power;
             
             Nodeexp=Nodeexp->next;
             Nodecoeff=Nodecoeff->next;
            }
           return sum;
          }


 
