/*d teja vardhan     cs15b014   30/8/16*/
/*POLYNOMIAL FUNCTIONS*/
#include "Polynomial.h"
#include<math.h>
#include<stdio.h>
#include<stdlib.h>
// to get degree
int get_degree(Polynomial p1){
	Node*exp=(p1.exponents)->head;
	Node*coef=(p1.coeffs)->head;
	int t;
	while(exp!=NULL){
		if(coef->data!=0)
			{
				t=exp->data;
			}
		coef=coef->next;
		exp=exp->next;
	}
	return t;
	
}

// to print a polynomial
void print_polynomial(Polynomial p1){
	Node *exp=(p1.exponents)->head;
	Node *coef=(p1.coeffs)->head;
	if(exp==NULL)
		return ;
	if(exp->data==0){
			if(coef->data>0)
			{
				printf("%d ",coef->data);
			}
			else if(coef->data<0){
				printf("%d ",coef->data);
			}
		}
		else if(exp->data==1){
			if(coef->data>0)
			{
				printf("%dx^1 ",coef->data);
			}
			else if(coef->data<0){
				printf("%dx^1 ",coef->data);
			}
		}
		else if(coef->data>0)
		{
			printf("%dx^%d ",coef->data,exp->data);
		}
		else if(coef->data<0){
			printf("%dx^%d ",coef->data,exp->data);
		}
		coef=coef->next;
		exp=exp->next;
	
	while(exp!=NULL){
		if(exp->data==0){
			if(coef->data>0)
			{
				printf("+ %d ",coef->data);
			}
			else if(coef->data<0){
				printf("- %d ",-1* coef->data);
			}
		}
		else if(exp->data==1){
			if(coef->data>0)
			{
				printf("+ %dx^1 ",coef->data);
			}
			else if(coef->data<0){
				printf("- %dx^1 ",-1 * coef->data);
			}
		}
		else if(coef->data>0)
			{
				printf("+ %dx^%d ",coef->data,exp->data);
			}
		else if(coef->data<0){
				printf("- %dx^%d ",-1* coef->data,exp->data);
		}
		coef=coef->next;
		exp=exp->next;
	}
	printf("\n");
}
// Polynomial multiply(Polynomial p1, Polynomial p2){
// 	Node *exp=(p1.exponents)->head;
// 	Node *coef=(p1.coeffs)->head;
// 	Node *exp1=(p2.exponents)->head;
// 	Node *coef1=(p2.coeffs)->head;
// 	Polynomial p3;
// 	p3.exponents=llist_new();
// 	p3.coeffs=llist_new();
// 	Node*exp3=(p3.exponents)->head;
// 	Node*coef3=(p3.coeffs)->head;
// 	Node*exp4,*coef4;
// 	while(exp!=NULL){
// 	int i=0;
// 	exp4=exp1;
// 	coef4=coef1;
// 		while(exp4!=NULL){
			
// 			while(exp3!=NULL){
// 				while(exp3!=NULL){
// 					if(((exp3->data)>=((exp1->data)+(exp->data))))
// 						break;
// 					i++;
// 					exp3=exp3->next;
// 					coef3=coef3->next;
// 				}
// 				if(exp3==NULL)
// 				{
// 					break;
// 				}
// 				if(((exp3->data)==((exp1->data)+(exp->data)))){
// 					coef3->data += (coef1->data)*(coef->data);
// 				}
// 				else{
// 				llist_insert(p3.exponents , i, (exp1->data)+(exp->data) );
// 				llist_insert(p3.coeffs, i,  (coef1->data)*(coef->data) );
// 				exp4=exp4->next;
// 				coef4=coef4->next;
// 				}
// 				i++;
// 			}
// 			llist_append(p3.exponents ,  (exp1->data)+(exp->data) );
// 			llist_append(p3.coeffs,   (coef1->data)*(coef->data) );
// 			exp4=exp4->next;
// 			coef4=coef4->next;
			
			
// 		}
// 		exp=exp->next;
// 		coef=coef->next;
		
// 	}
// 	return p3;
	
// }
// to add two polynomials
Polynomial add(Polynomial p1, Polynomial p2){
	Node *exp=(p1.exponents)->head;
	Node *coef=(p1.coeffs)->head;
	Node *exp1=(p2.exponents)->head;
	Node *coef1=(p2.coeffs)->head;
	Polynomial p3;
	p3.exponents=llist_new();
	p3.coeffs=llist_new();
	Node *exp3=(p3.exponents)->head;
	Node *coef3=(p3.coeffs)->head;
	while(exp!=NULL&&exp1!=NULL){
		if(exp->data==exp1->data){
			llist_append(p3.exponents, exp->data );
			llist_append( p3.coeffs, ((coef->data) + (coef1->data)) );
			coef=coef->next;
			exp=exp->next;
			coef1=coef1->next;
			exp1=exp1->next;
			
		}
		else if(exp->data<exp1->data)
		{
			llist_append(p3.exponents, exp->data );
			llist_append( p3.coeffs, coef->data );
			coef=coef->next;
			exp=exp->next;
		}
		else{
			llist_append(p3.exponents, exp1->data );
			llist_append( p3.coeffs, coef1->data );
			coef1=coef1->next;
			exp1=exp1->next;
		}
		
		
	}
	while(exp!=NULL){
		llist_append(p3.exponents, exp->data );
		llist_append( p3.coeffs, coef->data );
		coef=coef->next;
		exp=exp->next;
	}
	
	while(exp1!=NULL){
		llist_append(p3.exponents, exp1->data );
		llist_append( p3.coeffs, coef1->data );
		coef1=coef1->next;
		exp1=exp1->next;
	}
	return p3;
}
// to subtract two polynomials
Polynomial subtract(Polynomial p1, Polynomial p2){
	Node *exp=(p1.exponents)->head;
	Node *coef=(p1.coeffs)->head;
	Node *exp1=(p2.exponents)->head;
	Node *coef1=(p2.coeffs)->head;
	Polynomial p3;
	p3.exponents=llist_new();
	p3.coeffs=llist_new();
	Node *exp3=(p3.exponents)->head;
	Node *coef3=(p3.coeffs)->head;
	while(exp!=NULL&&exp1!=NULL){
		if(exp->data==exp1->data){
			llist_append(p3.exponents, exp->data );
			llist_append( p3.coeffs, coef->data - coef1->data );
			coef=coef->next;
			exp=exp->next;
			coef1=coef1->next;
			exp1=exp1->next;
			
		}
		else if(exp->data<exp1->data)
		{
			llist_append(p3.exponents, exp->data );
			llist_append( p3.coeffs, coef->data );
			coef=coef->next;
			exp=exp->next;
		}
		else{
			llist_append(p3.exponents, exp1->data );
			llist_append( p3.coeffs, -1*coef1->data );
			coef1=coef1->next;
			exp1=exp1->next;
		}
		
	}
	while(exp!=NULL){
		llist_append(p3.exponents, exp->data );
		llist_append( p3.coeffs, coef->data );
		coef=coef->next;
		exp=exp->next;
	}
	
	while(exp1!=NULL){
		llist_append(p3.exponents, exp1->data );
		llist_append( p3.coeffs, -coef1->data );
		coef1=coef1->next;
		exp1=exp1->next;
	}
	return p3;
}
// to evaluate polynomial
long long int evaluate(Polynomial p1, int k){
	Node *exp=(p1.exponents)->head;
	Node *coef=(p1.coeffs)->head;
	long long int m;
	long long int s=0;
	while(exp!=NULL){
	m=pow(k,exp->data);
	s+=(coef->data)*(m);
	exp=exp->next;
	coef=coef->next;
	}
	return s;

}
// to multiply two numbers

Polynomial multiply(Polynomial p1, Polynomial p2){

	Node *exp=(p1.exponents)->head;
	Node *coef=(p1.coeffs)->head;
	Node *exp1=(p2.exponents)->head;
	Node *coef1=(p2.coeffs)->head;
	Polynomial p3;
	p3.exponents=llist_new();
	p3.coeffs=llist_new();
	Node *exp3=(p3.exponents)->head;
	Node *coef3=(p3.coeffs)->head;
	while(exp!=NULL){
		exp1=(p2.exponents)->head;
 		coef1=(p2.coeffs)->head;
 		Polynomial p4;
		p4.exponents=llist_new();
		p4.coeffs=llist_new();
		while(exp1!=NULL){
			llist_append(p4.exponents, (exp->data)+(exp1->data) );
			llist_append( p4.coeffs, (coef1->data)*(coef->data) );
			exp1=exp1->next;
			coef1=coef1->next;
		}
		p3=add(p3,p4);
		exp=exp->next;
		coef=coef->next;
	}
	return p3;
}
