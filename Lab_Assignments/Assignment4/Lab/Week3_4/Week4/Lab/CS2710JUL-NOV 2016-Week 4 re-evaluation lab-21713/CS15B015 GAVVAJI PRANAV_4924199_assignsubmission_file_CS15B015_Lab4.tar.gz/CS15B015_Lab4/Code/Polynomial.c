/*	Program to implement basic operations on polynomials using pre-defined linked list functions
		G.Pranav	CS15B015	30-8-2016	*/
#include "Polynomial.h"
#include<math.h>	//including math library to use pow() function
#include<stdlib.h>
#include<stdio.h>
/*function to return the degree of the polynomial*/
int get_degree(Polynomial pol){
    LList *lst=pol.exponents;
    int size=llist_size(lst);
    int b=llist_get(lst,size-1);
    int a=size;
    while(b==0){		//checking whether the coefficient term is 0 or not
        int a=a--;
        b=llist_get(lst,a-1);
    }
    return b;
}
/*	function to print the polynomial in the given format*/
void print_polynomial(Polynomial pol){
    LList *lst1=pol.exponents;
    LList *lst2=pol.coeffs;
    int size=llist_size(lst1);
    int a=llist_get(lst1,0);
    int b=llist_get(lst2,0);
    int j=0;
    if(a==0){			//checking whether the first term is constant or not
        printf("%d ",b);
        j++;
    }
        
    int i;
    for(i=j;i<size;i++){
        int g=llist_get(lst2,i);
        int h=llist_get(lst1,i);
        if((g>0)&&(i!=0)) printf("+ %dx^%d ",g,h);
        if((g<0)&&(i!=0)) printf("- %dx^%d ",-g,h);
        if((g!=0)&&(i==0)) printf("%dx^%d ",g,h);        
    }

    printf("\n");
}
/* 	Function to Add two polynomials and return the result*/
Polynomial add(Polynomial pol1, Polynomial pol2){
    Polynomial ans;
    ans.exponents=llist_new();
    ans.coeffs=llist_new();
    LList *lst5=ans.exponents;
    LList *lst6=ans.coeffs;
    
    LList *lst1=pol1.exponents;
    LList *lst2=pol1.coeffs;
    
    LList *lst3=pol2.exponents;
    LList *lst4=pol2.coeffs;
    
    int size1=llist_size(lst1);
    int size2=llist_size(lst3);
    int i=0,j=0;
    while((size1>i)&&(size2>j)){		//Inserting all the terms of a polynomial and some terms of the other
        int a=llist_get(lst1,i);
        int b=llist_get(lst3,j);
        if(a<b){
            int c=llist_get(lst2,i);
            llist_append(lst5,a);
            llist_append(lst6,c);
            i++;
        }
        else if(b<a){
            int d=llist_get(lst4,j);
            llist_append(lst5,b);
            llist_append(lst6,d);
            j++;
        }
        else{
            int e=llist_get(lst4,j);
            int f=llist_get(lst2,i);
            int g=e+f;
            llist_append(lst5,b);
            llist_append(lst6,g);
            j++;
            i++;
        }
    }
    int k;		//Inserting the remaining terms
    if(i==size1){
        while(j<size2){
            int l=llist_get(lst3,j);
            int h=llist_get(lst4,j);
            llist_append(lst5,l);
            llist_append(lst6,h);
            j++;
        }
    }
    else if(j==size2){
         while(i<size1){
            int o=llist_get(lst1,i);
            int p=llist_get(lst2,i);
            llist_append(lst5,o);
            llist_append(lst6,p);
            i++;
        }       
    }
    return ans;
}
/*	Function to Subtract second Polynomial from first*/
Polynomial subtract(Polynomial p1, Polynomial p2){
    Polynomial ans;
    ans.exponents=llist_new();
    ans.coeffs=llist_new();
    LList *lst5=ans.exponents;
    LList *lst6=ans.coeffs;
    
    LList *lst1=p1.exponents;
    LList *lst2=p1.coeffs;
    
    LList *lst3=p2.exponents;
    LList *lst4=p2.coeffs;
    
    int size1=llist_size(lst1);
    int size2=llist_size(lst3);
    int i=0,j=0;
    while((size1>i)&&(size2>j)){		//Inserting all the terms of a polynomial and some terms of the other
        int a=llist_get(lst1,i);
        int b=llist_get(lst3,j);
        if(a<b){
            int c=llist_get(lst2,i);
            llist_append(lst5,a);
            llist_append(lst6,c);
            i++;
        }
        else if(b<a){
            int d=llist_get(lst4,j);
            llist_append(lst5,b);
            llist_append(lst6,((-1)*d));
            j++;
        }
        else{
            int e=llist_get(lst4,j);
            int f=llist_get(lst2,i);
            int g=((-1*e)+f);
            llist_append(lst5,b);
            llist_append(lst6,g);
            j++;
            i++;
        }
    }
    int k;			//Inserting the remaining terms
    if(i>=size1){
        while(j<size2){
            int l=llist_get(lst3,j);
            int h=llist_get(lst4,j);
            llist_append(lst5,l);
            llist_append(lst6,((-1)*h));
            j++;
        }
    }
    else if(j>=size2){
         while(i<size1){
            int o=llist_get(lst1,i);
            int p=llist_get(lst2,i);
            llist_append(lst5,o);
            llist_append(lst6,p);
            i++;
        }       
    }
    return ans;
}
/*	Function to Evaluate Polynomial at var=k and return the result*/
long long int evaluate(Polynomial pol, int k){
    int i;
    LList *lst1=pol.exponents;
    LList *lst2=pol.coeffs;
    int size=llist_size(lst1);
    long long int ans=0;
    for(i=0;i<size;i++){
        int a=llist_get(lst1,i);
        int b=llist_get(lst2,i);
        long long int c=pow(k,a);
        long long int d=c*b;
        ans=ans+d;
    }
    return ans;
}
/* 	Function to Multiply two polynomials and return the result*/
Polynomial multiply(Polynomial pol1, Polynomial pol2){
    Polynomial ans;
    ans.exponents=llist_new();
    ans.coeffs=llist_new();
    LList *lst11=pol1.exponents;
    LList *lst12=pol1.coeffs;
    int size1=llist_size(lst11);
    LList *lst21=pol2.exponents;
    LList *lst22=pol2.coeffs;
    int size2=llist_size(lst21);
    LList *lst1=ans.exponents;
    LList *lst2=ans.coeffs;
    
    int i;
    int a,b,c,d,coeff,exp;
    a=llist_get(lst11,0);
    b=llist_get(lst12,0);
    for(i=0;i<size2;i++){		//multiplying first term of the pol1 with pol2 and appending them to ans
        c=llist_get(lst21,i);
        d=llist_get(lst22,i);
        coeff=b*d;
        exp=a+c;
        llist_append(lst1,exp);
        llist_append(lst2,coeff); 
    }
    int j,k;
    int var;
    for(i=1;i<size1;i++){	//multiplying the remaining terms of pol1 with pol2 and appending them at required positions
        a=llist_get(lst11,i);
        b=llist_get(lst12,i);
        for(j=0;j<size2;j++){
            c=llist_get(lst21,j);
            d=llist_get(lst22,j);
            coeff=b*d;
            exp=a+c;
            int size=llist_size(lst1);
            for(k=0;k<size;k++){
                var=llist_get(lst1,k);
                if(var>=exp) break;
            }
            if(k==size){
                llist_append(lst1,exp);
                llist_append(lst2,coeff);
            }
            if(var==exp){
                int var1=llist_get(lst2,k);
                int var2=var1+coeff;
                llist_insert(lst2,k,var2);
                llist_remove(lst2,k+1);
            }
            if((k!=size)&&(var>exp)){
                llist_insert(lst1,k,exp);
                llist_insert(lst2,k,coeff);
            }
        }
    }
    return ans;
}























