#include "List.h"
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
 

/*
typedef struct Node_ Node;
struct Node_ {
    int data;
    Node* next;
};

typedef struct LList_ {
    Node* head;
} LList; */

Node* node_new( int data){
	Node* node;
	node=(Node*)malloc(sizeof(struct Node_));
	if(node==NULL){
//		printf("eror! out of memory!!");
	}
	else{	
	node->data=data;
	node->next=NULL;}
	return node;
}


LList* llist_new(){
	LList *llist;
	llist=(LList*)malloc(sizeof(LList));

	if(llist==NULL){
//		printf("error! out of memory!!");
	}
	else{	
	llist->head=NULL;}
	return llist;
}


int llist_size( LList* lst ){
//	printf("here ");
	if(lst->head==NULL)
		return 0;
	else{
		int count=1;
		Node* tmp;
		tmp=lst->head;
		while(tmp->next!=NULL){
		//	printf("to infinity ");
			count++;
			tmp=tmp->next;
			
			}
		return count;
	}
}



void llist_print(LList* lst){
	if(lst->head==NULL);
	//	printf("list is empty!!!");
	else{
		Node* cur=lst->head;
		while(1){
			printf("%d ",cur->data);
			if(cur->next!=NULL){
				cur=cur->next;
			}
			else
				break;
		}
	}
printf("\n");
}



int llist_get( LList* lst, int idx ){

	int length=llist_size(lst);
	if((idx>=length)||(idx<0))
		return -1;
	else{
		int i=0;
		Node* cur=lst->head;
		while(i!=idx){
			cur=cur->next;
			i++;
		}

		return cur->data;
	}
}




void llist_append( LList* lst, int data ){

	if(lst->head==NULL){
		Node* target=node_new(data);
		lst->head=target;
	}
	

	else{
		Node* cur=lst->head;
		Node* target=node_new(data);
		while(cur->next!=NULL){
			cur=cur->next;
		}
		cur->next=target;
	}
}


void llist_prepend( LList* lst, int data ){
		
	if(lst->head==NULL){
		Node* target=node_new(data);
		lst->head=target;
	}
	else{
		Node* target=node_new(data);
		target->next=lst->head;
		lst->head=target;
	}
}
	

void llist_insert( LList* lst, int idx, int data ){

	int length=llist_size(lst);
	if((idx>length)||(idx<0));
	//	printf("Error");

	else if(idx==0){
		Node* target=node_new(data);
		target->next=lst->head;
		lst->head=target;}

	else{
		int i=1;
		Node* cur=lst->head;
		Node* target=node_new(data);
		while(i!=idx){
			cur=cur->next;
			i++;
		}

		target->next=cur->next;
		cur->next=target;
	}
}		


// Remove an element from the end of the list
void llist_remove_last( LList* lst ){
	if(lst->head==NULL){
		return;
	}
	
	else if(lst->head->next==NULL){
		lst->head=NULL;
	}
	else{
		Node* cur=lst->head;
		Node* nx=cur->next;
		while(nx->next!=NULL){
			cur=cur->next;
			nx=nx->next;
		}
		cur->next=NULL;
		free(nx);
	}
}


// Remove an element from the beginning of the list
void llist_remove_first( LList* lst ){
	if(lst->head==NULL){
		return;
	//	printf("List is empty");
	}
	
	else if(lst->head->next==NULL){
		lst->head=NULL;
	}
	else{
		Node *tmp;
		tmp=lst->head;
		lst->head=lst->head->next;
		free(tmp);
	}

}


// Remove an element from an arbitrary @idx position in the list
void llist_remove( LList* lst, int idx ){

	int length=llist_size(lst);
	if((idx>length)||(idx<0));
	//	printf("Error");
	
	if(idx==0){
		Node* temp;
		temp=lst->head;
		lst->head=lst->head->next;
	}

	else{
		int i=1;
		Node* cur=lst->head;
		Node* tmp;
		while(i!=idx){
			cur=cur->next;
			i++;
		}

		tmp=cur->next;
		cur->next=tmp->next;
		free(tmp);
	}
}

