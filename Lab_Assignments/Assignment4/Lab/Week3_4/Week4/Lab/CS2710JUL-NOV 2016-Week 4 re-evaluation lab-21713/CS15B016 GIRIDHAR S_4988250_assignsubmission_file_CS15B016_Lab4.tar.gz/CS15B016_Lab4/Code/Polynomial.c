#include "Polynomial.h"
#include "List.h"
#include<stdio.h>
#include<math.h>



/*function to return the degree of the polynomial*/
int get_degree(Polynomial P){

return llist_get(P.exponents, llist_size(P.exponents)-1);

}



// print Polynomial
void print_polynomial(Polynomial p)
{
int i;
int coeff, exp;
for(i=0;i<llist_size(p.exponents);i++){
	coeff=llist_get(p.coeffs,i);
	exp=llist_get(p.exponents,i);
	if(coeff==0)
		continue;
	/*
	if(exp==0){
		if(coeff<0)
			printf("%d ",coeff);
		else if(coeff>=1)
			printf("+%d ", coeff);
	}
	else if(exp==1){

		if(coeff==-1)
			printf("-x ");
		else if(coeff<0)
			printf("%dx ",coeff);
		else if(coeff==1)
			printf("+x ");
		else if(coeff>1)
			printf("+%dx ", coeff);
	}
	else if(exp>1){
		if(coeff==-1)
			printf("-x^%d ", exp);
		else if(coeff<0)
			printf("%dx^%d ", coeff,exp);
		else if(coeff==1)
			printf("+x^%d ", exp);
		else if(coeff>1)
			printf("+%dx^%d ", coeff,exp);

	}*/

	if(i==0){
		if(exp==0){
			printf("%d ",coeff);
		}
	
		else if(coeff==1){
			printf("1x^%d ", exp);
		}
	
		else if(coeff<0){
			if(coeff==-1) printf("-1x^%d ",exp);
			else{
			printf("%dx^%d ",coeff, exp);}
		}
		else{
			printf("%dx^%d ",coeff, exp);
		}
		
		continue;
	}


	if(exp==0){
		printf("%d ",coeff);
	}
	
	else if(coeff==1){
		printf("+ 1x^%d ", exp);
	}
	
	else if(coeff<0){
		if(coeff==-1) printf("- 1x^%d ",exp);
		else{
		printf("- %dx^%d ",(-1)*coeff, exp);}
	}
	else{
		printf("+ %dx^%d ",coeff, exp);
	}
	}
	printf("\n");

}
/*
if(p.exponents->head==NULL);
	//	printf("list is empty!!!");
	else{
		Node* cur_exp=p.exponent->head;
		Node* cur_coeff=p.coeffs->head;
		while(1){
			printf("%dx^%d ",cur_coeff->data, cur_exp->data);
			if(cur_coeff->next!=NULL){
				cur_coeff=cur_coeff->next;
				cur_exp=cur_exp->next;
			}
			else
				break;
		}
	}
*/






/*Add two polynomials and return the result*/
Polynomial add(Polynomial a, Polynomial b){

Polynomial c;
c.exponents=llist_new();
c.coeffs=llist_new();
int i=0,j=0;
  while(j<llist_size(b.coeffs) && i<llist_size(a.coeffs)){
    if(llist_get(b.exponents,j)<llist_get(a.exponents,i)){
      
      llist_append(c.exponents, llist_get(b.exponents,j));
      llist_append(c.coeffs, llist_get(b.coeffs,j));
      j++;
    }
    else if(llist_get(b.exponents,j)>llist_get(a.exponents,i)){
      llist_append(c.exponents, llist_get(a.exponents,i));
      llist_append(c.coeffs, llist_get(a.coeffs,i));
      i++;
    }
    else{
      llist_append(c.exponents, llist_get(b.exponents,j));
      llist_append(c.coeffs, llist_get(b.coeffs,j)+llist_get(a.coeffs,i));
      
      i++;j++;
    }
  }

  while(i<llist_size(a.coeffs)){
      
      llist_append(c.exponents, llist_get(a.exponents,i));
      llist_append(c.coeffs, llist_get(a.coeffs,i));
      i++;
  }

  while(j<llist_size(b.coeffs)){
      
      llist_append(c.exponents, llist_get(b.exponents,j));
      llist_append(c.coeffs, llist_get(b.coeffs,j));
      j++;
      
  }
  return c;
    
}



/*Multiply two polynomials and return the result*/
Polynomial multiply(Polynomial a, Polynomial b){

int i, j;
Polynomial c/*term*/;
c.exponents=llist_new();
c.coeffs=llist_new();
//term.exponents=llist_new();
//term.coeffs=llist_new();
int term_exp;
int term_coeff;
i=0;j=0;
int length_a=llist_size(a.exponents);
int length_b=llist_size(b.exponents);

int sum;
sum=get_degree(a)+get_degree(b);
int sumdash=0;

int flag=0;

for(sumdash=0;sumdash<=sum;sumdash++){
	term_exp=sumdash;
	term_coeff=0;
	for(i=0;i<length_a;i++){
		for(j=length_b-1;j>=0;j--){
			if(llist_get(a.exponents,i)+llist_get(b.exponents,j)==sumdash){
				term_coeff+=llist_get(a.coeffs,i)*llist_get(b.coeffs,j);
				flag=1;
				break;
				}
			}
			if(llist_get(a.exponents,i)>sumdash)
				break;
		}
	if(flag){
		llist_append(c.coeffs, term_coeff);
		llist_append(c.exponents, term_exp);
		}
	}
/*for(i=0;i<length_a;i++){
	for(j=0;j<length_b;j++){
		term_exp=llist_get(a.exponents,i)+llist_get(b.exponents,j);
		term_coeff=llist_get(a.coeffs,i)*llist_get(b.coeffs,j);	
		llist_append(term.coeffs, term_coeff);
		llist_append(term.exponents, term_exp);	
		print_polynomial(term);	
		}
	}*/

return c;
}


/*
sum=deg(a) +deg(b)
sumdash=0

sumdash:0-sum

term_exp=sumdash;
i:0-size(a),j:0-size(b)
if(a.exp[i]+j[exp[j]==sumdash)
  term_coeff+=(a.coeffs[i]*b.coeffs[j])
  flag=1
  
if flag is 1
c.coeffs append term_coeff
cexponents append term_exp


*/

/*
int sum;
sum=get_degree(a)+get_degree(b);
int sumdash=0;

int term_exp,term_coeff,flag=0;

for(sumdash=0;sumdash<=sum;sumdash++){
	term_exp=sumdash;
	term_coeff=0;
	for(i=0;i<length_a;i++){
		for(j=length_b=1;j>=0;j++){
			if(llist_get(a.exp,i)+llist_get(b.exp,j)==sumdash){
				term_coeff+=llist_get(a.coeffs,i)*llist_get(b.coeffs,j);
				flag=1;
				break;
				}
			}
			if(llist_get(a.exp,i)>sumdash)
				break;
		}
	if(flag){
		llist_append(c.coeffs, term_coeff);
		llist_append(c.exponent, term_exp);
		}

*/
		
/*Subtract second Polynomial from first*/
Polynomial subtract(Polynomial a, Polynomial b){
	Polynomial c;
c.exponents=llist_new();
c.coeffs=llist_new();
int i=0,j=0;
  while(j<llist_size(b.coeffs) && i<llist_size(a.coeffs)){
    	if(llist_get(b.exponents,j)<llist_get(a.exponents,i)){
      
     		 llist_append(c.exponents, llist_get(b.exponents,j));
     		 llist_append(c.coeffs, (-1)*llist_get(b.coeffs,j));
      		j++;
    	}
    	else if(llist_get(b.exponents,j)>llist_get(a.exponents,i)){
      		llist_append(c.exponents, llist_get(a.exponents,i));
      		llist_append(c.coeffs, llist_get(a.coeffs,i));
      		i++;
    	}
    	else{
    	  	llist_append(c.exponents, llist_get(b.exponents,j));
    	  	llist_append(c.coeffs, llist_get(a.coeffs,i)-llist_get(b.coeffs,j));
      
      		i++;j++;
    	}
  }

  while(i<llist_size(a.coeffs)){
      
      llist_append(c.exponents, llist_get(a.exponents,i));
      llist_append(c.coeffs, llist_get(a.coeffs,i));
      i++;
  }

  while(j<llist_size(b.coeffs)){
      
      llist_append(c.exponents, llist_get(b.exponents,j));
      llist_append(c.coeffs, (-1)*llist_get(b.coeffs,j));
      j++;
      
  }
  return c;
}

/*Evaluate Polynomial at var=k and return the result*/
long long evaluate(Polynomial a, int k){
	long long value=0;

	int i=0;
	int length_a=llist_size(a.exponents);
	for(i=0;i<length_a;i++){
		value+=llist_get(a.coeffs,i)*pow(k,llist_get(a.exponents,i));
		}
	return value;



/*
	Node* cur_exp=a.exponent->head;
	Node* cur_coeff=a.coeffs->head;
	while(1){
		value+=(cur_coeff)*(pow(k,cur_exp));
		if(cur_coeff->next!=NULL){
			cur_coeff=cur_coeff->next;
			cur_exp=cur_exp->next;
		}
		else
			break;
	}
	return value;
}


*/


}

