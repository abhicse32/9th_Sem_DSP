#include<stdio.h>
#include "List.h"
#include "Polynomial.h"

/*
void destroy_poly(Polynomial *p){
	destroy_this_list(p->exponents);
	destroy_this_list(p->coeffs);
	free(p);
}


void destroy_this_list(LList* gone){
	int len=llist_size(gone);
	while(len){
		llist_remove_first(gone);
		len--;
	}
}
*/




int main(){
/*
Polynomial a;
a.exponents=llist_new();
a.coeffs=llist_new();
int exp, coeff;
int enter=1;

while(enter){
	scanf("%d",&exp);
	scanf("%d",&coeff);
	scanf("%d",&enter);
	llist_append(a.exponents, exp);
	llist_append(a.coeffs, coeff);
}

Polynomial b;
b.exponents=llist_new();
b.coeffs=llist_new();
enter=1;

while(enter){
	scanf("%d",&exp);
	scanf("%d",&coeff);
	scanf("%d",&enter);
	llist_append(b.exponents, exp);
	llist_append(b.coeffs, coeff);
}


Polynomial c;
c.exponents=llist_new();
c.coeffs=llist_new();

printf("The degree of a is %d\n",get_degree(a));
printf("The degree of b is %d\n",get_degree(b));

c=add(a,b);

print_polynomial(a);
print_polynomial(b);
printf("sum is \n");
print_polynomial(c);

c=subtract(a,b);

//print_polynomial(a);
//print_polynomial(b);
printf("diff is \n");
print_polynomial(c);

c=multiply(a,b);
printf("multiply is \n");
print_polynomial(c);


*/
int option;
int t,i;
Polynomial p1,p2,res;

scanf("%d",&option);

while(option!=-1){
	int num;
//	printf("$$option no %d",option);
//	putchar('\n');
//	putchar('\n');

	p1.exponents=llist_new();
	p2.exponents=llist_new();
	p1.coeffs=llist_new();
	p2.coeffs=llist_new();
	res.exponents=llist_new();
	res.coeffs=llist_new();

//	llist_print(p1.exponents);
//	llist_print(p1.coeffs);
//	putchar('\n');

//	llist_print(p2.exponents);
//	llist_print(p2.coeffs);
//	putchar('\n');
//	putchar('\n');

	switch(option){
		case 1: 
			scanf("%d",&t);
			i=0;
			while(i<t){
				scanf("%d",&num);
				llist_append(p1.exponents,num);
				i++;
			}
			i=0;
			while(i<t){
				scanf("%d",&num);
				llist_append(p1.coeffs,num);
				i++;
			}
			print_polynomial(p1);
			break;

		case 2: 
			scanf("%d",&t);
			i=0;
			while(i<t){
				scanf("%d",&num);
				llist_append(p1.exponents,num);
				i++;
			}
			i=0;
			while(i<t){
				scanf("%d",&num);
				llist_append(p1.coeffs,num);
				i++;
			}
			printf("%d\n",get_degree(p1));
			break;
		
		case 3:

			scanf("%d",&t);
			i=0;
			while(i<t){
				scanf("%d",&num);
				llist_append(p1.exponents,num);
				i++;
			}
			i=0;
			while(i<t){
				scanf("%d",&num);
				llist_append(p1.coeffs,num);
				i++;
			}

			scanf("%d",&t);
			i=0;
			while(i<t){
				scanf("%d",&num);
				llist_append(p2.exponents,num);
				i++;
			}
			i=0;
			while(i<t){
				scanf("%d",&num);
				llist_append(p2.coeffs,num);
				i++;
			}

			res=add(p1,p2);
			print_polynomial(res);
			break;

		case 4: 


			scanf("%d",&t);
			i=0;
			while(i<t){
				scanf("%d",&num);
				llist_append(p1.exponents,num);
				i++;
			}
			i=0;
			while(i<t){
				scanf("%d",&num);
				llist_append(p1.coeffs,num);
				i++;
			}

			scanf("%d",&t);
			i=0;
			while(i<t){
				scanf("%d",&num);
				llist_append(p2.exponents,num);
				i++;
			}
			i=0;
			while(i<t){
				scanf("%d",&num);
				llist_append(p2.coeffs,num);
				i++;
			}

			res=subtract(p1,p2);
			print_polynomial(res);
			break;

		case 5:


			scanf("%d",&t);
			i=0;
			while(i<t){
				scanf("%d",&num);
				llist_append(p1.exponents,num);
				i++;
			}
			i=0;
			while(i<t){
				scanf("%d",&num);
				llist_append(p1.coeffs,num);
				i++;
			}

			scanf("%d",&t);
			i=0;
			while(i<t){
				scanf("%d",&num);
				llist_append(p2.exponents,num);
				i++;
			}
			i=0;
			while(i<t){
				scanf("%d",&num);
				llist_append(p2.coeffs,num);
				i++;
			}

			res=multiply(p1,p2);
			print_polynomial(res);
			break;

		case 6:
			scanf("%d",&t);
			i=0;
			while(i<t){
				scanf("%d",&num);
				llist_append(p1.exponents,num);
				i++;
			}
			i=0;
			while(i<t){
				scanf("%d",&num);
				llist_append(p1.coeffs,num);
				i++;
			}
			scanf("%d",&t);
			printf("%lld",evaluate(p1,t));
			putchar('\n');			
			break;


	}
//	printf("##option no %d",option);
	scanf("%d",&option);
//	Polynomial *tmp=&p1;
//	destroy_poly(tmp);
	
}


}



