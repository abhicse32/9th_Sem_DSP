#include "Polynomial.h"
#include "List.h"
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

int get_degree(Polynomial p)				//getting degree of a polynomial
{
	int size = llist_size(p.exponents);
	return (llist_get (p.exponents, size-1 ));
}

void print_polynomial(Polynomial p)			//printing polynomial
{	
	int i;
	int size = llist_size(p.exponents);
	
	for(i = 0; i < size; i++)
	{
		int coef = llist_get(p.coeffs, i);
		int expo = llist_get(p.exponents, i);
		if(coef == 0) 
		{
			i++;
			continue;
		}
		
		if(expo == 0)  	printf("%d",coef);
		else if(expo > 0)
		{
		
			if(i == 0)	
			{
				printf("%d", coef);
		 		printf("x^%d", expo);
		 		continue;
			}	
			else
			{
				if(coef > 0)
				{
					printf(" + %d", coef);
			 		printf("x^%d", expo);
				}	
				else 
				{
					coef = (-1)*coef;
					printf(" - %d", coef);
					printf("x^%d",expo);
				}
			}		
		}
	}
	printf(" \n");
	fflush(stdout);
	return ;
}

Polynomial add(Polynomial p1, Polynomial p2)               //adding two polynomials                           
{
  	Polynomial p3;						//using merge sort
  	
 	p3.exponents = llist_new();
  	p3.coeffs    = llist_new();
  	
  	Node *e1;
  	e1 = ((p1.exponents)->head);
  	
  	Node *e2;
  	e2 = ((p2.exponents)->head);
  	
  	Node *c1;
  	c1 = ((p1.coeffs)->head);
  	
  	Node *c2;
  	c2 = ((p2.coeffs)->head);
  	
  	LList *e;
  	LList *c;
  	e = p3.exponents;
  	c = p3.coeffs;
  	if(e1 == NULL)
    	return p2;
  	if(e2 == NULL)
    	return p1;
  	while((e1 != NULL)&&(e2 != NULL))
  	{
    		if(e1->data == e2->data)
    		{
    			if(c1 -> data != -1 * c2 -> data)
    			{
      				llist_append( e, (e1->data) );
      				llist_append( c, (c1->data + c2->data) );
      			}
      			e1 = (e1->next);
      			c1 = (c1->next);
      			e2 = (e2->next);
      			c2 = (c2->next);
      			
    		}
    		else if((e1->data) < (e2->data))
    		{
      			llist_append( e, (e1->data) );
      			llist_append( c, (c1->data) );
      			e1 = (e1->next);
      			c1 = (c1->next);
      			
    		}
    		else
    		{
      			llist_append( e, (e2->data) );
      			llist_append( c, (c2->data) );
      			e2 = (e2->next);
      			c2 = (c2->next);
      			
    		}
  		if((e2 == NULL)&&(e1 != NULL))
  		{	
   			while(e1 != NULL)
    			{
     				llist_append( e, (e1->data) );
      				llist_append( c, (c1->data) );
      				e1 = (e1->next);
      				c1 = (c1->next);
    			}
  		}	
  		if((e1 == NULL)&&(e2 != NULL))
  		{	
    			while(e2 != NULL)
    			{
      				llist_append( e, (e2->data) );
      				llist_append( c, (c2->data) );
      				e2 = (e2->next);
      				c2 = (c2->next);
    			}
  		}
  	}
  	
  return p3; 
}	

Polynomial subtract(Polynomial p1, Polynomial p2)                   //subtracting polynomials                       
{
  	Node *a;							//use add function
  	a=p2.coeffs->head;
  	while(a!=NULL)
  	{
  		a->data= -1 * (a->data);
  		a=a->next;
  	}
  	return add(p1,p2); 
}
	
Polynomial multiply(Polynomial p1, Polynomial p2)                //multiplying two polynomials                        
{

	Polynomial p3;
  	Polynomial p4;   
  	   
  	p3.exponents = llist_new(); 
  	p4.coeffs = llist_new();  
  	p3.coeffs = llist_new();
  	p4.exponents = llist_new(); 

  	int n1 = llist_size(p1.exponents);   
  	int n2 = llist_size(p2.exponents);   

  	int i;  
  	int j;  

  	for(i=0;i<n1;i++)    
  	{
    		for(j=0;j<n2;j++)
    		{
      			int expo = (llist_get(p1.exponents,i))+ (llist_get(p2.exponents,j));
      			int coef = (llist_get(p1.coeffs,i))   * (llist_get(p2.coeffs,j));
      			if(coef==0);
      			else
      			{
        			llist_append(p4.exponents, expo);
        			llist_append(p4.coeffs,coef);
      			}
    		}
    		p3 = add(p4,p3);
    		p4.exponents = llist_new();  
    		p4.coeffs = llist_new();     
  	}
  	return p3;
}	
	
long long int evaluate(Polynomial p1, int k)                    //evaluating the value of polynomial                     
{
  long long int ans = 0;
  Node *e;
  e = (Node *)malloc(sizeof(Node));
  e = ((p1.exponents)->head);
  
  Node *c;
  c = (Node *)malloc(sizeof(Node));
  c = ((p1.coeffs)->head);
  while(e != NULL)
  {
    ans += (c->data) * pow(k,(e->data));
    e = (e->next);
    c = (c->next);
  }

  return ans;
}	
	
	
		
		
		
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

	
