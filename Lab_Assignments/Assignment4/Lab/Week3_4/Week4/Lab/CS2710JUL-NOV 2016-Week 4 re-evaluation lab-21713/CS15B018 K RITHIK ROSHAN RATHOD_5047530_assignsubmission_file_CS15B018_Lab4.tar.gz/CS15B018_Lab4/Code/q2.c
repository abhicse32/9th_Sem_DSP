#include<stdio.h>
#include"List.h"
#include<stdlib.h>
#include"Polynomial.h"

int main()
{

	int option;
	scanf("%d",&option);	
	Polynomial p1;
	Polynomial p2;
    
   	p1.exponents = llist_new();
   	p1.coeffs    = llist_new();
   	p2.exponents = llist_new();
   	p2.coeffs    = llist_new();
	

	while(option != -1)
	{
	
	int n1,n2,t,i;
	switch(option)
	{						
		case 1 :						//printing polynomial 
		{
			scanf("%d",&n1);
			for(i = 0; i < n1; i++)
			{
				scanf("%d",&t);
				llist_append(p1.exponents,t);
			}
			for(i = 0; i < n1; i++)
			{
				scanf("%d",&t);
				llist_append(p1.coeffs,t);
			}						
			print_polynomial(p1);
			break;
		}
			
		case 2 : 						//getting degree of a polynomial
		{
				
			scanf("%d",&n1);
			for(i = 0; i < n1; i++)
			{
				scanf("%d",&t);
				llist_append(p1.exponents,t);
			}
			for(i = 0; i < n1; i++) 
			{
				scanf("%d",&t);
				llist_append(p1.coeffs,t);
			}
					
			int a = get_degree(p1);
			printf("%d\n",a);
			break;
		}		
		case 3 : 						//adding two polynomials
		{

			scanf("%d",&n1);
			for(i = 0; i < n1; i++)
			{
				scanf("%d",&t);
				llist_append(p1.exponents,t);
			}
			
			for(i = 0; i < n1; i++)
			{
				scanf("%d",&t);
				llist_append(p1.coeffs,t);
			}
			
					
			scanf("%d",&n2);
			for(i = 0; i < n2; i++)
			{	
				scanf("%d",&t);
				llist_append(p2.exponents,t);
			}
			for(i = 0; i < n2; i++)
			{
				scanf("%d",&t);
				llist_append(p2.coeffs,t);
			}
			print_polynomial(add(p1,p2));
			break;
			
			
		}
			
		case 4 :						//subtracting polynomials 
		{
			scanf("%d",&n1);
			for(i = 0; i < n1; i++)
			{
				scanf("%d",&t);
				llist_append(p1.exponents,t);
			}
			for(i = 0; i < n1; i++)
			{
				scanf("%d",&t);
				llist_append(p1.coeffs,t);
			}
					
					
			scanf("%d",&n2);
			for(i = 0; i < n2; i++)
			{
				scanf("%d",&t);
				llist_append(p2.exponents,t);
			}
			for(i = 0; i < n2; i++)
			{
	 			scanf("%d",&t);
				llist_append(p2.coeffs,t);
			}
			print_polynomial(subtract(p1,p2));
			break;
		}
			
		case 5 : 						//multiplying two polynomials       
		{
			scanf("%d",&n1);
			for(i = 0; i < n1; i++) 
			{
				scanf("%d",&t);
				llist_append(p1.exponents,t);
			}
			for(i = 0; i < n1; i++)
			{
				scanf("%d",&t);
				llist_append(p1.coeffs,t);
			}
					
			scanf("%d",&n2);
			for(i = 0; i < n2; i++)
			{
				scanf("%d",&t);
				llist_append(p2.exponents,t);
			}
			for(i = 0; i < n2; i++)
			{
				scanf("%d",&t);
				llist_append(p2.coeffs,t);
			}
			print_polynomial(multiply(p1,p2));
			break;
		}
			
		case 6 : 						//evaluating the value of polynomial 
		{	
			int k;			
			scanf("%d",&n1);
			for(i = 0; i < n1; i++)
			{
				scanf("%d",&t);
				llist_append(p1.exponents,t);
			}
			for(i = 0; i < n1; i++)
			{
				scanf("%d",&t);
				llist_append(p1.coeffs,t);
			}
			scanf("%d",&k);	
					
			long long int e = evaluate(p1,k);
			printf("%lld\n",e);
			
			break;
		}		
	}
	p1.exponents = llist_new();
   	p1.coeffs    = llist_new();
   	p2.exponents = llist_new();
   	p2.coeffs    = llist_new();

	scanf("%d",&option);	
	}
}
