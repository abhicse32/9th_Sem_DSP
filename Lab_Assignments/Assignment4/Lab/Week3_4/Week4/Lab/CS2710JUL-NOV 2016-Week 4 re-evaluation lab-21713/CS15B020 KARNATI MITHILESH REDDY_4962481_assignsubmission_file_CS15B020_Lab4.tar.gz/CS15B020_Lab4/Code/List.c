#include "List.h"
#include<stdlib.h>
#include<stdio.h>
#include<limits.h>
#include "Polynomial.h"
Node* node_new( int data)
 { 
   Node *new_node;

  new_node=(Node*)malloc(sizeof(Node));



 if(new_node!=NULL)
  {
  new_node->data=data;
  new_node->next=NULL;
  }
  
 return new_node;
 }

LList* llist_new()
{ LList* new_list;
  new_list=(LList*)malloc(sizeof(LList));

  if(new_list!=NULL)
  { new_list->head=NULL;
  }
  
  return new_list;
}

int llist_size( LList* lst )
{ int ctr=0;
  Node *start,*mid;
  
  start=lst->head;
  while(start!=NULL)
   { ctr++;
     mid=start->next;
     start=mid;
   }

  return ctr;
}

void llist_print( LList* lst )
{ Node *start,*mid;
  
  start=lst->head;
  while(start!=NULL)
  { printf("%d ",start->data);
    mid=start->next;
    start=mid;
  }
  printf("\n");
}

int llist_get( LList* lst, int idx )
{ Node  *start,*mid;
  start=lst->head;
  while(start!=NULL)
  { if(idx==0)
     { return (start->data);
     }
    mid=start->next;
    start=mid;
    idx--;
  }
 return -1;
}

void llist_append( LList* lst, int data )
{ Node *start,*mid;
  start=lst->head;
  while(start!=NULL)
  {
    mid=start->next;
    if(mid==NULL)
    { start->next=node_new(data);
      return;
    }
    start=mid;
  }
 
    lst->head=node_new(data);
    return;
}

void llist_prepend( LList* lst, int data )
{ Node *start,*mid;
  start=node_new(data);
  mid=lst->head;
  start->next=mid;
  lst->head=start;
}

void llist_insert( LList* lst, int idx, int data )
{ Node  *start,*mid;
  start=lst->head;
  if(idx==0)
   { llist_prepend(lst,data);
     return;
   }
  if(idx==llist_size(lst))
   { llist_append(lst,data);
     return;
   }
  while(start!=NULL)
  { if(idx==0)
     { mid->next=node_new(data);
       (mid->next)->next=start;
       return;
     }
    mid=start;
    start=start->next;
    idx--;
  }
}

void llist_remove_last( LList* lst )
{ Node *start,*mid;
  
  start=lst->head;
  while(start->next!=NULL)
  { mid=start;
    start=start->next;
  }
  free(start);
  mid->next=NULL;
} 

void llist_remove_first( LList* lst )
{ Node *start,*mid;
  
  start=lst->head;
  mid=start->next;
  lst->head=mid;
  free(start);
} 

void llist_remove( LList* lst, int idx )
{ Node  *start,*mid;
  start=lst->head;
  if(idx==0)
   { llist_remove_first(lst);
     return;
   }
  while(start!=NULL)
  { if(idx==0)
     { mid->next=start->next;
       free(start);
       return;
     }
    mid=start;
    start=start->next;
    idx--;
  }
}

