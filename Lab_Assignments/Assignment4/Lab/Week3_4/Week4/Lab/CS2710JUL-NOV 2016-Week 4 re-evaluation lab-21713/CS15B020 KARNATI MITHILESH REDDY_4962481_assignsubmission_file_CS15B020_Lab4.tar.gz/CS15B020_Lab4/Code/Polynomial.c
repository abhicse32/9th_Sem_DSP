#include "Polynomial.h"
#include "List.h"
#include<stdlib.h>
#include<stdio.h>

long int powr(int x,int y)
{  long int k=1,i;
    for(i=0;i<y;i++)
    {  k=k*x;
    }
    return k;
}
/*void clear_poly(Polynomial P)
{      Node *mid,*current;

       while(P.exponents->head!=NULL)
            { mid=P.exponents->head;
              current=mid->next;
              free(mid);
              P.exponents->head=current;
            }
      while(P.coeffs->head!=NULL)
            { mid=P.coeffs->head;
              current=mid->next;
              free(mid);
              P.coeffs->head=current;
            }
}

int eval_calc(Polynomial P,int ctr,int val)
{   Node *start,*t,*mid;
	long int k=1;
	int i,j;
    start=P.exponents->head;
	t=P.coeffs->head;
    ctr=j;
	while(j>0)
	{     
		start=start->next;
		t=t->next;
	    j--;
	}
   
	if(start==NULL)
    { return 0;}

    mid=start->next;
    
    if(mid==NULL)
    {    for(i=start->data;i<mid->data;i++)
        k=k*val;
        return t->data;
    }

    for(i=start->data;i<mid->data;i++)
    	k=k*val;
	
	return t->data + k*eval_calc(P,ctr+1,val);
}*/

int get_degree(Polynomial P)
{
  return llist_get(P.exponents,llist_size(P.exponents)-1);
}
 
void print_polynomial(Polynomial P)
{  Node *ste,*mide,*stc,*midc;
    int flag=0,rear=0;
   ste=P.exponents->head;
   stc=P.coeffs->head;
   while(stc!=NULL)
   { midc=stc->next;
     mide=ste->next;

     if(stc->data==0)
     { ste=mide;
       stc=midc;
       continue;
     }

     if(stc->data>0)
     {
       if(ste->data==0)
       {
        if(flag==1 || rear==1)
        { printf("+ ");
        }
           printf("%d ",stc->data);
       }
        else
       {
           if(flag==1||rear==1)
           { printf("+ ");}
           printf("%dx^%d ",stc->data,ste->data);
       }
    }
     else
     {
       if(ste->data==0)
       {
           if(flag==1||rear==1)
           { printf("- ");
           }
           printf("%d ",(stc->data));
       }
       else
       {
           if(flag==1||rear==1)
           { printf("- ");
               printf("%dx^%d ",-(stc->data),ste->data);
           }
           else
           printf("%dx^%d ",(stc->data),ste->data);
       }
    }

    ste=mide;
    stc=midc;
       flag=1;
    if(stc!=NULL)
    { if(stc->next==NULL)
      {flag=0;
          rear=1;
      }
    }
   }
   printf("\n");
}

Polynomial add(Polynomial Polynomial1,Polynomial Polynomial2)
{ 
  Polynomial P;
  P.exponents=llist_new();
  P.coeffs=llist_new();

  Node *stc1,*midc1,*ste1,*stc2,*midc2,*ste2;
  stc1=Polynomial1.coeffs->head;
  ste1=Polynomial1.exponents->head;
  stc2=Polynomial2.coeffs->head;
  ste2=Polynomial2.exponents->head;

  while(stc1!=NULL || stc2!=NULL)
   { if(ste1!=NULL && ste2!=NULL)
     { if(ste1->data<ste2->data)
      { 
        llist_append(P.exponents,ste1->data);
        llist_append(P.coeffs,stc1->data);
        ste1=ste1->next;
        stc1=stc1->next;
      }
     else if(ste1->data>ste2->data)
      { llist_append(P.exponents,ste2->data);
        llist_append(P.coeffs,stc2->data);
        ste2=ste2->next;
        stc2=stc2->next;
      }   
     else
      { llist_append(P.exponents,ste2->data);
        llist_append(P.coeffs,stc2->data+stc1->data);
        ste2=ste2->next;
        stc2=stc2->next;
        ste1=ste1->next;
        stc1=stc1->next;
      }
    }
    else if(ste2==NULL)
      { 
        llist_append(P.exponents,ste1->data);
        llist_append(P.coeffs,stc1->data);
        ste1=ste1->next;
        stc1=stc1->next;
      }
    else if(ste1==NULL)
      { llist_append(P.exponents,ste2->data);
        llist_append(P.coeffs,stc2->data);
        ste2=ste2->next;
        stc2=stc2->next;
      }
    
   }
   return P;
}        

Polynomial subtract(Polynomial Polynomial1,Polynomial Polynomial2)
{
    Polynomial P;
    P.exponents=llist_new();
    P.coeffs=llist_new();
    
    Node *stc1,*midc1,*ste1,*stc2,*midc2,*ste2;
    stc1=Polynomial1.coeffs->head;
    ste1=Polynomial1.exponents->head;
    stc2=Polynomial2.coeffs->head;
    ste2=Polynomial2.exponents->head;
    
    while(stc1!=NULL || stc2!=NULL)
    { if(ste1!=NULL && ste2!=NULL)
    { if(ste1->data<ste2->data)
    {
        llist_append(P.exponents,ste1->data);
        llist_append(P.coeffs,stc1->data);
        ste1=ste1->next;
        stc1=stc1->next;
    }
    else if(ste1->data>ste2->data)
    { llist_append(P.exponents,ste2->data);
        llist_append(P.coeffs,-(stc2->data));
        ste2=ste2->next;
        stc2=stc2->next;
    }
    else
    { llist_append(P.exponents,ste2->data);
        llist_append(P.coeffs,stc1->data-(stc2->data));
        ste2=ste2->next;
        stc2=stc2->next;
        ste1=ste1->next;
        stc1=stc1->next;
    }
    }
    else if(ste2==NULL)
    {
        llist_append(P.exponents,ste1->data);
        llist_append(P.coeffs,stc1->data);
        ste1=ste1->next;
        stc1=stc1->next;
    }
    else if(ste1==NULL)
    { llist_append(P.exponents,ste2->data);
        llist_append(P.coeffs,-(stc2->data));
        ste2=ste2->next;
        stc2=stc2->next;
    }
        
    }
    return P;
}

long int evaluate(Polynomial P, int k)
{  Node *start,*t,*mid;
    long int sum=0;
    start=P.exponents->head;
    t=P.coeffs->head;
    while(start!=NULL)
    {  sum=sum+((t->data)*powr(k,start->data));
        start=start->next;
        t=t->next;
    }
    return sum;
}
      


Polynomial multiply(Polynomial Poly1,Polynomial Poly2)
{
	Polynomial a1,temp,blank,c1;
	
	a1.exponents=llist_new();
    a1.coeffs=llist_new();
    
    blank.exponents=llist_new();
    blank.coeffs=llist_new();
    
    temp.exponents=llist_new();
    temp.coeffs=llist_new();
    
	Node *n1,*n2,*b1,*b2,*mid,*current;
	
	n1=Poly1.exponents->head;
	n2=Poly1.coeffs->head;
	
	while(n1!=NULL)
		{	a1=add(blank,Poly2);
		
			b1=a1.exponents->head;
			b2=a1.coeffs->head;

			while(b1!=NULL)
			 { b1->data=n1->data+b1->data;
			   b2->data=n2->data*b2->data;
			   b1=b1->next;
			   b2=b2->next;
   			 }
            temp=add(temp,a1);
          /*  c1=add(temp,a1);
            clear_poly(temp);
            temp=c1;
            clear_poly(c1);
            clear_poly(a1);*/
            
            n1=n1->next;
            n2=n2->next;

		}
		
	return temp;
}	