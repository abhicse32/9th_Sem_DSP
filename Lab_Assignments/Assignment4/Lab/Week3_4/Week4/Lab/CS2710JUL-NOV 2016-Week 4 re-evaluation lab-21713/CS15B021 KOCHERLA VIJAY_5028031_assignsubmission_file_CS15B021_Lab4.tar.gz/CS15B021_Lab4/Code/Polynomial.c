#include"Polynomial.h"
#include"List.h"
#include<stdio.h>
#include<stdlib.h>

int get_degree(Polynomial p1)
{
	LList *exp1 = p1.exponents;
	Node *exp2 = exp1->head;
	if(exp2 == NULL)
	{
		return -1;
	}
	int max;
	max = exp2->data;
	while(exp2->next != NULL)
	{
		exp2 = exp2->next;
		if(max < exp2->data)
		{
			max = exp2->data;
		}
		
	}
	return max;
}
void print_polynomial(Polynomial p1)
{
	Node *exp2 = (p1.exponents)->head;
	Node *coeff2 = (p1.coeffs)->head;
	if(exp2 == NULL)
	{
		printf("0");
	}
	
	else	{	int flag = 0;
				while(exp2 != NULL)
				{
					if((exp2->data) == 0)
					{
						printf("%d ",coeff2->data);
						flag++;
					}
					else { if((coeff2->data) > 0)
					{
						if(flag>0)
						{
						
							printf("+ %dx^%d ",coeff2->data,exp2->data);
						}
						if(flag == 0)
						{
							printf("%dx^%d ",coeff2->data,exp2->data);
						}
						flag++;					
					}	
					if((coeff2 ->data) < 0)
					{	if(flag>0)
						{
						printf("- %dx^%d ",-(coeff2->data),exp2->data);
						}
						if(flag == 0)
						{
						printf("%dx^%d ",(coeff2->data),exp2->data);  
                        flag++;       
						}
                    }

					}
					exp2 = exp2->next;
					coeff2 = coeff2->next;
					
			}
			printf("\n");
}
}
Polynomial add(Polynomial p1, Polynomial p2)
{
	Node *exp1 = (p1.exponents)->head;
	Node *exp2 = (p2.exponents)->head;
	Node *coeff1 = (p1.coeffs)->head;
	Node *coeff2 = (p2.coeffs)->head;
	
	if(exp1 == NULL)
	{
		return p2;
	}
	if(exp2 == NULL)
	{
		return p1;
	}
	LList *expans = llist_new();
	LList *coeffans = llist_new();
	while(exp1 != NULL && exp2 != NULL)
	{
		if((exp1->data) == (exp2->data))
		{	
            int x = (coeff1->data) + (coeff2->data);
            if (x!=0)   {
			                llist_append(expans,(exp1->data));
			                llist_append(coeffans,x);
                        }
			exp1 = exp1->next;
			exp2 = exp2->next;
			coeff1 = coeff1->next;
			coeff2 = coeff2->next;
		}
		else if((exp1->data) > (exp2->data))
		{
			llist_append(coeffans,coeff2->data);
			llist_append(expans,exp2->data);
			exp2 = exp2->next;
			coeff2 = coeff2->next;
		}
		else if((exp1->data) < (exp2->data))
		{
			llist_append(coeffans,coeff1->data);
			llist_append(expans,exp1->data);
			exp1 = exp1->next;
			coeff1 = coeff1->next;
		}
	}
	if((exp1 == NULL) && (exp2 == NULL))
	{
		Polynomial pans;
		pans.exponents = expans;
		pans.coeffs = coeffans;
		return pans;
	}
	else if((exp1 == NULL) && (exp2 != NULL))
	{
		while(exp2 != NULL)
		{
			llist_append(coeffans,coeff2->data);
			llist_append(expans,exp2->data);
			exp2 = exp2->next;
			coeff2 = coeff2->next;
		}
		Polynomial pans;
		pans.exponents = expans;
		pans.coeffs = coeffans;
		return pans;
	}
	else if((exp1 != NULL) && (exp2 == NULL))
	{
		while(exp1 != NULL)
		{
			llist_append(coeffans,coeff1->data);
			llist_append(expans,exp1->data);
			exp1 = exp1->next;
			coeff1 = coeff1->next;
		}
		Polynomial pans;
		pans.exponents = expans;
		pans.coeffs = coeffans;
		return pans;
	}
}
Polynomial subtract(Polynomial p1, Polynomial p2)
{
	Node *exp1 = (p1.exponents)->head;
	Node *exp2 = (p2.exponents)->head;
	Node *coeff1 = (p1.coeffs)->head;
	Node *coeff2 = (p2.coeffs)->head;
	
	if(exp1 == NULL)
	{
		return p2;
	}
	if(exp2 == NULL)
	{
		return p1;
	}
	LList *expans = llist_new();
	LList *coeffans = llist_new();
	while(exp1 != NULL && exp2 != NULL)
	{
		if((exp1->data) == (exp2->data))
		{	
            int x = (coeff1->data) - (coeff2->data);
            if (x!=0)   {
			                llist_append(expans,(exp1->data));
			                llist_append(coeffans,x);
                        }
			exp1 = exp1->next;
			exp2 = exp2->next;
			coeff1 = coeff1->next;
			coeff2 = coeff2->next;
		}
		else if((exp1->data) > (exp2->data))
		{
			llist_append(coeffans,-(coeff2->data));
			llist_append(expans,exp2->data);
			exp2 = exp2->next;
			coeff2 = coeff2->next;
		}
		else if((exp1->data) < (exp2->data))
		{
			llist_append(coeffans,(coeff1->data));
			llist_append(expans,exp1->data);
			exp1 = exp1->next;
			coeff1 = coeff1->next;
		}
	}
	if((exp1 == NULL) && (exp2 == NULL))
	{
		Polynomial pans;
		pans.exponents = expans;
		pans.coeffs = coeffans;
		return pans;
	}
	else if((exp1 == NULL) && (exp2 != NULL))
	{
		while(exp2 != NULL)
		{
			llist_append(coeffans,-(coeff2->data));
			llist_append(expans,exp2->data);
			exp2 = exp2->next;
			coeff2 = coeff2->next;
		}
		Polynomial pans;
		pans.exponents = expans;
		pans.coeffs = coeffans;
		return pans;
	}
	else if((exp1 != NULL) && (exp2 == NULL))
	{
		while(exp1 != NULL)
		{
			llist_append(coeffans,coeff1->data);
			llist_append(expans,exp1->data);
			exp1 = exp1->next;
			coeff1 = coeff1->next;
		}
		Polynomial pans;
		pans.exponents = expans;
		pans.coeffs = coeffans;
		return pans;
	}
}


long long int evaluate(Polynomial p1, int k)
{
	LList *exp = p1.exponents;
	LList *coeff = p1.coeffs;
	Node *exp1 = exp->head;
	Node *coeff1 = coeff->head;
	long long int value = 0;
	int i = 0;
	if(exp1 == NULL)
	{
		return -1;
	}
	while(exp1 != NULL)
	{
		long long int l = 1;
		for(i = 0;i < (exp1->data);i++)
		{
			l = l*k;
		}
		value = value + (coeff1->data)*l;
		exp1 = exp1->next;
		coeff1 = coeff1->next;
	}
	return value;
}				
Polynomial multiply(Polynomial p1, Polynomial p2)
{
	Polynomial new1;
	Polynomial new2;
	
	new1.exponents = llist_new();
	new2.exponents = llist_new();
	new1.coeffs = llist_new();
	new2.coeffs = llist_new();
	Node *exp1 = (p1.exponents)->head;
	Node *exp2 = (p2.exponents)->head;
	Node *coeff1 = (p1.coeffs)->head;
	Node *coeff2 = (p2.coeffs)->head;
	while(exp1 != NULL)
	{
		while(exp2 != NULL)
		{
			llist_append(new1.exponents,(exp1->data) + (exp2->data));
			llist_append(new1.coeffs,(coeff1->data)*(coeff2->data));
			exp2 = exp2->next;
			coeff2 = coeff2->next;
		}
		exp1 = exp1->next;
		coeff1 = coeff1->next;
		new2 = add(new1,new2);
		new1.exponents = llist_new();
		new1.coeffs = llist_new();
		exp2 = (p2.exponents)->head;
		coeff2 = (p2.coeffs)->head;
	}
	
	return new2;
}
	

		
		
			
	

	
	

	
	
