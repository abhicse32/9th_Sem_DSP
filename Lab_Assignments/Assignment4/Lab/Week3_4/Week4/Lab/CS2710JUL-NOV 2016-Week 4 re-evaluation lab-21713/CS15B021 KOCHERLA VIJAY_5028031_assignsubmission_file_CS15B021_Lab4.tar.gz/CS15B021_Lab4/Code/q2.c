#include<stdio.h>
#include<stdlib.h>
#include "List.h"
#include "Polynomial.h"
void main()
{
    int sent = 0;
        while(sent != -1)
        {
            int option;
            scanf("%d",&option);
            if(option == 1)
            {   
                Polynomial p1;
                p1.exponents = llist_new();
                p1.coeffs = llist_new();
                int i;
                scanf("%d",&i);
                int j;int k;int l;
                for(j = 0;j<i;j++)
                {
                    scanf("%d",&k);
                    llist_append(p1.exponents,k);
                }
                for(j = 0;j<i;j++)
                {
                    scanf("%d",&l);
                    llist_append(p1.coeffs,l);
                }
                print_polynomial(p1);
             }
             if(option == 2)
             {
                Polynomial p1;
                p1.exponents = llist_new();
                p1.coeffs = llist_new();
                int i;
                scanf("%d",&i);
                int j;int k;int l;
                for(j = 0;j<i;j++)
                {
                    scanf("%d",&k);
                    llist_append(p1.exponents,k);
                }
                for(j = 0;j<i;j++)
                {
                    scanf("%d",&l);
                    llist_append(p1.coeffs,l);
                }
                  printf("%d\n",get_degree(p1));
              }
              if(option == 6)
              {
                Polynomial p1;
                p1.exponents = llist_new();
                p1.coeffs = llist_new();
                int i;
                scanf("%d",&i);
                int j;int k;int l;
                for(j = 0;j<i;j++)
                {
                    scanf("%d",&k);
                    llist_append(p1.exponents,k);
                }
                for(j = 0;j<i;j++)
                {
                    scanf("%d",&l);
                    llist_append(p1.coeffs,l);
                }
                int key;
                scanf("%d",&key);
                long long int ans = evaluate(p1, key);
                printf("%lld\n",ans);
               }
               if(option == 3)
               {
                Polynomial p1;
                p1.exponents = llist_new();
                p1.coeffs = llist_new();
                int i;
                scanf("%d",&i);
                int j;int k;int l;
                for(j = 0;j<i;j++)
                {
                    scanf("%d",&k);
                    llist_append(p1.exponents,k);
                }
                for(j = 0;j<i;j++)
                {
                    scanf("%d",&l);
                    llist_append(p1.coeffs,l);
                }
                Polynomial p2;
                p2.exponents = llist_new();
                p2.coeffs = llist_new();
                int p;
                scanf("%d",&p);
                int m;int n;int o;
                for(m = 0;m<p;m++)
                {
                    scanf("%d",&n);
                    llist_append(p2.exponents,n);
                }
                for(m = 0;m<p;m++)
                {
                    scanf("%d",&o);
                    llist_append(p2.coeffs,o);
                }
                print_polynomial(add(p1,p2));
              }
              if(option == 4)
              {
                Polynomial p1;
                p1.exponents = llist_new();
                p1.coeffs = llist_new();
                int i;
                scanf("%d",&i);
                int j;int k;int l;
                for(j = 0;j<i;j++)
                {
                    scanf("%d",&k);
                    llist_append(p1.exponents,k);
                }
                for(j = 0;j<i;j++)
                {
                    scanf("%d",&l);
                    llist_append(p1.coeffs,l);
                }
                Polynomial p2;
                p2.exponents = llist_new();
                p2.coeffs = llist_new();
                int p;
                scanf("%d",&p);
                int m;int n;int o;
                for(m = 0;m<p;m++)
                {
                    scanf("%d",&n);
                    llist_append(p2.exponents,n);
                }
                for(m = 0;m<p;m++)
                {
                    scanf("%d",&o);
                    llist_append(p2.coeffs,o);
                }
                print_polynomial(subtract(p1,p2));
              }
              if(option == 5)
              {
                Polynomial p1;
                p1.exponents = llist_new();
                p1.coeffs = llist_new();
                int i;
                scanf("%d",&i);
                int j;int k;int l;
                for(j = 0;j<i;j++)
                {
                    scanf("%d",&k);
                    llist_append(p1.exponents,k);
                }
                for(j = 0;j<i;j++)
                {
                    scanf("%d",&l);
                    llist_append(p1.coeffs,l);
                }
                Polynomial p2;
                p2.exponents = llist_new();
                p2.coeffs = llist_new();
                int p;
                scanf("%d",&p);
                int m;int n;int o;
                for(m = 0;m<p;m++)
                {
                    scanf("%d",&n);
                    llist_append(p2.exponents,n);
                }
                for(m = 0;m<p;m++)
                {
                    scanf("%d",&o);
                    llist_append(p2.coeffs,o);
                }
                print_polynomial(multiply(p1,p2));
              } 
              if(option == -1)
              {
                break;
              }
          }
 }

              
                
