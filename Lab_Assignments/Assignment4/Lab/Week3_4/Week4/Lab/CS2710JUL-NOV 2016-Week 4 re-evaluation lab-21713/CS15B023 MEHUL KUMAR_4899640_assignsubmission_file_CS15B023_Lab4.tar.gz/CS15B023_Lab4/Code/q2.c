#include<stdio.h>
#include"List.h"
#include"Polynomial.h"

int main()
{ Polynomial p1,p2,p3;
  int val=0,n,i,x;
  long int y;
 
 while(val!=-1)
 {
  scanf("%d",&val);
    p1.exponents=llist_new();
    p2.exponents=llist_new();
    p3.exponents=llist_new();
    p1.coeffs=llist_new();
    p2.coeffs=llist_new();
    p3.coeffs=llist_new();
  switch(val)
  { 
    
      case 1: scanf("%d",&n);
            for(i=0;i<n;i++)
            { scanf("%d",&x);
              llist_append(p1.exponents,x);
            }
            for(i=0;i<n;i++)
            { scanf("%d",&x);
              llist_append(p1.coeffs,x);
            }
            print_polynomial(p1);
            break;
            
    case 2: scanf("%d",&n);
            for(i=0;i<n;i++)
            { scanf("%d",&x);
              llist_append(p1.exponents,x);
            }
            for(i=0;i<n;i++)
            { scanf("%d",&x);
              llist_append(p1.coeffs,x);
            }
            x=get_degree(p1);
            printf("%d\n",x);
            break;
    case 3: scanf("%d",&n);
            for(i=0;i<n;i++)
            { scanf("%d",&x);
              llist_append(p1.exponents,x);
            }
            for(i=0;i<n;i++)
            { scanf("%d",&x);
              llist_append(p1.coeffs,x);
            }
            scanf("%d",&n);
            for(i=0;i<n;i++)
            { scanf("%d",&x);
              llist_append(p2.exponents,x);
            }
            for(i=0;i<n;i++)
            { scanf("%d",&x);
              llist_append(p2.coeffs,x);
            }
            p3=add(p1,p2);
            print_polynomial(p3);
            break;
    case 4: scanf("%d",&n);
            for(i=0;i<n;i++)
            { scanf("%d",&x);
              llist_append(p1.exponents,x);
            }
            for(i=0;i<n;i++)
            { scanf("%d",&x);
              llist_append(p1.coeffs,x);
            }
            scanf("%d",&n);
            for(i=0;i<n;i++)
            { scanf("%d",&x);
              llist_append(p2.exponents,x);
            }
            for(i=0;i<n;i++)
            { scanf("%d",&x);
              llist_append(p2.coeffs,x);
            }
            p3=subtract(p1,p2);
            print_polynomial(p3);
            break;
    case 5: scanf("%d",&n);
            for(i=0;i<n;i++)
            { scanf("%d",&x);
              llist_append(p1.exponents,x);
            }
            for(i=0;i<n;i++)
            { scanf("%d",&x);
              llist_append(p1.coeffs,x);
            }
            scanf("%d",&n);
            for(i=0;i<n;i++)
            { scanf("%d",&x);
              llist_append(p2.exponents,x);
            }
            for(i=0;i<n;i++)
            { scanf("%d",&x);
              llist_append(p2.coeffs,x);
            }
            p3=multiply(p1,p2);
            print_polynomial(p3);
            break;
    case 6: scanf("%d",&n);
            for(i=0;i<n;i++)
            { scanf("%d",&x);
              llist_append(p1.exponents,x);
            }
            for(i=0;i<n;i++)
            { scanf("%d",&x);
              llist_append(p1.coeffs,x);
            }
            scanf("%d",&x);
            y=evaluate(p1,x);
            printf("%ld\n",y);
            break;
     default: val=-1;
  }
 }
 return 0;
}
            
            