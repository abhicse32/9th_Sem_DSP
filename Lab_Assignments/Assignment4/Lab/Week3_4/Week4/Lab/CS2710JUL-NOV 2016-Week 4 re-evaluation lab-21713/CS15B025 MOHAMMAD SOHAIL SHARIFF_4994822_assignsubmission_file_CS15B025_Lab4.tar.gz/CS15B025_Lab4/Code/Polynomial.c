#include "Polynomial.h"
#include "List.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
/*
  FUNCTIONS OF POLYNOMIALS
*/
int get_degree(Polynomial p)                                                   //TO GET DEGREE
{
  Node *temp;
  temp = (Node *)malloc(sizeof(Node));
  temp = ((p.exponents)->head);
  while((temp->next) != NULL)
  {
    temp = temp->next;
  }
  return (temp->data);
}

void print_polynomial(Polynomial p)                                           //TO PRINT POLYNOMIAL
{
  Node *temp_e;
  temp_e = (Node *)malloc(sizeof(Node));
  temp_e = ((p.exponents)->head);
  Node *temp_c;
  temp_c = (Node *)malloc(sizeof(Node));
  temp_c = ((p.coeffs)->head);
  int c = 0;
  if((temp_e->data) == 0)
  {
    printf("%d",(temp_c->data));
    c++;
    temp_e = (temp_e->next);
    temp_c = (temp_c->next);
  }
  while((temp_e != NULL) && (temp_c != NULL))
  {
    if(c == 0)
    {
      if(temp_c->data != 0)
        printf("%dx^%d",(temp_c->data),(temp_e->data));
      c++;
      temp_e = (temp_e->next);
      temp_c = (temp_c->next);
    }
    else
    {
      if(temp_c->data < 0)
        printf(" - %dx^%d",(-(temp_c->data)),(temp_e->data));
      else if(temp_c->data != 0)
        printf(" + %dx^%d",(temp_c->data),(temp_e->data));
    temp_e = (temp_e->next);
    temp_c = (temp_c->next);
    }
  }
  printf(" \n");                                                 /* EXTRA SPACE AT THE END */
}

Polynomial add(Polynomial p1, Polynomial p2)                                          //ADDITION
{
  Polynomial p3;
  p3.exponents = llist_new();
  p3.coeffs = llist_new();
  Node *temp1_e;
  temp1_e = (Node *)malloc(sizeof(Node));
  temp1_e = ((p1.exponents)->head);
  Node *temp1_c;
  temp1_c = (Node *)malloc(sizeof(Node));
  temp1_c = ((p1.coeffs)->head);
  Node *temp2_e;
  temp2_e = (Node *)malloc(sizeof(Node));
  temp2_e = ((p2.exponents)->head);
  Node *temp2_c;
  temp2_c = (Node *)malloc(sizeof(Node));
  temp2_c = ((p2.coeffs)->head);
  LList *a;
  LList *b;
  a = p3.exponents;
  b = p3.coeffs;
  if(temp1_e == NULL)
    return p2;
  if(temp2_e == NULL)
    return p1;

  while((temp1_e != NULL)&&(temp2_e != NULL))
  {
    if(temp1_e->data == temp2_e->data)
    {
      llist_append( a, (temp1_e->data) );
      llist_append( b, (temp1_c->data + temp2_c->data) );
      temp1_e = (temp1_e->next);
      temp1_c = (temp1_c->next);
      temp2_e = (temp2_e->next);
      temp2_c = (temp2_c->next);
    }
    else if(temp1_e->data < temp2_e->data)
    {
      llist_append( a, (temp1_e->data) );
      llist_append( b, (temp1_c->data) );
      temp1_e = (temp1_e->next);
      temp1_c = (temp1_c->next);
    }
    else
    {
      llist_append( a, (temp2_e->data) );
      llist_append( b, (temp2_c->data) );
      temp2_e = (temp2_e->next);
      temp2_c = (temp2_c->next);
    }
  }
  if(temp2_e == NULL)
  {
    while(temp1_e != NULL)
    {
      llist_append( a, (temp1_e->data) );
      llist_append( b, (temp1_c->data) );
      temp1_e = (temp1_e->next);
      temp1_c = (temp1_c->next);
    }
  }
  if(temp1_e == NULL)
  {
    while(temp2_e != NULL)
    {
      llist_append( a, (temp2_e->data) );
      llist_append( b, (temp2_c->data) );
      temp2_e = (temp2_e->next);
      temp2_c = (temp2_c->next);
    }
  }
  return p3; 
}

Polynomial subtract(Polynomial p1, Polynomial p2)                                      //SUBTRACTION
{
  Polynomial p3;
  p3.exponents = llist_new();
  p3.coeffs = llist_new();
  Node *temp1_e;
  temp1_e = (Node *)malloc(sizeof(Node));
  temp1_e = ((p1.exponents)->head);
  Node *temp1_c;
  temp1_c = (Node *)malloc(sizeof(Node));
  temp1_c = ((p1.coeffs)->head);
  Node *temp2_e;
  temp2_e = (Node *)malloc(sizeof(Node));
  temp2_e = ((p2.exponents)->head);
  Node *temp2_c;
  temp2_c = (Node *)malloc(sizeof(Node));
  temp2_c = ((p2.coeffs)->head);

  if(temp1_e == NULL)
    return p2;
  if(temp2_e == NULL)
    return p1;

  LList *a;
  LList *b;
  a = p3.exponents;
  b = p3.coeffs;
  
  while((temp1_e != NULL)&&(temp2_e != NULL))
  {
    if(temp1_e->data == temp2_e->data)
    {
      llist_append( a, (temp1_e->data) );
      llist_append( b, (temp1_c->data - temp2_c->data) );
      temp1_e = (temp1_e->next);
      temp1_c = (temp1_c->next);
      temp2_e = (temp2_e->next);
      temp2_c = (temp2_c->next);
    }
    else if(temp1_e->data < temp2_e->data)
    {
      llist_append( a, (temp1_e->data) );
      llist_append( b, (temp1_c->data) );
      temp1_e = (temp1_e->next);
      temp1_c = (temp1_c->next);
    }
    else
    {
      llist_append( a, (temp2_e->data) );
      llist_append( b, (-(temp2_c->data)) );
      temp2_e = (temp2_e->next);
      temp2_c = (temp2_c->next);
    }
  }
  while(temp1_e != NULL)
  {
    llist_append( a, (temp1_e->data) );
    llist_append( b, (temp1_c->data) );
    temp1_e = (temp1_e->next);
    temp1_c = (temp1_c->next);
  }
  while(temp2_e != NULL)
  {
    llist_append( a, (temp2_e->data) );
    llist_append( b, (-(temp2_c->data)) );
    temp2_e = (temp2_e->next);
    temp2_c = (temp2_c->next);
  }

  return p3; 
}

Polynomial multiply(Polynomial p1, Polynomial p2)                                        //MULTIPLICATION
{
  Polynomial p4;   
  Polynomial p3;   
  p4.exponents = llist_new(); 
  p3.exponents = llist_new();  
  p4.coeffs = llist_new();  
  p3.coeffs = llist_new();  

  int n = llist_size(p1.exponents);   
  int m = llist_size(p2.exponents);   

  int i;  
  int j;  

  for(i=0;i<n;i++)    
  {
    for(j=0;j<m;j++)
    {
      int expo = (llist_get(p1.exponents,i))+(llist_get(p2.exponents,j));
      int coeff = (llist_get(p1.coeffs,i))*(llist_get(p2.coeffs,j));
      if(coeff==0);
      else
      {
        llist_append(p4.exponents, expo);
        llist_append(p4.coeffs,coeff);
      }
    }
    p3 = add(p4,p3);
    p4.exponents = llist_new();  
    p4.coeffs = llist_new();     
  }
  return p3;
}

long long int evaluate(Polynomial p1, int k)                                         //EVALUATION
{
  long long int eval = 0;
  Node *temp1_e;
  temp1_e = (Node *)malloc(sizeof(Node));
  temp1_e = ((p1.exponents)->head);
  Node *temp1_c;
  temp1_c = (Node *)malloc(sizeof(Node));
  temp1_c = ((p1.coeffs)->head);
  while(temp1_e != NULL)
  {
    eval += (temp1_c->data) * pow(k,(temp1_e->data));
    temp1_e = (temp1_e->next);
    temp1_c = (temp1_c->next);
  }

  return eval;
}
