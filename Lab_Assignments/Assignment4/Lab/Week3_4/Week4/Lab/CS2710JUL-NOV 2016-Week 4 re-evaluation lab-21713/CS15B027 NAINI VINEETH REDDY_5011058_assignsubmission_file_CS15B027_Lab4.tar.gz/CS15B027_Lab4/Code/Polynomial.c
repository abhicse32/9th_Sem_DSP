#include "Polynomial.h"
#include "List.h"
#include<stdio.h>
#include<math.h>
#include<stdlib.h>
int get_degree(Polynomial p)
{
    int l = llist_size(p.exponents);          // no of exponents
    int degree = llist_get(p.exponents,l-1);     // using get function
    return degree;
}
void print_polynomial(Polynomial p)     
{
  Node *temp_e;
  temp_e = (Node *)malloc(sizeof(Node));
  temp_e = ((p.exponents)->head);
  Node *temp_c;
  temp_c = (Node *)malloc(sizeof(Node));
  temp_c = ((p.coeffs)->head);
  int c = 0;                     //counter to see if constant is present or not
  if((temp_e->data) == 0)       // printing for constant
  {
    printf("%d",(temp_c->data));
    c++;
    temp_e = (temp_e->next);
    temp_c = (temp_c->next);
  }
  while((temp_e != NULL) && (temp_c != NULL))
  {
    if(c == 0)           // c will be zero if consant is not present
    {
      printf("%dx^%d",(temp_c->data),(temp_e->data));
      c++;
      temp_e = (temp_e->next);
      temp_c = (temp_c->next);
   }
    else
    {
      if(temp_c->data < 0)
        printf(" - %dx^%d",(-(temp_c->data)),(temp_e->data));     // printing for negative coefficents
      else
        printf(" + %dx^%d",(temp_c->data),(temp_e->data));
    temp_e = (temp_e->next);
    temp_c = (temp_c->next);
    }
  }
  printf(" \n");
}
Polynomial add(Polynomial p1, Polynomial p2)             // adding two  polynomials
{
    Polynomial psum;                 // declaring and initialising a new polynomial
    psum.exponents = llist_new();    
    psum.coeffs = llist_new(); 

    int x = llist_size(p1.exponents);  
    int y = llist_size(p2.exponents);

    int i;
    int j;   // using counters

    i=0;
    j=0;
    while((i<x) && (j<y))         
    {
            if (llist_get(p1.exponents,i) > llist_get(p2.exponents,j)) 
            {
              llist_append(psum.exponents,llist_get(p2.exponents,j));    // appending the least exponent among p1 and p2 to psum
              llist_append(psum.coeffs,llist_get(p2.coeffs,j));
              j++;
            }
            else if(llist_get(p1.exponents,i) < llist_get(p2.exponents,j)) 
            {
               llist_append(psum.exponents,llist_get(p1.exponents,i));
               llist_append(psum.coeffs,llist_get(p1.coeffs,i));
               i++;
            }
            else
            {
                    int sum = (llist_get(p1.coeffs,i)) + (llist_get(p2.coeffs,j));
                    if(sum!=0)
                    {
	
                            llist_append(psum.exponents, llist_get(p1.exponents,i));
                            llist_append(psum.coeffs, sum); // appending if the sum is non zero
                    }
                      i++;
                      j++;
            }
        }

    while(j<y)
        {
            llist_append(psum.exponents,llist_get(p2.exponents,j));    // adding remaining exponents in p2 if present
            llist_append(psum.coeffs,llist_get(p2.coeffs,j));
            j++;
        }

    while(i<x)
        {
            llist_append(psum.exponents,llist_get(p1.exponents,i));    // adding remaining exponents in p1 if present
            llist_append(psum.coeffs,llist_get(p1.coeffs,i));
            i++;
        }

    return psum;              // returning the polynomial
}

Polynomial subtract(Polynomial p1, Polynomial p2)   // subracting second from first
{
    Polynomial psub;                 // declaring and initialising a new polynomial
    psub.exponents = llist_new();
    psub.coeffs = llist_new();

    int x = llist_size(p1.exponents);  
    int y = llist_size(p2.exponents);  
    int i;
    int j;     // using counters

    i=0;
    j=0;
    while((i<x) && (j<y))
        {
            if (llist_get(p1.exponents,i) > llist_get(p2.exponents,j))
            {
               llist_append(psub.exponents,llist_get(p2.exponents,j)); // appending the least exponent among p1 and p2 to psub
               llist_append(psub.coeffs,-(llist_get(p2.coeffs,j)));
               j++;
            }

            else if(llist_get(p1.exponents,i) < llist_get(p2.exponents,j))
            {
               llist_append(psub.exponents,llist_get(p1.exponents,i));// appending the least exponent among p1 and p2 to psub
               llist_append(psub.coeffs,llist_get(p1.coeffs,i));
               i++;
            }
            else {
                    int sum = (llist_get(p1.coeffs,i))-(llist_get(p2.coeffs,j));
                    if(sum != 0)
                    {
                            llist_append(psub.exponents,llist_get(p1.exponents,i));
                            llist_append(psub.coeffs,sum);  // appending if the sum is non zero
                    }
                    i++;
                    j++;
                 }
        }
    while(j<y)
        {
            llist_append(psub.exponents,llist_get(p2.exponents,j));
            llist_append(psub.coeffs,-(llist_get(p2.coeffs,j)));  // subracting remaining exponents in p2 if present
            j++;
        }

    while(i<x)
        {
            llist_append(psub.exponents,llist_get(p1.exponents,i));
            llist_append(psub.coeffs,llist_get(p1.coeffs,i));       // adding remaining exponents in p1 if present
            i++;
        }

    return psub;         // returning the polynomial
}

Polynomial multiply(Polynomial p1, Polynomial p2)
  {
    Polynomial ans;
    ans.exponents=llist_new();   // declaring and initialising a new polynomial
    ans.coeffs=llist_new();
    
   Polynomial temp;
     temp.exponents=llist_new();      // declaring and initialising a new polynomial
     temp.coeffs=llist_new();
    int i=0;
    int j;
    while( i<llist_size(p1.exponents))
    {  
                                             // multiplying each term of p1 to all terms of p2 and storing in temp
         while(j<llist_size(p2.exponents))
         { 
            int x = (llist_get(p1.exponents,i))+(llist_get(p2.exponents,j));        //adding exponents
            int y = (llist_get(p1.coeffs,i))*(llist_get(p2.coeffs,j));              //multiplying coefficients 
                 if(y!=0)
                 {
                    llist_append(temp.exponents,x);
                    llist_append(temp.coeffs,y);
                 }    
                    j++;         
          }
                     ans=add(ans,temp);                              // adding temp every time to ans
      i++;
      j=0; 
      temp.exponents=llist_new();               // freeing the temp variable every time 
      temp.coeffs=llist_new();   
    }
return ans;      // eturning the polynomial
}
long long int evaluate(Polynomial p, int k)         // evaluating the polynomial
{
   Node* x = (p.exponents)->head;
   Node* y = (p.coeffs)->head;

    long long int sum = 0;
     while((x != NULL) && (y != NULL))
     {
         sum = sum + (y->data)*pow(k,x->data);    // using power function
		 x = x->next;
		 y = y->next;
     }
   return sum;   // returning the value of polynomial  
}
