#include "List.h"
#include"Polynomial.h"
#include<stdlib.h>
#include<stdio.h>
int main(){
	int i,n,inp;
	scanf("%d",&i);
	while(i!=-1)
    {                  //  terminate if i is -1
		switch(i)
        {
			case 1:                                                        //printing the polynomial if i is 1 
            {
				Polynomial *p1 = (Polynomial*)malloc(sizeof(Polynomial));
    			p1->exponents = llist_new();
    			p1->coeffs = llist_new();
				scanf("%d",&n);
				for (int i = 0; i < n; ++i)
				{
					scanf("%d",&inp);                      // taking input of exponents and appending each time
					llist_append(p1->exponents,inp);
				}
				for (int i = 0; i < n; ++i)
				{
					scanf("%d",&inp);
					llist_append(p1->coeffs,inp);          // taking input of coefficients and appending each time
				}
				print_polynomial(*p1);
				break;

			}
			case 2:                // printing the degree if i is 2
            {
				Polynomial *p1 = (Polynomial*)malloc(sizeof(Polynomial));
    			p1->exponents = llist_new();
    			p1->coeffs = llist_new();
				scanf("%d",&n);
				for (int i = 0; i < n; ++i)
				{
					scanf("%d",&inp);
					llist_append(p1->exponents,inp);
				}
				for (int i = 0; i < n; ++i)
				{
					scanf("%d",&inp);
					llist_append(p1->coeffs,inp);
				}
				int deg=get_degree(*p1);
				printf("%d\n",deg);             // printing the degree
				break;
			}
			case 3:          // adding two polynomials if i is 3
            {
				Polynomial *p1 = (Polynomial*)malloc(sizeof(Polynomial));
    			p1->exponents = llist_new();
    			p1->coeffs = llist_new();
    			Polynomial *p2 = (Polynomial*)malloc(sizeof(Polynomial));
    			p2->exponents = llist_new();
    			p2->coeffs = llist_new();
				scanf("%d",&n);
				for (int i = 0; i < n; ++i)
				{
					scanf("%d",&inp);
					llist_append(p1->exponents,inp);
				}
				for (int i = 0; i < n; ++i)
				{
					scanf("%d",&inp);
					llist_append(p1->coeffs,inp);
				}
				scanf("%d",&n);
				for (int i = 0; i < n; ++i)
				{
					scanf("%d",&inp);
					llist_append(p2->exponents,inp);
				}
				for (int i = 0; i < n; ++i)
				{
					scanf("%d",&inp);
					llist_append(p2->coeffs,inp);
				}

				Polynomial pa = add(*p1,*p2);
				print_polynomial(pa);              // printing the polynomial
				break;

			}
			case 4:                 //  subracting the polynomials if i is 4
            {
				Polynomial *p1 = (Polynomial*)malloc(sizeof(Polynomial));
    			p1->exponents = llist_new();
    			p1->coeffs = llist_new();
    			Polynomial *p2 = (Polynomial*)malloc(sizeof(Polynomial));
    			p2->exponents = llist_new();
    			p2->coeffs = llist_new();
				scanf("%d",&n);
				for (int i = 0; i < n; ++i)
				{
					scanf("%d",&inp);
					llist_append(p1->exponents,inp);
				}
				for (int i = 0; i < n; ++i)
				{
					scanf("%d",&inp);
					llist_append(p1->coeffs,inp);
				}
				scanf("%d",&n);
				for (int i = 0; i < n; ++i)
				{
					scanf("%d",&inp);
					llist_append(p2->exponents,inp);
				}
				for (int i = 0; i < n; ++i)
				{
					scanf("%d",&inp);
					llist_append(p2->coeffs,inp);
				}
				Polynomial pb = subtract(*p1,*p2);
				print_polynomial(pb);           // printing the polynomial
				break;
			}
			case 5:                           //  multiplying the polynomials if i is 5
            {
				Polynomial *p1 = (Polynomial*)malloc(sizeof(Polynomial));
    			p1->exponents = llist_new();
    			p1->coeffs = llist_new();
    			Polynomial *p2 = (Polynomial*)malloc(sizeof(Polynomial));
    			p2->exponents = llist_new();
    			p2->coeffs = llist_new();
				scanf("%d",&n);
				for (int i = 0; i < n; ++i)
				{
					scanf("%d",&inp);
					llist_append(p1->exponents,inp);
				}
				for (int i = 0; i < n; ++i)
				{
					scanf("%d",&inp);
					llist_append(p1->coeffs,inp);
				}
				scanf("%d",&n);
				for (int i = 0; i < n; ++i)
				{
					scanf("%d",&inp);
					llist_append(p2->exponents,inp);
				}
				for (int i = 0; i < n; ++i)
				{
					scanf("%d",&inp);
					llist_append(p2->coeffs,inp);
				}
				Polynomial pm = multiply(*p1,*p2);
				print_polynomial(pm);                          // printing the polynomial
				break;
			}
			case 6:                  // finding the value of polynomial if i is 6
            {
				Polynomial *p1 = (Polynomial*)malloc(sizeof(Polynomial));
    			p1->exponents = llist_new();
    			p1->coeffs = llist_new();
    			Polynomial *p2 = (Polynomial*)malloc(sizeof(Polynomial));
    			p2->exponents = llist_new();
    			p2->coeffs = llist_new();
				scanf("%d",&n);
				for (int i = 0; i < n; ++i)
				{
					scanf("%d",&inp);
					llist_append(p1->exponents,inp);
				}
				for (int i = 0; i < n; ++i)
				{
					scanf("%d",&inp);
					llist_append(p1->coeffs,inp);
				}
				scanf("%d",&n);                      // taking input of variable
				
				long long int val= evaluate(*p1, n);
				printf("%lld\n",val);               // printing the value of polynomial
				break;
			}
		}
		scanf("%d",&i);                 // taking input until user enters -1            
	}
}
