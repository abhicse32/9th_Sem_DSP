#include <stdio.h>
#include "Polynomial.h"
#include "List.h"

int main() 
{
	int option;
	scanf("%d", &option);
	while (option != -1) 
	{
		Polynomial pol1;
		pol1.exponents = llist_new();
		pol1.coeffs = llist_new();
		int sz1;
		scanf("%d", &sz1);
		int i, data;
		for (i = 0; i < sz1; i++) 
		{
			scanf("%d",&data);
			llist_append(pol1.exponents,data);
		}
		for (i = 0; i < sz1; i++) 
		{
			scanf("%d", &data);
			llist_append(pol1.coeffs,data);
		}
		if (option == 1) 
		{
			print_polynomial(pol1);
		} 
		else if (option == 2) 
		{
			int deg = get_degree(pol1);
			printf("%d\n", deg);
		} 
		else if (option == 3 || option == 4 || option == 5) 
		{
			Polynomial pol2;
			pol2.exponents = llist_new();
			pol2.coeffs = llist_new();
			int sz2;
			scanf("%d", &sz2);
			int j, dat;
			for (j = 0; j < sz2; j++) 
			{
				scanf("%d", &dat);
				llist_append(pol2.exponents, dat);
			}
			for (j = 0; j < sz2; j++) 
			{
				scanf("%d", &dat);
				llist_append(pol2.coeffs, dat);
			}
			Polynomial pol;
			if (option == 3) 
			{
				pol = add(pol1, pol2);
				print_polynomial(pol);
			} 
			else if (option == 4) 
			{
				pol = subtract(pol1, pol2);
				print_polynomial(pol);
			} 
			else if (option == 5) 
			{
				pol = multiply(pol1, pol2);
				print_polynomial(pol);
			}
		} 
		else if (option == 6) 
		{
			int k;
			scanf("%d", &k);
			long long res = evaluate(pol1, k);
			printf("%lld\n", res);
		}
		scanf("%d", &option);
	}
	return 0;
}

