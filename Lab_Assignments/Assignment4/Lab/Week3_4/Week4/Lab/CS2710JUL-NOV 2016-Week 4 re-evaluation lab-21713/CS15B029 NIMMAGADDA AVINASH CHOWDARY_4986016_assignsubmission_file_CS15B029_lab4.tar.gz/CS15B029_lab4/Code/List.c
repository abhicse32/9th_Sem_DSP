#include<stdio.h>
#include<stdlib.h>
#include "List.h"
#include<limits.h>

  // Create a new node with next set to NULL
Node* node_new( int data)
      {
       Node * address=(Node *)malloc(sizeof(Node)*1);
       address->data=data;
       address->next=NULL;
       return address;
      } 

  // Create an empty list (head shall be NULL)
  
 LList* llist_new()
{
  LList* node=(LList *)malloc(sizeof(LList));
  node->head = NULL;
  return node;
}

 // Traverse the linked list and return its size
 
 int llist_size( LList* lst )
      {Node * p;
       if(lst->head==NULL)
         {return 0;}
       else
         {
          p=lst->head;
         }
       
       int s=1;   
          while(p->next!=NULL)
            {
             s++;
             p=p->next;
            }
          
        return s;      
       }

 // Traverse the linked list and print each element
 
void llist_print( LList* lst )
{
    Node* temp=(Node *)malloc(sizeof (Node));
    temp = (lst->head);
   while(temp!=NULL)
   {
      printf("%d ",temp->data);
      temp = temp->next;
   }
  printf("\n");
}

 //get the element at position @idx
 
 int llist_get( LList* lst, int idx )
      {Node * p;
       p=lst->head;
       int i;
       for(i=0;p!=NULL && i<idx;)
        {
         p=p->next;
         i++;
        }
       if(p==NULL)
         return INT_MIN;
       else
         return p->data;
      }
      
   // Add a new element at the end of the list

 void llist_append( LList* lst, int data ){
        Node*new=node_new(data);     
        Node* p;
        p=lst->head;
        if(lst->head==NULL){
                lst->head=new;
                new->next=NULL;
                return;
        }
        while(p->next!=NULL){
                p=p->next;
        }
        p->next=new;
        new->next=NULL;
        return;
}

 // Add a new element at the beginning of the list
 
 void llist_prepend( LList* lst, int data ){
        Node* new = (Node*) malloc(sizeof(Node));
        new->data=data;
        new->next=lst->head;
        lst->head=new;              
}
       
 // Add a new element at the @idx index
 
 void llist_insert( LList* lst, int idx, int data )
{
  if(idx == 0)
  {
    llist_prepend(lst,data);
  }
  else
  {
    Node* temp=(Node *)malloc(sizeof (Node));
    temp = (lst->head);
    int i = 0;
    while((i < idx-1)&&(temp->next)!=NULL)
    {
      temp = temp->next;
      i++;
    }
    Node *new = node_new(data);
    new->next = temp->next;
    temp->next = new;
  }
}
      
     
             
  // Remove an element from the end of the list 

 void llist_remove_last( LList* lst )
      {Node * p=lst->head;
       if(lst->head!=NULL)
         {if(p->next==NULL)
            lst->head=NULL;
          else
          {
          while((p->next)->next!=NULL)
               p=p->next;

          p->next=NULL;
          }
         }
       }

 // Remove an element from the beginning of the list
 
void llist_remove_first( LList* lst )
{
   lst->head = (lst->head)->next;
}

  // Remove an element from an arbitrary @idx position in the list
  
void llist_remove( LList* lst, int idx )
{
 if(idx==0)
 {
   llist_remove_first(lst);
 }
   else
   {
    int i=0;
    Node* ptr=(Node *)malloc(sizeof (Node));
    ptr = (lst->head);
    while((i < (idx-1))&&(ptr->next != NULL))
    {
      ptr = ptr->next;
      i++;
    }
        (ptr->next) = ((ptr->next)->next);
   }
}

              

       
       
      
               
               
              
               
             


       
