#include<stdio.h>
#include<stdlib.h>
#include <math.h>
#include "Polynomial.h"

int get_degree(Polynomial pol)
{
   Node* temp=(Node *)malloc(sizeof (Node));
   temp=(pol.exponents)->head;
   int i;
   for(i=0;temp->next!=NULL;i++)
   {
      temp=temp->next;
   }
   return temp->data;
}

void print_polynomial(Polynomial temp)
{
    int size = llist_size(temp.exponents);
    int a=llist_get(temp.exponents,0);
    int b=llist_get(temp.coeffs,0);
    int j=0;
    if(a==0)
    {
        printf("%d ",b);
        j++;
    }
        
    int i;
    for(i=j;i<size;i++){
        int g=llist_get(temp.coeffs,i);
        int h=llist_get(temp.exponents,i);
        if((g>0)&&(i!=0)) printf("+ %dx^%d ",g,h);
        if((g<0)&&(i!=0)) printf("- %dx^%d ",-g,h);
        if((g!=0)&&(i==0)) printf("%dx^%d ",g,h);        
    }

    printf("\n");
}

 Polynomial add(Polynomial temp1, Polynomial temp2) {
	Polynomial *temp = (Polynomial*) malloc(sizeof(Polynomial));
	temp->exponents = llist_new();
	temp->coeffs = llist_new();
	Node *exp1 = (temp1.exponents)->head;
	Node *coef1 = (temp1.coeffs)->head;
	Node *exp2 = (temp2.exponents)->head;
	Node *coef2 = (temp2.coeffs)->head;
	while (coef1 != NULL && coef2 != NULL) {
		if (exp1->data == exp2->data) {
			llist_append(temp->coeffs, coef1->data + coef2->data);
			llist_append(temp->exponents, exp1->data);
			exp1 = exp1->next;
			coef1 = coef1->next;
			exp2 = exp2->next;
			coef2 = coef2->next;
		} else if (exp1->data < exp2->data) {
			llist_append(temp->coeffs, coef1->data);
			llist_append(temp->exponents, exp1->data);
			exp1 = exp1->next;
			coef1 = coef1->next;
		} else {
			llist_append(temp->coeffs, coef2->data);
			llist_append(temp->exponents, exp2->data);
			exp2 = exp2->next;
			coef2 = coef2->next;
		}
	}
	if (coef1 == NULL) {
		while (coef2 != NULL) {
			llist_append(temp->coeffs, coef2->data);
			llist_append(temp->exponents, exp2->data);
			exp2 = exp2->next;
			coef2 = coef2->next;
		}
	} else {
		while (coef1 != NULL) {
			llist_append(temp->coeffs, coef1->data);
			llist_append(temp->exponents, exp1->data);
			exp1 = exp1->next;
			coef1 = coef1->next;
		}
	}
	return *temp;
}

Polynomial subtract(Polynomial temp1, Polynomial temp2) {
	Polynomial *temp = (Polynomial*) malloc(sizeof(Polynomial));
	temp->exponents = llist_new();
	temp->coeffs = llist_new();
	Node *exp1 = (temp1.exponents)->head;
	Node *coef1 = (temp1.coeffs)->head;
	Node *exp2 = (temp2.exponents)->head;
	Node *coef2 = (temp2.coeffs)->head;
	while (coef1 != NULL && coef2 != NULL) {
		if (exp1->data == exp2->data) {
			llist_append(temp->coeffs, coef1->data - coef2->data);
			llist_append(temp->exponents, exp1->data);
			exp1 = exp1->next;
			coef1 = coef1->next;
			exp2 = exp2->next;
			coef2 = coef2->next;
		} else if (exp1->data < exp2->data) {
			llist_append(temp->coeffs, coef1->data);
			llist_append(temp->exponents, exp1->data);
			exp1 = exp1->next;
			coef1 = coef1->next;
		} else {
			llist_append(temp->coeffs, -1 * coef2->data);
			llist_append(temp->exponents, exp2->data);
			exp2 = exp2->next;
			coef2 = coef2->next;
		}
	}
	if (coef1 == NULL) {
		while (coef2 != NULL) {
			llist_append(temp->coeffs, -1 * coef2->data);
			llist_append(temp->exponents, exp2->data);
			exp2 = exp2->next;
			coef2 = coef2->next;
		}
	} else {
		while (coef1 != NULL) {
			llist_append(temp->coeffs, coef1->data);
			llist_append(temp->exponents, exp1->data);
			exp1 = exp1->next;
			coef1 = coef1->next;
		}
	}
	return *temp;
}

Polynomial multiply(Polynomial p1, Polynomial p2)   
{
    Polynomial f;   
    Polynomial g;   

    f.exponents = llist_new();  
    g.exponents = llist_new();  

    f.coeffs = llist_new();     
    g.coeffs = llist_new();     

    int n = llist_size(p1.exponents);   
    int m = llist_size(p2.exponents);   

    int i;  
    int j;  

    for(i=0;i<n;i++)   
        {
            for(j=0;j<m;j++)
                {
                    int expo = (llist_get(p1.exponents,i))+(llist_get(p2.exponents,j));
                    int coeff = (llist_get(p1.coeffs,i))*(llist_get(p2.coeffs,j));
                    if(coeff==0);
                    else
                        {
                            llist_append(f.exponents, expo);
                            llist_append(f.coeffs,coeff);
                        }
                }
            g = add(f,g);
            f.exponents = llist_new();  
            f.coeffs = llist_new();     
        }
    return g;
}
    
long long evaluate(Polynomial p, int k) {

  int size=llist_size(p.exponents);
  int i;
  long long result=0;
  int cof,pow;
  long long exp;
  Node *tc=p.coeffs->head;
  Node *te=p.exponents->head;
  for(i=0;i<size;i++){
   exp=1;
   cof=tc->data;
   pow=te->data;
   tc=tc->next;
   te=te->next;
   int j;
   for(j=0;j<pow;j++){
         exp=exp*k;
      }
    result=result+exp*cof;
    }
   return result;
 }
  
      
  
       

