#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "Polynomial.h"

void print_polynomial(Polynomial ply) {
	int i;
	int size = llist_size(ply.exponents);
	Node *et = (ply.exponents)->head;
	Node *ct = (ply.coeffs)->head;
	for (i = 0; i < size; i++) {
		int exp = et->data;
		int cof = ct->data;
		if (cof == 0) {
		    et = et->next;
		    ct = ct->next;
			continue;
		}
		if (cof > 0) {
			if (i == 0) {
				if (exp != 0) {
					printf("%dx^%d ", cof, exp);
				} else if (exp == 0) {
					printf("%d ", cof);
				}
			} else {
				if (exp != 0) {
					printf("+ %dx^%d ", cof, exp);
				} else if (exp == 0) {
					printf("+ %d ", cof);
				}
			}
		} else {
			if (i == 0) {
				if (exp != 0) {
					printf("-%dx^%d ", -cof, exp);
				} else if (exp == 0) {
					printf("-%d ", -cof);
				}
			} else {
				if (exp != 0) {
					printf("- %dx^%d ", -cof, exp);
				} else if (exp == 0) {
					printf("- %d ", -cof);
				}
			}
		}
		et = et->next;
		ct = ct->next;
	}

	printf("\n");
}

int get_degree(Polynomial ply) {
	int size = llist_size(ply.exponents);
	int deg = llist_get(ply.exponents, size - 1);
	return deg;
}

Polynomial add(Polynomial ply1, Polynomial ply2) {
	Polynomial *ply = (Polynomial*) malloc(sizeof(Polynomial));
	ply->exponents = llist_new();
	ply->coeffs = llist_new();
	Node *et1 = (ply1.exponents)->head;
	Node *ct1 = (ply1.coeffs)->head;
	Node *et2 = (ply2.exponents)->head;
	Node *ct2 = (ply2.coeffs)->head;
	while (ct1 != NULL && ct2 != NULL) {
		if (et1->data == et2->data) {
			llist_append(ply->coeffs, ct1->data + ct2->data);
			llist_append(ply->exponents, et1->data);
			et1 = et1->next;
			ct1 = ct1->next;
			et2 = et2->next;
			ct2 = ct2->next;
		} else if (et1->data < et2->data) {
			llist_append(ply->coeffs, ct1->data);
			llist_append(ply->exponents, et1->data);
			et1 = et1->next;
			ct1 = ct1->next;
		} else {
			llist_append(ply->coeffs, ct2->data);
			llist_append(ply->exponents, et2->data);
			et2 = et2->next;
			ct2 = ct2->next;
		}
	}
	if (ct1 == NULL) {
		while (ct2 != NULL) {
			llist_append(ply->coeffs, ct2->data);
			llist_append(ply->exponents, et2->data);
			et2 = et2->next;
			ct2 = ct2->next;
		}
	} else {
		while (ct1 != NULL) {
			llist_append(ply->coeffs, ct1->data);
			llist_append(ply->exponents, et1->data);
			et1 = et1->next;
			ct1 = ct1->next;
		}
	}
	return *ply;
}

Polynomial subtract(Polynomial ply1, Polynomial ply2) {
	Polynomial *ply = (Polynomial*) malloc(sizeof(Polynomial));
	ply->exponents = llist_new();
	ply->coeffs = llist_new();
	Node *et1 = (ply1.exponents)->head;
	Node *ct1 = (ply1.coeffs)->head;
	Node *et2 = (ply2.exponents)->head;
	Node *ct2 = (ply2.coeffs)->head;
	while (ct1 != NULL && ct2 != NULL) {
		if (et1->data == et2->data) {
			llist_append(ply->coeffs, ct1->data - ct2->data);
			llist_append(ply->exponents, et1->data);
			et1 = et1->next;
			ct1 = ct1->next;
			et2 = et2->next;
			ct2 = ct2->next;
		} else if (et1->data < et2->data) {
			llist_append(ply->coeffs, ct1->data);
			llist_append(ply->exponents, et1->data);
			et1 = et1->next;
			ct1 = ct1->next;
		} else {
			llist_append(ply->coeffs, -1 * ct2->data);
			llist_append(ply->exponents, et2->data);
			et2 = et2->next;
			ct2 = ct2->next;
		}
	}
	if (ct1 == NULL) {
		while (ct2 != NULL) {
			llist_append(ply->coeffs, -1 * ct2->data);
			llist_append(ply->exponents, et2->data);
			et2 = et2->next;
			ct2 = ct2->next;
		}
	} else {
		while (ct1 != NULL) {
			llist_append(ply->coeffs, ct1->data);
			llist_append(ply->exponents, et1->data);
			et1 = et1->next;
			ct1 = ct1->next;
		}
	}
	return *ply;
}

Polynomial multiply(Polynomial ply1, Polynomial ply2) {
	Polynomial *ply = (Polynomial*) malloc(sizeof(Polynomial));
	ply->exponents = llist_new();
	ply->coeffs = llist_new();
	int i, j, sz = 0;
	int sz1 = llist_size(ply1.exponents);
	int sz2 = llist_size(ply2.exponents);
	if (sz1 == 0 || sz2 == 0) {
		return *ply;
	}

	Node *et1 = (ply1.exponents)->head;
	Node *ct1 = (ply1.coeffs)->head;
	Node *et2 = (ply2.exponents)->head;
	Node *ct2 = (ply2.coeffs)->head;

	for (j = 0; j < sz2; j++) {
		llist_append(ply->coeffs, ct1->data * ct2->data);
		llist_append(ply->exponents, et1->data + et2->data);
		et2 = et2->next;
		ct2 = ct2->next;
	}
	et2 = (ply2.exponents)->head;
	ct2 = (ply2.coeffs)->head;
	et1 = et1->next;
	ct1 = ct1->next;
	for (i = 1; i < sz1; i++) {
		Polynomial plyt;
		plyt.exponents = llist_new();
		plyt.coeffs = llist_new();
		for (j = 0; j < sz2; j++) {
			llist_append(plyt.coeffs, ct1->data * ct2->data);
			llist_append(plyt.exponents, et1->data + et2->data);
			et2 = et2->next;
			ct2 = ct2->next;
		}
		*ply = add(*ply, plyt);
		et2 = (ply2.exponents)->head;
		ct2 = (ply2.coeffs)->head;
		et1 = et1->next;
		ct1 = ct1->next;
		sz = 0;
	}
	return *ply;
}

long long evaluate(Polynomial ply, int k) {
	int i, j, pow;
	long long mul = 1;
	int size = llist_size(ply.exponents);
	if (size == 0) {
		return 0;
	} else if (size == 1) {
		pow = llist_get(ply.exponents, 0);
		for (j = 0; j < pow; j++) {
			mul = mul * k;
		}
		return (llist_get(ply.coeffs, 0) * mul);
	}
	pow = llist_get(ply.exponents, size - 1)
			- llist_get(ply.exponents, size - 2);
	for (j = 0; j < pow; j++) {
		mul = mul * k;
	}
	long long res = llist_get(ply.coeffs, size - 1) * mul
			+ llist_get(ply.coeffs, size - 2);
	i = size - 3;
	while (i >= 0) {
		mul = 1;
		pow = llist_get(ply.exponents, i + 1) - llist_get(ply.exponents, i);
		for (j = 0; j < pow; j++) {
			mul = mul * k;
		}
		res = res * mul + llist_get(ply.coeffs, i);
		i--;
	}
	mul = 1;
	pow = llist_get(ply.exponents, 0);
	for (j = 0; j < pow; j++) {
		mul = mul * k;
	}
	res = res * mul;
	return res;
}
