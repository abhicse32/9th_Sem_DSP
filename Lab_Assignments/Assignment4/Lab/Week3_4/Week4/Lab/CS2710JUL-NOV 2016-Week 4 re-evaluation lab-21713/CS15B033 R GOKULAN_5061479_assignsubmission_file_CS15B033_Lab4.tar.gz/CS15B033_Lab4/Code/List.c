#include "List.h"
#define INT_MIN -2147483648
#include<stdio.h>
#include<stdlib.h>

Node* node_new( int data)
{
	Node *a = malloc( sizeof(Node));;
	a->data = data;
	a->next = NULL;
	return a;
}

LList* llist_new()
{
	LList *a = malloc( sizeof(LList));
	a->head = NULL;
	return a;
}

int llist_size( LList* lst )
{
	int count=0;
	if( lst-> head == NULL)
		count = 0;
	else
	{
		Node *cur = lst -> head;
		while( cur != NULL)
		{
			count++;
			cur = cur -> next;
		}
	}
	return count;
}

void llist_print( LList* lst )
{
	Node *head = lst->head;
	while( head != NULL)
	{
		printf("%d ", head->data);
		head = head-> next;
	}
	printf("\n");
}

int llist_get( LList* lst, int idx )
{
	int i = 0;
	Node *a = lst->head;
	while( a!= NULL)
	{
		if( i == idx)
			return a->data;
		i++;
		a = a-> next;
	}
	return INT_MIN;	
}

void llist_append( LList* lst, int data )
{
	Node *b = (Node*) malloc(sizeof(Node));
	Node *a = lst->head;
	if( lst->head == NULL )
	{
		b->data = data;
		b->next = NULL;
		lst->head = b;
	}
	else
	{
		while( a != NULL)
		{
			if( a-> next == NULL )
			{
				Node *b  = (Node*) malloc( sizeof(Node));
				b-> data = data;
				b-> next = NULL;
				a-> next = b;
				break;
			}
			a = a-> next;
		}
	}
}

void llist_prepend( LList* lst, int data )
{
	
	Node *a = (Node*) malloc( sizeof(Node));
	a-> data = data;
	a-> next = lst -> head;
	lst -> head = a;
}

void llist_insert( LList* lst, int idx, int data )
{
	if(idx == 0)
		llist_prepend(lst, data);
	else if( idx == llist_size(lst))
		llist_append(lst, data);
	else
	{
	int i;
	Node *x = lst->head;
	for(i=0; i < idx; i++)
	{
		if( i == idx-1)
		{
			Node *a = (Node*) malloc( sizeof(Node));
			a->data = data;
			a->next = x->next;
			x->next = a;
		}
		x = x->next;
	}
	}	
		
}

void llist_remove_last( LList* lst )
{
	Node *a = lst->head;
	if( a == NULL)
		printf("Underflow");
	else if( a->next == NULL)
	{
		free( a);
		lst->head = NULL;
	}
	else
	{
		while( a!= NULL )
		{
			if( (a->next) ->next == NULL)
			{
				Node *temp = a->next;
				a->next = NULL;
				free(temp);
			}
			a = a->next;
		}
		
	}
}

void llist_remove_first( LList* lst )
{
	Node *a = lst->head;
	if( a == NULL)
		printf("Underflow");
	else
	{
		lst -> head = a-> next;
		free(a);
	}
}

void llist_remove( LList* lst, int idx )
{
	if(idx == 0)
		llist_remove_first(lst);
	else if( idx == llist_size(lst))
		llist_remove_last(lst);
	else
	{
	int i;
	Node *x = lst->head;
	for(i=0; i < idx; i++)
	{
		if( i == idx-1)
		{
			Node *a = x->next;
			x->next = a->next;
			free(a);
			break;
		}
		x = x->next;
	}
	}
}
