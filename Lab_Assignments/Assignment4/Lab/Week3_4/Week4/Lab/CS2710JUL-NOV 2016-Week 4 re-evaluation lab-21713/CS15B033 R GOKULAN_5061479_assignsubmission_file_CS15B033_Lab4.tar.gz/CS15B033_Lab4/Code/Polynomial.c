#include "Polynomial.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

int ab(int a)
{
	if(a<0)
		a=a*-1;
	return a;
}
//Formatting Printing
double power(int k, int n)
{
	if(n == 0)
		return 1;
	else
		return k*power(k,n-1);
}//math.h was a not working. Used this instead.

int get_degree(Polynomial Poly1)
{
	LList *exponents, *coeffs;
	
	exponents = Poly1.exponents;
	coeffs = Poly1.coeffs;

	Node *temp = exponents->head;
	Node *cotemp = coeffs->head;

	int i;
	int max = temp->data;
	temp = temp-> next;
	cotemp = cotemp->next;

	for(i=1; i< llist_size(exponents); i++)
	{
		int coeff = cotemp->data;
		if(temp->data > max && coeff != 0)//Finding max exponent and
		{								//ensuring its coefficient is non-zero.
			max = temp->data;
		}
		temp = temp->next;
	}
	return max;
}

// print Polynomial
void print_polynomial(Polynomial Poly1)
{
	LList *exponents, *coeffs;
	
	exponents = Poly1.exponents;
	coeffs = Poly1.coeffs;

	Node *temp = exponents->head;
	Node *cotemp = coeffs->head;

	while( temp!= NULL)
	{
		char c = '+';
		if(temp->next == NULL)//last element
			c = ' ';
		else if( cotemp->next->data < 0)//if next element is negative
			c = '-';
		if(temp->data==0)//For printing first element
			printf("%d %c ", cotemp->data, c);
		else if( temp->data == exponents->head->data)
			printf("%dx^%d %c ", cotemp->data,temp->data, c);
		else
			printf("%dx^%d %c ", ab(cotemp->data), temp->data, c );
		temp = temp->next;
		cotemp = cotemp->next;
	}
	printf("\n");
}

/*Multiply two polynomials and return the result*/
Polynomial multiply(Polynomial Poly1, Polynomial Poly2)
{
	int max1 = get_degree(Poly1);
	int max2 = get_degree(Poly2);
	int max = max1 + max2;
	
	Polynomial Poly;

	LList *exp = llist_new();
	LList *coeff = llist_new();

	int i,j,k;
	for(k=0; k<= max; k++)
	{
		Node *a1 = Poly1.exponents->head;
		Node *b1 = Poly1.coeffs->head;

		int val = 0;
		for(i=0; i< llist_size((Poly1.exponents)) ; i++)
		{
			Node *a2 = Poly2.exponents->head;
			Node *b2 = Poly2.coeffs->head;

			for(j=0; j< llist_size(Poly2.exponents); j++)
			{
				if( a1->data + a2->data == k)
				{
					val += b1->data * b2->data;//add to val only if sum of powers is k.
				}
				a2 = a2->next;
				b2 = b2->next;
			}
			a1 = a1->next;
			b1 = b1->next;
		}
		if(val != 0)//append only if coeff is non-zero
		{
			llist_append( exp, k);
			llist_append( coeff, val);
		}
	}
	Poly.exponents = exp;
	Poly.coeffs = coeff;
	return Poly;
}

/*Add two polynomials and return the result*/
Polynomial add(Polynomial Poly1, Polynomial Poly2)
{
	Polynomial Poly;

	LList *exponents1, *coeffs1;
	LList *exponents2, *coeffs2;
	LList *exponents3, *coeffs3;
	
	exponents1 = Poly1.exponents;
	coeffs1 = Poly1.coeffs;

	exponents2 = Poly2.exponents;
	coeffs2 = Poly2.coeffs;

	exponents3 = llist_new();
	coeffs3 = llist_new();

	Node *temp1 = exponents1->head;
	Node *cotemp1 = coeffs1->head;

	Node *temp2 = exponents2->head;
	Node *cotemp2 = coeffs2->head;

	int max = ( get_degree(Poly1), get_degree(Poly2));
	int i=0;
	while( i<=max  && temp1!= NULL && temp2 != NULL)
	{
		if(temp1->data == temp2->data) 
		{
			int sum = cotemp1->data + cotemp2->data;
			if( sum != 0)//add only if sum is non-zero.
			{
			llist_append( exponents3, temp1->data );
			llist_append( coeffs3, sum);
			}
			temp1 = temp1-> next;
			cotemp1 = cotemp1->next;
			temp2 = temp2->next;
			cotemp2 = cotemp2->next;
		}
		else if( temp1->data < temp2->data)
		{
			llist_insert( exponents3, i, temp1->data);
			llist_insert( coeffs3, i, cotemp1->data);
			
			temp1 = temp1->next;
			cotemp1 = cotemp1->next;
		}
		else
		{
			llist_insert( exponents3, i, temp2->data);
			llist_insert( coeffs3, i, cotemp2->data);
			
			cotemp2 = cotemp2->next;
			temp2 = temp2->next;
		}
		i++;
	}
	while( temp1 != NULL)
	{	
		llist_append( exponents3, temp1->data);
		llist_append( coeffs3, cotemp1->data);
			
		temp1 = temp1->next;
		cotemp1 = cotemp1->next;
	}
	while ( temp2 != NULL)
	{
		llist_append( exponents3, temp2->data);
		llist_append( coeffs3, cotemp2->data);
			
		cotemp2 = cotemp2->next;
		temp2 = temp2->next;
	}
	Poly.exponents = exponents3;
	Poly.coeffs = coeffs3;
	return Poly;
}

/*Subtract second Polynomial from first*/
Polynomial subtract(Polynomial Poly1, Polynomial Poly2)
{
	Polynomial Poly;

	LList *exponents1, *coeffs1;
	LList *exponents2, *coeffs2;
	LList *exponents3, *coeffs3;
	
	exponents1 = Poly1.exponents;
	coeffs1 = Poly1.coeffs;

	exponents2 = Poly2.exponents;
	coeffs2 = Poly2.coeffs;

	exponents3 = llist_new();
	coeffs3 = llist_new();

	Node *temp1 = exponents1->head;
	Node *cotemp1 = coeffs1->head;

	Node *temp2 = exponents2->head;
	Node *cotemp2 = coeffs2->head;

	int max = ( get_degree(Poly1), get_degree(Poly2));
	int i=0;
	while( i<= max && temp1!= NULL && temp2 != NULL)
	{
		if(temp1->data == temp2->data)
		{
			int dif = cotemp1->data - cotemp2->data;
			if(dif != 0)//adding only if difference is non-zero
			{
			llist_append( exponents3, temp1->data );
			llist_append( coeffs3, dif);
			}
			temp1 = temp1-> next;
			cotemp1 = cotemp1->next;
			temp2 = temp2->next;
			cotemp2 = cotemp2->next;
		}
		else if( temp1->data < temp2->data)
		{
			llist_insert( exponents3, i, temp1->data);
			llist_insert( coeffs3, i, cotemp1->data);
			
			temp1 = temp1->next;
			cotemp1 = cotemp1->next;
		}
		else
		{
			llist_insert( exponents3, i, temp2->data);
			llist_insert( coeffs3, i, -cotemp2->data);//Negative because -Poly2 is added.
			
			cotemp2 = cotemp2->next;
			temp2 = temp2->next;
		}
		i++;
	}
	while( temp1 != NULL)
	{			
		llist_append( exponents3, temp1->data);
		llist_append( coeffs3, cotemp1->data);
			
		temp1 = temp1->next;
		cotemp1 = cotemp1->next;
		i++;
	}
	while ( temp2 != NULL)
	{		
		llist_append( exponents3, temp2->data);
		llist_append( coeffs3, -cotemp2->data);//Negative
			
		cotemp2 = cotemp2->next;
		temp2 = temp2->next;
		i++;
	}
	Poly.exponents = exponents3;
	Poly.coeffs = coeffs3;
	return Poly;
}

/*Evaluate Polynomial at var=k and return the result*/
long long evaluate(Polynomial Poly, int k)
{
	LList *exponents, *coeffs;
		
	exponents = Poly.exponents;
	coeffs = Poly.coeffs;

	Node *temp = exponents->head;
	Node *cotemp = coeffs->head;

	long long result = 0;
	while( temp!= NULL)
	{
		result += cotemp->data * power(k, temp->data);
		temp = temp->next;
		cotemp = cotemp -> next;
	}
	return result;
}
