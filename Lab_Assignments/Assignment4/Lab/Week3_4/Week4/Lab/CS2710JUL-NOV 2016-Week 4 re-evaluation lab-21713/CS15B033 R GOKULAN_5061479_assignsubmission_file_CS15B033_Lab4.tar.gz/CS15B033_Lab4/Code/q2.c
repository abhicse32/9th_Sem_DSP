#include "List.h"
#include <stdio.h>
#include "Polynomial.h"

void get_input(Polynomial *Poly)//Function which stores polynomial from input.
{
	int t;
	scanf("%d", &t);
	int i;
	for(i=0; i<t; i++)
	{
		int c;
		scanf("%d", &c);
		llist_append(Poly->exponents, c);

	}
	for(i=0; i<t; i++)
	{
		int c;
		scanf("%d", &c);
		llist_append(Poly->coeffs, c);
	}
}
int main()
{
	int choice;
	do
	{
	scanf("%d", &choice);

	Polynomial p1, p2, p3;// Variables for input and output.
	p1.exponents = llist_new();//Initialization
	p1.coeffs = llist_new();
	p2.exponents = llist_new();
	p2.coeffs = llist_new();
	p3.exponents = llist_new();
	p3.coeffs = llist_new();
	
	switch(choice)
	{
		case 1:	get_input(&p1);
				print_polynomial(p1);
				break;

		case 2: get_input(&p1);
				int degree = get_degree(p1);
				printf("%d\n", degree);
				break;

		case 3: get_input(&p1);
				get_input(&p2);
				p3 = add( p1, p2);
				print_polynomial(p3);
				break;

		case 4:	get_input(&p1);
				get_input(&p2);
				p3 = subtract( p1, p2);
				print_polynomial(p3);
				break;

		case 5: get_input(&p1);
				get_input(&p2);
				p3 = multiply( p1, p2);
				print_polynomial(p3);
				break;

		case 6: get_input(&p1);
				int k;
				scanf("%d", &k);
				long long ans = evaluate(p1, k);
				printf("%lld\n", ans);
				break;
	}
	}while(choice != -1);//Loop runs till choice becomes -1.
	return 0;
}
