//Polynomial.c by Raghavan S CS15B034 Lab Assignment 4
#include "Polynomial.h"
#include<stdio.h>
#include<stdlib.h>
/*function to return the degree of the polynomial*/
int get_degree(Polynomial p)
{
if(p.exponents->head==NULL)
	return -1;
int r=llist_get(p.exponents,llist_size(p.exponents)-1);
return r;
}

// print Polynomial
void print_polynomial(Polynomial p)
{
int m0,n0;
if(p.exponents->head==NULL)
{
	printf("%d",0);
	return;
}
Node *n;
Node *m;
n=p.exponents->head;
m=p.coeffs->head;
m0=m->data;
n0=n->data;
if(n0==0)
	printf("%d ",m0);
else
	printf("%dx^%d ",m0,n0);
m=m->next;
n=n->next;
while(n!=NULL)
{
	m0=m->data;
	n0=n->data;
	if(m0>0)
	printf("+ %dx^%d ",m0,n0);
	else
	printf("- %dx^%d ",-1*m0,n0);
	m=m->next;
	n=n->next;
}
printf("\n");
// printf("yes\n");
return;
}

/*Multiply two polynomials and return the result*/
Polynomial multiply(Polynomial p, Polynomial q)
{
Polynomial r;
r.exponents=llist_new();
r.coeffs=llist_new();
int i=0,j=0,k;
int ae,be,ac,bc,cc,ce;
int s1=llist_size(p.exponents),s2=llist_size(q.exponents);
int t1,t2,fl;
  while(i<s1)
  {
	j=0;
	ae=llist_get(p.exponents,i);
	ac=llist_get(p.coeffs,i);
	while(j<s2)
	{
		be=llist_get(q.exponents,j);
		bc=llist_get(q.coeffs,j);
		ce=ae+be;
		cc=ac*bc;
		if(r.exponents->head==NULL)
		{
			llist_append(r.exponents,ce);
			llist_append(r.coeffs,cc);
		}
		else
		{
			fl=0;
			for(k=0;k<llist_size(r.exponents);k++)
			{
				t1=llist_get(r.exponents,k);
				t2=llist_get(r.coeffs,k);
				if(t1==ce)
				{
					if(t2+cc!=0)
					{
						llist_remove(r.exponents,k);
						llist_remove(r.coeffs,k);
						llist_insert(r.exponents,k,ce);
						llist_insert(r.coeffs,k,cc+t2);
					}
					else
					{
						llist_remove(r.exponents,k);
						llist_remove(r.coeffs,k);
					}
					fl=1;
					break;
				}
				else if(t1>ce)
				{
					llist_insert(r.exponents,k,ce);
					llist_insert(r.coeffs,k,cc);
					fl=1;
					break;
				}
			}
			if(fl==0)
			{
				llist_insert(r.exponents,k,ce);
				llist_insert(r.coeffs,k,cc);
			}

		}
		j++;

	}
	i++;
	}
return r;
}

/*Add two polynomials and return the result*/
Polynomial add(Polynomial p, Polynomial q)
{
Polynomial r;
//printf("a");
r.exponents=llist_new();
r.coeffs=llist_new();
int i=0,j=0,k=0;
int ae,be,ac,bc,cb,cc;
int t1,fl;
int s1=llist_size(p.exponents),s2=llist_size(q.exponents);
  while(i<s1&&j<s2)
  {
	ae=llist_get(p.exponents,i);
	ac=llist_get(p.coeffs,i);
	be=llist_get(q.exponents,j);
	bc=llist_get(q.coeffs,j);
	//printf("d");
	if(ae<be)
	{
		llist_insert(r.exponents,k,ae);
		llist_insert(r.coeffs,k,ac);
		i++;
		k++;
	}
	else if(ae>be)
	{
		llist_insert(r.exponents,k,be);
		llist_insert(r.coeffs,k,bc);
		j++;
		k++;
	}
	else
	{
		if(ac+bc!=0)
		{
			llist_insert(r.exponents,k,ae);
			llist_insert(r.coeffs,k,ac+bc);
			k++;
		}
		j++;
		i++;
	}

  }
  while(i<s1)
  {
		ae=llist_get(p.exponents,i);
		ac=llist_get(p.coeffs,i);
		llist_insert(r.exponents,k,ae);
		llist_insert(r.coeffs,k,ac);
		i++;
		k++;

  }
  while(j<s2)
  {
		be=llist_get(q.exponents,j);
		bc=llist_get(q.coeffs,j);
		llist_insert(r.exponents,k,be);
		llist_insert(r.coeffs,k,bc);
		j++;
		k++;

  }
return r;
}

/*Subtract second Polynomial from first*/
Polynomial subtract(Polynomial p, Polynomial q)
{
Polynomial r;
r.exponents=llist_new();
r.coeffs=llist_new();
int i=0,j=0,k=0;
int ae,be,ac,bc,cb,cc;
int t1,fl;
  while(i<llist_size(p.exponents)&&j<llist_size(q.exponents))
  {
	ae=llist_get(p.exponents,i);
	ac=llist_get(p.coeffs,i);
	be=llist_get(q.exponents,j);
	bc=llist_get(q.coeffs,j);
	if(ae<be)
	{
		llist_insert(r.exponents,k,ae);
		llist_insert(r.coeffs,k,ac);
		i++;
		k++;
	}
	else if(ae>be)
	{
		llist_insert(r.exponents,k,be);
		llist_insert(r.coeffs,k,-1*bc);
		j++;
		k++;
	}
	else
	{
		if(ac-bc!=0)
		{
			llist_insert(r.exponents,k,ae);
			llist_insert(r.coeffs,k,ac-bc);
			k++;
		}
		j++;
		i++;
	}

  }
  while(i<llist_size(p.exponents))
  {
		ae=llist_get(p.exponents,i);
		ac=llist_get(p.coeffs,i);
		llist_insert(r.exponents,k,ae);
		llist_insert(r.coeffs,k,ac);
		i++;
		k++;

  }
  while(j<llist_size(q.exponents))
  {
		be=llist_get(q.exponents,j);
		bc=llist_get(q.coeffs,j);
		llist_insert(r.exponents,k,be);
		llist_insert(r.coeffs,k,-1*bc);
		j++;
		k++;

  }
return r;
}

/*Evaluate Polynomial at var=k and return the result*/
long long evaluate(Polynomial p, int k)
{
long long ev=0;
int i=llist_size(p.exponents)-1;
int maxexp=llist_get(p.exponents,i);
int a,b;
while(maxexp>=0&&i>=0)
{
	a=llist_get(p.coeffs,i);
	b=llist_get(p.exponents,i);
	while(maxexp>b)
	{
		ev*=k;
		maxexp--;
	}
	ev=ev*k+a;
	i--;
	maxexp--;
}
while(maxexp>=0)
{
	ev*=k;
	maxexp--;
}
return ev;
}
