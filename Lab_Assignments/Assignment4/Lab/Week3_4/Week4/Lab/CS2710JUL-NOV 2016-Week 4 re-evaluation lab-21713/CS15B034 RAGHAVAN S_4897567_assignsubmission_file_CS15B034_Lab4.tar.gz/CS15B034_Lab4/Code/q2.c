//q2.c by Raghavan S CS15B034 Lab Assignment 4
#include "Polynomial.h"
#include<stdio.h>
#include<stdlib.h>
Polynomial getinp()
{
Polynomial p;
p.exponents=llist_new();
p.coeffs=llist_new();
int i,t=0,dat1,dat2;
scanf("%d",&t);
for(i=0;i<t;i++)
{
	scanf("%d",&dat1);
	llist_append(p.exponents,dat1);
}
for(i=0;i<t;i++)
{
	scanf("%d",&dat2);
	llist_append(p.coeffs,dat2);
}
return p;
}
int main()
{
int ch=0;
Polynomial p1,p2,p3;
int k;
while(ch!=-1)
{
	scanf("%d",&ch);
	switch(ch)
	{
		case 1:	p1=getinp();
						print_polynomial(p1);
						break;
		case 2: p1=getinp();
						printf("%d\n",get_degree(p1));
						break;
		case 3: p1=getinp();
						p2=getinp();
						p3=add(p1,p2);
						print_polynomial(p3);
						break;
		case 4: p1=getinp();
						p2=getinp();
						p3=subtract(p1,p2);
						print_polynomial(p3);
						break;
		case 5: p1=getinp();
						p2=getinp();
						p3=multiply(p1,p2);
						print_polynomial(p3);
						break;
		case 6:	p1=getinp();
						scanf("%d",&k);
						printf("%lld\n",evaluate(p1,k));
						break;


	}
}
return 0;
}
