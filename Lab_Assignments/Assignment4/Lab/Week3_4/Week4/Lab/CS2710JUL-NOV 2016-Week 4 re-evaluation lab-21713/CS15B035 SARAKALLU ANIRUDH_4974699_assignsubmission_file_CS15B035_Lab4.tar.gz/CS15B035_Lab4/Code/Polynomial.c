#include<stdio.h>
#include<stdlib.h>
#include "Polynomial.h"
#include "List.h"







int get_degree(Polynomial p){
        
        int size=llist_size((p.exponents));
        return llist_get((p.exponents),size-1);       
}

void print_polynomial(Polynomial p){
	
        Node *exp,*coeff;
        exp=((p.exponents)->head);
        coeff=((p.coeffs)->head);
        if(exp==NULL) return;
          if(exp->data==0){
          		if(coeff->data>0){ 
                		printf("%d",coeff->data);
                		exp=exp->next;
                		coeff=coeff->next;
                	}
                	else if(coeff->data<0){ 
                		printf("-%d",-(coeff->data));
                		exp=exp->next;
                		coeff=coeff->next;
                		
          		}
          		 else {
          			coeff = coeff->next;
          			exp = exp->next;
          		}
          		
          }
          else {
          	if(coeff->data>0){ 
                		printf("%dx^%d",coeff->data,exp->data);
                		exp=exp->next;
                		coeff=coeff->next;
                	}
                	else if(coeff->data<0){ 
                		printf("-%dx^%d",-(coeff->data),exp->data);
                		exp=exp->next;
                		coeff=coeff->next;
                		
          		} else {
          			coeff = coeff->next;
          			exp = exp->next;
          		}
          	
          
          
          
          }
        while(exp!=NULL){
        	
        	if(exp!=NULL&&(coeff->data)>0){
                	printf(" + %dx^%d",coeff->data,exp->data);
                	exp=exp->next;
                	coeff=coeff->next;
               }
               else if(exp!=NULL&&(coeff->data)<0){
               		printf(" - %dx^%d",-(coeff->data),exp->data);
               		exp=exp->next;
                	coeff=coeff->next;						
               		
                		
                } else {
          			coeff = coeff->next;
          			exp = exp->next;
          		}
        }
                printf(" \n");
       	
                                
}


Polynomial add(Polynomial p1, Polynomial p2){
        Polynomial* p3=malloc(sizeof(Polynomial));
        p3->exponents=llist_new();
        p3->coeffs=llist_new();
        Node *head_exp1,*head_exp2,*head_coeff1,*head_coeff2;
        head_exp1=((p1.exponents)->head);
        head_exp2=((p2.exponents)->head);
        head_coeff1=((p1.coeffs)->head);
        head_coeff2=((p2.coeffs)->head);
        Node* temp1=(p3->exponents)->head;
        Node* temp2=(p3->coeffs)->head;
        
        while(1){
        	
                if((head_exp1!=NULL && head_exp2!=NULL) && (head_exp1->data == head_exp2->data))
                {	
                	
                        llist_append(p3->coeffs,(head_coeff1->data)+(head_coeff2->data));
                        llist_append(p3->exponents,(head_exp1->data));
                        if(head_exp1!=NULL)head_exp1=head_exp1->next;
                        if(head_exp2!=NULL)head_exp2=head_exp2->next;
                        if(head_coeff1!=NULL)head_coeff1=head_coeff1->next;
                        if(head_coeff2!=NULL)head_coeff2=head_coeff2->next;
                        //print_polynomial(*p3);
                        continue;
                                
                }
                else if((head_exp1!=NULL && head_exp2!=NULL)&&head_exp1->data > head_exp2->data){
                	
                	llist_append(p3->exponents,head_exp2->data);
                	llist_append(p3->coeffs,head_coeff2->data);
                        if(head_exp2!=NULL)head_exp2=head_exp2->next;
                        if(head_coeff2!=NULL)head_coeff2=head_coeff2->next;
                        continue;
                        
                               
        
                }
                else if((head_exp1!=NULL && head_exp2!=NULL)&&head_exp1->data < head_exp2->data){
                        	llist_append(p3->exponents,head_exp1->data);
                		llist_append(p3->coeffs,head_coeff1->data);
                        	if(head_exp1!=NULL)head_exp1=head_exp1->next;
                        	if(head_coeff1!=NULL)head_coeff1=head_coeff1->next;
                        	continue;
                        	        
                	}
                	
                
                 
                 if(head_exp1==NULL&&head_exp2!=NULL){
                        while(head_exp2!=NULL){
                                llist_append(p3->coeffs,head_coeff2->data);
                                llist_append(p3->exponents,head_exp2->data);
                                if(head_exp2!=NULL)head_exp2=head_exp2->next;
                                if(head_coeff2!=NULL)head_coeff2=head_coeff2->next;
                                
                                
                                
               
                        }
                        break;
                        
                 
                 }
                        else if(head_exp2==NULL&&head_exp1!=NULL){
                        while(head_exp1!=NULL){
                                llist_append(p3->coeffs,head_coeff1->data);
                                llist_append(p3->exponents,head_exp1->data);
                                if(head_exp1!=NULL)head_exp1=head_exp1->next;
                                if(head_coeff1!=NULL)head_coeff1=head_coeff1->next;
                                 
                                
               
                        }
                        break;
                        
                        
                 
                 }
                 
                 if(head_exp2==NULL&&head_exp1==NULL) break;
                                
	}
	return *p3;
}	


long long int pow1(int k,int x){
	int i=0;
	if(x==0) return 1;
	long long int prod=k;
	for(i=1;i<=x-1;i++){
		prod=prod*k;
	
	}
	return prod;



}


long long int evaluate(Polynomial p, int k){
	long long int result=0;
	Node *exp,*coeff;
        exp=((p.exponents)->head);
        coeff=((p.coeffs)->head);
        while(exp!=NULL){
        	result=result+((coeff->data)*pow1(k,exp->data));
        	exp=exp->next;
        	coeff=coeff->next;
       
        }
        return result;
               
}
void insert(Polynomial* p,int exp_res,int coeff_res){
	Node* exp;
	Node* coeff;
	Node *exp_prev,*coeff_prev;
	exp=(p->exponents)->head;
	exp_prev=NULL;
	coeff=(p->coeffs)->head;
	coeff_prev=NULL;
	
	if(exp==NULL&&coeff==NULL){
		
		llist_append(p->exponents,exp_res);
		llist_append(p->coeffs,coeff_res);
		exp=(p->exponents)->head;
		coeff=(p->coeffs)->head;
		
		return;
		
	}
	while(exp!=NULL&&coeff!=NULL){
		if(exp!=NULL && exp->data < exp_res){
			exp_prev=exp;
			exp=exp->next;
			coeff_prev=coeff;
			coeff=coeff->next;
			
			
			
			
		}
		else if(exp!=NULL&&exp->data>exp_res){
			
			Node* resexp=node_new(exp_res);
			Node* rescoeff=node_new(coeff_res);
			resexp->next=exp;
			exp_prev->next=resexp;
			rescoeff->next=coeff;
			coeff_prev->next=rescoeff;
			exp=(p->exponents)->head;
			coeff=(p->coeffs)->head;
			
			return;
		}
		else if(exp!=NULL&&exp->data==exp_res){
			coeff->data=coeff->data+coeff_res;
			exp=(p->exponents)->head;
			coeff=(p->coeffs)->head;
			
			return;
		
		
		}
		
		
	}
	if(exp==NULL&&coeff==NULL){
		llist_append(p->exponents,exp_res);
		llist_append(p->coeffs,coeff_res);
		
		return;
	
	}
	

}

Polynomial subtract(Polynomial p1, Polynomial p2){
        Polynomial* p3=malloc(sizeof(Polynomial));
        p3->exponents=llist_new();
        p3->coeffs=llist_new();
        Node *head_exp1,*head_exp2,*head_coeff1,*head_coeff2;
        head_exp1=((p1.exponents)->head);
        head_exp2=((p2.exponents)->head);
        head_coeff1=((p1.coeffs)->head);
        head_coeff2=((p2.coeffs)->head);
        Node* temp1=(p3->exponents)->head;
        Node* temp2=(p3->coeffs)->head;
        
        while(1){
        	
                if((head_exp1!=NULL && head_exp2!=NULL) && (head_exp1->data == head_exp2->data))
                {	
                	
                        llist_append(p3->coeffs,(head_coeff1->data)-(head_coeff2->data));
                        llist_append(p3->exponents,(head_exp1->data));
                        if(head_exp1!=NULL)head_exp1=head_exp1->next;
                        if(head_exp2!=NULL)head_exp2=head_exp2->next;
                        if(head_coeff1!=NULL)head_coeff1=head_coeff1->next;
                        if(head_coeff2!=NULL)head_coeff2=head_coeff2->next;
                        //print_polynomial(*p3);
                        continue;
                                
                }
                else if((head_exp1!=NULL && head_exp2!=NULL)&&head_exp1->data > head_exp2->data){
                	
                	llist_append(p3->exponents,head_exp2->data);
                	llist_append(p3->coeffs,-(head_coeff2->data));
                        if(head_exp2!=NULL)head_exp2=head_exp2->next;
                        if(head_coeff2!=NULL)head_coeff2=head_coeff2->next;
                        continue;
                        
                               
        
                }
                else if((head_exp1!=NULL && head_exp2!=NULL)&&head_exp1->data < head_exp2->data){
                        	llist_append(p3->exponents,head_exp1->data);
                		llist_append(p3->coeffs,head_coeff1->data);
                        	if(head_exp1!=NULL)head_exp1=head_exp1->next;
                        	if(head_coeff1!=NULL)head_coeff1=head_coeff1->next;
                        	continue;
                        	        
                	}
                	
                
                 
                 if(head_exp1==NULL&&head_exp2!=NULL){
                        while(head_exp2!=NULL){
                                llist_append(p3->coeffs,-(head_coeff2->data));
                                llist_append(p3->exponents,head_exp2->data);
                                if(head_exp2!=NULL)head_exp2=head_exp2->next;
                                if(head_coeff2!=NULL)head_coeff2=head_coeff2->next;
                                
                                
                                
               
                        }
                        break;
                        
                 
                 }
                        else if(head_exp2==NULL&&head_exp1!=NULL){
                        while(head_exp1!=NULL){
                                llist_append(p3->coeffs,head_coeff1->data);
                                llist_append(p3->exponents,head_exp1->data);
                                if(head_exp1!=NULL)head_exp1=head_exp1->next;
                                if(head_coeff1!=NULL)head_coeff1=head_coeff1->next;
                                 
                                
               
                        }
                        break;
                        
                        
                 
                 }
                 
                 if(head_exp2==NULL&&head_exp1==NULL) break;
                                
	}
	return *p3;
}	


Polynomial multiply(Polynomial p1, Polynomial p2){
	Polynomial* p3=(Polynomial*)malloc(sizeof(Polynomial));
	(p3->exponents)=llist_new();
        (p3->coeffs)=llist_new();
	Node *exp1,*coeff1,*exp2,*coeff2;
	exp1=(p1.exponents)->head;
	exp2=(p2.exponents)->head;
	coeff1=(p1.coeffs)->head;
	coeff2=(p2.coeffs)->head;
	int exp_res;
	int coeff_res;
	
	while(exp1!=NULL&&coeff1!=NULL){

		while(exp2!=NULL&&coeff2!=NULL){
			
			exp_res=exp1->data+exp2->data;
			exp2=exp2->next;
			coeff_res=coeff1->data*coeff2->data;
			coeff2=coeff2->next;
			
			
			insert(p3,exp_res,coeff_res);
			
		
			
			
			
		}
		
		exp2=(p2.exponents)->head;
		coeff2=(p2.coeffs)->head;
		exp1=exp1->next;
		coeff1=coeff1->next;
		
		
	}
	
	return *p3;	
	
}


