#include <stdio.h>
#include "Polynomial.h"
#include "List.h"

int main() {
	int opt;
	scanf("%d", &opt);
	while (opt != -1) {
		Polynomial ply1;
		ply1.exponents = llist_new();
		ply1.coeffs = llist_new();
		int sz1;
		scanf("%d", &sz1);
		int i, data;
		for (i = 0; i < sz1; i++) {
			scanf("%d", &data);
			llist_append(ply1.exponents, data);
		}
		for (i = 0; i < sz1; i++) {
			scanf("%d", &data);
			llist_append(ply1.coeffs, data);
		}
		if (opt == 1) {
			print_polynomial(ply1);
		} else if (opt == 2) {
			int deg = get_degree(ply1);
			printf("%d\n", deg);
		} else if (opt == 3 || opt == 4 || opt == 5) {
			Polynomial ply2;
			ply2.exponents = llist_new();
			ply2.coeffs = llist_new();
			int sz2;
			scanf("%d", &sz2);
			int j, dat;
			for (j = 0; j < sz2; j++) {
				scanf("%d", &dat);
				llist_append(ply2.exponents, dat);
			}
			for (j = 0; j < sz2; j++) {
				scanf("%d", &dat);
				llist_append(ply2.coeffs, dat);
			}
			Polynomial ply;
			if (opt == 3) {
				ply = add(ply1, ply2);
				print_polynomial(ply);
			} else if (opt == 4) {
				ply = subtract(ply1, ply2);
				print_polynomial(ply);
			} else if (opt == 5) {
				ply = multiply(ply1, ply2);
				print_polynomial(ply);
			}
		} else if (opt == 6) {
			int k;
			scanf("%d", &k);
			long long res = evaluate(ply1, k);
			printf("%lld\n", res);
		}
		scanf("%d", &opt);
	}
	return 0;
}

