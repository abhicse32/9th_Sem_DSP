#include "Polynomial.h"
#include"List.h"

#include<stdio.h>
#include<stdlib.h>
#include<math.h>


/*function to return the degree of the polynomial*/
int get_degree(Polynomial poly)
{
    
    if(poly.exponents->head==NULL || poly.coeffs->head==NULL) 
    return ;
    int a;
     a= llist_size(poly.exponents);
     return llist_get(poly.exponents,a-1);
     
    //int count=0;
    //Node *p,*q;
    //p=poly.exponents->head;
    //q=poly.coeffs->head;
    //if(p==NULL || q==NULL)
    //{
     //   return ;
    // }
    //while(p->next!=NULL&&q!=NULL)
    //{
        
        //p=p->next;
       // q=q->next;
    //}
    //return p->data;
}
    

// print Polynomial
void print_polynomial(Polynomial poly)
{
    
    Node *p,*q;
    p=poly.exponents->head;
    q=poly.coeffs->head;
    if(p==NULL || q==NULL)
    return ;
    printf("%dx^%d",q->data,p->data);
    p=p->next;
    q=q->next;
    while(p!=NULL&&q!=NULL)
    {
        
        printf("+%dx^%d",q->data,p->data);
        p=p->next;
        q=q->next;
     }
     
}

/*Multiply two polynomials and return the result*/
Polynomial multiply(Polynomial A, Polynomial B)
{
    
    Polynomial *C;
    C=(Polynomial*)malloc(sizeof(Polynomial));
	C->exponents=(LList*)malloc(sizeof(LList));
	C->coeffs=(LList*)malloc(sizeof(LList));
    Polynomial *D;
    D=(Polynomial*)malloc(sizeof(Polynomial));
	D->exponents=(LList*)malloc(sizeof(LList));
	D->coeffs=(LList*)malloc(sizeof(LList));
    if(A.exponents->head==NULL||B.exponents->head==NULL||A.coeffs->head==NULL||B.coeffs->head==NULL)
    return ;
    int n1,n2,i,j,k,sum,a,b;
    n1=llist_size(A.exponents);
    n2=llist_size(B.exponents);
    for(i=0;i<n1;i++)
    {
        for(j=0;j<n2;j++)
        {   
            a=(llist_get(A.coeffs,i))*(llist_get(B.coeffs,j));
            llist_insert(C->coeffs,n1*i+j,a);
            b=llist_get(A.exponents,i)+llist_get(B.exponents,j);
            llist_insert(C->exponents,n1*i+j,b);
         }
     }
     int n3=llist_size(C->exponents);
     
     i=0,k=0;
     Node*p;
     p=C->exponents->head;
     
     while(p!=NULL)
     {
        if(llist_get(C->exponents,i)==-1)
        {
            p=p->next;
            k--;;
            break;
        }
        else
        {
            sum= llist_get(C->coeffs,i);
            for(j=i+1;j<n3;j++)
            {   
                
                if(llist_get(C->exponents,i)==llist_get(C->exponents,j))
                {
                                    sum= llist_get(C->coeffs,j) + sum;
                    llist_insert(C->exponents,j,-1);
                    llist_remove(C->exponents,j+1);
                     
                }
                llist_insert(D->coeffs,k,sum);
                llist_insert(D->exponents,k,llist_get(C->exponents,i));
             }
             p=p->next;
             k++;
         }
        
    
}  
print_polynomial(*D);
return *D;
}
    

/*Add two polynomials and return the result*/
Polynomial add(Polynomial A, Polynomial B)
{
   
    Polynomial *C=(Polynomial*)malloc(sizeof(Polynomial));
	C->exponents=(LList*)malloc(sizeof(LList));
	C->coeffs=(LList*)malloc(sizeof(LList));
    if(A.exponents->head==NULL||B.exponents->head==NULL||A.coeffs->head==NULL||B.coeffs->head==NULL)
    return ;
    Node *aex=(Node*)malloc(sizeof(Node));
    Node *bex=(Node*)malloc(sizeof(Node));
	Node *cex=(Node*)malloc(sizeof(Node));
	Node *aco=(Node*)malloc(sizeof(Node));
	Node *bco=(Node*)malloc(sizeof(Node));
	Node *cco=(Node*)malloc(sizeof(Node));
    aex=A.exponents->head;
    bex=B.exponents->head;
    cex=C->exponents->head;
    aco=A.coeffs->head;
    bco=B.coeffs->head;
    cco=C->coeffs->head;
    while(aex!=NULL && bex!=NULL)
    {
        if(aex==bex)
        {
            cex->data=aex->data;
            cco->data=aco->data+bco->data;
            aex=aex->next;
            aco=aco->next;
            bex=bex->next;
            bco=bco->next;
            cex=cex->next;
            cco=cco->next;
        }
        if(aex>bex)
        {
            cex->data=bex->data;
            cco->data=bco->data;
            bex=bex->next;
            bco=bco->next;
            cex=cex->next;
            cco=cco->next;
        }
        if(aex<bex)
        {
            cex->data=aex->data;
            cco->data=aco->data;
            aex=aex->next;
            aco=aco->next;
            cex=cex->next;
            cco=cco->next;
        }
        }
	print_polynomial(*C);
     return *C;
     
 }

/*Subtract second Polynomial from first*/
Polynomial subtract(Polynomial p1, Polynomial p2)
{
    Polynomial *C=(Polynomial*)malloc(sizeof(Polynomial));
	C->exponents=llist_new();
	C->coeffs=llist_new();
    if(p1.exponents->head==NULL||p2.exponents->head==NULL||p1.coeffs->head==NULL||p2.coeffs->head==NULL)
    return ;
    Node *p1ex=(Node*)malloc(sizeof(Node));
    Node *p2ex=(Node*)malloc(sizeof(Node));
	Node *cex=(Node*)malloc(sizeof(Node));
	Node *p1co=(Node*)malloc(sizeof(Node));
	Node *p2co=(Node*)malloc(sizeof(Node));
	Node *cco=(Node*)malloc(sizeof(Node));
    p1ex=p1.exponents->head;
    p2ex=p2.exponents->head;
    cex=C->exponents->head;
    p1co=p1.coeffs->head;
    p2co=p2.coeffs->head;
    cco=C->coeffs->head;
    while(p1ex!=NULL && p2ex!=NULL)
    {
        if(p1ex==p2ex)
        {
            cex->data=p1ex->data;
            cco->data=p1co->data-p2co->data;
            p1ex=p1ex->next;
            p1co=p1co->next;
            p2ex=p2ex->next;
            p2co=p2co->next;
            cex=cex->next;
            cco=cco->next;
        }
        if(p1ex>p2ex)
        {
            cex->data=p2ex->data;
            cco->data=p2co->data;
            p2ex=p2ex->next;
            p2co=p2co->next;
            cex=cex->next;
            cco=cco->next;
        }
        if(p1ex<p2ex)
        {
            cex->data=p1ex->data;
            cco->data=p1co->data;
            p1ex=p1ex->next;
            p1co=p1co->next;
            cex=cex->next;
            cco=cco->next;
        }
        }
	
     return *C;
}
    

/*Evaluate Polynomial at var=k and return the result*/
int evaluate(Polynomial A, int k)
{
    
    int i,j;
    
    if(A.exponents->head==NULL || A.coeffs->head==NULL)
    return ;
    int n=llist_size(A.coeffs);
    int sum=0;
    int r;
    for(i=0;i<n;i++)
    {
        r=1;
        for(j=0;j<llist_get(A.exponents,i);j++)
        {
        r=r*k;
        }
       
        sum=sum+(llist_get(A.coeffs,i))*r;
    }
	printf("%d",sum);
    return sum;
     
}

int main()
{
    int option,t,t1,t2,i,j,value;
    scanf("%d",&option);
    
    switch(option)
    {
        case 1:
        {
        Polynomial *p=(Polynomial*)malloc(sizeof(Polynomial));
	p->exponents=(LList*)malloc(sizeof(LList));
	p->coeffs=(LList*)malloc(sizeof(LList));
        scanf("%d",&t);
        for(i=0;i<t;i++)
        {
        
            scanf("%d",&value);
            
            llist_insert(p->exponents,i,value);
            
         }
         
         for(i=0;i<t;i++)
         {
         
            scanf("%d",&value);
            llist_insert(p->coeffs,i,value);
         }
        
        print_polynomial(*p);
        break;
        }
        case 2:
        {
        scanf("%d",&t);
        Polynomial *p=(Polynomial*)malloc(sizeof(Polynomial));
	p->exponents=(LList*)malloc(sizeof(LList));
	p->coeffs=(LList*)malloc(sizeof(LList));
        scanf("%d",&t);
        for(i=0;i<t;i++)
        {
            scanf("%d",&value);
            llist_insert(p->exponents,i,value);
         }
         for(i=0;i<t;i++)
         {
            scanf("%d",&value);
            llist_insert(p->coeffs,i,value);
         }
       int d= get_degree(*p);
	printf("%d",d);
        break;
        }
        case 3:
        {
        scanf("%d",&t1);
        Polynomial *p=(Polynomial*)malloc(sizeof(Polynomial));
	p->exponents=(LList*)malloc(sizeof(LList));
	p->coeffs=(LList*)malloc(sizeof(LList));
        
        for(i=0;i<t1;i++)
        {
            scanf("%d",&value);
            llist_insert(p->exponents,i,value);
         }
         for(i=0;i<t1;i++)
         {
            scanf("%d",&value);
            llist_insert(p->coeffs,i,value);
         }
         
         Polynomial *q=(Polynomial*)malloc(sizeof(Polynomial));
	q->exponents=(LList*)malloc(sizeof(LList));
	q->coeffs=(LList*)malloc(sizeof(LList));
        scanf("%d",&t2);
        for(i=0;i<t2;i++)
        {
            scanf("%d",&value);
            llist_insert(q->exponents,i,value);
         }
	
         for(i=0;i<t2;i++)
         {
            scanf("%d",&value);
            llist_insert(q->coeffs,i,value);
		printf(" _ ");
         }
	
        add(*p,*q);
        break;
        }
        case 4:
        {
        scanf("%d",&t1);
        Polynomial *p=(Polynomial*)malloc(sizeof(Polynomial));
	p->exponents=(LList*)malloc(sizeof(LList));
	p->coeffs=(LList*)malloc(sizeof(LList));
        
        for(i=0;i<t1;i++)
        {
            scanf("%d",&value);
            llist_insert(p->exponents,i,value);
         }
         for(i=0;i<t1;i++)
         {
            scanf("%d",&value);
            llist_insert(p->coeffs,i,value);
         }
         scanf("%d",&t2);
         Polynomial *q=(Polynomial*)malloc(sizeof(Polynomial));
	q->exponents=(LList*)malloc(sizeof(LList));
	q->coeffs=(LList*)malloc(sizeof(LList));
        
        for(i=0;i<t2;i++)
        {
            scanf("%d",&value);
            llist_insert(q->exponents,i,value);
         }
         for(i=0;i<t2;i++)
         {
            scanf("%d",&value);
            llist_insert(q->coeffs,i,value);
         }
        subtract(*p,*q);
        break;
        }
        case 5 :
        {
        scanf("%d",&t1);
        Polynomial *p=(Polynomial*)malloc(sizeof(Polynomial));
	p->exponents=(LList*)malloc(sizeof(LList));
	p->coeffs=(LList*)malloc(sizeof(LList));
        
        for(i=0;i<t1;i++)
        {
            scanf("%d",&value);
            llist_insert(p->exponents,i,value);
         }
         for(i=0;i<t1;i++)
         {
            scanf("%d",&value);
            llist_insert(p->coeffs,i,value);
         }
         scanf("%d",&t2);
         Polynomial *q=(Polynomial*)malloc(sizeof(Polynomial));
	q->exponents=(LList*)malloc(sizeof(LList));
	q->coeffs=(LList*)malloc(sizeof(LList));
        
        for(i=0;i<t2;i++)
        {
            scanf("%d",&value);
            llist_insert(q->exponents,i,value);
         }
         for(i=0;i<t2;i++)
         {
            scanf("%d",&value);
            llist_insert(q->coeffs,i,value);
         }
        multiply(*p,*q);
        break;
        }
        case 6 :
        {
        
        Polynomial *p=(Polynomial*)malloc(sizeof(Polynomial));
	p->exponents=(LList*)malloc(sizeof(LList));
	p->coeffs=(LList*)malloc(sizeof(LList));
        scanf("%d",&t);
        for(i=0;i<t;i++)
        {
            scanf("%d",&value);
            llist_insert(p->exponents,i,value);
         }
         for(i=0;i<t;i++)
         {
            scanf("%d",&value);
            llist_insert(p->coeffs,i,value);
         }
         int k;
         scanf("%d",&k);
        evaluate(*p,k);
        break;
        }
    }
  return 0;
  
}
    
