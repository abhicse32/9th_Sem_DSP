#include "List.h"
#include<stdio.h>
#include<stdlib.h>


Node* node_new( int data)
  {
   Node* x;
   x=(Node *)malloc(sizeof(Node));
   x->data=data;
   x->next=NULL;
   return x;
  }

LList* llist_new()
  {
   LList* x;
   x=(LList *)malloc(sizeof(LList));
   x->head=NULL;
   return x;
  }

int llist_size( LList* lst )
  {
   Node* x;
   x=lst->head;
   int i=0;
	if(x==NULL) return 0;
   while(x!=NULL)
    {
     i++;
     x=x->next;
    }
   return i;
  }

void llist_print( LList* lst )
  {
   Node* x;
   x=lst->head;
   while(x!=NULL)
    {
     printf("%d ",x->data);
     x=x->next;
    }
   printf("\n");
  }

int llist_get( LList* lst, int idx )
  {
   Node* x;
   x=lst->head;
   int i=0;
   while(x!=NULL)
    {
     if(i==idx)
      {
       return x->data;        
      }
     i++;
     x=x->next;
    }
  }

void llist_append( LList* lst, int data )
  {
   Node* x;
   x=lst->head;
   Node* y;
   y=(Node *)malloc(sizeof(Node));
   y->next=NULL;
   y->data=data;
 if(x==NULL) {y=node_new(data); return ;}
   while(1)
    {
     if(x->next==NULL)
      {
       x->next=y; 
       break;
      }
     x=x->next;
    }
  }

void llist_prepend( LList* lst, int data )
  {
   Node* x;
   Node* y;
   y=node_new(data);
   x=lst->head;
   y->next=x;
   lst->head=y;
  }

void llist_insert( LList* lst, int idx, int data )
  {
   Node* x;
   Node* y;
   Node* t;
   x=(Node *)malloc(sizeof(LList));
   y=(Node *)malloc(sizeof(LList));
   y->data=data;
   x=lst->head;
   int i=0;
   if(idx==0) {llist_prepend(lst,data); return ;}
   while(x!=NULL)
    {
     if(i==idx-1)
       {
        t=x->next;
        x->next=y;
        y->next=t;
       }
     i++;
     x=x->next;
    }
  }
void llist_remove_last( LList* lst )
  {
   Node* x;
   x=(Node *)malloc(sizeof(Node));
   x=lst->head;
   while(x!=NULL)
    {
     if(x->next==NULL){x=NULL;}
     x=x->next;
    }
  }
void llist_remove_first( LList* lst )
  {
   	Node *x;
	x=lst->head;
	lst->head=x->next;
  }
void llist_remove( LList* lst, int idx )
  {
   int i;
   Node* x;
   x=(Node *)malloc(sizeof(Node));
   x=lst->head;
   while(i<idx)
    {
     if(i==idx-1){x->next=(x->next)->next; break;}
     i++; x=x->next;
    }
  }




