#include<stdio.h>
#include<stdlib.h>
#include "Polynomial.h"
#include<math.h>

void reset(Polynomial* x, int a);

typedef struct Polynomial1_lst
{
	Node* exponents;
	Node* coeffs;
}Polynomial1;


void print_polynomial(Polynomial a2)
  {
   Polynomial* a1;
   a1= &a2;
   Polynomial1* a;
   (a1->coeffs)->head = (a->coeffs);
   (a1->exponents)->head = (a->exponents);   

   while(a->coeffs!=NULL)
    {
     if((a->coeffs)->next!=NULL) printf("%dx^%d + ", (a->coeffs)->data, (a->exponents)->data);
     else printf("%dx^%d", (a->coeffs)->data, (a->exponents)->data);
     (a->coeffs)=(a->coeffs)->next;
     (a->exponents)=(a->exponents)->next;
    }
  
   printf("\n");
  }

int get_degree(Polynomial a2)
  {
   int i, x, t;
   Polynomial* a1;
   a1= &a2;
   Polynomial1* a;
   (a1->coeffs)->head = (a->coeffs);
   (a1->exponents)->head = (a->exponents);   
   
   while(i<t)
    {
     if((a->coeffs)->data!=0) x=i;
     (a->coeffs)=(a->coeffs)->next;
     i++;
    }

   return x;
  }

Polynomial add(Polynomial p1, Polynomial p2)    
{
    Polynomial p;  
    p.exponents = llist_new();  
    p.coeffs = llist_new();     

    int n = llist_size(p1.exponents);   
    int m = llist_size(p2.exponents);   

    int i;  
    int j;  

    for(i=0,j=0; (i<n) && (j<m);)  
        {
            if (llist_get(p1.exponents,i) > llist_get(p2.exponents,j))  {
                                                                            llist_append(p.exponents,llist_get(p2.exponents,j));
                                                                            llist_append(p.coeffs,llist_get(p2.coeffs,j));
                                                                            j++;
                                                                        }

            else if(llist_get(p1.exponents,i) < llist_get(p2.exponents,j)) {
                                                                             llist_append(p.exponents,llist_get(p1.exponents,i));
                                                                             llist_append(p.coeffs,llist_get(p1.coeffs,i));
                                                                             i++;
                                                                           }
            else {
                    int sum = (llist_get(p1.coeffs,i)) + (llist_get(p2.coeffs,j));
                    if(sum==0);
                    else {
                            llist_append(p.exponents, llist_get(p1.exponents,i));
                            llist_append(p.coeffs, sum);
                         }
                    i++;
                    j++;
                 }
        }

   return p;
  }

Polynomial subtract(Polynomial p1, Polynomial p2)
  {
    Polynomial p;  
    p.exponents = llist_new();  
    p.coeffs = llist_new();     

    int n = llist_size(p1.exponents);   
    int m = llist_size(p2.exponents);   

    int i;  
    int j;  

    for(i=0,j=0; (i<n) && (j<m);)  
        {
            if (llist_get(p1.exponents,i) > llist_get(p2.exponents,j))  {
                                                                            llist_append(p.exponents,llist_get(p2.exponents,j));
                                                                            llist_append(p.coeffs,(-1)*(llist_get(p2.coeffs,j)));
                                                                            j++;
                                                                        }

            else if(llist_get(p1.exponents,i) < llist_get(p2.exponents,j)) {
                                                                             llist_append(p.exponents,llist_get(p1.exponents,i));
                                                                             llist_append(p.coeffs,llist_get(p1.coeffs,i));
                                                                             i++;
                                                                           }
            else {
                    int sum = (llist_get(p1.coeffs,i)) + (-1)*(llist_get(p2.coeffs,j));
                    if(sum==0);
                    else {
                            llist_append(p.exponents, llist_get(p1.exponents,i));
                            llist_append(p.coeffs, sum);
                         }
                    i++;
                    j++;
                 }
        }

   return p;
  }
  

Polynomial multiply(Polynomial p1, Polynomial p2)
  {
    Polynomial f;   
    Polynomial g;   
    f.exponents = llist_new();  
    g.exponents = llist_new();  
    f.coeffs = llist_new();     
    g.coeffs = llist_new();     

    int n = llist_size(p1.exponents);   
    int m = llist_size(p2.exponents);   
    int i;  
    int j;  

    for(i=0;i<n;i++)    
        {
            for(j=0;j<m;j++)
                {
                    int expo = (llist_get(p1.exponents,i))+(llist_get(p2.exponents,j));
                    int coeff = (llist_get(p1.coeffs,i))*(llist_get(p2.coeffs,j));
                    if(coeff==0);
                    else
                        {
                            llist_append(f.exponents, expo);
                            llist_append(f.coeffs,coeff);
                        }
                }
            g = add(f,g);
            f.exponents = llist_new();  
            f.coeffs = llist_new();     
        }
    return g;

  }

int evaluate(Polynomial a2, int k)
  {
   Polynomial* a1= &a2;
   int ans=0;
   Polynomial1* a;
   (a1->coeffs)->head = (a->coeffs);
   (a1->exponents)->head = (a->exponents);   

   while((a->coeffs)!=NULL)
     {
      ans=ans+ ((a->coeffs)->data) * (pow(k, (a->exponents)->data));
     }

   return ans;
  }











