#include<stdio.h>
#include<stdlib.h>
#include "Polynomial.h"
#include "List.h"

   int t, t1, t2;

typedef struct Polynomial1_lst
{
	Node* exponents;
	Node* coeffs;
}Polynomial1;

void scan1(Polynomial* a1);
void scan2(Polynomial* a1, Polynomial* b1);

int main()
  {
   int i, k;
   scanf("%d",&i);
   Polynomial* a1;
   Polynomial* b1;
   Polynomial a2, b2;
   
   if(i==-1){return 0;}
   if(i==1){scan1(a1); print_polynomial;(a2);}
   if(i==2){scan1(a1); get_degree(a2);}
   if(i==3){scan2(a1, b1); add(a2, b2);}
   if(i==4){scan2(a1, b1); subtract(a2, b2);}
   if(i==5){scan2(a1, b1); multiply(a2, b2);}
   if(i==6){scan1(a1); scanf("%d",&k); evaluate(a2, k);}
  }

void scan1(Polynomial* a1)
  {
   scanf("%d",&t);
   Polynomial1* a;
   (a1->coeffs)->head=(a->coeffs);
   (a1->exponents)->head=(a->exponents);
   int i=0;
   while(i<t)
    {
     scanf("%d",&(a->exponents)->data);
     (a->exponents)=(a->exponents)->next;
     i++;
    }
   i=0;
   while(i<t)
    {
     scanf("%d",&(a->coeffs)->data);
     (a->coeffs)=(a->coeffs)->next;
     i++;
    }
   (a->coeffs)=NULL;
   (a->exponents)=NULL;      
  }

void scan2(Polynomial* a1, Polynomial* b1)
  {
   scanf("%d",&t1);
   Polynomial1* a;
   (a1->coeffs)->head=(a->coeffs);
   (a1->exponents)->head=(a->exponents);
   int i=0;
   while(i<t1)
    {
     scanf("%d",&(a->exponents)->data);
     (a->exponents)=(a->exponents)->next;
     i++;
    }
   i=0;
   while(i<t1)
    {
     scanf("%d",&(a->coeffs)->data);
     (a->coeffs)=(a->coeffs)->next;
     i++;
    }
   (a->coeffs)=NULL;
   (a->exponents)=NULL;

   scanf("%d",&t2);
   Polynomial1* b;
   (b1->coeffs)->head=(b->coeffs);
   (b1->exponents)->head=(b->exponents);
   i=0;
   while(i<t2)
    {
     scanf("%d",&(b->exponents)->data);
     (b->exponents)=(b->exponents)->next;
     i++;
    }
   i=0;
   while(i<t2)
    {
     scanf("%d",&(b->coeffs)->data);
     (b->coeffs)=(b->coeffs)->next;
     i++;
    }
   (b->coeffs)=NULL;
   (b->exponents)=NULL;      
  }
