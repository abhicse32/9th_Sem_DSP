#include "Polynomial.h"
#include<stdlib.h>
#include<stdio.h>


/*Printing the degree of the polynomial
Input=Polynomial
Output=Degree*/
int get_degree(Polynomial x){
	return ((x.exponents)->head)->data;
}


/* print Polynomial */
void print_polynomial(Polynomial x){
	
	int n, i;
	int e, c;
	n=llist_size(x.exponents);
	
	for(i=n-1;i>=0;i--){
		e = llist_get(x.exponents, i);
		c = llist_get(x.coeffs, i);
		if(i==n-1){
			if(e!=0){
				printf("%d", c);
				printf("x^%d ", e);
			}
			else
				printf("%d ", c);
			}
		else{
			if(c>=0)
				printf("+ %d", c);
			else
				printf("- %d", -c);
			printf("x^%d ", e);
			}	
		}
	printf("\n");
}

/*Multiply two polynomials and return the result*/
Polynomial multiply(Polynomial p1, Polynomial p2){
	
	Polynomial p3, temp; //p3-final polynomial, temp-temporary
	Node *exp1, *coeff1, *exp2, *coeff2;
	int e, c;
	int i,j; //Counters
	int n, m; // Sizes of the two lists
	int e1, c1; //Exponents and coefficients of p1
	int e2, c2; //Exponents and coefficients of p2 
	
	p3.exponents = llist_new();
	p3.coeffs=llist_new();
	exp1 = (p1.exponents)->head;
	coeff1 = (p1.coeffs)->head;
	exp2 = (p2.exponents)->head;
	coeff2 = (p2.coeffs)->head;
	temp.exponents = llist_new();
	temp.coeffs = llist_new();
	
	n=llist_size(p1.exponents);
	m=llist_size(p2.exponents);
	
	/*Multiplying every element of first polynomial with
	the second polynomial to get a new polynomial temp.
	Then adding the temp to the final polynomial p3*/
	for(i=0;i<n;i++){
		e1=llist_get( p1.exponents, i);
		c1= llist_get( p1.coeffs, i);
		
		for(j=0;j<m;j++){
			e2 = llist_get( p2.exponents, j);
			c2 = llist_get( p2.coeffs, j);
			llist_append( temp.exponents, e1+e2);
			llist_append( temp.coeffs, c1*c2);
			

		}
		p3 = add(p3, temp);
		temp.exponents = llist_new();
		temp.coeffs = llist_new();
	}
	
	
	return p3;
}

/*Add two polynomials and return the result*/
Polynomial add(Polynomial x, Polynomial y){
	Node *exp1, *coeff1, *exp2, *coeff2;
	Polynomial sum;
	sum.exponents = llist_new();
	sum.coeffs=llist_new();
	
	exp1 = (x.exponents)->head;
	coeff1 = (x.coeffs)->head;
	exp2 = (y.exponents)->head;
	coeff2 = (y.coeffs)->head;
	
	while(exp1!=NULL && exp2!=NULL){
		//If the exponents are equal then simply add the coefficients
		if(exp1->data==exp2->data){
		if((coeff1->data + coeff2->data)!=0){
			llist_append( sum.exponents, exp1->data );
			llist_append( sum.coeffs, (coeff1->data + coeff2->data) );
			}
			exp1=exp1->next;
			exp2=exp2->next;
			coeff1=coeff1->next;
			coeff2=coeff2->next;
			}
		
		//If exponents are different then add the bigger term to the sum
		else if(exp1->data > exp2->data){
			llist_append( sum.exponents, exp1->data );
			llist_append( sum.coeffs, coeff1->data );
			exp1=exp1->next;
			coeff1=coeff1->next;
			}
		else {
			llist_append( sum.exponents, exp2->data );
			llist_append( sum.coeffs, coeff2->data );
			exp2=exp2->next;
			coeff2=coeff2->next;
			}
	}
	
	//Appending the remaining terms of p1 to the sum
	while(exp1!=NULL){
		llist_append( sum.exponents, exp1->data );
		llist_append( sum.coeffs, coeff1->data );
		exp1=exp1->next;
		coeff1=coeff1->next;
		}
		
	//Appending the remaining terms of p2 to the sum
	while(exp2!=NULL){
		llist_append( sum.exponents, exp2->data );
		llist_append( sum.coeffs, coeff2->data );
		exp2=exp2->next;
		coeff2=coeff2->next;
		}
		
	return sum;
}

/*Subtract second Polynomial from first
Essentially perform addition of first and
negative of the second polynomial*/
Polynomial subtract(Polynomial p1, Polynomial p2){
	Node *exp2, *coeff2;
	Polynomial p3;
	
	p3.exponents = llist_new();
	p3.coeffs=llist_new();
	exp2 = (p2.exponents)->head;
	coeff2 = (p2.coeffs)->head;
	
	while(coeff2!=NULL){
		llist_append( p3.exponents, exp2->data );
		llist_append( p3.coeffs, -(coeff2->data) );
		exp2=exp2->next;
		coeff2=coeff2->next;
		}
	return add(p1, p3);
}

/*Evaluate Polynomial at var=k and return the result
Horner's method*/
long long int evaluate(Polynomial x, int k){
	
	long long int sum=0;
	int exp1, exp2;
	int c;
	int n=llist_size(x.exponents);
	int i=0, j;
	
		
	while(i<n-1){
		exp1 = llist_get(x.exponents, i);
		exp2 = llist_get(x.exponents, i+1);
		c=llist_get(x.coeffs, i);
		sum+=c;
		for(j=0;j<exp1-exp2;j++)
			sum*=k;
		i++;
		}
		exp1 = llist_get(x.exponents, i);
		c=llist_get(x.coeffs, i);
		sum+=c;
		for(j=0;j<exp1;j++)
			sum*=k;
	return sum;
}	


