#include<stdio.h>
#include"Polynomial.h"

void poly_init(Polynomial P);
int main(void){

    int n;
    int t;
    int i;
    int e, c;
    int degree;
    long long int val;
    int k;
    Polynomial p1, p2, p3;
    
    
    
    while(1){
    
    		scanf("%d", &n);
	    /*Initialising the linked lists for the 
	    exponents and coefficients of all the 
	    three polynomials*/
	    p1.exponents = llist_new();
	    p1.coeffs=llist_new();
	    p2.exponents = llist_new();
	    p2.coeffs=llist_new();
	    p3.exponents = llist_new();
	    p3.coeffs=llist_new();
	    
	    
	    
	    switch(n){
		
		case 1: //Printing the polynomial

		    poly_init(p1);
		    print_polynomial(p1);
		    break;
		    
		case 2: //Printing degree of the polynomial
		   
		    poly_init(p1);
		    degree = get_degree(p1);
		    printf("%d\n", degree);
		    break;
		    
		case 3: //Addition of polynomials
		
		    poly_init(p1);
		    poly_init(p2);
		    p3 = add(p1, p2);
		    print_polynomial(p3);
		    break;
		    
		case 4: //Subtraction of second polynomial from first
		
		    poly_init(p1);
		    poly_init(p2);
		    p3 = subtract(p1, p2);
		    print_polynomial(p3);
		    break;
		    
		case 5: //Multiplication of two polynomials
		
		    poly_init(p1);
		    poly_init(p2);
		    p3 = multiply(p1, p2);
		    print_polynomial(p3);
		    break;
		    
		case 6: //Evaluating the polynomial at k
		    
		    poly_init(p1);
		    scanf("%d", &k);
		    val = evaluate(p1, k);
		    printf("%lld\n", val);
		     
		case -1:
		    break;
		}
		if(n==-1)
			break;
	}
}

/*Initialising the polynomial
Input=Empty polynomial
Output=void*/
void poly_init(Polynomial p){

    int t;
    int c, e, i;
    scanf("%d", &t);

    for(i=0;i<t;i++){
            scanf("%d", &e);
            llist_prepend(p.exponents, e);

                }
    for(i=0;i<t;i++){
           scanf("%d", &c);
            llist_prepend(p.coeffs, c);

                }       
                
}
