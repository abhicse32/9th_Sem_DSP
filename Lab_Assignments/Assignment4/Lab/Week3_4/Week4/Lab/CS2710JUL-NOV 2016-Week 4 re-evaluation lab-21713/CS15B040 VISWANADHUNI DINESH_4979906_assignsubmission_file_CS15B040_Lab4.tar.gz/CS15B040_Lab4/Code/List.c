#include "List.h"
#include<stdio.h>
#include<stdlib.h>
#include<limits.h>


Node* node_new(int data){
	Node *node=(Node*)malloc(sizeof(Node));
	node->data=data;
	node->next=NULL;
	return node;
}

LList* llist_new(){
	LList *list=(LList*)malloc(sizeof(LList));
	list->head=NULL;
	return list;
}

int llist_size( LList* lst ){
	Node *cur=(Node*)malloc(sizeof(Node));
	int count=0;
	for(cur=lst->head;cur!=NULL;cur=cur->next){
		count++;
	}
	return count;
}

void llist_print( LList* lst ){
	Node *cur=(Node*)malloc(sizeof(Node));
	for(cur=lst->head;cur!=NULL;cur=cur->next){	
		printf("%d ",cur->data);
	}
		printf("\n");
}

int llist_get( LList* lst, int idx ){
	if(lst->head==NULL || idx >= llist_size(lst) || idx<0){
		return -1;
	}
	int i=0;
	Node *cur=(Node*)malloc(sizeof(Node));
	for(cur=lst->head;cur!=NULL;cur=cur->next){	
		if(i==idx){
			return cur->data;
		}
		i++;
	}
	
}

void llist_append( LList* lst, int data ){

	Node *cur;
	Node *target=node_new(data);
	if(lst->head==NULL){
		lst->head=target;
	}
	else{
		for(cur=lst->head;cur->next!=NULL;cur=cur->next){
		}
		cur->next=target;
	}
}

void llist_prepend( LList* lst, int data ){
	Node *target=node_new(data);
	target->next=lst->head;
	lst->head=target;

}
		
void llist_insert( LList* lst, int idx, int data ){

	if(idx==0){
		llist_prepend(lst,data);
	}
	else{
		int i=0;
		Node *cur;
		for(cur=lst->head;(cur!=NULL)&&(i<idx-1);cur=cur->next){
			i++;
		}
		if(cur==NULL){
			return;
		}
		Node *target=node_new(data);
		target->next=cur->next;
		cur->next=target;
	}
}
	
void llist_remove_last( LList* lst ){
	Node *cur;
	for(cur=lst->head;(cur->next)->next!=NULL;cur=cur->next){
		}
	cur->next=NULL;	
}

void llist_remove_first( LList* lst ){
	if(lst->head==NULL){
		return;
	}
	lst->head=(lst->head)->next;
}


void llist_remove( LList* lst, int idx ){
	if(idx==0){
		llist_remove_first(lst);
	}
	else{
	int i=0;
	Node *cur;
	for(cur=lst->head;(cur->next!=NULL)&&(i<idx-1);cur=cur->next){
		i++;
	}	
	cur->next=(cur->next)->next;
	}
}

