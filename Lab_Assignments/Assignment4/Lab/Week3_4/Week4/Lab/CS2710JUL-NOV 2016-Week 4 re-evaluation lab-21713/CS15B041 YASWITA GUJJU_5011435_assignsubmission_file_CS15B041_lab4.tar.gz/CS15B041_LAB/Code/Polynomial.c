
#include "Polynomial.h"
#include <stdlib.h>
#include <stdio.h>
int get_degree(Polynomial p)
{
	int degree=0;

	if(p.expo->head!=NULL)
	{ 
	
	while(p.expo->head->next!=NULL)
		{
			
			p.expo->head=p.expo->head->next;
		}
	degree=	p.expo->head->data;
	
	}
	return degree;
}


void print_polynomial(Polynomial p)
{
	
	int flag=0;
       
	while(p.expo->head!=NULL)
	{	if(p.coef->head->data<0 && flag!=0)
		{
			printf("- ");
			p.coef->head->data*=-1;
		}
		else if(flag!=0) printf("+ ");
		if(p.expo->head->data==0)
			printf("%d ",p.coef->head->data);
		else printf("%dx^%d ",p.coef->head->data,p.expo->head->data );
		

		p.expo->head=p.expo->head->next;
		p.coef->head=p.coef->head->next;
		flag=1;
	}
	printf("\n");
	
}

Polynomial add(Polynomial p1, Polynomial p2)
{
	

	Polynomial sum;
	sum.expo=llist_new();
	sum.coef=llist_new();

	while(p1.expo->head!=NULL && p2.expo->head!=NULL)
	{	
		if(p1.expo->head->data == p2.expo->head->data)
			{
				int coeff=p1.coef->head->data + p2.coef->head->data;
				int exp=p1.expo->head->data;
				if(coeff!=0)
				{
				llist_append( sum.coef, coeff);
				llist_append( sum.expo, exp);
				}
				p1.expo->head=p1.expo->head->next;
				p1.coef->head=p1.coef->head->next;
				p2.expo->head=p2.expo->head->next;
				p2.coef->head=p2.coef->head->next;
				
			}
		
		else if(p1.expo->head->data < p2.expo->head->data)
		{
			int coeff=p1.coef->head->data;
			int exp=p1.expo->head->data;
			if(coeff!=0)
				{
				llist_append( sum.coef, coeff);
				llist_append( sum.expo, exp);
				}
			p1.expo->head=p1.expo->head->next;
			p1.coef->head=p1.coef->head->next;
			
		}
		else
		{
			int coeff=p2.coef->head->data;
			int exp=p2.expo->head->data;
			if(coeff!=0)
				{
				llist_append( sum.coef, coeff);
				llist_append( sum.expo, exp);
				}
			p2.expo->head=p2.expo->head->next;
			p2.coef->head=p2.coef->head->next;
			
		}	

	}

	while(p1.expo->head!=NULL)
	{
		int coeff=p1.coef->head->data;
			int exp=p1.expo->head->data;
			if(coeff!=0)
				{
				llist_append( sum.coef, coeff);
				llist_append( sum.expo, exp);
				}
			p1.expo->head=p1.expo->head->next;
			p1.coef->head=p1.coef->head->next;
	}

	while(p2.expo->head!=NULL)
	{
		int coeff=p2.coef->head->data;
			int exp=p2.expo->head->data;
			if(coeff!=0)
				{
				llist_append( sum.coef, coeff);
				llist_append( sum.expo, exp);
				}
			p2.expo->head=p2.expo->head->next;
			p2.coef->head=p2.coef->head->next;
	}
	return sum;
}


Polynomial subtract(Polynomial p1, Polynomial p2)
{
	
	Polynomial sub;
	sub.expo=llist_new();
	sub.coef=llist_new();

	while(p1.expo->head!=NULL && p2.expo->head!=NULL)
	{
		
		if(p1.expo->head->data == p2.expo->head->data)
			{
				int coeff=p1.coef->head->data - p2.coef->head->data;
				int exp=p1.expo->head->data;
				if(coeff!=0)
				{
				llist_append( sub.coef, coeff);
				llist_append( sub.expo, exp);
				}
				p1.expo->head=p1.expo->head->next;
				p1.coef->head=p1.coef->head->next;
				p2.expo->head=p2.expo->head->next;
				p2.coef->head=p2.coef->head->next;
				
			}
		
		else if(p1.expo->head->data < p2.expo->head->data)
		{
			int coeff=p1.coef->head->data;
			int exp=p1.expo->head->data;
			if(coeff!=0)
				{
				llist_append( sub.coef, coeff);
				llist_append( sub.expo, exp);
				}
			p1.expo->head=p1.expo->head->next;
			p1.coef->head=p1.coef->head->next;
			
		}
		else
		{
			int coeff=-p2.coef->head->data;
			int exp=p2.expo->head->data;
			if(coeff!=0)
				{
				llist_append( sub.coef, coeff);
				llist_append( sub.expo, exp);
				}
			p2.expo->head=p2.expo->head->next;
			p2.coef->head=p2.coef->head->next;
			
		}	

	}

	while(p1.expo->head!=NULL)
	{
		int coeff=p1.coef->head->data;
			int exp=p1.expo->head->data;
			if(coeff!=0)
				{
				llist_append( sub.coef, coeff);
				llist_append( sub.expo, exp);
				}
			p1.expo->head=p1.expo->head->next;
			p1.coef->head=p1.coef->head->next;
	}

	while(p2.expo->head!=NULL)
	{
		int coeff=-p2.coef->head->data;
			int exp=p2.expo->head->data;
			if(coeff!=0)
				{
				llist_append( sub.coef, coeff);
				llist_append( sub.expo, exp);
				}
			p2.expo->head=p2.expo->head->next;
			p2.coef->head=p2.coef->head->next;
	}
	return sub;

}
Polynomial multiply(Polynomial p1, Polynomial p2)
{

	Node* new1a;
	Node* new1b;
	Node* new2a;
	Node* new2b;
	new1a=p1.expo->head;
	new2a=p1.coef->head;
	new1b=p2.expo->head;
	new2b=p2.coef->head;
    Polynomial m;
    m.expo=llist_new();
	m.coef=llist_new();
	


	if(p1.expo->head==NULL && p2.expo->head==NULL)
		{}
	else if(p1.expo->head==NULL || p2.expo->head==NULL)
		{}
	
	else
	{
		
		while(p1.expo->head!=NULL)
		{	
			Polynomial temp;
			temp.expo=llist_new();
			temp.coef=llist_new();
			
			while(p2.expo->head!=NULL)
			{
				int exp=p1.expo->head->data + p2.expo->head->data;
				int coeff=p1.coef->head->data * p2.coef->head->data;
				if(coeff!=0)
				{
				llist_append( temp.coef, coeff);
				llist_append( temp.expo, exp);
				}
				
				p2.expo->head=p2.expo->head->next;
				p2.coef->head=p2.coef->head->next;
				

			}
			m=add(m,temp);
			
			p2.expo->head=new1b;
			p2.coef->head=new2b;
			p1.expo->head=p1.expo->head->next;
			p1.coef->head=p1.coef->head->next;
			
			

		}


	}
	return m;
}

long long int evaluate(Polynomial p,int k)
{
	long long int res=0;
	int exp;
	while(p.expo->head!=NULL)
	{
		 exp=p.expo->head->data;
		long long int val=1;
		int i;
		for(i=1;i<=exp;i++)
			val*=k;
		res+=val*(p.coef->head->data);
		p.expo->head=p.expo->head->next;
		p.coef->head=p.coef->head->next;


	}
return res;

}
