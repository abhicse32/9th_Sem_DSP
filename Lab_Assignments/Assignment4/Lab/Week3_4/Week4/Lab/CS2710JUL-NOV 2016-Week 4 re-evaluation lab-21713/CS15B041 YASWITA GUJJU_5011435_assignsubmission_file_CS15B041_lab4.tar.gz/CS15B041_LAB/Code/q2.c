#include"Polynomial.c"
#include"List.c"
#include<stdio.h>
#include <stdlib.h>

void main()
{


int ch;//user's choice
scanf("%d",&ch);
	while(ch!=-1)
{
		if(ch==1) 
			{int t;
		
			Polynomial q;
			q.exp=llist_new();
			q.coef=llist_new();
			scanf(" %d",&t);
			int i,a;
			for(i=0;i<t;i++)
			{   
				scanf(" %d",&a);
				llist_append( q.exp, a);
		
			}
			for(i=0;i<t;i++)
			{   
				scanf(" %d",&a);
				llist_append( q.coef, a);
		
			}
			
			print_polynomial(q);
			
	}


else if(ch==2)
		{
			int t;
		
			Polynomial q;
			q.exp=llist_new();
			q.coef=llist_new();
			scanf("%d",&t);
			int i,a;
			for(i=0;i<t;i++)
			{   
				scanf("%d",&a);
				llist_append( q.exp, a);
		
			}
			for(i=0;i<t;i++)
			{   
				scanf("%d",&a);
				llist_append( q.coef, a);
		
			}
			printf("%d\n",get_degree(q));
			
		}

 	else if(ch==3)
	{
	
			int t1,t2;
			Polynomial q1,q2;
			int i,a;
			q1.exp=llist_new();
			q1.coef=llist_new();
			q2.exp=llist_new();
			q2.coef=llist_new();
			scanf("%d",&t1);
			
			for(i=0;i<t1;i++)
			{   
				scanf("%d",&a);
				llist_append( q1.exp, a);
		
			}
			for(i=0;i<t1;i++)
			{   
				scanf("%d",&a);
				llist_append( q1.coef, a);
		
			}

			scanf("%d",&t2);
			
			for(i=0;i<t2;i++)
			{   
				scanf("%d",&a);
				llist_append( q2.exp, a);
		
			}
			for(i=0;i<t2;i++)
			{   
				scanf("%d",&a);
				llist_append( q2.coef, a);
		
			}
			Polynomial out;
		 out=add(q1,q2);
			
			print_polynomial(out);
	}


else if(ch==4) 
{			int t1,t2;
			Polynomial q1,q2;
			int i,a;
			q1.exp=llist_new();
			q1.coef=llist_new();
			q2.exp=llist_new();
			q2.coef=llist_new();
			scanf("%d",&t1);
			
			for(i=0;i<t1;i++)
			{   
				scanf("%d",&a);
				llist_append( q1.exp, a);
		
			}
			for(i=0;i<t1;i++)
			{   
				scanf("%d",&a);
				llist_append( q1.coef, a);
		
			}

			scanf("%d",&t2);
			
			for(i=0;i<t2;i++)
			{   
				scanf("%d",&a);
				llist_append( q2.exp, a);
		
			}
			for(i=0;i<t2;i++)
			{   
				scanf("%d",&a);
				llist_append( q2.coef, a);
		
			}

			Polynomial out;
			out=multiply(q1,q2);
			print_polynomial(out);

	}
else if(ch==5)
	{		int t1,t2;
			Polynomial q1,q2;
			int i,a;
			q1.exp=llist_new();
			q1.coef=llist_new();
			q2.exp=llist_new();
			q2.coef=llist_new();
			scanf("%d",&t1);
			
			for(i=0;i<t1;i++)
			{   
				scanf("%d",&a);
				llist_append( q1.exp, a);
		
			}
			for(i=0;i<t1;i++)
			{   
				scanf("%d",&a);
				llist_append( q1.coef, a);
		
			}

			scanf("%d",&t2);
			
			for(i=0;i<t2;i++)
			{   
				scanf("%d",&a);
				llist_append( q2.exp, a);
		
			}
			for(i=0;i<t2;i++)
			{   
				scanf("%d",&a);
				llist_append( q2.coef, a);
		
		}	Polynomial out;
			out=multiply(q1,q2);
			print_polynomial(out);
	}

else if(ch==6)
	{		int t,k;
			Polynomial q;
			q.exp=llist_new();
			q.coef=llist_new();
			scanf("%d",&t);
			int i,a;
			for(i=0;i<t;i++)
			{   
				scanf("%d",&a);
				llist_append( q.exp, a);
		
			}
			for(i=0;i<t;i++)
			{   
				scanf("%d",&a);
				llist_append( q.coef, a);
		
			}
			scanf("%d",&k);
			printf("%lld\n",evaluate(q,k));
	}


}




}






















