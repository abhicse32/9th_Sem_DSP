/*Implements all functions Listed in Polynomial.h
Y BHARGAVA SAI CS15B042 29th Aug 2016*/
#include "Polynomial.h"
#include <limits.h>
#include <stdio.h>

/*function to return the degree of the polynomial*/
int get_degree(Polynomial p){
	return llist_get(p . exponents,llist_size(p . exponents) - 1);
}

// print Polynomial
void print_polynomial(Polynomial p){
	Node * x = p . exponents -> head;
	Node * y = p . coeffs -> head;
	int f = 0; 
	if(x == NULL) return;
	if(x -> data == 0){
		if(y -> data != 0){
			printf("%d ",y -> data);
			f++;
		}	
			x = x -> next;
			y = y -> next;
	
	}

	if(x == p . exponents -> head){
		if(y -> data != 0){
			printf("%dx^%d ",y -> data,x -> data);
			f++;
		}	
		x = x -> next;
		y = y -> next;	
	}	
	while(x != NULL){
		if(y -> data < 0 || f == 0){
			printf("- %dx^%d ",(-1)*(y -> data),x -> data);
			f++;
			x = x -> next;
			y = y -> next;
		}
		else{
			if(y -> data != 0){
				printf("+ %dx^%d ",y -> data,x -> data);
				f++;
			}	
				x = x -> next;
				y = y -> next;
		}	
	}
	printf("\n");
	fflush(stdout);
	return;
}

/*Add two polynomials and return the result*/
Polynomial add(Polynomial p1, Polynomial p2){
	Polynomial p3;
	p3 . exponents = llist_new();
	p3 . coeffs 	= llist_new();
	Node * x1 = p1 . exponents -> head;
	Node * y1 = p1 . coeffs -> head;

	Node * x2 = p2 . exponents -> head;
	Node * y2 = p2 . coeffs -> head;
	while(x1 != NULL && x2 != NULL){
		if(x1 -> data == x2 -> data){
			llist_append(p3 . exponents,x1 -> data);
			llist_append(p3 . coeffs,y1 -> data + y2 -> data);
			x1 = x1 -> next;
			x2 = x2 -> next;
			y1 = y1 -> next;
			y2 = y2 -> next;
		}
		else if(x1 -> data > x2 -> data){
			llist_append(p3 . exponents,x2 -> data);
			llist_append(p3 . coeffs,y2 -> data);
			x2 = x2 -> next;
			y2 = y2 -> next;
		} 	
		else{
			llist_append(p3 . exponents,x1 -> data);
			llist_append(p3 . coeffs,y1 -> data);
			x1 = x1 -> next;
			y1 = y1 -> next;
		}
	}
	if(x1 == NULL){
		while(x2 != NULL){
			llist_append(p3 . exponents,x2 -> data);
			llist_append(p3 . coeffs,y2 -> data);
			x2 = x2 -> next;
			y2 = y2 -> next;
		}		
	}
	else{
		while(x1 != NULL){
			llist_append(p3 . exponents,x1 -> data);
			llist_append(p3 . coeffs,y1 -> data);
			x1 = x1 -> next;
			y1 = y1 -> next;
		}
	}
	return p3;	
}

/*Subtract second Polynomial from first*/
Polynomial subtract(Polynomial p1, Polynomial p2){
	Node * y2 = p2 . coeffs -> head;
	while(y2 != NULL){
		y2 -> data = (-1)*(y2 -> data);
		y2 = y2 -> next;
	}
	return add(p1,p2);	
}

/*Evaluates k^x (required to evaluate polynomial)*/
long long int power(int k,int x){
	int i ;
	long long int result = 1;
	for(i = 1;i <= x; i++){
		result = result*k;
	}
	return result;
}
/*Evaluate Polynomial at var=k and return the result*/
long long int evaluate(Polynomial p, int k){
	Node * x = p . exponents -> head;
	Node * y = p . coeffs -> head;
	long long int a,value;
	value = 0;
	if(x == NULL) return INT_MIN;
	while(x != NULL){
		a = power(k,x -> data);
		a = a * (y -> data);
		value += a;
		x = x -> next;
		y = y -> next;
	}
	return value;	
}

/*Checks if p already exists in p3.exponents linked list 
if exists adds q to existing exponents's coefficient else creates a new node and inserts at correct position */
void insert(Polynomial p3,int p,int q){
	Node * x3 = p3 . exponents -> head;
	Node * y3 = p3 . coeffs -> head;
	
	if(x3 == NULL){
		llist_append(p3 . exponents,p);		
		llist_append(p3 . coeffs,q);
		return;
	}

	if(x3 -> data > p){
		llist_prepend(p3 . exponents,p);
		llist_prepend(p3 . coeffs,q);
		return;		
	}

	while(1){
		if(x3 -> data < p){
			if(x3 -> next == NULL){
				Node *x = node_new(p);
				Node *y = node_new(q);
				x3 -> next = x;
				y3 -> next = y;
				return;
			} 
			if(x3 -> next -> data > p){
				Node *x = node_new(p);
				Node *y = node_new(q);
				x -> next = x3 -> next;
				x3 -> next = x;
				y -> next = y3 -> next;
				y3 -> next = y;
				return;
			}	
			else{
				x3 = x3 -> next;
				y3 = y3 -> next;
			}
		}
		else if(x3 -> data == p){
			y3 -> data += q;
			return;
		}		
	}
}

/*Multiply two polynomials and return the result*/
Polynomial multiply(Polynomial p1, Polynomial p2){
	Polynomial  p3;
	p3 . exponents = llist_new();
	p3 . coeffs 	= llist_new();
	int p,q;
	Node * x1 = p1 . exponents -> head;
	Node * y1 = p1 . coeffs -> head;
	Node * x2 = p2 . exponents -> head;
	Node * y2 = p2 . coeffs -> head;
	while(x1 != NULL){
		while(x2 != NULL){
			p = (x1 -> data)+(x2 -> data);
			q = (y1 -> data)*(y2 -> data);
			insert(p3,p,q);
			x2 = x2 -> next;
			y2 = y2 -> next;
		}
		x1 = x1 -> next;
		y1 = y1 -> next;
		x2 = p2 . exponents -> head;
		y2 = p2 . coeffs -> head;
	}
	return p3;
}
