/*Driver Program for question 2
Y BHARGAVA SAI CS15B042 29th Aug 2016*/
#include "Polynomial.h"
#include <stdio.h>

int main(){
	int v;
	int t,t1,t2;
	int i;
	Polynomial p,p1,p2;
	p . exponents  = llist_new();
	p . coeffs 	= llist_new();
	p1 . exponents = llist_new();
	p1 . coeffs 	= llist_new();
	p2 . exponents = llist_new();
	p2 . coeffs 	= llist_new();
	int data;
	scanf("%d",&v);
	while(v != -1){
		if(v == 1){
			p . exponents  = llist_new();
			p . coeffs 	= llist_new();
			scanf("%d",&t);
			for(i = 0;i < t;i++) {
				scanf("%d",&data);
				llist_append(p . exponents,data);
			}
			for(i = 0;i < t;i++) {
				scanf("%d",&data);
				llist_append(p . coeffs,data);
			}
			print_polynomial(p);
		}
		else if(v == 2){
			p . exponents  = llist_new();
			p . coeffs 	= llist_new();
			scanf("%d",&t);
			for(i = 0;i < t;i++) {
				scanf("%d",&data);
				llist_append(p . exponents,data);
			}
			for(i = 0;i < t;i++) {
				scanf("%d",&data);
				llist_append(p . coeffs,data);
			}
			printf("%d\n",get_degree(p));
		}
		else if(v == 3){
			p1 . exponents = llist_new();
			p1 . coeffs 	= llist_new();
			p2 . exponents = llist_new();
			p2 . coeffs 	= llist_new();
			scanf("%d",&t1);
			for(i = 0;i < t1;i++) {
				scanf("%d",&data);
				llist_append(p1 . exponents,data);
			}
			for(i = 0;i < t1;i++) {
				scanf("%d",&data);
				llist_append(p1 . coeffs,data);
			}
			scanf("%d",&t2);
			for(i = 0;i < t2;i++) {
				scanf("%d",&data);
				llist_append(p2 . exponents,data);
			}
			for(i = 0;i < t2;i++) {
				scanf("%d",&data);
				llist_append(p2 . coeffs,data);
			}
			p = add(p1,p2);
			print_polynomial(p);
		}
		else if(v == 4){
			p1 . exponents = llist_new();
			p1 . coeffs 	= llist_new();
			p2 . exponents = llist_new();
			p2 . coeffs 	= llist_new();
			scanf("%d",&t1);
			for(i = 0;i < t1;i++) {
				scanf("%d",&data);
				llist_append(p1 . exponents,data);
			}
			for(i = 0;i < t1;i++) {
				scanf("%d",&data);
				llist_append(p1 . coeffs,data);
			}
			scanf("%d",&t2);
			for(i = 0;i < t2;i++) {
				scanf("%d",&data);
				llist_append(p2 . exponents,data);
			}
			for(i = 0;i < t2;i++) {
				scanf("%d",&data);
				llist_append(p2 . coeffs,data);
			}
			p = subtract(p1,p2);
			print_polynomial(p);
		}
		else if(v == 5){
			p1 . exponents = llist_new();
			p1 . coeffs 	= llist_new();
			p2 . exponents = llist_new();
			p2 . coeffs 	= llist_new();
			scanf("%d",&t1);
			for(i = 0;i < t1;i++) {
				scanf("%d",&data);
				llist_append(p1 . exponents,data);
			}
			for(i = 0;i < t1;i++) {
				scanf("%d",&data);
				llist_append(p1 . coeffs,data);
			}
			scanf("%d",&t2);
			for(i = 0;i < t2;i++) {
				scanf("%d",&data);
				llist_append(p2 . exponents,data);
			}
			for(i = 0;i < t2;i++) {
				scanf("%d",&data);
				llist_append(p2 . coeffs,data);
			}
			p = multiply(p1,p2);
			print_polynomial(p);
		}
		else if(v == 6){
			p . exponents  = llist_new();
			p . coeffs 	= llist_new();
			scanf("%d",&t);
			for(i = 0;i < t;i++) {
				scanf("%d",&data);
				llist_append(p . exponents,data);
			}
			for(i = 0;i < t;i++) {
				scanf("%d",&data);
				llist_append(p . coeffs,data);
			}
			int k;
			scanf("%d",&k);
			printf("%lld\n",evaluate(p,k));
		}
		scanf("%d",&v);
	}
	return 0;
}
