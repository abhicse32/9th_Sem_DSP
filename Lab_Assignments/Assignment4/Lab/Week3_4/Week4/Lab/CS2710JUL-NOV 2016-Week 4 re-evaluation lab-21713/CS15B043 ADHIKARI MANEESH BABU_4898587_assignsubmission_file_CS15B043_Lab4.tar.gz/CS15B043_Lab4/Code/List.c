 

 #include<stdio.h>
 #include<stdlib.h>
 #include<limits.h>
 #include "List.h"
 
 typedef Node* PtrToNode;
 typedef LList* List;

 // Create a new node with next set to NULL

 Node* node_new( int data)
{
  PtrToNode NewNode = ( PtrToNode )malloc( sizeof( Node ) );
  NewNode->data = data;
  NewNode->next = NULL;
  
  return NewNode;
}
 
 // Create an empty list (head shall be NULL)

 LList* llist_new()
{
  List Head = ( List )malloc( sizeof( LList ) );
  Head->head = NULL;
  return Head;
}
  
 // Traverse the linked list and return its size

 int llist_size( LList* lst )
{
  PtrToNode Temp = lst->head;
  int size = 0;
  
     while( Temp )
    {
      size++;
      Temp = Temp->next;
    }

  return size;
}

 // Traverse the linked list and print each element

 void llist_print( LList* lst )
{
  PtrToNode Temp = lst->head;

     while( Temp )
    {
      printf( "%d " , Temp->data );
      Temp = Temp->next;
    }
 
  printf( "\n" );
  fflush(stdout);  
}

 //get the element at position @idx

 int llist_get( LList* lst, int idx )
{
  PtrToNode Temp = lst->head;
  int index = -1;

     while( Temp )
    {
      index++;
  
         if( index == idx )
          return Temp->data;
 
      Temp = Temp->next;   
    } 

  return -1;   
}

 // Add a new element at the end of the list

 void llist_append( LList* lst, int data )
{
  PtrToNode Temp = lst->head;
  PtrToNode NewNode = node_new( data );  

     if( !Temp )
    { 
      lst->head = NewNode;
      return;
    }

     while( Temp->next )
      Temp = Temp->next;

  Temp->next = NewNode;
}
 
 // Add a new element at the beginning of the list

 void llist_prepend( LList* lst, int data )
{
  PtrToNode NewNode = node_new( data );
  PtrToNode Temp = lst->head; 
         
     if( !Temp )
    {
      lst->head = NewNode;
      return;
    }
  
  NewNode->next = Temp;
  lst->head = NewNode;
}

 // Add a new element at the @idx index
 
 void llist_insert( LList* lst, int idx, int data )
{
  PtrToNode NewNode , Temp1 = lst->head , Temp2 = NULL;
  int index = 0;
   
     if( !Temp1 )
    {
         if( idx == index )
        {
          llist_prepend( lst, data );
          return; 
        }
      return;
    }    
 
     while( Temp1 )
    {
         if( index == idx )
        {
          NewNode = node_new( data );
          
             if( !Temp2 )
            {
              NewNode->next = Temp1;
              lst->head = NewNode;
              return;  
            }
             else
            {
              Temp2->next = NewNode;
              NewNode->next = Temp1;
              return;
            } 
        }

      Temp2 = Temp1;
      Temp1 = Temp1->next;
      index++;
    }
	
    if( index == idx )
   { 
     NewNode = node_new( data );
     Temp2->next = NewNode;
   }
}

 // Remove an element from the end of the list

 void llist_remove_last( LList* lst )
{
  PtrToNode Temp1 = lst->head , Temp2 = NULL;

     if( !Temp1 )
      return;

     while( Temp1->next )
    {
      Temp2 = Temp1;
      Temp1 = Temp1->next;
    }

  free( Temp1 );

     if( Temp2 )
      Temp2->next = NULL;
     else
      lst->head = NULL;    
}

 // Remove an element from the beginning of the list

 void llist_remove_first( LList* lst )
{
  PtrToNode Temp1 = lst->head , Temp2 = lst->head;

     if( !Temp1 )
      return;
  
  Temp1 = Temp1->next;
  free( Temp2 );
  lst->head = Temp1;   
}

 // Remove an element from an arbitrary @idx position in the list

 void llist_remove( LList* lst, int idx )
{
  PtrToNode Temp1 = lst->head , Temp2 = NULL;
  int index = 0;

     while( Temp1 )
    {
         if( index == idx )
        {
             if( !Temp2 )
            {
              lst->head = Temp1->next;
              free( Temp1 );
              return;
            }  
             else
            {
              Temp2->next = Temp1->next;
              free( Temp1 );
              return;  
            }
        } 

      Temp2 = Temp1;
      Temp1 = Temp1->next;
      index++;  
    }
}



  




















 


