
 #include<stdio.h>
 #include<math.h>
 #include<stdlib.h>
 #include "Polynomial.h"
 #include "List.h"
 
 typedef Polynomial *PolPtr;
 typedef Node* PtrToNode;
 typedef LList* List;
 
 /* Initialising a new 'Polynomial' */
 
 void PolListNew( PolPtr P )
{
  P->exponents = llist_new();
  P->coeffs = llist_new();
}
 
 /* Function to take the input exponents and coefficients into a 'Polynomial' */ 
 
 void Input( PolPtr P )
{
  int T , Temp , i;
  scanf( "%d" , &T );
  
     for( i = 0 ; i < T ; i++ )
    { 
      scanf( "%d" , &Temp );
      llist_append( P->exponents , Temp );
    }  
    
     for( i = 0 ; i < T ; i++ )
    {
      scanf( "%d" , &Temp );
      llist_append( P->coeffs , Temp );
    } 
} 

 // print Polynomial
 
 void print_polynomial( Polynomial P ) 
{
  int c , index = 0;
  List LE = P.exponents , LC = P.coeffs;
  PtrToNode Temp1 = LE->head , Temp2 = LC->head;
  
     while( Temp1 )
    {
      c = Temp2->data;
      
         if( c )
        {
             if( index )
            { 
                 if( c > 0 )
                  printf( " + " );
                 else
                {
                  c *= -1;
                  printf( " - " );
                }     
            }
            
             if( Temp1->data )   
              printf( "%dx^%d" , c , Temp1->data );
             else
              printf( "%d" , c );
                     
          index = 1;      
        } 
      
      Temp1 = Temp1->next;
      Temp2 = Temp2->next;
    }
    
  puts( " " );  
}  

 /*function to return the degree of the polynomial*/

 int get_degree( Polynomial P )
{
  int size = llist_size( P.exponents );
  int degree = llist_get( P.exponents , size - 1 );
  
  return degree;
} 

 /*Add two polynomials and return the result*/

 Polynomial add( Polynomial P1 , Polynomial P2 )
{
  Polynomial P3;
  PolListNew( &P3 );
  List LE3 = P3.exponents , LC3 = P3.coeffs;
  
  List LE1 = P1.exponents , LE2 = P2.exponents , LC1 = P1.coeffs , LC2 = P2.coeffs;  
  PtrToNode TempE1 = LE1->head , TempE2 = LE2->head , TempC1 = LC1->head , TempC2 = LC2->head;
  
     while( TempE1 && TempE2 )
    {
         if( TempE1->data < TempE2->data )
        {
          llist_append( LE3 ,  TempE1->data );
          llist_append( LC3 ,  TempC1->data );
          TempE1 = TempE1->next;
          TempC1 = TempC1->next;
        } 
         else
        {
             if( TempE1->data > TempE2->data )
            {
              llist_append( LE3 ,  TempE2->data );
              llist_append( LC3 ,  TempC2->data );
              TempE2 = TempE2->next;
              TempC2 = TempC2->next;
            } 
             else
            {
              llist_append( LE3 ,  TempE2->data );
              llist_append( LC3 ,  TempC2->data + TempC1->data );
              TempE2 = TempE2->next;
              TempE1 = TempE1->next;
              TempC1 = TempC1->next;
              TempC2 = TempC2->next;
            } 
        }   
    }    
  
     if( !TempE1 )
    {
         while( TempE2 )
        {
          llist_append( LE3 ,  TempE2->data );
          llist_append( LC3 ,  TempC2->data );
          TempE2 = TempE2->next;
          TempC2 = TempC2->next;
        } 
    } 
     
     if( !TempE2 )
    {
         while( TempE1 )
        {
          llist_append( LE3 ,  TempE1->data );
          llist_append( LC3 ,  TempC1->data );
          TempE1 = TempE1->next;
          TempC1 = TempC1->next;
        }
    } 
    
  return P3;
} 

 /*Subtract second Polynomial from first*/
 
 Polynomial subtract( Polynomial P1 , Polynomial P2 )
{ 
  Polynomial P3;
  PolListNew( &P3 );
  List LE3 = P3.exponents , LC3 = P3.coeffs;
  
  List LE1 = P1.exponents , LE2 = P2.exponents , LC1 = P1.coeffs , LC2 = P2.coeffs;  
  PtrToNode TempE1 = LE1->head , TempE2 = LE2->head , TempC1 = LC1->head , TempC2 = LC2->head;
  
     while( TempE1 && TempE2 )
    {
         if( TempE1->data < TempE2->data )
        {
          llist_append( LE3 ,  TempE1->data );
          llist_append( LC3 ,  TempC1->data );
          TempE1 = TempE1->next;
          TempC1 = TempC1->next;
        } 
         else
        {
             if( TempE1->data > TempE2->data )
            {
              llist_append( LE3 ,  TempE2->data );
              llist_append( LC3 ,  -1 * TempC2->data );
              TempE2 = TempE2->next;
              TempC2 = TempC2->next;
            } 
             else
            {
              llist_append( LE3 ,  TempE2->data );
              llist_append( LC3 ,  TempC1->data - TempC2->data );
              TempE2 = TempE2->next;
              TempE1 = TempE1->next;
              TempC1 = TempC1->next;
              TempC2 = TempC2->next;
            } 
        }   
    }    
  
     if( !TempE1 )
    {
         while( TempE2 )
        {
          llist_append( LE3 ,  TempE2->data );
          llist_append( LC3 ,  -1 * TempC2->data );
          TempE2 = TempE2->next;
          TempC2 = TempC2->next;
        } 
    } 
     
     if( !TempE2 )
    {
         while( TempE1 )
        {
          llist_append( LE3 ,  TempE1->data );
          llist_append( LC3 ,  TempC1->data );
          TempE1 = TempE1->next;
          TempC1 = TempC1->next;          
        }
    } 
      
  return P3;  
}

 /*Evaluate Polynomial at var=k and return the result*/
 
 long long int evaluate( Polynomial P , int k)
{
  long long int pol_val = 0 , var;
  List LE = P.exponents , LC = P.coeffs;
  PtrToNode TempE = LE->head , TempC = LC->head; 
  
     while( TempE )
    {
      var = pow( k , TempE->data );
      pol_val += var * TempC->data;
      
      TempE = TempE->next;
      TempC = TempC->next;
    } 
   
  return pol_val;
} 

 /*Multiply two polynomials and return the result*/
 
 Polynomial multiply( Polynomial P1 , Polynomial P2 )
{
  Polynomial P3;
  PolListNew( &P3 );
  List LE3 = P3.exponents , LC3 = P3.coeffs , LE1 = P1.exponents , LC1 = P1.coeffs , LE2 = P2.exponents , LC2 = P2.coeffs;
  PtrToNode TempE1 = LE1->head , TempE2 = LE2->head , TempC1 = LC1->head , TempC2 = LC2->head;
  
  int mul , exp , cof , M;
  
     while( TempE1 )
    {
      cof = TempC1->data;
      exp = TempE1->data;
    
         while( TempE2 )
        {
          mul = cof * TempC2->data;
          M = exp + TempE2->data;
          
          insert_sort( LE3 , LC3 , M , mul );
          
          TempE2 = TempE2->next;
          TempC2 = TempC2->next;
        } 
        
      TempE2 = LE2->head;
      TempC2 = LC2->head;
      TempC1 = TempC1->next;
      TempE1 = TempE1->next;  
    }
    
  return P3;     
}

 void insert_sort( List LE , List LC , int exp , int coeff )
{
  PtrToNode TempE = LE->head , TempC = LC->head;
  int index = 0;
  
     if( !TempE )
    {
      llist_prepend( LE , exp );
      llist_prepend( LC , coeff );
      return;
    } 
    
     while( TempE )
    {
         if( TempE->data == exp )
        {
          TempC->data += coeff;
          return; 
        }  
        
         if( TempE->data > exp )
        {
          llist_insert( LE , index , exp );
          llist_insert( LC , index , coeff );
          return;
        }  
        
      TempE = TempE->next;
      TempC = TempC->next;
      index++;   
    }
    
  llist_append( LE , exp );
  llist_append( LC , coeff );  
} 

 void Free_Memory( Polynomial P )
{
  List LE = P.exponents , LC = P.coeffs;
  PtrToNode TempE = LE->head , TempC = LC->head , Temp;
  
     while( TempE )
    {
      Temp = TempE->next;
      free( TempE );
      TempE = Temp;
    }    
  
  LE->head = NULL;
  
     while( TempC )
    {
      Temp = TempC->next;
      free( TempC );
      TempC = Temp;
    }  
    
  LC->head = NULL;  
} 

































 
