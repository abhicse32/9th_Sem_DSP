#ifndef POLYNOMIAL_H
#define POLYNOMIAL_H
#include "List.h"

typedef struct Polynomial_lst{
	LList* exponents;
	LList* coeffs;
}Polynomial;


/*function to return the degree of the polynomial*/
int get_degree(Polynomial);

// print Polynomial
void print_polynomial(Polynomial);

/*Multiply two polynomials and return the result*/
Polynomial multiply(Polynomial, Polynomial);

/*Add two polynomials and return the result*/
Polynomial add(Polynomial, Polynomial);

/*Subtract second Polynomial from first*/
Polynomial subtract(Polynomial p1, Polynomial p2);

/*Evaluate Polynomial at var=k and return the result*/
long long int evaluate(Polynomial, int k);

/* Creates an empty Polynomial List */
void PolListNew( Polynomial* P );

/* Inserts an element in the list so that the resultant list is sorted in ascending order */
void insert_sort( LList *LE , LList *LC , int exp , int coeff );
  
/* Function to take the elements of Polynomail as input */  
void Input( Polynomial *P );  

/* Function to initialize List Pointers in Polynomial */
void PolListNew( Polynomial *P );
  
/* Function to free the memory */
void Free_Memory( Polynomial P );  
#endif
