
 #include<stdio.h>
 #include<stdlib.h>
 #include "Polynomial.h" 
 #include "List.h"
 
 typedef Node* PtrToNode;
 typedef LList* List;

 int main( void )
{
  int option , M = 1 , k , degree;
  long long int pol_val;
  scanf( "%d" , &option );  
  Polynomial P1 , P2 , P3;
   
  PolListNew( &P1 );
  PolListNew( &P2 ); 
  
     while( M )
    { 
         switch( option )
        { 
          case 1:
           Input( &P1 );
           print_polynomial( P1 );
           fflush( stdout );
           Free_Memory( P1 );
           break;
       
          case 2:
           Input( &P1 );
           degree = get_degree( P1 );
           printf( "%d\n" , degree );
           fflush( stdout );
           Free_Memory( P1 );
           break;
       
         case 3:
          Input( &P1 );
          Input( &P2 );
          P3 = add( P1 , P2 );
          print_polynomial( P3 );
          fflush( stdout );
          Free_Memory( P1 );
          Free_Memory( P2 );
          Free_Memory( P3 );
          break;
       
         case 4:
          Input( &P1 );
          Input( &P2 );
          P3 = subtract( P1 , P2 );
          print_polynomial( P3 );
          fflush( stdout );
          Free_Memory( P1 );
          Free_Memory( P2 );
          Free_Memory( P3 );
          break;

         case 5:
          Input( &P1 );
          Input( &P2 );
          P3 = multiply( P1 , P2 );
          print_polynomial( P3 );
          fflush( stdout );
          Free_Memory( P1 );
          Free_Memory( P2 );
          Free_Memory( P3 );          
          break;
           
         case 6:
          Input( &P1 );
          scanf( "%d" , &k );
          pol_val = evaluate( P1 , k );
          printf( "%lld\n" , pol_val );
          fflush( stdout );
          Free_Memory( P1 );
          break;       
       }
       
      scanf( "%d" , &option );
      
         if( option == -1 )
          M = 0;  
    }   
    
  free( P1.exponents );
  free( P1.coeffs );
  free( P2.exponents );
  free( P2.coeffs );  
  return 0;
} 














