/* To implement polynomial in the form of linked list and perform following operations:
	1) Print a polynomial 
	2) Degree of a polynomial,
	3) Add two polynomials,
	4) Subtract two polynomials,
	5) Multiply two polynomials,
	6) Evaluate a polynomial 
  Author:CS15B046 Jahnvi Patel
  29th August 2016
*/

#include "Polynomial.h"
#include <stdlib.h>
#include <stdio.h>

/*function to return the degree of the polynomial*/
int get_degree(Polynomial p)
{
	int degree=0;

	if(p.exponents->head!=NULL)
	{ 
	
	while(p.exponents->head->next!=NULL)
		{
			
			p.exponents->head=p.exponents->head->next;
		}
	degree=	p.exponents->head->data;
	
	}
	return degree;
}

// print Polynomial

void print_polynomial(Polynomial p)
{
	
	int count=0;
       
	while(p.exponents->head!=NULL)
	{	if(p.coeffs->head->data<0 && count!=0)
		{
			printf("- ");
			p.coeffs->head->data*=-1;
		}
		else if(count!=0) printf("+ ");
		if(p.exponents->head->data==0)
			printf("%d ",p.coeffs->head->data);
		else printf("%dx^%d ",p.coeffs->head->data,p.exponents->head->data );
		

		p.exponents->head=p.exponents->head->next;
		p.coeffs->head=p.coeffs->head->next;
		count=1;
	}
	printf("\n");
	
}

/*Add two polynomials and return the result*/

Polynomial add(Polynomial p1, Polynomial p2)
{
	

	Polynomial out;
	out.exponents=llist_new();
	out.coeffs=llist_new();

	while(p1.exponents->head!=NULL && p2.exponents->head!=NULL)
	{	/*If both equal, add and move both pointers forward*/
		if(p1.exponents->head->data == p2.exponents->head->data)
			{
				int coeff=p1.coeffs->head->data + p2.coeffs->head->data;
				int exp=p1.exponents->head->data;
				if(coeff!=0)
				{
				llist_append( out.coeffs, coeff);
				llist_append( out.exponents, exp);
				}
				p1.exponents->head=p1.exponents->head->next;
				p1.coeffs->head=p1.coeffs->head->next;
				p2.exponents->head=p2.exponents->head->next;
				p2.coeffs->head=p2.coeffs->head->next;
				
			}
		/*Move the corresponding pointer forward and append the value to output*/
		else if(p1.exponents->head->data < p2.exponents->head->data)
		{
			int coeff=p1.coeffs->head->data;
			int exp=p1.exponents->head->data;
			if(coeff!=0)
				{
				llist_append( out.coeffs, coeff);
				llist_append( out.exponents, exp);
				}
			p1.exponents->head=p1.exponents->head->next;
			p1.coeffs->head=p1.coeffs->head->next;
			
		}
		else
		{
			int coeff=p2.coeffs->head->data;
			int exp=p2.exponents->head->data;
			if(coeff!=0)
				{
				llist_append( out.coeffs, coeff);
				llist_append( out.exponents, exp);
				}
			p2.exponents->head=p2.exponents->head->next;
			p2.coeffs->head=p2.coeffs->head->next;
			
		}	

	}

	while(p1.exponents->head!=NULL)
	{
		int coeff=p1.coeffs->head->data;
			int exp=p1.exponents->head->data;
			if(coeff!=0)
				{
				llist_append( out.coeffs, coeff);
				llist_append( out.exponents, exp);
				}
			p1.exponents->head=p1.exponents->head->next;
			p1.coeffs->head=p1.coeffs->head->next;
	}

	while(p2.exponents->head!=NULL)
	{
		int coeff=p2.coeffs->head->data;
			int exp=p2.exponents->head->data;
			if(coeff!=0)
				{
				llist_append( out.coeffs, coeff);
				llist_append( out.exponents, exp);
				}
			p2.exponents->head=p2.exponents->head->next;
			p2.coeffs->head=p2.coeffs->head->next;
	}
	return out;
}

/*Subtract second Polynomial from first*/

Polynomial subtract(Polynomial p1, Polynomial p2)
{
	
	Polynomial out;
	out.exponents=llist_new();
	out.coeffs=llist_new();

	while(p1.exponents->head!=NULL && p2.exponents->head!=NULL)
	{
		/*If both equal, subtract and move both pointers forward*/
		if(p1.exponents->head->data == p2.exponents->head->data)
			{
				int coeff=p1.coeffs->head->data - p2.coeffs->head->data;
				int exp=p1.exponents->head->data;
				if(coeff!=0)
				{
				llist_append( out.coeffs, coeff);
				llist_append( out.exponents, exp);
				}
				p1.exponents->head=p1.exponents->head->next;
				p1.coeffs->head=p1.coeffs->head->next;
				p2.exponents->head=p2.exponents->head->next;
				p2.coeffs->head=p2.coeffs->head->next;
				
			}
		/*Move the corresponding pointer forward and append the value to output*/
		else if(p1.exponents->head->data < p2.exponents->head->data)
		{
			int coeff=p1.coeffs->head->data;
			int exp=p1.exponents->head->data;
			if(coeff!=0)
				{
				llist_append( out.coeffs, coeff);
				llist_append( out.exponents, exp);
				}
			p1.exponents->head=p1.exponents->head->next;
			p1.coeffs->head=p1.coeffs->head->next;
			
		}
		else
		{
			int coeff=-p2.coeffs->head->data;
			int exp=p2.exponents->head->data;
			if(coeff!=0)
				{
				llist_append( out.coeffs, coeff);
				llist_append( out.exponents, exp);
				}
			p2.exponents->head=p2.exponents->head->next;
			p2.coeffs->head=p2.coeffs->head->next;
			
		}	

	}

	while(p1.exponents->head!=NULL)
	{
		int coeff=p1.coeffs->head->data;
			int exp=p1.exponents->head->data;
			if(coeff!=0)
				{
				llist_append( out.coeffs, coeff);
				llist_append( out.exponents, exp);
				}
			p1.exponents->head=p1.exponents->head->next;
			p1.coeffs->head=p1.coeffs->head->next;
	}

	while(p2.exponents->head!=NULL)
	{
		int coeff=-p2.coeffs->head->data;
			int exp=p2.exponents->head->data;
			if(coeff!=0)
				{
				llist_append( out.coeffs, coeff);
				llist_append( out.exponents, exp);
				}
			p2.exponents->head=p2.exponents->head->next;
			p2.coeffs->head=p2.coeffs->head->next;
	}
	return out;

}
/*Multiply two polynomials and return the result*/

Polynomial multiply(Polynomial p1, Polynomial p2)
{

	Node* initHead1a;
	Node* initHead1b;
	Node* initHead2a;
	Node* initHead2b;
	initHead1a=p1.exponents->head;
	initHead2a=p1.coeffs->head;
	initHead1b=p2.exponents->head;
	initHead2b=p2.coeffs->head;
    Polynomial m;
    m.exponents=llist_new();
	m.coeffs=llist_new();
	


	if(p1.exponents->head==NULL && p2.exponents->head==NULL)
		{}
	else if(p1.exponents->head==NULL)
		{}
	else if(p2.exponents->head==NULL)
		{}
	else
	{
		/*Breaking the multiplication into addition sub-modules:
		  First term of p1 is multiplied to all terms of p2 this forms first term to be added
		  This process is continued till all the terms are generated and added*/

		while(p1.exponents->head!=NULL)
		{	
			Polynomial temp;
			temp.exponents=llist_new();
			temp.coeffs=llist_new();
			
			while(p2.exponents->head!=NULL)
			{
				int exp=p1.exponents->head->data + p2.exponents->head->data;
				int coeff=p1.coeffs->head->data * p2.coeffs->head->data;
				if(coeff!=0)
				{
				llist_append( temp.coeffs, coeff);
				llist_append( temp.exponents, exp);
				}
				
				p2.exponents->head=p2.exponents->head->next;
				p2.coeffs->head=p2.coeffs->head->next;
				

			}
			m=add(m,temp);
			
			p2.exponents->head=initHead1b;
			p2.coeffs->head=initHead2b;
			p1.exponents->head=p1.exponents->head->next;
			p1.coeffs->head=p1.coeffs->head->next;
			
			

		}


	}
	return m;
}

/*Evaluate Polynomial at var=k and return the result*/

long long int evaluate(Polynomial p,int k)
{
	long long int res=0;
	while(p.exponents->head!=NULL)
	{
		int exp=p.exponents->head->data;
		long long int val=1;
		int i;
		for(i=1;i<=exp;i++)
			val*=k;
		res+=val*(p.coeffs->head->data);
		p.exponents->head=p.exponents->head->next;
		p.coeffs->head=p.coeffs->head->next;


	}
return res;

}
