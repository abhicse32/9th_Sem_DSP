/* To implement polynomial in the form of linked list and perform following operations:
	1) Print a polynomial 
	2) Degree of a polynomial,
	3) Add two polynomials,
	4) Subtract two polynomials,
	5) Multiply two polynomials,
	6) Evaluate a polynomial 
  Author:CS15B046 Jahnvi Patel
  29th August 2016
*/



#include "Polynomial.h"
#include <stdlib.h>
#include <stdio.h>

void main()
{


int choice;//user's choice
do
{
	scanf("%d",&choice);
/* Printing a polynomial and finding degree of polynomial*/

	if(choice==1 || choice==2)
	{		int t;
		/*number of entries*/
			Polynomial p;
			p.exponents=llist_new();
			p.coeffs=llist_new();
			scanf("%d",&t);
			int i,a;
			for(i=0;i<t;i++)
			{   
				scanf("%d",&a);
				llist_append( p.exponents, a);
		
			}
			for(i=0;i<t;i++)
			{   
				scanf("%d",&a);
				llist_append( p.coeffs, a);
		
			}
			if(choice==1)
			print_polynomial(p);
			else printf("%d\n",get_degree(p));
	}
/*Addition,Subtraction and Multiplication of two polynomials*/
 	else if(choice>=3 && choice<=5)
	{
	
			int t1,t2;
			Polynomial p1,p2;
			int i,a;
			p1.exponents=llist_new();
			p1.coeffs=llist_new();
			p2.exponents=llist_new();
			p2.coeffs=llist_new();
			scanf("%d",&t1);
			
			for(i=0;i<t1;i++)
			{   
				scanf("%d",&a);
				llist_append( p1.exponents, a);
		
			}
			for(i=0;i<t1;i++)
			{   
				scanf("%d",&a);
				llist_append( p1.coeffs, a);
		
			}

			scanf("%d",&t2);
			
			for(i=0;i<t2;i++)
			{   
				scanf("%d",&a);
				llist_append( p2.exponents, a);
		
			}
			for(i=0;i<t2;i++)
			{   
				scanf("%d",&a);
				llist_append( p2.coeffs, a);
		
			}
			Polynomial out;
			if(choice==3) out=add(p1,p2);
			else if(choice==4) out=subtract(p1,p2);
			else if(choice==5) out=multiply(p1,p2);
			print_polynomial(out);
	}

/*Evaluation of polynomial at value k*/
	else if(choice==6)
	{		int t,k;
			Polynomial p;
			p.exponents=llist_new();
			p.coeffs=llist_new();
			scanf("%d",&t);
			int i,a;
			for(i=0;i<t;i++)
			{   
				scanf("%d",&a);
				llist_append( p.exponents, a);
		
			}
			for(i=0;i<t;i++)
			{   
				scanf("%d",&a);
				llist_append( p.coeffs, a);
		
			}
			scanf("%d",&k);
			printf("%lld\n",evaluate(p,k));
	}


}while(choice!=-1);//EXIT


}
