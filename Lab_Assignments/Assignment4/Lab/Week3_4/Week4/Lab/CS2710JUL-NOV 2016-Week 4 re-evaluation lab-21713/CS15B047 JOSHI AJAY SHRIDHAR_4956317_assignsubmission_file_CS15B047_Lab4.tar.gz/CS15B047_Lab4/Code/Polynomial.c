#include "Polynomial.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
/*
Organization of data
p-->exp -->head-->next,head-->data
p-->coeff->head-->next,head-->data
*/

//Find degree of polynomial
int get_degree(Polynomial p)
{
	int degree = 0 ,num_terms = 0;
	int i;
	Node *temphead = p.exponents->head ;//store copy of head
	num_terms = llist_size(p.exponents); //find length of polynomial LL
        //Traverse through LL and find max exponent
	for(i=0;i<num_terms;i++)
	{
		if(degree < temphead->data )
		{
			degree = temphead->data ;
		}		
		temphead = temphead->next ;
	}
	return degree ;	
}

//Prints polynomial
void print_polynomial(Polynomial p)
{
        int i;
        //store copy of both exp and coeff LL heads
        Node *tempexphead = p.exponents->head ;
	Node *tempcoeffhead = p.coeffs->head ;
	
	if(tempexphead != NULL) //Check for empty list
	{
	        for(i=0;i < llist_size(p.coeffs);i++)
	        {
	                if(tempexphead->data !=0) //Check for constant term --> exp=0 
	                {	                
	                        if(tempcoeffhead->data < 0 && tempcoeffhead != p.coeffs->head) //Check for negative coeff 
                        	{
                        		printf("- %dx^%d ",(-1)*tempcoeffhead->data,tempexphead->data);
		                }
		                else if(tempcoeffhead->data < 0 && tempcoeffhead == p.coeffs->head)//Check for -ve coeff and start posn
		                {
		                        printf("-%dx^%d ",(-1)*tempcoeffhead->data,tempexphead->data);
		                }
		                else if(tempcoeffhead->data > 0)// for +ve coeff
		                {
		                        if(tempcoeffhead == p.coeffs->head)
		                                printf("%dx^%d ",tempcoeffhead->data,tempexphead->data);
	                                else
	                                        printf("+ %dx^%d ",tempcoeffhead->data,tempexphead->data);
		                }		
	                }
	                else
	                {
	                        printf("%d ",tempcoeffhead->data);
	                }
	                //Increment both pointers
	                tempcoeffhead = tempcoeffhead->next ;
	                tempexphead = tempexphead->next ;
	        }
	        printf("\n");
        }
}

//add 2 polynomials
Polynomial add(Polynomial P1, Polynomial P2)
{
        Polynomial addition ;
        //LL creation
        addition.exponents = llist_new();        
        addition.coeffs = llist_new();        

        //Check for empty polynomials
	if(P1.coeffs->head == NULL)
	        return P2 ;
        else if(P2.coeffs->head == NULL)
                return P1 ;
        else
        {
                while(P1.coeffs->head != NULL || P2.coeffs->head != NULL )
                {
                        //If 1 list finishes copy other list into answer polynomial 
                        if(P1.coeffs->head == NULL)
                        {
                                while(P2.coeffs->head != NULL)
                                {
                                        llist_append(addition.coeffs,P2.coeffs->head->data);
                                        llist_append(addition.exponents,P2.exponents->head->data);
                                        P2.coeffs->head = P2.coeffs->head->next ;
                                        P2.exponents->head = P2.exponents->head->next ;
                                }
                        }
                        else if(P2.coeffs->head == NULL)
                        {
                                while(P1.coeffs->head != NULL)
                                {
                                        llist_append(addition.coeffs,P1.coeffs->head->data);
                                        llist_append(addition.exponents,P1.exponents->head->data);
                                        P1.coeffs->head = P1.coeffs->head->next ;
                                        P1.exponents->head = P1.exponents->head->next ;
                                }
                        }
                        else
                        {
                                //Result poly to be sorted in asc order of exponent,so lower exp term goes first
                                if(P1.exponents->head->data > P2.exponents->head->data)
                                {
                                        llist_append(addition.coeffs,P2.coeffs->head->data);
                                        llist_append(addition.exponents,P2.exponents->head->data);
                                        P2.coeffs->head = P2.coeffs->head->next ;
                                        P2.exponents->head = P2.exponents->head->next ;
                                                                        
                                }
                                else if(P2.exponents->head->data > P1.exponents->head->data)  
                                {
                                        llist_append(addition.coeffs,P1.coeffs->head->data);
                                        llist_append(addition.exponents,P1.exponents->head->data);
                                        P1.coeffs->head = P1.coeffs->head->next ;
                                        P1.exponents->head = P1.exponents->head->next ;                                
                                }
                                //Add coeffs if same exponent
                                else
                                {
                                        llist_append(addition.coeffs,P1.coeffs->head->data + P2.coeffs->head->data);
                                        llist_append(addition.exponents,P1.exponents->head->data);
                                        P1.coeffs->head = P1.coeffs->head->next ;
                                        P1.exponents->head = P1.exponents->head->next ;                                        
                                        P2.coeffs->head = P2.coeffs->head->next ;
                                        P2.exponents->head = P2.exponents->head->next ;                                        
                                }                                
                        }                        
                }
        
        return addition ;
        }
                
}

//P1 - P2
Polynomial subtract(Polynomial P1, Polynomial P2)
{
        Polynomial subtraction ;
        
        subtraction.exponents = llist_new();        
        subtraction.coeffs = llist_new();        
	
	if(P1.coeffs->head == NULL && P2.coeffs->head != NULL)
	{
	        //Difference from addition--> -(P2) to be returned
	        while(P2.coeffs->head != NULL)
                {
                        llist_append(subtraction.coeffs,(-1)*P2.coeffs->head->data);
                        llist_append(subtraction.exponents,P2.exponents->head->data);
                        P2.coeffs->head = P2.coeffs->head->next ;
                        P2.exponents->head = P2.exponents->head->next ;
                }
                return P2;
	}
	//CHeck for empty list
        else if(P2.coeffs->head == NULL)
                return P1 ;
        //Remaining is same as addition with just - in place of +
        else
        {
                while(P1.coeffs->head != NULL || P2.coeffs->head != NULL )
                {
                        if(P1.coeffs->head == NULL)
                        {
                                while(P2.coeffs->head != NULL)
                                {
                                        llist_append(subtraction.coeffs,(-1)*P2.coeffs->head->data);
                                        llist_append(subtraction.exponents,P2.exponents->head->data);
                                        P2.coeffs->head = P2.coeffs->head->next ;
                                        P2.exponents->head = P2.exponents->head->next ;
                                }
                        }
                        else if(P2.coeffs->head == NULL)
                        {
                                while(P1.coeffs->head != NULL)
                                {
                                        llist_append(subtraction.coeffs,P1.coeffs->head->data);
                                        llist_append(subtraction.exponents,P1.exponents->head->data);
                                        P1.coeffs->head = P1.coeffs->head->next ;
                                        P1.exponents->head = P1.exponents->head->next ;
                                }
                        }
                        else
                        {
                                if(P1.exponents->head->data > P2.exponents->head->data)
                                {
                                        llist_append(subtraction.coeffs,(-1)*P2.coeffs->head->data);
                                        llist_append(subtraction.exponents,P2.exponents->head->data);
                                        P2.coeffs->head = P2.coeffs->head->next ;
                                        P2.exponents->head = P2.exponents->head->next ;
                                                                        
                                }
                                else if(P2.exponents->head->data > P1.exponents->head->data)  
                                {
                                        llist_append(subtraction.coeffs,P1.coeffs->head->data);
                                        llist_append(subtraction.exponents,P1.exponents->head->data);
                                        P1.coeffs->head = P1.coeffs->head->next ;
                                        P1.exponents->head = P1.exponents->head->next ;                                
                                }
                                else
                                {
                                        llist_append(subtraction.coeffs,P1.coeffs->head->data - P2.coeffs->head->data);
                                        llist_append(subtraction.exponents,P1.exponents->head->data);
                                        P1.coeffs->head = P1.coeffs->head->next ;
                                        P1.exponents->head = P1.exponents->head->next ;                                        
                                        P2.coeffs->head = P2.coeffs->head->next ;
                                        P2.exponents->head = P2.exponents->head->next ;                                        
                                }                                
                        }                        
                }
        return subtraction ;
        }
                
}

//Multiply 2 poly
Polynomial multiply(Polynomial P1, Polynomial P2)
{
        Polynomial mult;
        Polynomial temp1;

        //Create LL for storing answer
        mult.exponents = llist_new();
        mult.coeffs = llist_new();        

        //Store headptr of 1 polynomial
	Node *temp_exp_head = P2.exponents->head ;
	Node *temp_coeff_head = P2.coeffs->head ;

	//store headptr of both answer LL
        Node *temp_exp_mult = mult.exponents->head ;
        Node *temp_coeff_mult = mult.coeffs->head ;
        
        
        int exp=0,index=0,combined_coeff=0;
        int i,j;
        //Store length of 1st LL        
        int length1 = llist_size(P1.exponents); 
        
        if(P1.coeffs->head == NULL || P2.coeffs->head == NULL)
        {
        }
        else//Execute only if neither LL is empty
        {
                //Iterate over every ele in poly1
                for(i=0;i<length1;i++)
                {                
                        //Initialize and reate temporary polynomial        
                        temp1.exponents = llist_new();
                        temp1.coeffs = llist_new();
                        //Initialize pointers
                	temp_exp_head = P2.exponents->head ;
                	temp_coeff_head = P2.coeffs->head ;
                        
                                                
                        for(j=0;j<llist_size(P2.exponents);j++)
                        {
                                //store result of mult of 2 monomials
                                exp = P1.exponents->head->data + temp_exp_head->data ; 
                                combined_coeff = P1.coeffs->head->data * temp_coeff_head->data ;
                                
                                //Result can be simply appended while keeping order as lists are sorted 
                                llist_append(temp1.exponents,exp);
                                llist_append(temp1.coeffs,combined_coeff);
                                
                                //Increment pointers - inner loop                                                                                                
                                temp_exp_head = temp_exp_head->next ;
                                temp_coeff_head = temp_coeff_head->next;                                                                               
                        }
                        //Add temporary result to final answer and accumulate ans in mult
                        mult = add(mult,temp1) ;
                        //Incrment pointers - outer loop
                        P1.exponents->head = P1.exponents->head->next ;
                        P1.coeffs->head = P1.coeffs->head->next ;
                }                                                            
                
                //2 free statements removed                
                                     
                return mult;        
        }        
        
}

//Evaluate poly value at given variable value
long long int evaluate(Polynomial p, int k)
{
        //store head of LLs of poly
        Node *temp_exp_head = p.exponents->head ;
        Node *temp_coeff_head = p.coeffs->head ;        
        
        long long int answer = 0;
        int i;
        //Traverse through list and accumulate answer
        for(i=0;i<llist_size(p.coeffs);i++)
        {
                answer = answer + ((temp_coeff_head->data) * (long long int)pow(k,temp_exp_head->data));
                temp_exp_head = temp_exp_head->next ;
                temp_coeff_head = temp_coeff_head->next ;                
        }
        return answer ;
}
