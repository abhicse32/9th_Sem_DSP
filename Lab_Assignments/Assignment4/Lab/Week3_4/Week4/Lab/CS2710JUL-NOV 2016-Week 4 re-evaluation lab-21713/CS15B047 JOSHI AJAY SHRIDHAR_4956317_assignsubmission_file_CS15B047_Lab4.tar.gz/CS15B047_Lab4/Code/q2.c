#include<stdio.h>
#include<stdlib.h>
#include "Polynomial.h"

int main()
{
        int option;        
        int num_terms;
        int i;
	int num_terms1,num_terms2;
	int exp,coeff;
        int var_value ;
	int degree;                        
	Polynomial P1,P2,P ;
	
	//Take input option
	scanf("%d",&option);      
	
	while(option!=-1)//option = -1 -->termination
	{
	
	        /*
	        1-->print poly
	        2-->print degree of poly
	        3-->add 2 poly
	        4-->subtract 2 poly (P1-P2)
	        5-->multiply 2 poly
	        6-->print poly value at given variable value
	        */
                if(option==1 || option == 2 || option == 6)
                {
                        scanf("%d",&num_terms);		        
	                P.exponents = llist_new();
                	P.coeffs = llist_new();
		
	                for(i=0;i<num_terms;i++)
	                {
	                        scanf("%d",&exp);
	                        llist_append(P.exponents,exp);	        
	                }
	                for(i=0;i<num_terms;i++)
	                {
	                        scanf("%d",&coeff);
	                        llist_append(P.coeffs,coeff);	        
	                }        
	                
	                if(option == 1)	        
	                        print_polynomial(P);
	                
	                else if(option ==2)
	                {
	                        printf("%d\n",get_degree(P));               
	                }	        
	                
	                if(option == 6)
	                {
                                scanf("%d",&var_value);
                                printf("%lld\n",evaluate(P,var_value));
	                }
                }
                
                else
                {
                        scanf("%d",&num_terms1);
		
	                P1.exponents = llist_new();
	                P1.coeffs = llist_new();
		
	                for(i=0;i<num_terms1;i++)
	                {
	                        scanf("%d",&exp);
	                        llist_append(P1.exponents,exp);	        
	                }

	                for(i=0;i<num_terms1;i++)
	                {
	                        scanf("%d",&coeff);
	                        llist_append(P1.coeffs,coeff);	        
	                }
	
	                scanf("%d",&num_terms2);
	
	                P2.exponents = llist_new();
	                P2.coeffs = llist_new();
		
	                for(i=0;i<num_terms2;i++)
	                {
	                        scanf("%d",&exp);
	                        llist_append(P2.exponents,exp);	        	                        
	                }

	                for(i=0;i<num_terms2;i++)
	                {
	                        scanf("%d",&coeff);
	                        llist_append(P2.coeffs,coeff);	        	                        
	                }
	                
	                if(option == 3)
	                {
                        	print_polynomial(add(P1,P2));	                
	                }
	                else if(option == 4)
	                {
                        	print_polynomial(subtract(P1,P2));
	                }
	                else
	                {
                        	print_polynomial(multiply(P1,P2));
	                }
	                	        	                
                }
                
                scanf("%d",&option);      
                
        }        
        free(P.exponents);
        free(P.coeffs);
        free(P2.exponents);
        free(P2.coeffs);
        free(P1.exponents);
        free(P1.coeffs);
	
}
