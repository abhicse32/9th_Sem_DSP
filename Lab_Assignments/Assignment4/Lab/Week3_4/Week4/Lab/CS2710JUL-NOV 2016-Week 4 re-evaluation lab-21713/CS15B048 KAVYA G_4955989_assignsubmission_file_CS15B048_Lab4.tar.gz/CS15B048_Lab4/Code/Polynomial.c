#include<stdio.h>
#include<math.h>
#include<stdlib.h>
#include "Polynomial.h"

int get_degree(Polynomial P){
  // Returns last exponent since they are in ascending order
  return llist_get(P.exponents, llist_size(P.exponents) - 1); 
}

void print_polynomial(Polynomial P){

  if(P.exponents->head == NULL){
	printf("\n");
	return;
  }

  int flag = 0;// To check if it is the first time it is printing or not in while loop

  //Special case for the element of exponent 0 since it should be printed differently
  if(P.exponents->head->data == 0){
	// To show that the first element has been printed
	flag = 1;
	if(P.coeffs->head->data < 0)
	  printf("-%d ", -1*P.coeffs->head->data);
	else {
	  printf("%d ", P.coeffs->head->data);
	}
	if(P.exponents->head->next != NULL){
	  P.exponents->head = P.exponents->head->next;
	  P.coeffs->head = P.coeffs->head->next;
	}
	else{
	  printf("\n");
	  return;
	}

	// Code to print x^1 as just x which was not required
	/*
	if(P.exponents->head->data == 1){
	  if(P.coeffs->head->data < 0)
		printf(" - %dx", -1*P.coeffs->head->data);
	  else {
		printf(" + %dx", P.coeffs->head->data);
	  }
	  if(P.exponents->head->next != NULL){
		P.exponents->head = P.exponents->head->next;
		P.coeffs->head = P.coeffs->head->next;
	  }
	  else{
		printf("\n");
		return;
	  }
	}
  */
  }
  // Code to print x^1 as just x which was not required
  /*
  if(P.exponents->head->data == 1){
	if(P.coeffs->head->data < 0)
	  printf("- %dx", -1*P.coeffs->head->data);
	else {
	  printf("%dx", P.coeffs->head->data);
	}
	if(P.exponents->head->next != NULL){
	  P.exponents->head = P.exponents->head->next;
	  P.coeffs->head = P.coeffs->head->next;
	}
	else{
	  printf("\n");
	  return;
	}
  }
  */
  while(P.exponents->head != NULL){
	if(P.coeffs->head->data < 0){
	  // Check if this is the first element to be printed which is special case and has different arrangement of spaces
	  if(flag == 0){
		printf("-%dx^%d ", -1*P.coeffs->head->data, P.exponents->head->data);
		flag = 1;
	  }
	  else
		printf("- %dx^%d ", -1*P.coeffs->head->data, P.exponents->head->data);
	}
	else {
	  // Check if this is the first element to be printed which is special case and has different arrangement of spaces
	  if(flag == 0){
		printf("%dx^%d ", P.coeffs->head->data, P.exponents->head->data);
		flag = 1;
	  }
	  else 
		printf("+ %dx^%d ", P.coeffs->head->data, P.exponents->head->data);
	}
	P.exponents->head = P.exponents->head->next;
	P.coeffs->head = P.coeffs->head->next;
  }
  printf("\n");
}

Polynomial add(Polynomial P1, Polynomial P2){
  Polynomial result;
  result.exponents = llist_new();
  result.coeffs = llist_new();

  // When one of them is null return the other
  if(P1.exponents->head == NULL)
	return P2;
  if(P2.exponents->head == NULL)
	return P1;

  while(P1.exponents->head != NULL && P2.exponents->head != NULL){
	// If first has lower exponent then use as it is and increment that pointer
	if(P1.exponents->head->data < P2.exponents->head->data){
	  llist_append(result.exponents, P1.exponents->head->data);
	  llist_append(result.coeffs, P1.coeffs->head->data);
	  P1.exponents->head = P1.exponents->head->next;
	  P1.coeffs->head = P1.coeffs->head->next;
	}
	// If second has lower exponent then use as it is and increment that pointer
	else if(P2.exponents->head->data < P1.exponents->head->data){
	  llist_append(result.exponents, P2.exponents->head->data);
	  llist_append(result.coeffs, P2.coeffs->head->data);
	  P2.exponents->head = P2.exponents->head->next;
	  P2.coeffs->head = P2.coeffs->head->next;
	}
	// If both have same exponents then add coefficients and increment both pointers
	else if(P1.exponents->head->data == P2.exponents->head->data){
	  if(P1.coeffs->head->data != -1*P2.coeffs->head->data){
		llist_append(result.exponents, P1.exponents->head->data);
		llist_append(result.coeffs, P1.coeffs->head->data + P2.coeffs->head->data);
	  }
	  P1.exponents->head = P1.exponents->head->next;
	  P1.coeffs->head = P1.coeffs->head->next;
	  P2.exponents->head = P2.exponents->head->next;
	  P2.coeffs->head = P2.coeffs->head->next;
	}
  }

  // If first has more elements then leftover elements are automatically transferred as they are
  while(P1.exponents->head != NULL){
	llist_append(result.exponents, P1.exponents->head->data);
	llist_append(result.coeffs, P1.coeffs->head->data);
	P1.exponents->head = P1.exponents->head->next;
	P1.coeffs->head = P1.coeffs->head->next;
  }

  // If second has more elements then leftover elements are automatically transferred as they are
  while(P2.exponents->head != NULL){
	llist_append(result.exponents, P2.exponents->head->data);
	llist_append(result.coeffs, P2.coeffs->head->data);
	P2.exponents->head = P2.exponents->head->next;
	P2.coeffs->head = P2.coeffs->head->next;
  }

  return result;

}

Polynomial subtract(Polynomial P1, Polynomial P2){
  Polynomial result;
  result.exponents = llist_new();
  result.coeffs = llist_new();

  // If second is null then answer is first
  if(P2.exponents->head == NULL)
	return P1;

  while(P1.exponents->head != NULL && P2.exponents->head != NULL){
	// If first has lower exponent then use as it is and increment the pointer
	if(P1.exponents->head->data < P2.exponents->head->data){
	  llist_append(result.exponents, P1.exponents->head->data);
	  llist_append(result.coeffs, P1.coeffs->head->data);
	  P1.exponents->head = P1.exponents->head->next;
	  P1.coeffs->head = P1.coeffs->head->next;
	}
	// If second has lower exponent use its negative and increment the pointer
	else if(P2.exponents->head->data < P1.exponents->head->data){
	  llist_append(result.exponents, P2.exponents->head->data);
	  llist_append(result.coeffs, -1*P2.coeffs->head->data);
	  P2.exponents->head = P2.exponents->head->next;
	  P2.coeffs->head = P2.coeffs->head->next;
	}
	// If both have same exponent then subtract and use and increment both pointers
	else if(P1.exponents->head->data == P2.exponents->head->data){
	  if(P1.coeffs->head->data != P2.coeffs->head->data){
		llist_append(result.exponents, P1.exponents->head->data);
		llist_append(result.coeffs, P1.coeffs->head->data - P2.coeffs->head->data);
	  }
	  P1.exponents->head = P1.exponents->head->next;
	  P1.coeffs->head = P1.coeffs->head->next;
	  P2.exponents->head = P2.exponents->head->next;
	  P2.coeffs->head = P2.coeffs->head->next;
	}
  }

  // If first has more elements then leftover elements are automatically transferred as they are
  while(P1.exponents->head != NULL){
	llist_append(result.exponents, P1.exponents->head->data);
	llist_append(result.coeffs, P1.coeffs->head->data);
	P1.exponents->head = P1.exponents->head->next;
	P1.coeffs->head = P1.coeffs->head->next;
  }

  // If second has more elements then leftover elements are automatically transferred as their negative
  while(P2.exponents->head != NULL){
	llist_append(result.exponents, P2.exponents->head->data);
	llist_append(result.coeffs, -1*P2.coeffs->head->data);
	P2.exponents->head = P2.exponents->head->next;
	P2.coeffs->head = P2.coeffs->head->next;
  }
  return result;

}

Polynomial multiply(Polynomial P1, Polynomial P2){
  Polynomial result;
  Polynomial temp;
  result.exponents = llist_new();
  result.coeffs = llist_new();
  Node *npe = (Node*) malloc(sizeof(Node*));
  Node *npc = (Node*) malloc(sizeof(Node*));
  /* Multiply individual value in first polynomial with entire of second polynomial by :
   * 1. Adding exponents
   * 2. Multiplying coefficients
   * Store the result in a temporary polynomial and add that to existing result
   */

  while(P1.exponents->head != NULL){
	npe = P2.exponents->head;
	npc = P2.coeffs->head;
	temp.exponents = llist_new();
	temp.coeffs = llist_new();

	while(npe != NULL){
	  llist_append(temp.exponents, P1.exponents->head->data + npe->data);
	  llist_append(temp.coeffs, P1.coeffs->head->data * npc->data);
	  npe = npe->next;
	  npc = npc->next;
	}
	result = add(result, temp);
	P1.exponents->head = P1.exponents->head->next;
	P1.coeffs->head = P1.coeffs->head->next;
  }
  return result;
}

long long int evaluate(Polynomial P, int k){
  long long int sum = 0; 
  while(P.exponents->head != NULL){
	/*
	if(P.exponents->head->data == 0){
	  sum += P.coeffs->head->data;
	  P.exponents->head = P.exponents->head->next;
	  P.coeffs->head = P.coeffs->head->next;
	}
	*/
	sum += P.coeffs->head->data * pow(k, P.exponents->head->data);
	P.exponents->head = P.exponents->head->next;
	P.coeffs->head = P.coeffs->head->next;
  }
  return sum;
}
