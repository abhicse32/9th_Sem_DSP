// Program to implement polynomial as a data structure using linked lists
// Author : G.Kavya CS15B048
// Date : 29.08.2016
#include<stdio.h>
#include<stdlib.h>
#include"Polynomial.h"

int main(){
  while(1){
	/* Choice is function to be called using the following list : 
	 * 1. Print polynomial
	 * 2. Find degree of polynomial
	 * 3. Add 2 polynomials
	 * 4. Subtract 2 polynomials
	 * 5. Multiply 2 polynomials
	 * 6. Evaluate polynomial at value k
	 */
	int choice;
	scanf("%d", &choice);
	if(choice == 1 || choice == 2){
	  Polynomial P;
	  P.exponents = llist_new();
	  P.coeffs = llist_new();
	  int t, i = 0, num;
	  scanf("%d", &t);
	  for(i = 0; i < t; i++){
		scanf("%d", &num);
		llist_append(P.exponents, num);
	  }
	  for(i = 0; i < t; i++){
		scanf("%d", &num);
		llist_append(P.coeffs, num);
	  }
	  if(choice == 1)
		print_polynomial(P);
	  else 
		printf("%d\n", get_degree(P));
	}

	if(choice == 3 || choice == 4 || choice == 5){
	  Polynomial P1, P2, P3;
	  P1.exponents = llist_new();
	  P1.coeffs = llist_new();
	  P2.exponents = llist_new();
	  P2.coeffs = llist_new();
	  P3.exponents = llist_new();
	  P3.coeffs = llist_new();

	  int t1, t2, num, i = 0;
	  scanf("%d", &t1);
	  for(i = 0; i < t1; i++){
		scanf("%d", &num);
		llist_append(P1.exponents, num);
	  }
	  for(i = 0; i < t1; i++){
		scanf("%d", &num);
		llist_append(P1.coeffs, num);
	  }

	  scanf("%d", &t2);

	  for(i = 0; i < t2; i++){
		scanf("%d", &num);
		llist_append(P2.exponents, num);
	  }
	  for(i = 0; i < t2; i++){
		scanf("%d", &num);
		llist_append(P2.coeffs, num);
	  }

	  if(choice == 3){
		P3 = add(P1, P2);
	  }
	  if(choice == 4)
		P3 = subtract(P1, P2);
	  if(choice == 5)
		P3 = multiply(P1, P2);
	  print_polynomial(P3);
	}
	if(choice == 6){
	  Polynomial P;
	  P.exponents = llist_new();
	  P.coeffs = llist_new();
	  int t, i = 0, num, k;
	  scanf("%d", &t);
	  for(;i < t; i++){
		scanf("%d", &num);
		llist_append(P.exponents, num);
	  }
	  while(t-- >= 1){
		scanf("%d", &num);
		llist_append(P.coeffs, num);
	  }
	  scanf("%d", &k);// Value of variable where polynomial is evaluated
	  printf("%lld\n", evaluate(P, k));

	}
	if(choice == -1)
	  break;
  }
	return 0;
  }
