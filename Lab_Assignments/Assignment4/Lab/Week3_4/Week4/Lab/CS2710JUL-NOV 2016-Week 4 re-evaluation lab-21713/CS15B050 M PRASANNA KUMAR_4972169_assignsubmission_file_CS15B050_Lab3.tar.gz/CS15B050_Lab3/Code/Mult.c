#include <stdlib.h>
#include <stdio.h>

typedef struct Node_ Node;
struct Node_ {
    int data;
    Node* next;
};

typedef struct LList_ {
    Node* head;
} LList;

typedef struct Polynomial_lst{
	LList* exponents;
	LList* coeffs;
}Polynomial;

Node* node_new (int data)
{
    Node* temp = (Node*)malloc(sizeof(Node));
    temp->data = data;
    temp->next = NULL;
    return temp;
}

LList* llist_new()
{
    LList* temp = (LList*)malloc(sizeof(LList));
    temp->head = NULL;
    return temp;
}

void llist_append( LList* lst, int data )
{
    Node* newNode = node_new(data);
    Node* temp = lst->head;
    if(temp == NULL)
    {
        lst->head = newNode;
        newNode->next = NULL;
    }
    else
    {
        while(temp->next!=NULL)
        {
            temp=temp->next;
        }
        temp->next = newNode;
        newNode->next = NULL;
    }
}

void print_polynomial(Polynomial p)
{
    Node* temp_exp = p.exponents->head;
    Node* temp_coeffs = p.coeffs->head;
    while(temp_exp!=NULL)
    {     
        if(temp_exp->next == NULL)
        {
            if(temp_exp->data != 0)
            {
                printf("%dx^%d",abs(temp_coeffs->data), temp_exp->data);
            }
            else
            {
                printf("%d",abs(temp_coeffs->data));
            }
        }
        else
        {   
            if(temp_coeffs->next->data >=0)
            {
                if(temp_exp-> data != 0)
                {
                    printf("%dx^%d + ",abs(temp_coeffs->data), temp_exp->data);
                }
                else
                {
                    printf("%d + ",abs(temp_coeffs->data));
                }
            }
            else
            {
                if(temp_exp-> data != 0)
                {
                    printf("%dx^%d - ",abs(temp_coeffs->data), temp_exp->data);
                }
                else
                {
                    printf("%d - ",abs(temp_coeffs->data));
                }
            }
        }
        temp_exp = temp_exp->next;
        temp_coeffs = temp_coeffs->next;
    }
}

Polynomial add(Polynomial P1, Polynomial P2)
{
        Polynomial addition ;
        //LL creation
        addition.exponents = llist_new();        
        addition.coeffs = llist_new();        

        //Check for empty polynomials
	if(P1.coeffs->head == NULL)
	        return P2 ;
        else if(P2.coeffs->head == NULL)
                return P1 ;
        else
        {
                while(P1.coeffs->head != NULL || P2.coeffs->head != NULL )
                {
                        //If 1 list finishes copy other list into answer polynomial 
                        if(P1.coeffs->head == NULL)
                        {
                                while(P2.coeffs->head != NULL)
                                {
                                        llist_append(addition.coeffs,P2.coeffs->head->data);
                                        llist_append(addition.exponents,P2.exponents->head->data);
                                        P2.coeffs->head = P2.coeffs->head->next ;
                                        P2.exponents->head = P2.exponents->head->next ;
                                }
                        }
                        else if(P2.coeffs->head == NULL)
                        {
                                while(P1.coeffs->head != NULL)
                                {
                                        llist_append(addition.coeffs,P1.coeffs->head->data);
                                        llist_append(addition.exponents,P1.exponents->head->data);
                                        P1.coeffs->head = P1.coeffs->head->next ;
                                        P1.exponents->head = P1.exponents->head->next ;
                                }
                        }
                        else
                        {
                                //Result poly to be sorted in asc order of exponent,so lower exp term goes first
                                if(P1.exponents->head->data > P2.exponents->head->data)
                                {
                                        llist_append(addition.coeffs,P2.coeffs->head->data);
                                        llist_append(addition.exponents,P2.exponents->head->data);
                                        P2.coeffs->head = P2.coeffs->head->next ;
                                        P2.exponents->head = P2.exponents->head->next ;
                                                                        
                                }
                                else if(P2.exponents->head->data > P1.exponents->head->data)  
                                {
                                        llist_append(addition.coeffs,P1.coeffs->head->data);
                                        llist_append(addition.exponents,P1.exponents->head->data);
                                        P1.coeffs->head = P1.coeffs->head->next ;
                                        P1.exponents->head = P1.exponents->head->next ;                                
                                }
                                //Add coeffs if same exponent
                                else
                                {
                                        llist_append(addition.coeffs,P1.coeffs->head->data + P2.coeffs->head->data);
                                        llist_append(addition.exponents,P1.exponents->head->data);
                                        P1.coeffs->head = P1.coeffs->head->next ;
                                        P1.exponents->head = P1.exponents->head->next ;                                        
                                        P2.coeffs->head = P2.coeffs->head->next ;
                                        P2.exponents->head = P2.exponents->head->next ;                                        
                                }                                
                        }                        
                }
        return addition ;
        }
                
}


Polynomial multiply(Polynomial p1, Polynomial p2)
{
	Polynomial C;

	C.exponents=llist_new();
	C.coeffs=llist_new();
	Node* ptr1;
	ptr1=p1.exponents->head;
	Node* ptr2;
	ptr2=p1.coeffs->head;
	Node* ptr3;
	ptr3=p2.exponents->head;
	Node* ptr4;
	ptr4=p2.coeffs->head;
	Polynomial D;
	D.exponents=llist_new();
	D.coeffs=llist_new();


	while(ptr3!=NULL) 
	{
		llist_append(C.exponents,ptr1->data + ptr3->data);
		llist_append(C.coeffs,ptr2->data * ptr4->data);
		ptr3=ptr3->next;
		ptr4=ptr4->next;
	}
	ptr3=p2.exponents->head;
	ptr4=p2.coeffs->head;
	
	ptr1=ptr1->next;
	ptr2=ptr2->next;

	while(ptr1!=NULL)
	{
		while(ptr3!=NULL)
		{
			llist_append(D.exponents,ptr1->data + ptr3->data);
			llist_append(D.coeffs,ptr2->data * ptr4->data);
			C=add(C,D);
			ptr3=ptr3->next;
			ptr4=ptr4->next;
		}
		ptr3=p2.exponents->head;
		ptr4=p2.coeffs->head;
		ptr1=ptr1->next;
		ptr2=ptr2->next;
	}
	
	
	return C;
}

int main()
{
	int t;
    scanf("%d",&t);
    Polynomial temp1,temp2;
    temp1.exponents=llist_new();
    temp1.coeffs=llist_new();
    temp2.exponents=llist_new();
    temp2.coeffs=llist_new();
    int i=t;
    while(i>0)
    {
        int k;
        scanf("%d",&k);
        llist_append(temp1.exponents, k);
        i--;
    }
    i=t;
    while(i>0)
    {
        int k;
        scanf("%d",&k);
        llist_append(temp1.coeffs, k);
        i--;
    }
    scanf("%d",&t);
    i=t;
    while(i>0)
    {
        int k;
        scanf("%d",&k);
        llist_append(temp2.exponents, k);
        i--;
    }
    i=t;
    while(i>0)
    {
        int k;
        scanf("%d",&k);
        llist_append(temp2.coeffs, k);
        i--;
    }
	print_polynomial(multiply(temp1, temp2));
	return 0;
}
