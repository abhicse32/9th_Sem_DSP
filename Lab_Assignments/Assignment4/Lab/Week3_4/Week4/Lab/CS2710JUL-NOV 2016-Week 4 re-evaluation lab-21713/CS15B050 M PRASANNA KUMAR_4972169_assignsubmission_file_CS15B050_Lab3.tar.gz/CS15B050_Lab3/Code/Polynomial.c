#include "Polynomial.h"
#include<math.h>
#include<stdlib.h>
#include<stdio.h>
int get_degree(Polynomial A)																		//Finds the degree of polynomial
{
	Node* temp;
	temp=A.exponents->head;
	if(temp== NULL) return -1;
	else if(temp->next==NULL) return temp->data;
	else
	{
		while(temp->next!=NULL) temp=temp->next;
		return (temp->data);																		//As it is in ascending order last element is degree
	}
}

void print_polynomial(Polynomial A)																	//Prints the polynomial
{
	Node* temp1;
	temp1=A.exponents->head;																		//Pointer for Exponents list
	Node* temp2;
	temp2=A.coeffs->head;																			//Pointer for coeffs list
	if(temp1==NULL || temp2==NULL) return;															//If either of the list is empty
	while(temp1!=NULL)
	{				
		if(temp1->data==0)																			
		{
			printf("%d ",temp2->data);																//If exponent is 0 print a0
		}
		else 																						
		{
			if(temp2->data<0)																		
			{																						//
		        if(temp1!= A.exponents->head) printf("- %dx^%d ",(temp2->data)*-1,temp1->data);		//Neat presentation
			    else printf("-%dx^%d ",(temp2->data)*-1,temp1->data);				                //
			}																						
			else if(temp2->data > 0)
			{																						//
			    if(temp1 != A.exponents->head) printf("+ %dx^%d ",(temp2->data),temp1->data);		//Neat presentation
			    else printf("%dx^%d ",(temp2->data),temp1->data);									//
			}
		}
		temp1=temp1->next;
		temp2=temp2->next;
	}	
	printf("\n");
}

Polynomial add(Polynomial A, Polynomial B)															//Adds the two polynomials
{
	Polynomial C;																					//The output list
	C.exponents=llist_new();																		
	C.coeffs=llist_new();
	Node* ptr1;
	ptr1=A.exponents->head;
	Node* ptr2;
	ptr2=A.coeffs->head;
	Node* ptr3;
	ptr3=B.exponents->head;
	Node* ptr4;
	ptr4=B.coeffs->head;
	while(ptr1!=NULL && ptr3!=NULL)																	//Loop till either of the list terminates
	{
		if(ptr1->data < ptr3->data) 																//Exponent1 is lesser
		{
			llist_append(C.exponents,ptr1->data);
			llist_append(C.coeffs,ptr2->data);
			
			ptr1 = ptr1->next;
			ptr2 = ptr2->next;
		}
		else if(ptr1->data==ptr3->data)																//Exponents are equal
		{
			llist_append(C.exponents,ptr1->data);
			llist_append(C.coeffs,ptr2->data + ptr4->data);
			
			ptr1 = ptr1->next;
			ptr2 = ptr2->next;
			ptr3 = ptr3->next;
			ptr4 = ptr4->next;
		}
		else																						//Exponent2 is lesser
		{
			llist_append(C.exponents,ptr3->data);
			llist_append(C.coeffs,ptr4->data);
			
			ptr3=ptr3->next;
			ptr4=ptr4->next;
		}
	}
	while(ptr1!=NULL)																				//Appending the remaining list elements if any
	{
		llist_append(C.exponents,ptr1->data);
		llist_append(C.coeffs,ptr2->data);
			
		ptr1 = ptr1->next;
		ptr2 = ptr2->next;
	}
	while(ptr3!=NULL)																				//Appending the remaining list elements if any
	{
		llist_append(C.exponents,ptr3->data);
		llist_append(C.coeffs,ptr4->data);
			
		ptr3=ptr3->next;
		ptr4=ptr4->next;
	}
	return C;
}

Polynomial subtract(Polynomial A, Polynomial B)														//Subtracts second polynomial from first
{
	Polynomial C;																					//The output list
	C.exponents=llist_new();																		
	C.coeffs=llist_new();
	Node* ptr1;
	ptr1=A.exponents->head;
	Node* ptr2;
	ptr2=A.coeffs->head;
	Node* ptr3;
	ptr3=B.exponents->head;
	Node* ptr4;
	ptr4=B.coeffs->head;
	while(ptr1!=NULL && ptr3!=NULL)																	//Loop till either of the list terminates
	{
		if(ptr1->data < ptr3->data) 																//Exponent1 is lesser
		{
			llist_append(C.exponents,ptr1->data);
			llist_append(C.coeffs,ptr2->data);
			
			ptr1 = ptr1->next;
			ptr2 = ptr2->next;
		}
		else if(ptr1->data==ptr3->data)																//Exponents are equal
		{
			llist_append(C.exponents,ptr1->data);
			llist_append(C.coeffs,ptr2->data - ptr4->data);
			
			ptr1 = ptr1->next;
			ptr2 = ptr2->next;
			ptr3 = ptr3->next;
			ptr4 = ptr4->next;
		}
		else																						//Exponent2 is lesser
		{
			llist_append(C.exponents,ptr3->data);
			llist_append(C.coeffs,-(ptr4->data));
			
			ptr3=ptr3->next;
			ptr4=ptr4->next;
		}
	}
	while(ptr1!=NULL)																				//Appending the remaining list elements if any
	{
		llist_append(C.exponents,ptr1->data);
		llist_append(C.coeffs,ptr2->data);
			
		ptr1 = ptr1->next;
		ptr2 = ptr2->next;
	}
	while(ptr3!=NULL)																				//Appending the remaining list elements if any
	{
		llist_append(C.exponents,ptr3->data);
		llist_append(C.coeffs,-(ptr4->data));
			
		ptr3=ptr3->next;
		ptr4=ptr4->next;
	}
	return C;
}

long long int evaluate(Polynomial A, int k)															//Evaluates function value at k
{
	Node* temp1;
	temp1=A.exponents->head;
	Node* temp2;
	temp2=A.coeffs->head;
	long long int sum=0;																			//Function value
	if(temp1== NULL || temp2==NULL) return -1;
	while(temp1!=NULL)
	{
		sum+=(temp2->data)*pow(k,temp1->data);														//Evaluating it separately
		temp1=temp1->next;
		temp2=temp2->next;
	}
	return sum;
}

Polynomial multiply(Polynomial p1, Polynomial p2)													//Multiplies two polynomials
{
	Polynomial C;																					//The output list
	C.exponents=llist_new();																		
	C.coeffs=llist_new();																			
	Node* ptr1;
	ptr1=p1.exponents->head;
	Node* ptr2;
	ptr2=p1.coeffs->head;
	Node* ptr3;
	ptr3=p2.exponents->head;
	Node* ptr4;
	ptr4=p2.coeffs->head;
	Polynomial D;																					//Temporary list
	if(ptr1==NULL) return p2;
	else if(ptr2==NULL) return p1;
	else
	{
		while(ptr3!=NULL)																				//Base case 
		{
			llist_append(C.exponents,ptr1->data + ptr3->data);
			llist_append(C.coeffs,ptr2->data * ptr4->data);
			ptr3=ptr3->next;
			ptr4=ptr4->next;
		}
		ptr3=p2.exponents->head;
		ptr4=p2.coeffs->head;
		
		ptr1=ptr1->next;
		ptr2=ptr2->next;

		while(ptr1!=NULL)																				//Loop till ptr1 is equal to NULL
		{
			D.exponents=llist_new();
			D.coeffs=llist_new();
			while(ptr3!=NULL)																			//Loop till ptr2 is equal to NULL
			{
				llist_append(D.exponents,ptr1->data + ptr3->data);
				llist_append(D.coeffs,ptr2->data * ptr4->data);
				
				ptr3=ptr3->next;
				ptr4=ptr4->next;
			}
			C=add(C,D);																					//Add the polynomials after multiplying in each step
			ptr3=p2.exponents->head;
			ptr4=p2.coeffs->head;
			ptr1=ptr1->next;
			ptr2=ptr2->next;
		}
		return C;
	}
}
