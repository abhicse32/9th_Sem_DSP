#include<stdio.h>
#include<stdlib.h>
#include"Polynomial.h"
void Print();														//
void Degree();														//
void Add();															//Function
void Sub();															//Declarations
void Multiply();													//
void Evaluate();													//
int main()											
{
	int choice;
	
	do
	{
		scanf("%d",&choice);										//Choice of user
		switch(choice)
		{
			case 1:	Print();
					break;
			case 2: Degree();
					break;
			case 3: Add();
					break;
			case 4: Sub();
					break;
			case 5: Multiply();
					break;
			case 6: Evaluate();
					break;
			default: break;
		}
	}while(choice!=-1);
	return 0;
}

void Print()
{
	int t;															//No. of elements in the polynomial
	scanf("%d",&t);
	Polynomial A;
	A.exponents=llist_new();
	A.coeffs=llist_new();
	int temp;
	int i;
	for(i=1;i<=t;i++) 
	{
		scanf("%d",&temp);											//Reading the exponent's list elements
		llist_append(A.exponents,temp);
	}
	for(i=1;i<=t;i++) 
	{
		scanf("%d",&temp);											//Reading the coeffecient's list elements
		llist_append(A.coeffs,temp);
	}
	print_polynomial(A);											//Function Call
}

void Degree()
{
	int t;
	scanf("%d",&t);													//No. of elements in the polynomial
	Polynomial A;
	A.exponents=llist_new();
	A.coeffs=llist_new();
	int temp;
	int i;
	for(i=1;i<=t;i++) 
	{
		scanf("%d",&temp);
		llist_append(A.exponents,temp);
	}
	for(i=1;i<=t;i++) 
	{
		scanf("%d",&temp);
		llist_append(A.coeffs,temp);
	}
	printf("%d\n",get_degree(A));									//Function Call
}

void Add()															
{
	int t1,t2;														
	scanf("%d",&t1);												//No. of elements in polynomial 1
	Polynomial A,B;
	A.exponents=llist_new();
	A.coeffs=llist_new();
	B.exponents=llist_new();
	B.coeffs=llist_new();
	int temp;
	int i;
	for(i=1;i<=t1;i++) 
	{
		scanf("%d",&temp);
		llist_append(A.exponents,temp);
	}
	for(i=1;i<=t1;i++) 
	{
		scanf("%d",&temp);
		llist_append(A.coeffs,temp);
	}
	scanf("%d",&t2);												//No. of elements in polynomial 2
	for(i=1;i<=t2;i++) 
	{
		scanf("%d",&temp);
		llist_append(B.exponents,temp);
	}
	for(i=1;i<=t2;i++) 
	{
		scanf("%d",&temp);
		llist_append(B.coeffs,temp);
	}
	print_polynomial(add(A,B));										//Function Call
}

void Sub()
{
	int t1,t2;														
	scanf("%d",&t1);												//No. of elements in polynomial 1
	Polynomial A,B;
	A.exponents=llist_new();
	A.coeffs=llist_new();
	B.exponents=llist_new();
	B.coeffs=llist_new();
	int temp;
	int i;
	for(i=1;i<=t1;i++) 
	{
		scanf("%d",&temp);
		llist_append(A.exponents,temp);
	}
	for(i=1;i<=t1;i++) 
	{
		scanf("%d",&temp);
		llist_append(A.coeffs,temp);
	}
	scanf("%d",&t2);												//No. of elements in polynomial 2
	for(i=1;i<=t2;i++) 
	{
		scanf("%d",&temp);
		llist_append(B.exponents,temp);
	}
	for(i=1;i<=t2;i++) 
	{
		scanf("%d",&temp);
		llist_append(B.coeffs,temp);
	}
	print_polynomial(subtract(A,B));								//Function Call
}

void Multiply()
{
	int t1,t2;														
	scanf("%d",&t1);												//No. of elements in polynomial 1
	Polynomial A,B;
	A.exponents=llist_new();
	A.coeffs=llist_new();
	B.exponents=llist_new();
	B.coeffs=llist_new();
	int temp;
	int i;
	for(i=1;i<=t1;i++) 
	{
		scanf("%d",&temp);
		llist_append(A.exponents,temp);
	}
	for(i=1;i<=t1;i++) 
	{
		scanf("%d",&temp);
		llist_append(A.coeffs,temp);
	}
	scanf("%d",&t2);												//No. of elements in polynomial 2
	for(i=1;i<=t2;i++) 
	{
		scanf("%d",&temp);
		llist_append(B.exponents,temp);
	}
	for(i=1;i<=t2;i++) 
	{
		scanf("%d",&temp);
		llist_append(B.coeffs,temp);
	}
	print_polynomial(multiply(A,B));								//Function Call
}

void Evaluate()
{
	int t;
	scanf("%d",&t);													//No. of elements in the polynomial
	Polynomial A;
	A.exponents=llist_new();
	A.coeffs=llist_new();
	int temp;
	int i;
	for(i=1;i<=t;i++) 
	{
		scanf("%d",&temp);
		llist_append(A.exponents,temp);
	}
	for(i=1;i<=t;i++) 
	{
		scanf("%d",&temp);
		llist_append(A.coeffs,temp);
	}
	int key;
	scanf("%d",&key);												//Reading the variable 
	printf("%lld\n",(evaluate(A,key)));								//Printing the returned value
}