#include "Polynomial.h"
#include"List.h"
#include"List.c"
#include<stdio.h>
#include<math.h>
#include<stdlib.h>
/*function to return the degree of the polynomial*/
int get_degree(Polynomial P)
{
  Polynomial *p =&P;
  Node *a,*b,*c;
  a=p-> exponents -> head;
  b=p -> coeffs -> head;
  if(a==NULL&&b==NULL)
  {
    return;
  }
  else
  {
     int i;
     while(a!=NULL)
     {
       c=a;
       a=a->next;
     }
  }
  return (c -> data);
  /* Polynomial* p=&P;
  int i = llist_size( p->exponents );
  int r = llist_get( p->exponents , i-1 );
  return r; 8?
*/
}

// print Polynomial
void print_polynomial(Polynomial A)
{
   Node *a,*b,*c;
   Polynomial *p = &A;
   a=p-> exponents -> head;
   b=p-> coeffs -> head;
   if(a==NULL)
   {
      //printf("List is empty")
      return;
   }  
   else
   { 
       printf("%d",a->data);
       a=a->next;
       b=b->next;   
     while(a!=NULL && b!=NULL)
     {
        c=a->next;
       
        if(c==NULL)
        {
          printf("%dx^%d",a->data,b->data);
          return;
        }    
        printf("%dx^%d+",a->data,b->data);
        a=a->next;
        b=b->next;
     }
   }

}

/*Multiply two polynomials and return the result*/
Polynomial multiply(Polynomial A, Polynomial B)
{
  Polynomial *r;
  r= (Polynomial *) malloc(sizeof(Polynomial));
  x1= a -> coeffs -> head;
  x2= b -> coeffs ->head;
  x3= r -> coeffs ->head;
  y1 =a -> exponents ->head;
  y2 =b -> exponents->head;
  y3 =r -> exponents ->head;
  n1= llist_size( a->coeffs);
  n2= llist_size( b->coeffs );
   int i,j;
  for(i=1;i<=n1;i++)
  {
    for(j=1;j<=n2;j++)
    {
      x3->data=llist_get( A->coeffs, i)*llist_get( A->coeffs, i);
      y3->data=llist_get( A->exponents, i)+llist_get( A->exponents, i);
      x3=x3->next;
      y3=y3->next;
    }
  }
  
}
  /*Add two polynomials and return the result*/
Polynomial add(Polynomial A, Polynomial B)
{
  int n1,n2;
  Polynomial* a = &A;
  Polynomial* b = &B;
  Polynomial *r = (Polynomial *) malloc(sizeof(Polynomial));
  r->exponents = llist_new();
  r->coeffs = llist_new();
  Node *x1,*x2,*x3,*y1,*y2,*y3;
  x1= a -> coeffs -> head;
  x2= b -> coeffs ->head;
  x3= r -> coeffs ->head;
  y1 =a -> exponents ->head;
  y2 =b -> exponents->head;
  y3 =r -> exponents ->head;
  n1= llist_size( a -> coeffs  );
  n2= llist_size( b -> coeffs );
  
  while(y1 !=NULL || y2!=NULL)
  {
    if(y1->data==y2->data)
    {
      x3->data=x1->data + x2->data;
      y3->data=y1->data;
      x1=x1->next;
      x2=x2->next;
      y1=y1->next;
      y2=y2->next;
      x3=x3->next;
      y3=y3->next;
    }
    if(y1->data > y2->data)
    {
      x3->data=x2->data;
      y3->data=y2->data;
      x2=x2->next;
      y2=y2->next;
      x3=x3->next;
      y3=y3->next;
    }
    if(y1->data < y2->data)
    {
      x3->data=x1->data;
      y3->data=y1->data;
      x1=x1->next;
      y1=y1->next;
      x3=x3->next;
      y3=y3->next; 
    }
   if(y1==NULL);
   {
     while(y2!=NULL)
     {
      x3->data=x2->data;
      y3->data=y2->data;
      x2=x2->next;
      y2=y2->next;
      x3=x3->next;
      y3=y3->next; 
     }
   }
   if(y2==NULL);
   {
     while(y1!=NULL)
      {
      x3->data=x1->data;
      y3->data=y1->data;
      x1=x1->next;
      y1=y1->next;
      x3=x3->next;
      y3=y3->next; 
      }
   }
  return *r;
}
}

/*Subtract second Polynomial from first*/
Polynomial subtract(Polynomial p1, Polynomial p2)
{
  int n1,n2;
  Polynomial* a = &p1;
  Polynomial* b = &p2;
  Polynomial *r;
  r= (Polynomial *) malloc(sizeof(Polynomial));
  r->exponents = llist_new();
  r->coeffs = llist_new();
  LList *p,*q;
  Node *x1,*x2,*x3,*y1,*y2,*y3;
  x1= a -> coeffs -> head;
  x2= b -> coeffs ->head;
  x3= r -> coeffs ->head;
  y1 =a -> exponents ->head;
  y2 =b -> exponents->head;
  y3 =r -> exponents ->head;
  n1= llist_size( a -> coeffs);
  n2= llist_size( b -> coeffs );
  
  while(y1 !=NULL || y2!=NULL)
  {
    if(y1->data==y2->data)
    {
      x3->data=x1->data - x2->data;
      y3->data=y1->data;
      x1=x1->next;
      x2=x2->next;
      y1=y1->next;
      y2=y2->next;
      x3=x3->next;
      y3=y3->next;
    }
    if(y1->data > y2->data)
    {
      x3->data=-(x2->data);
      y3->data=-(y2->data);
      x2=x2->next;
      y2=y2->next;
      x3=x3->next;
      y3=y3->next;
    }
    if(y1->data < y2->data)
    {
      x3->data=x1->data;
      y3->data=y1->data;
      x1=x1->next;
      y1=y1->next;
      x3=x3->next;
      y3=y3->next; 
    }
   if(y1==NULL);
   {
     while(y2!=NULL)
     {
      x3->data=-(x2->data);
      y3->data=-(y2->data);
      x2=x2->next;
      y2=y2->next;
      x3=x3->next;
      y3=y3->next;
     }
   }
   if(y2==NULL);
   {
     while(y1!=NULL)
      {
      x3->data=x1->data;
      y3->data=y1->data;
      x1=x1->next;
      y1=y1->next;
      x3=x3->next;
      y3=y3->next; 
      }
   }
  
}
}
/*Evaluate Polynomial at var=k and return the result*/
long long evaluate(Polynomial p, int k)
{
  int p1= llist_get( p.exponents, 0 );
  int p2= llist_get( p.coeffs, 0 );
  int i=0,result=0,j;
  int n= llist_size(p.exponents);
  while(i<n)
  {
     int product= 1;
     for(j=0;j<llist_get( p.exponents, i);j++)
     {
       product=product*k;
     }    
     result=result+(llist_get( p.coeffs, i)* product);
     i++;
  }
  return k;
}

int main()
{
  int t,i,j;
  int op;
  int coefficient,exponent;
  scanf("%d",&op);
  int t1,t2;
    switch(op)
    {
        case 1:
        {
        Polynomial *A=(Polynomial*)malloc(sizeof(Polynomial));
        scanf("%d",&t);
        for(i=0;i<t;i++)
        {
            scanf("%d",&exponent);
            llist_insert(A->exponents,i,exponent);
         }
         for(i=0;i<t;i++)
         {
            scanf("%d",&coefficient);
            llist_insert(A->coeffs,i,coefficient);
         }
        print_polynomial(*A);
        break;
        }
        case 2:
        {
        Polynomial *B=(Polynomial*)malloc(sizeof(Polynomial));
        scanf("%d",&t);
        for(i=0;i<t;i++)
        {
            scanf("%d",&exponent);
            llist_insert(B->exponents,i,exponent);
         }
         for(i=0;i<t;i++)
         {
            scanf("%d",&coefficient);
            llist_insert(B->coeffs,i,coefficient);
         }
        get_degree(*B);
        break;
        }
        case 3:
        {
        Polynomial *C=(Polynomial*)malloc(sizeof(Polynomial));     
        scanf("%d",&t1);
        for(i=0;i<t1;i++)
        {
            scanf("%d",&coefficient);
            llist_insert(C->exponents,i,exponent);
         }
         for(i=0;i<t1;i++)
         {
            scanf("%d",&coefficient);
            llist_insert(C->coeffs,i,coefficient);
         }
        Polynomial *D=(Polynomial*)malloc(sizeof(Polynomial));
        scanf("%d",&t2);
        for(i=0;i<t2;i++)
        {
            scanf("%d",&exponent);
            llist_insert(D->exponents,i,exponent);
         }
         for(i=0;i<t2;i++)
         {
            scanf("%d",&coefficient);
            llist_insert(D->coeffs,i,coefficient);
         }
        Polynomial *e=(Polynomial*)malloc(sizeof(Polynomial));
        *e=add(*C,*D);
        print_polynomial(*e);        
        break;
        }
        case 4:
        {
        Polynomial *f=(Polynomial*)malloc(sizeof(Polynomial));
        scanf("%d",&t1);
        for(i=0;i<t1;i++)
        {
            scanf("%d",&exponent);
            llist_insert(f->exponents,i,exponent);
         }
         for(i=0;i<t1;i++)
         {
            scanf("%d",&coefficient);
            llist_insert(f->coeffs,i,coefficient);
         }
        scanf("%d",&t2);
        Polynomial *g=(Polynomial*)malloc(sizeof(Polynomial));
        for(i=0;i<t2;i++)
        {
            scanf("%d",&exponent);
            llist_insert(g->exponents,i,exponent);
         }
         for(i=0;i<t2;i++)
         {
            scanf("%d",&coefficient);
            llist_insert(g->coeffs,i,coefficient);
         }
         Polynomial *H=(Polynomial*)malloc(sizeof(Polynomial));
         *H=subtract(*f,*g);
         print_polynomial(*H); 
         break;
         }
    /*    case 5:
        Polynomial *I=(Polynomial*)malloc(sizeof(Polynomial));
        Polynomial *J=(Polynomial*)malloc(sizeof(Polynomial));
        Polynomial *L=(Polynomial*)malloc(sizeof(Polynomial));
        scanf("%d",&t1);
        for(i=0;i<t1;i++)
        {
            scanf("%d",&exponent);
            llist_insert(I->exponents,i,exponent);
         }
         for(i=0;i<t1;i++)
         {
            scanf("%d",&coefficient);
            llist_insert(I->coeffs,i,coefficient);
         }
        scanf("%d",&t2);
        for(i=0;i<t2;i++)
        {
            scanf("%d",&exponent);
            llist_insert(J->exponents,i,exponent);
         }
         for(i=0;i<t2;i++)
         {
            scanf("%d",&coefficient);
            llist_insert(J->coeffs,i,coefficient);
         }
        L=multiply(I,J);
        print_polynomial(L); 
        break;  */
        case 6:
        {
         int k;
        scanf("%d",&t);
        Polynomial *M=(Polynomial*)malloc(sizeof(Polynomial));
        for(i=0;i<t;i++)
        {
            scanf("%d",&exponent);
            llist_insert(M->exponents,i,exponent);
         }
         for(i=0;i<t;i++)
         {
            scanf("%d",&coefficient);
            llist_insert(M->coeffs,i,coefficient);
         }
        scanf("%d",&k);
        evaluate(*M,k);
        break;
        }
    }
  }

