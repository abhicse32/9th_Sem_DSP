#include "List.h"

int main(){
LList *lst = llist_new();
llist_prepend(lst,4);
llist_prepend(lst,5);
llist_prepend(lst,6);

llist_insert(lst,1,9);
llist_insert(lst,1,10);
printf("%d\n",llist_get(lst,4));
llist_print(lst);
return 0;
}
