// Lab Assignment 4
// Defines functions related to polynomial manipulation declared in Polynomial.h
// Author : Milind Srivastava
// Date : 29 Aug 2016

#include "Polynomial.h"
#include <math.h>
#include <stdlib.h>
#include <stdio.h>

/*function to return the degree of the polynomial*/
int get_degree(Polynomial p)
{
    Node* temp = p.exponents->head;
    if(temp == NULL) // null polynomial
    {
        return -1;
    }
    if(temp->next == NULL)
    {
        return temp->data;
    }
    while(temp->next!=NULL)
    {
        temp=temp->next;
    }
    return temp->data;
}

void print_polynomial(Polynomial p)
{
    Node* temp_exp = p.exponents->head;
    Node* temp_coeffs = p.coeffs->head;

    int flag = 0;

    while(temp_exp != NULL)
    {
        if(flag == 0) // for the first term, no need to print an extra + sign
        {
            if(temp_coeffs->data != 0) // print only if coeff != 0
            {
                if(temp_exp->data == 0) // if exponent is 0, print only coeff
                {
                    printf("%d ", temp_coeffs->data);
                }
                else
                {
                    printf("%dx^%d ", temp_coeffs->data, temp_exp->data);
                }
            }
        }
        else
        {
            if(temp_exp->data == 0) // if exponent is 0, print only coeff
            {
                if(temp_coeffs->data > 0) // if coeff > 0, prepend a + sign
                {
                    printf("+ %d ", temp_coeffs->data);     
                }
                else if(temp_coeffs->data < 0)
                {
                    printf("- %d ", abs(temp_coeffs->data));
                }
                else // coeff == 0
                {
                    ;
                }
            }
            else
            {
                if(temp_coeffs->data > 0) // coeff > 0, prepend a + sign
                {
                    printf("+ %dx^%d ", temp_coeffs->data, temp_exp->data);
                }
                else if(temp_coeffs->data < 0)
                {
                    printf("- %dx^%d ", abs(temp_coeffs->data), temp_exp->data);
                }
                else
                {
                    ;
                }
            }
        }
        flag=1;
        temp_exp = temp_exp->next;
        temp_coeffs = temp_coeffs->next;
    }
}

Polynomial multiply(Polynomial p1, Polynomial p2)
{
    Node* temp_p1_exp = p1.exponents->head;
    Node* temp_p1_coeffs = p1.coeffs->head;

    Polynomial finalProd;

    finalProd.exponents = llist_new();
    finalProd.coeffs = llist_new();

    while (temp_p1_exp != NULL)
    {
        Polynomial prod;

        prod.exponents = llist_new();
        prod.coeffs = llist_new();

        Node* temp_p2_exp = p2.exponents->head;
        Node* temp_p2_coeffs = p2.coeffs->head;

        while(temp_p2_exp != NULL) // multiplying each term of p1 by whole polynomial p2 and adding the result to finalProd
        {

            llist_append(prod.exponents, temp_p1_exp->data+temp_p2_exp->data);
            llist_append(prod.coeffs, temp_p1_coeffs->data*temp_p2_coeffs->data);

            temp_p2_exp = temp_p2_exp->next;
            temp_p2_coeffs = temp_p2_coeffs->next;
        }
        finalProd = add(finalProd, prod); // updating finalProd

        temp_p1_exp = temp_p1_exp->next;
        temp_p1_coeffs = temp_p1_coeffs->next;
    }

    return finalProd;
}

/*Add two polynomials and return the result*/
Polynomial add(Polynomial p1, Polynomial p2)
{
    Polynomial sum;
    
    // initialisation

    sum.coeffs = llist_new();
    sum.exponents = llist_new();

    Node* temp_p1_exp = p1.exponents->head;
    Node* temp_p1_coeffs = p1.coeffs->head;
    
    Node* temp_p2_exp = p2.exponents->head;
    Node* temp_p2_coeffs = p2.coeffs->head;
    
    while(temp_p1_exp!=NULL && temp_p2_exp!=NULL) // following "merging 2 arrays" routine
    {
        if(temp_p1_exp->data == temp_p2_exp->data)
        {
            llist_append(sum.exponents, temp_p1_exp->data);
            llist_append(sum.coeffs, temp_p1_coeffs->data + temp_p2_coeffs->data);
            
            temp_p1_exp = temp_p1_exp->next;
            temp_p2_exp = temp_p2_exp->next;
            temp_p1_coeffs = temp_p1_coeffs->next;
            temp_p2_coeffs = temp_p2_coeffs->next;
        }
        else
        {
            if(temp_p1_exp->data > temp_p2_exp->data)
            {
                llist_append(sum.exponents, temp_p2_exp->data);
                llist_append(sum.coeffs, temp_p2_coeffs->data);
                
                temp_p2_exp = temp_p2_exp->next;
                temp_p2_coeffs = temp_p2_coeffs->next;
            }
            else
            {
                llist_append(sum.exponents, temp_p1_exp->data);
                llist_append(sum.coeffs, temp_p1_coeffs->data);
                
                temp_p1_exp = temp_p1_exp->next;
                temp_p1_coeffs = temp_p1_coeffs->next;
            }
        }
    }
    if (temp_p1_exp == NULL) // if p1 was exhausted
    {
        if(temp_p2_exp!=NULL)
        {
            while(temp_p2_exp != NULL)
            {
                llist_append(sum.exponents, temp_p2_exp->data);
                llist_append(sum.coeffs, temp_p2_coeffs->data);
                
                temp_p2_exp = temp_p2_exp->next;
                temp_p2_coeffs = temp_p2_coeffs->next;
            }
        }
        else
        {
            ;
        }
    }
    else // if p2 was exhausted
    {
        while(temp_p1_exp != NULL)
        {
            llist_append(sum.exponents, temp_p1_exp->data);
            llist_append(sum.coeffs, temp_p1_coeffs->data);
            
            temp_p1_exp = temp_p1_exp->next;
            temp_p1_coeffs = temp_p1_coeffs->next;
        }
    }

    return sum;
}

/*Subtract second Polynomial from first*/
Polynomial subtract(Polynomial p1, Polynomial p2)
{
    Node* temp = p2.coeffs->head;

    while(temp!=NULL)
    {
        temp->data *= -1; // convert p2 to (-p2)
        temp=temp->next;
    }
    return add(p1,p2); // p1 + (-p2)
}

/*Evaluate Polynomial at var=k and return the result*/
long long int evaluate(Polynomial p, int k)
{
    Node* temp_exp = p.exponents->head;
    Node* temp_coeffs = p.coeffs->head;
    
    long long int value = 0;
    while(temp_exp!=NULL)
    {
        value += (temp_coeffs->data*((long long int)pow((double)k, (double)temp_exp->data))); // evaluating each term separately
        temp_exp = temp_exp->next;
        temp_coeffs = temp_coeffs->next;
    }
    return value;
}
