// Lab Assignment 4 Question 2
// Implements required functionality to test all polynomial functions
// Author : Milind Srivastava
// Date : 29 Aug 2016

#include "List.h"
#include "Polynomial.h"
#include <stdio.h>

void printPoly();
void degreePoly();
void addPoly();
void subtractPoly();
void multiplyPoly();
void evalPoly();

int main()
{
    int choice = -1;
    do{
        scanf("%d",&choice); // user inputs choice
        if (choice == -1)
        {
            break;
        }
        switch(choice)
        {
            case 1:printPoly();
            break;
            
            case 2:degreePoly();
            break;
            
            case 3:addPoly();
            break;
            
            case 4:subtractPoly();
            break;
            
            case 5:multiplyPoly();
            break;
            
            case 6:evalPoly();
            break;
            
            default:choice=-1;
            break;
        }
        printf("\n");        
    }while(choice!=-1);
    return 0;
}

void printPoly()
{
    int t;
    scanf("%d",&t);
    Polynomial temp;
    temp.exponents=llist_new();
    temp.coeffs=llist_new();
    int i=t;
    while(i>0) // inputting exponents of temp
    {
        int k;
        scanf("%d",&k);
        llist_append(temp.exponents, k);
        i--;
    }
    i=t;
    while(i>0) // inputting coeffs of temp
    {
        int k;
        scanf("%d",&k);
        llist_append(temp.coeffs, k);
        i--;
    }
    print_polynomial(temp);
}

void degreePoly()
{
    int t;
    scanf("%d",&t);
    Polynomial temp;
    temp.exponents=llist_new();
    temp.coeffs=llist_new();
    int i=t;
    while(i>0) // inputting exponents of temp
    {
        int k;
        scanf("%d",&k);
        llist_append(temp.exponents, k);
        i--;
    }
    i=t;
    while(i>0) // inputting coeffs of temp
    {
        int k;
        scanf("%d",&k);
        llist_append(temp.coeffs, k);
        i--;
    }
    printf("%d",get_degree(temp));
}

void addPoly()
{
    int t;
    scanf("%d",&t);
    Polynomial temp1,temp2;
    temp1.exponents=llist_new();
    temp1.coeffs=llist_new();
    temp2.exponents=llist_new();
    temp2.coeffs=llist_new();
    int i=t;
    while(i>0) // inputting exponents of temp1
    {
        int k;
        scanf("%d",&k);
        llist_append(temp1.exponents, k);
        i--;
    }
    i=t;
    while(i>0) // inputting coeffs of temp1
    {
        int k;
        scanf("%d",&k);
        llist_append(temp1.coeffs, k);
        i--;
    }
    scanf("%d",&t);
    i=t;
    while(i>0) // inputting exponents of temp2
    {
        int k;
        scanf("%d",&k);
        llist_append(temp2.exponents, k);
        i--;
    }
    i=t;
    while(i>0) // inputting coeffs of temp2
    {
        int k;
        scanf("%d",&k);
        llist_append(temp2.coeffs, k);
        i--;
    }
    print_polynomial(add(temp1, temp2));
}

void subtractPoly()
{
    int t;
    scanf("%d",&t);
    Polynomial temp1,temp2;
    temp1.exponents=llist_new();
    temp1.coeffs=llist_new();
    temp2.exponents=llist_new();
    temp2.coeffs=llist_new();
    int i=t;
    while(i>0) // inputting exponents of temp1
    {
        int k;
        scanf("%d",&k);
        llist_append(temp1.exponents, k);
        i--;
    }
    i=t;
    while(i>0) // inputting coeffs of temp2
    {
        int k;
        scanf("%d",&k);
        llist_append(temp1.coeffs, k);
        i--;
    }
    scanf("%d",&t);
    i=t;
    while(i>0) // inputting exponents of temp2
    {
        int k;
        scanf("%d",&k);
        llist_append(temp2.exponents, k);
        i--;
    }
    i=t;
    while(i>0) // inputting coeffs of temp2
    {
        int k;
        scanf("%d",&k);
        llist_append(temp2.coeffs, k);
        i--;
    }
    print_polynomial(subtract(temp1, temp2));
}

void multiplyPoly()
{
    int t;
    scanf("%d",&t);
    Polynomial temp1,temp2;
    temp1.exponents=llist_new();
    temp1.coeffs=llist_new();
    temp2.exponents=llist_new();
    temp2.coeffs=llist_new();
    int i=t;
    while(i>0) // inputting exponents of temp1
    {
        int k;
        scanf("%d",&k);
        llist_append(temp1.exponents, k);
        i--;
    }
    i=t;
    while(i>0) // inputting coeffs of temp2
    {
        int k;
        scanf("%d",&k);
        llist_append(temp1.coeffs, k);
        i--;
    }
    scanf("%d",&t);
    i=t;
    while(i>0) // inputting exponents of temp2
    {
        int k;
        scanf("%d",&k);
        llist_append(temp2.exponents, k);
        i--;
    }
    i=t;
    while(i>0) // inputting coeffs of temp2
    {
        int k;
        scanf("%d",&k);
        llist_append(temp2.coeffs, k);
        i--;
    }
    print_polynomial(multiply(temp1, temp2));
}

void evalPoly()
{
    int t;
    scanf("%d",&t);
    Polynomial temp;
    temp.exponents=llist_new();
    temp.coeffs=llist_new();
    int i=t;
    while(i>0) // inputting exponents of temp
    {
        int k;
        scanf("%d",&k);
        llist_append(temp.exponents, k);
        i--;
    }
    i=t;
    while(i>0) // inputting coeffs of temp
    {
        int k;
        scanf("%d",&k);
        llist_append(temp.coeffs, k);
        i--;
    }
    int key;
    scanf("%d",&key);
    printf("%lld",evaluate(temp,key));
}
