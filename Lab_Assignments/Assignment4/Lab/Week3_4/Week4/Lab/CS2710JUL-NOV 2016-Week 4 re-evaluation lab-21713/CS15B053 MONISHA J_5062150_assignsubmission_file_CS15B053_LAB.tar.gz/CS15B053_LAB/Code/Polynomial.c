#include "Polynomial.h"
#include "List.h"
//#include "List.c"

#include<stdio.h>
#include<stdlib.h>
#include<math.h>


long long int power(int n,int p)
{	
	long long int t=1;
	int i;
	for(i=0;i<p;i++)
		t=t*n;
	return t;
}

int get_degree(Polynomial p)
{
	Node *current;
	current=(Node*)malloc(sizeof(Node));
	current->next = p.exponents->head;
	
	if(p.exponents->head==NULL)
		return 0;
	else
		while(current->next!=NULL)
			current = current->next;
		return current->data;
}

void print_polynomial(Polynomial p)
{
	Node *curcoef;
	curcoef=(Node*)malloc(sizeof(Node));
	curcoef->next = p.coeffs->head;
	Node *curexp;
	curexp=(Node*)malloc(sizeof(Node));
	curexp->next = p.exponents->head;
		
	int firstterm=1;
	
	if(p.exponents->head!=NULL)
	{
		while(curexp->next!=NULL)
		{
			curcoef = curcoef->next;
			curexp = curexp->next;
			if(firstterm==1)
			{
				if(curexp->data==0)
					printf("%d ", curcoef->data);
				else
					printf("%dx^%d ", curcoef->data, curexp->data);	
				firstterm=0;
			}
			else if(curcoef->data>0)
				if(curexp->data==0)
					printf("+ %d ", curcoef->data);
				else	
					printf("+ %dx^%d ", curcoef->data, curexp->data); 
			else if(curcoef->data<0)
				if(curexp->data==0)
					printf("+ %d ", curcoef->data);
				else
					printf("- %dx^%d ", ((curcoef->data)*-1), curexp->data); 
		}
	}
	printf("\n");
		
}

Polynomial add(Polynomial p1, Polynomial p2)
{
	Node *curcoef1;
	curcoef1=(Node*)malloc(sizeof(Node));
	curcoef1 = p1.coeffs->head;
	Node *curexp1;
	curexp1=(Node*)malloc(sizeof(Node));
	curexp1 = p1.exponents->head;
	Node *curcoef2;
	curcoef2=(Node*)malloc(sizeof(Node));
	curcoef2 = p2.coeffs->head;
	Node *curexp2;
	curexp2=(Node*)malloc(sizeof(Node));
	curexp2 = p2.exponents->head;
	
	Polynomial sumlist;
	sumlist.exponents = llist_new();
	sumlist.coeffs = llist_new();
		
	if(p1.exponents->head==NULL)
		return p2;
	else if(p2.exponents->head==NULL)
		return p1;
	else
	{
		while(curexp1!=NULL && curexp2!=NULL)
		{
			 if(curexp1->data<curexp2->data)
			 {
			 	llist_append(sumlist.coeffs, curcoef1->data);
			 	llist_append(sumlist.exponents, curexp1->data);
			 	curcoef1 = curcoef1->next;
				curexp1 = curexp1->next;	
			 }
			 else if(curexp2->data<curexp1->data)
			 {
			 	llist_append(sumlist.coeffs, curcoef2->data);
			 	llist_append(sumlist.exponents, curexp2->data);
			 	curcoef2 = curcoef2->next;
				curexp2 = curexp2->next;	
			 }
			 else
			 {
			 	llist_append(sumlist.coeffs, curcoef1->data + curcoef2->data);
			 	llist_append(sumlist.exponents, curexp1->data);
			 	curcoef1 = curcoef1->next;
				curexp1 = curexp1->next;
				curcoef2 = curcoef2->next;
				curexp2 = curexp2->next;	
			 }
			 
		}
		
		while(curexp1!=NULL)
		{
			llist_append(sumlist.coeffs, curcoef1->data);
			llist_append(sumlist.exponents, curexp1->data);
		    curcoef1 = curcoef1->next;
			curexp1 = curexp1->next;
		}
		
		while(curexp2!=NULL)
		{
			llist_append(sumlist.coeffs, curcoef2->data);
			llist_append(sumlist.exponents, curexp2->data);
			curcoef2 = curcoef2->next;
			curexp2 = curexp2->next;
		}
		return sumlist;
	}
}


Polynomial subtract(Polynomial p1, Polynomial p2)
{
	Node *curcoef1;
	curcoef1=(Node*)malloc(sizeof(Node));
	curcoef1 = p1.coeffs->head;
	Node *curexp1;
	curexp1=(Node*)malloc(sizeof(Node));
	curexp1 = p1.exponents->head;
	Node *curcoef2;
	curcoef2=(Node*)malloc(sizeof(Node));
	curcoef2 = p2.coeffs->head;
	Node *curexp2;
	curexp2=(Node*)malloc(sizeof(Node));
	curexp2 = p2.exponents->head;
	
	Polynomial difflist;
	difflist.exponents = llist_new();
	difflist.coeffs = llist_new();
	
	if(p1.exponents->head==NULL)
		return p2;
	else if(p2.exponents->head==NULL)
		return p1;
	else
	{
		while(curexp1!=NULL && curexp2!=NULL)
		{
			 if(curexp1->data<curexp2->data)
			 {
			 	llist_append(difflist.coeffs, curcoef1->data);
			 	llist_append(difflist.exponents, curexp1->data);
			 	curcoef1 = curcoef1->next;
				curexp1 = curexp1->next;	
			 }
			 else if(curexp2->data<curexp1->data)
			 {
			 	llist_append(difflist.coeffs, -(curcoef2->data));
			 	llist_append(difflist.exponents, (curexp2->data));
			 	curcoef2 = curcoef2->next;
				curexp2 = curexp2->next;	
			 }
			 else
			 {
			 	llist_append(difflist.coeffs, curcoef1->data - curcoef2->data);
			 	llist_append(difflist.exponents, curexp1->data);
			 	curcoef1 = curcoef1->next;
				curexp1 = curexp1->next;
				curcoef2 = curcoef2->next;
				curexp2 = curexp2->next;	
			 }
			 
		}
		
		while(curexp1!=NULL)
		{
			llist_append(difflist.coeffs, curcoef1->data);
			llist_append(difflist.exponents, curexp1->data);
		       	curcoef1 = curcoef1->next;
			curexp1 = curexp1->next;
		}
		
		while(curexp2!=NULL)
		{
			llist_append(difflist.coeffs, -(curcoef2->data));
			llist_append(difflist.exponents, curexp2->data);
			curcoef2 = curcoef2->next;
			curexp2 = curexp2->next;
		}
		return difflist;
	}
}


Polynomial multiply(Polynomial p1, Polynomial p2)
{
	Node *curcoef1;
	curcoef1=(Node*)malloc(sizeof(Node));
	curcoef1 = p1.coeffs->head;
	Node *curexp1;
	curexp1=(Node*)malloc(sizeof(Node));
	curexp1 = p1.exponents->head;
	Node *curcoef2;
	curcoef2=(Node*)malloc(sizeof(Node));
	Node *curexp2;
	curexp2=(Node*)malloc(sizeof(Node));
	
	Polynomial product;
	product.exponents = llist_new();
	product.coeffs = llist_new();
	Node *curexp;
	curexp=(Node*)malloc(sizeof(Node));
	Node *curcoef;
	curcoef=(Node*)malloc(sizeof(Node));
	
	int foundprev, index;
	if(p1.exponents->head==NULL || p2.exponents->head==NULL)
		return NULL;
	else
	{
		while(curexp1!=NULL)
		{
			curexp2 = p2.exponents->head;
			curcoef2 = p2.coeffs->head;
			while(curexp2!=NULL)
			{
				if(product.exponents->head==NULL)
				{
					llist_append(product.exponents, curexp1->data + curexp2->data);
					llist_append(product.coeffs, curcoef1->data * curcoef2->data);
				}
				else
				{
					curexp = product.exponents->head;	
					curcoef = product.coeffs->head;
					foundprev=0;
					index=0;
					while(curexp!=NULL)
					{
						if((curexp1->data + curexp2->data) == curexp->data)
						{
							foundprev=1;
							curcoef->data += curcoef1->data * curcoef2->data;
							break;
						}
						else if((curexp1->data + curexp2->data)<curexp->data)
						{
							foundprev=2;
							break;
						}
						curexp = curexp->next;
						curcoef = curcoef->next;
						index++;
					}
					if(foundprev==0)
					{
						llist_append(product.exponents, curexp1->data + curexp2->data);
						llist_append(product.coeffs, curcoef1->data * curcoef2->data);
					}
					else if(foundprev==2)
					{
						llist_insert(product.exponents, index, curexp1->data + curexp2->data);
						llist_insert(product.coeffs, index, curcoef1->data * curcoef2->data);
					}
				}	
				curexp2 = curexp2->next;
				curcoef2 = curcoef2->next;
			}
			curexp1 = curexp1->next;
			curcoef1 = curcoef1->next;
		}
		return product;		
	}
}


long long int evaluate(Polynomial p, long long int x)
{
	long long int ans = 0;
	
	Node *curcoef;
	curcoef=(Node*)malloc(sizeof(Node));
	curcoef->next = p.coeffs->head;
	
	Node *curexp;
	curexp=(Node*)malloc(sizeof(Node));
	curexp->next = p.exponents->head;
		
	while(curexp->next!=NULL)
	{
		curcoef = curcoef->next;
		curexp = curexp->next;		
		ans = ans + (curcoef->data * power(x, curexp->data));
	}
	
	return ans;
}









