//#include "List.h"
//#include "List.c"
#include "Polynomial.h"
//#include "Polynomial.c"

#include<stdio.h>
#include<stdlib.h> 

void main()
{
	int choice;	
	int t, value, i, t1, t2;
	long long int x;
	
	Polynomial p;	
	Polynomial p1;
	Polynomial p2;
	scanf("%d", &choice);
	do
	{
		
		switch(choice)
		{
			case 1:	scanf("%d", &t);
				p.exponents = llist_new();	
				p.coeffs = llist_new();
				for(i=0; i<t; i++)
				{
					scanf("%d", &value);
					llist_append(p.exponents, value);
				}
				for(i=0; i<t; i++)
				{
					scanf("%d", &value);
					llist_append(p.coeffs, value);
				}
				print_polynomial(p);
				break;
				
			case 2: scanf("%d", &t);
				p.exponents = llist_new();	
				p.coeffs = llist_new();
				for(i=0; i<t; i++)
				{
					scanf("%d", &value);
					llist_append(p.exponents, value);
				}
				for(i=0; i<t; i++)
				{
					scanf("%d", &value);
					llist_append(p.coeffs, value);
				}
				printf("%d\n", get_degree(p));
				break;
				
			case 3: scanf("%d", &t1);
				p1.exponents = llist_new();	
				p1.coeffs = llist_new();
				p2.exponents = llist_new();	
				p2.coeffs = llist_new();
				for(i=0; i<t1; i++)
				{
					scanf("%d", &value);
					llist_append(p1.exponents, value);
				}
				for(i=0; i<t1; i++)
				{
					scanf("%d", &value);
					llist_append(p1.coeffs, value);
				}
				scanf("%d", &t2);
				for(i=0; i<t2; i++)
				{
					scanf("%d", &value);
					llist_append(p2.exponents, value);
				}
				for(i=0; i<t2; i++)
				{
					scanf("%d", &value);
					llist_append(p2.coeffs, value);
				}
				print_polynomial(add(p1, p2));
				break;
			
			case 4: scanf("%d", &t1);
				p1.exponents = llist_new();	
				p1.coeffs = llist_new();
				p2.exponents = llist_new();	
				p2.coeffs = llist_new();
				for(i=0; i<t1; i++)
				{
					scanf("%d", &value);
					llist_append(p1.exponents, value);
				}
				for(i=0; i<t1; i++)
				{
					scanf("%d", &value);
					llist_append(p1.coeffs, value);
				}
				scanf("%d", &t2);
				for(i=0; i<t2; i++)
				{
					scanf("%d", &value);
					llist_append(p2.exponents, value);
				}
				for(i=0; i<t2; i++)
				{
					scanf("%d", &value);
					llist_append(p2.coeffs, value);
				}
				print_polynomial(subtract(p1, p2));
				break;
			
			case 5: scanf("%d", &t1);
				p1.exponents = llist_new();	
				p1.coeffs = llist_new();
				p2.exponents = llist_new();	
				p2.coeffs = llist_new();
				for(i=0; i<t1; i++)
				{
					scanf("%d", &value);
					llist_append(p1.exponents, value);
				}
				for(i=0; i<t1; i++)
				{
					scanf("%d", &value);
					llist_append(p1.coeffs, value);
				}
				scanf("%d", &t2);
				for(i=0; i<t2; i++)
				{
					scanf("%d", &value);
					llist_append(p2.exponents, value);
				}
				for(i=0; i<t2; i++)
				{
					scanf("%d", &value);
					llist_append(p2.coeffs, value);
				}
				print_polynomial(multiply(p1, p2));
				break;
			
			case 6: scanf("%d", &t);
				p.exponents = llist_new();	
				p.coeffs = llist_new();
				for(i=0; i<t; i++)
				{
					scanf("%d", &value);
					llist_append(p.exponents, value);
				}
				for(i=0; i<t; i++)
				{
					scanf("%d", &value);
					llist_append(p.coeffs, value);
				}
				scanf("%lld", &x);
				printf("%lld\n", evaluate(p, x));
				break;
		}
			
			scanf("%d", &choice);
	}while(choice!=-1);
}			
			
			
				
				
		
			
			
		
				
	
	


