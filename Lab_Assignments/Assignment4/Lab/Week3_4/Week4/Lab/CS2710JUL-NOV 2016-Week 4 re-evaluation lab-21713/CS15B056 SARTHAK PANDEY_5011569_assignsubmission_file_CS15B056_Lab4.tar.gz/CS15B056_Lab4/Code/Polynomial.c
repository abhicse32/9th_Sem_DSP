//THIS CODE CONTAINS VARIOUS CODE IMPLEMENTATIONS OF Polynomial.h
#include "Polynomial.h"
#include <stdio.h>
#include "List.h"

int get_degree(Polynomial p)            //finds degree
{
	LList *exp;
	int i;
	exp=p.exponents;
	i=llist_size(exp);
	if (i==0)
	 return 0;
	else 
		return llist_get(exp,i-1);
}

void print_polynomial(Polynomial p1)                      //prints polynomial(code is lont to strictly follow the output format)
{
	int i=0;
	Node *expnode;
	Node *coeffnode;
	expnode=(p1.exponents)->head;
	coeffnode =(p1.coeffs)->head;
	for (;expnode!=NULL&&coeffnode!=NULL;expnode=expnode->next,coeffnode=coeffnode->next)           //goes till end of list
		{
		 if (expnode->data==0&&coeffnode->data!=0)
		 {
		 printf ("%d ",coeffnode->data);
		 i++;
		 }
		 else if (coeffnode->data>0)
		 {
		 if (i==0)
		 {
		 printf ("%dx^%d ",coeffnode->data,expnode->data);
		 i++;
		 }
		 else 
		 {
		 printf ("+ %dx^%d ",coeffnode->data,expnode->data);
		 i++;
		 }
		 }
		 else if (coeffnode->data<0)
		 {
		 if (i==0)
		 {
		 printf ("%dx^%d ",coeffnode->data,expnode->data);
		 i++;
		 }
		 else
		 {
		 printf ("- %dx^%d ",-coeffnode->data,expnode->data);
		 i++;
		 }
		 }
		 }
	printf ("\n");
}

Polynomial add(Polynomial p1, Polynomial p2)                //adds two polynomials
{
	Polynomial p;
	Node *curr1e;
	Node *curr2e;
	curr1e=p1.exponents->head;
	curr2e=p2.exponents->head;
	Node *curr1c;
	Node *curr2c;
	p.exponents=llist_new();
	p.coeffs=llist_new();
	curr1c=(p1.coeffs)->head;
	curr2c=(p2.coeffs)->head;
	
	for (;curr1e!=NULL||curr2e!=NULL;)
	{
		
		if (curr1e==NULL&&curr2e!=NULL)                  //if one list is over
		{
			llist_append(p.exponents,curr2e->data);
			llist_append(p.coeffs,curr2c->data);
			curr2e=curr2e->next;
			curr2c=curr2c->next;
		}
		else if (curr1e!=NULL&&curr2e==NULL)
		{
			llist_append(p.exponents,curr1e->data);
			llist_append(p.coeffs,curr1c->data);
			curr1e=curr1e->next;
			curr1c=curr1c->next;
		}
		else if ((curr1e->data==curr2e->data)&&curr1e!=NULL&&curr2e!=NULL)         //if same exp found in both ,then add
		{
			llist_append(p.exponents,curr1e->data);
			llist_append(p.coeffs,curr1c->data+curr2c->data);
			curr1e=curr1e->next;
			curr2e=curr2e->next;
			curr1c=curr1c->next;
			curr2c=curr2c->next;
		}
		else if ((curr1e->data>curr2e->data)&&curr1e!=NULL&&curr2e!=NULL)            //if diff exp the move pointers accordingly and assign smaller exp to ans
		{
			llist_append(p.exponents,curr2e->data);
			llist_append(p.coeffs,curr2c->data);
			curr2e=curr2e->next;
			curr2c=curr2c->next;
		}
		else if ((curr1e->data<curr2e->data)&&curr1e!=NULL&&curr2e!=NULL)
		{
			llist_append(p.exponents,curr1e->data);
			llist_append(p.coeffs,curr1c->data);
			curr1e=curr1e->next;
			curr1c=curr1c->next;
		}
	}
	return p;
}

Polynomial subtract(Polynomial p1, Polynomial p2)                          //performs polynomial subtraction (same as addition) 
{
	Polynomial p;
	Node *curr1e;
	Node *curr2e;
	curr1e=p1.exponents->head;
	curr2e=p2.exponents->head;
	Node *curr1c;
	Node *curr2c;
	p.exponents=llist_new();
	p.coeffs=llist_new();
	curr1c=(p1.coeffs)->head;
	curr2c=(p2.coeffs)->head;
	for (;curr1e!=NULL||curr2e!=NULL;)
	{
		
		if (curr1e==NULL&&curr2e!=NULL)
		{
			llist_append(p.exponents,curr2e->data);
			llist_append(p.coeffs,-curr2c->data);
			curr2e=curr2e->next;
			curr2c=curr2c->next;
		}
		else if (curr1e!=NULL&&curr2e==NULL)
		{
			llist_append(p.exponents,curr1e->data);
			llist_append(p.coeffs,curr1c->data);
			curr1e=curr1e->next;
			curr1c=curr1c->next;
		}
		else if ((curr1e->data==curr2e->data)&&curr1e!=NULL&&curr2e!=NULL)
		{
			llist_append(p.exponents,curr1e->data);
			llist_append(p.coeffs,curr1c->data-curr2c->data);
			curr1e=curr1e->next;
			curr2e=curr2e->next;
			curr1c=curr1c->next;
			curr2c=curr2c->next;
		}
		else if ((curr1e->data>curr2e->data)&&curr1e!=NULL&&curr2e!=NULL)
		{
			llist_append(p.exponents,curr2e->data);
			llist_append(p.coeffs,-1*(curr2c->data));
			curr2e=curr2e->next;
			curr2c=curr2c->next;
		}
		else if ((curr1e->data<curr2e->data)&&curr1e!=NULL&&curr2e!=NULL)
		{
			llist_append(p.exponents,curr1e->data);
			llist_append(p.coeffs,curr1c->data);
			curr1e=curr1e->next;
			curr1c=curr1c->next;
		}
	}
	return p;
}	

long long int evaluate(Polynomial p, int k)                 //evaluates polynomial value at k
{
	long long int i=0,j,m;
	Node *curre;
	Node *currc;
	curre=(p.exponents)->head;
	currc=(p.coeffs)->head;
	for (;curre!=NULL;curre=curre->next,currc=currc->next)
	{
		m=1;
		for (j=0;j<curre->data;j++)
			m=m*k;
		i=i+m*currc->data;
	}
	return i;
}

Polynomial multiply(Polynomial p1, Polynomial p2)     //the basic code here is we multiply each element of p1 with each of p2 and store the values in a polynomial p with degree =degp1+degp2
{
	Polynomial p;
	Node *curre;
	Node *currc;
	Node *curr1e;
	Node *curr1c;
	Node *curr2e;
	Node *curr2c;
	p.exponents=llist_new();
	p.coeffs=llist_new();
	curre=(p.exponents)->head;
	currc=(p.coeffs)->head;
	int n=get_degree(p1)+get_degree(p2),i,j,k;
	for (i=0;i<=n;i++)
	{
		llist_append(p.exponents,i);
		llist_append(p.coeffs,0);
	}
	for (curr1e=p1.exponents->head,curr1c=p1.coeffs->head;curr1e!=NULL;curr1e=curr1e->next,curr1c=curr1c->next)
		for (curr2e=p2.exponents->head,curr2c=p2.coeffs->head;curr2e!=NULL;curr2e=curr2e->next,curr2c=curr2c->next)
		{
			for (curre=(p.exponents)->head,currc=(p.coeffs)->head;curre!=NULL;curre=curre->next,currc=currc->next)
			{
				if (curre->data==curr1e->data+curr2e->data)
				{
					currc->data=currc->data+(curr1c->data)*(curr2c->data);                      //assigning to p is done here 
					break;
				}
			}
		}
	return p;
}
			
		
	
	
		
	
		
		
				
		
	
			
		
			
				
		


