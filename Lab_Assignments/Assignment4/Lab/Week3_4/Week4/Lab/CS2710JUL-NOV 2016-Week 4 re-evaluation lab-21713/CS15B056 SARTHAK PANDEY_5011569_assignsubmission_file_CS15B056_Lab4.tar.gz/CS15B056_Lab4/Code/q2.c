//THIS CODE CONTAINS THE MAIN FUNCTION WHICH CONTROLS THE FLOW OF PROGRAM
//AUTHOR - SARTHAK PANDEY
#include "Polynomial.h"
#include "List.h"
#include <stdio.h>
#include <stdlib.h>
int main ()
{
	int c,elm,t,k,i;
	scanf ("%d",&c);
	for (;c!=-1;)
	{
		if (c==1)                                               //prints polynomial
		{
			
			scanf ("%d",&t);
			Polynomial p;
			p.exponents=llist_new();
			p.coeffs=llist_new();
			for (i=0;i<t;i++)
			{
				scanf("%d",&elm);
				llist_append(p.exponents,elm);              //gives input to list
			}
			for (i=0;i<t;i++)
			{
				scanf("%d",&elm);
				llist_append(p.coeffs,elm);
			}
			print_polynomial(p);                               //calls print function
			if (p.exponents->head!=NULL)
			{
				free (p.exponents->head);
				free (p.coeffs->head);
			}
			scanf ("%d",&c);
				
		}
		else if (c==2)                                    //finds degree
		{
			scanf ("%d",&t);
			Polynomial p;
			p.exponents=llist_new();
			p.coeffs=llist_new();
			for (i=0;i<t;i++)
			{
				scanf("%d",&elm);
				llist_append(p.exponents,elm);
			}
			for (i=0;i<t;i++)
			{
				scanf("%d",&elm);
				llist_append(p.coeffs,elm);
			}
			printf("%d\n",get_degree(p));
			if (p.exponents->head!=NULL)
			{
				free (p.exponents->head);
				free (p.coeffs->head);
			}
			scanf ("%d",&c);
		}
		else if (c==3||c==4||c==5)
		{
			
			Polynomial p1;
			p1.exponents=llist_new();
			p1.coeffs=llist_new();

			scanf ("%d",&t);
			for (i=0;i<t;i++)
			{
				scanf("%d",&elm);
				llist_append(p1.exponents,elm);
			}
			for (i=0;i<t;i++)
			{
				scanf("%d",&elm);
				llist_append(p1.coeffs,elm);
			}
			
			scanf ("%d",&t);
			Polynomial p2;
			p2.exponents=llist_new();
			p2.coeffs=llist_new();
			for (i=0;i<t;i++)
			{
				scanf("%d",&elm);
				llist_append(p2.exponents,elm);
			}
			for (i=0;i<t;i++)
			{
				scanf("%d",&elm);
				llist_append(p2.coeffs,elm);
			}
			
			if (c==3)                                            //finds addition
				print_polynomial(add(p1,p2));
			else if (c==4)                                        //finds subtraction
				print_polynomial(subtract(p1,p2));
			else 						     //finds multiplication
				print_polynomial(multiply(p1,p2));
			if (p1.exponents->head!=NULL)
			{	
			free (p1.exponents->head);
			free (p1.coeffs->head);
			}
			if (p2.exponents->head!=NULL)
			{
			free (p2.exponents->head);
			free (p2.coeffs->head);
			}
			scanf ("%d",&c);
		}
		else if (c==6)                                            //evaluates polynomial at k
		{
			Polynomial p1;
			p1.exponents=llist_new();
			p1.coeffs=llist_new();
	
			scanf ("%d",&t);
			for (i=0;i<t;i++)
			{
				scanf("%d",&elm);
				llist_append(p1.exponents,elm);
			}
			for (i=0;i<t;i++)
			{
				scanf("%d",&elm);
				llist_append(p1.coeffs,elm);
			}
			scanf ("%d",&k);
			printf ("%lld\n",evaluate(p1,k));
			scanf ("%d",&c);
		}
	}
}
			
				
			
					
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
	
			
				

	
