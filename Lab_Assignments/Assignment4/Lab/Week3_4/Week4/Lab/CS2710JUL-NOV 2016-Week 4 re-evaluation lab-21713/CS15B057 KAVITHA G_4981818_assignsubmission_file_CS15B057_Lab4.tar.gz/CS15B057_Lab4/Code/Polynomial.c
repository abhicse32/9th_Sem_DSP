/*Author: G.Kavitha
Roll No. CS15B057
Date: 29/08/16 */
#include "Polynomial.h"
# include<stdio.h>
# include<stdlib.h>
# include<math.h>
/*function to return the degree of the polynomial*/
int get_degree(Polynomial p){
	LList* temp=(p.exponents);
	Node* st=temp->head;
	if(temp==NULL) return -1;
	if(st==NULL) return -1;
	if(st->next==NULL)
		return st->data;
	while(st->next!=NULL){
		st=st->next;
	}
	return st->data;
}

// print Polynomial
void print_polynomial(Polynomial p){
	LList* temp1=(p.exponents);
	Node* st1=temp1->head;
	LList* temp2=(p.coeffs);
	Node* st2=temp2->head;
	while(st1!=NULL&&st2!=NULL){
		if(st1==temp1->head){
			if(st1->data==0) printf("%d",st2->data);
			else printf("%dx^%d",st2->data,st1->data);
		}
		else{	
			if(st1->data==0) printf("%d",st2->data);
			else printf("%dx^%d",abs(st2->data),st1->data);
		}	
		if(st1->next!=NULL){
			printf(" ");
			if(st2->next->data>0) printf("+ ");
			else printf("- ");
		}
		st1=st1->next;
		st2=st2->next;
	}
	printf(" \n");
}

/*Multiply two polynomials and return the result*/
Polynomial multiply(Polynomial p, Polynomial q){
	Polynomial res;
	res.exponents=llist_new();
	res.coeffs=llist_new();
	LList* temp1=(p.exponents);
	Node* st1=temp1->head;
	LList* temp2=(p.coeffs);
	Node* st2=temp2->head;
	while(st1!=NULL){
		LList* temp3=(q.exponents);
		Node* st3=temp3->head;
		LList* temp4=(q.coeffs);
		Node* st4=temp4->head;
		while(st3!=NULL){
			st3->data+=st1->data;
			st4->data*=st2->data;
			st3=st3->next;
			st4=st4->next;
		}
		res=add(q,res);
		temp3=(q.exponents);
		st3=temp3->head;
		temp4=(q.coeffs);
		st4=temp4->head;
		while(st3!=NULL){
			st3->data-=st1->data;
			st4->data/=st2->data;
			st3=st3->next;
			st4=st4->next;
		}
		st2=st2->next;
		st1=st1->next;
	}
	return res;
}	

/*Add two polynomials and return the result*/
Polynomial add(Polynomial p, Polynomial q){
	Polynomial res;
	res.exponents=llist_new();
	res.coeffs=llist_new();
	LList* temp1=(p.exponents);
	Node* st1=temp1->head;
	LList* temp2=(p.coeffs);
	Node* st2=temp2->head;
	LList* temp3=(q.exponents);
	Node* st3=temp3->head;
	LList* temp4=(q.coeffs);
	Node* st4=temp4->head;
	while(st1!=NULL&&st3!=NULL){
		if(st1->data<st3->data) {
			llist_append(res.exponents,st1->data);
			llist_append(res.coeffs,st2->data);
			st1=st1->next;
			st2=st2->next;
		}
		else if(st1->data>st3->data){
			llist_append(res.exponents,st3->data);
			llist_append(res.coeffs,st4->data);
			st3=st3->next;
			st4=st4->next;
		}
		else{
			if(st2->data+st4->data!=0){
			llist_append(res.exponents,st1->data);
			llist_append(res.coeffs,st2->data+st4->data);}
			st1=st1->next;
			st2=st2->next;
			st3=st3->next;
			st4=st4->next;
		}
	}
	while(st1!=NULL){
			llist_append(res.exponents,st1->data);
			llist_append(res.coeffs,st2->data);
			st1=st1->next;
			st2=st2->next;
	}
	while(st3!=NULL){
			llist_append(res.exponents,st3->data);
			llist_append(res.coeffs,st4->data);
			st3=st3->next;
			st4=st4->next;
	}
	return res;
}


/*Subtract second Polynomial from first*/
Polynomial subtract(Polynomial p, Polynomial q){
	Polynomial res;
	res.exponents=llist_new();
	res.coeffs=llist_new();
	LList* temp1=(p.exponents);
	Node* st1=temp1->head;
	LList* temp2=(p.coeffs);
	Node* st2=temp2->head;
	LList* temp3=(q.exponents);
	Node* st3=temp3->head;
	LList* temp4=(q.coeffs);
	Node* st4=temp4->head;
	while(st1!=NULL&&st3!=NULL){
		if(st1->data<st3->data) {
			llist_append(res.exponents,st1->data);
			llist_append(res.coeffs,st2->data);
			st1=st1->next;
			st2=st2->next;
		}
		else if(st1->data>st3->data){
			llist_append(res.exponents,st3->data);
			llist_append(res.coeffs,-st4->data);
			st3=st3->next;
			st4=st4->next;
		}
		else{
			if(st2->data-st4->data!=0){
			llist_append(res.exponents,st1->data);
			llist_append(res.coeffs,st2->data-st4->data);}
			st1=st1->next;
			st2=st2->next;
			st3=st3->next;
			st4=st4->next;
		}
	}
	while(st1!=NULL){
			llist_append(res.exponents,st1->data);
			llist_append(res.coeffs,st2->data);
			st1=st1->next;
			st2=st2->next;
	}
	while(st3!=NULL){
			llist_append(res.exponents,st3->data);
			llist_append(res.coeffs,-st4->data);
			st3=st3->next;
			st4=st4->next;
	}
	return res;
}

/*Evaluate Polynomial at var=k and return the result*/
long long int evaluate(Polynomial p, int k){
	long long int ans=0;
	LList* temp1=(p.exponents);
	Node* st1=temp1->head;
	LList* temp2=(p.coeffs);
	Node* st2=temp2->head;
	long long int powk=1; 
	int prev=0,i;
	while(st1!=NULL){
		for(i=prev;i<st1->data;i++) powk*=k; 	
		ans=ans+(powk)*st2->data;
		prev=st1->data;
		st1=st1->next;
		st2=st2->next;
	}
	return ans;
}
