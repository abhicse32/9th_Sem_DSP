/*Author: G.Kavitha
Roll No. CS15B057
Date: 29/08/16 */
#include "Polynomial.h"
#include <string.h>
#include <stdio.h>
#include <string.h>
Polynomial inp(){
	Polynomial res;
	res.exponents=llist_new();
	res.coeffs=llist_new();
	long long int t,i,j;
	int p;
	scanf("%lld",&t);
	for(i=0;i<t;i++){
		scanf("%d",&p);
		llist_append(res.exponents,p);
	}
	j=0;
	for(i=0;i<t;i++){
		scanf("%d",&p);
		if(p==0) {llist_remove(res.exponents,i-j); j++;}
		else llist_append(res.coeffs,p);
	}
	return res;	
}	
int main(){
	int op;
	scanf("%d",&op);
	while(op!=-1){
		Polynomial p,q,res;
		switch(op){
			case 1: p=inp(); 
				print_polynomial(p); 
				break;
			case 2: p=inp(); 
				printf("%d\n",get_degree(p)); 
				break;
			case 3: p=inp(); 
				q=inp(); 
				res=add(p,q);
				print_polynomial(res); 
				break;
			case 4: p=inp(); 
				q=inp(); 
				res=subtract(p,q);
				print_polynomial(res); 
				break;
			case 5: p=inp(); 
				q=inp(); 
				res=multiply(p,q);
				print_polynomial(res); 
				break;
			case 6: p=inp(); 
				int k; 
				scanf("%d",&k);
				printf("%lld\n",evaluate(p,k));
				break;
		}
		scanf("%d",&op);
	}
	return 0;
}
