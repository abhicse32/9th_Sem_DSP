#include "List.h"
#include<limits.h>
#include<stdlib.h>
#include<stdio.h>
/*Function to create new node*/
Node* node_new(int data)
{
	Node* nd=(Node*)malloc(sizeof(Node));
	if(nd!=NULL)
	{
		nd->data=data;
		nd->next=NULL;
		return nd;
	}
	return nd;
}

/*Function to create empty list*/
LList* llist_new()
{
	LList* list=(LList*)malloc(sizeof(LList));
	list->head=NULL;
	return list;
}


/*Function to find size of a list*/
int llist_size(LList *lst)
{
	int size=0;
	Node* np=lst->head;
	while(np!=NULL)
	{
		size++;
		np=np->next;
	}
	return size;
}

/*Function to print a linked list*/
void llist_print(LList *lst)
{
	Node* np=lst->head;
	while(np!=NULL)
	{
		printf("%d ",np->data);
		np=np->next;
	}
	printf("\n");
}

/*Function to get an element at a particular index*/
int llist_get( LList* lst, int idx )
{
	Node* np=lst->head;
	int counter=0;
	while(np!=NULL)
	{
		if(counter==idx)
		{
			return np->data;
		}
		else
		{
			np=np->next;
			counter++;
		}
	}
	return -1;					//If index is out of bounds, it returns INT_MIN
}

/*Function to append an element to a list*/
void llist_append( LList* lst, int data )
{
	Node* np=lst->head;
	if(np==NULL)						//If the list is empty
	{
		lst->head=node_new(data);
	}
	else
	{
		while(np->next!=NULL)			//To reach last element
		{
			np=np->next;
		}
		np->next=node_new(data);
	}
}

/*Function to prepend an element to the list*/
void llist_prepend( LList* lst, int data )
{
	Node* np=node_new(data);
	np->next=lst->head;
	lst->head=np;	
}
// Add a new element at the @idx index
void llist_insert( LList* lst, int idx, int data )
{
	int counter=0;
	Node* np=lst->head;
	if(np==NULL&&idx==0)							//If the list is empty
	{
		lst->head=node_new(data);
	}
	else
	{
		if(idx==0)			//If only 1 element and we hav to add element at 0th index
		{
			llist_prepend(lst,data);			
		}
		else
		{
			while(np!=NULL)
			{
				if(counter==idx-1)		//To find element just before required index
				{
					Node* temp=np->next;
					np->next=node_new(data);
					np->next->next=temp;
					break;
				}
				counter++;
				np=np->next;
			
			}
		}
	}
	
}

// Remove an element from the end of the list
void llist_remove_last( LList* lst )
{

	Node* np=lst->head;
	if(np!=NULL)
	{
		while(np->next->next!=NULL)
		{
			np=np->next;
		}
		Node* del=np->next;
		np->next=NULL;
		free(del);
	}
}

// Remove an element from the beginning of the list
void llist_remove_first( LList* lst )
{
	
	Node* del=lst->head;
	if(del!=NULL)
	{
		lst->head=lst->head->next;
		free(del);
	}
}

// Remove an element from an arbitrary @idx position in the list
void llist_remove( LList* lst, int idx )
{
	if(lst->head!=NULL)			//if list is not empty
	{
		
		int counter=0;
		Node* np=lst->head;
		if(idx==0)				//if we have to delete at 0th index
		{
			Node* del=np;
			lst->head=np->next;
			free(del);
		}
		else
		{
			while(np!=NULL)		
			{
				if(counter==idx-1)	//If we reach element just before index
				{
				Node* del=np->next;
				np->next=np->next->next;
				free(del);
				break;
				}
				else
				{
					counter++;
					np=np->next;
				}
			}
		}	
	}	
}








