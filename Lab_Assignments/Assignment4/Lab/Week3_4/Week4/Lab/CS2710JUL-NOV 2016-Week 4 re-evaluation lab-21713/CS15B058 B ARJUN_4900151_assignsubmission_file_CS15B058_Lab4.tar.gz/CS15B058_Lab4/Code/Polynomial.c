#include "Polynomial.h"
#include<stdio.h>
#include<stdlib.h>

/*function to return the degree of the polynomial*/
int get_degree(Polynomial poly)
{
	Node* expcheck=poly.exponents->head;
	int max;
	while(expcheck->next!=NULL)	
	{
		expcheck=expcheck->next;
	}
	max=expcheck->data;			//Degree will be the exponent of last node.
	return max;
}

// print Polynomial
void print_polynomial(Polynomial poly)
{
	Node* traverseexp=poly.exponents->head;
	Node* traversecoeff=poly.coeffs->head;
	int flag=0;
	while(traverseexp!=NULL)
	{
		if(flag==0)						//flag==0 only for first term(output format is different than rest)
		{
			if(traversecoeff->data<0)	//coefficient is -ve		
			{	
				if(traverseexp->data==0)				//exponent is 0
					printf("-%d",-traversecoeff->data);		
				else
					printf("-%dx^%d",-traversecoeff->data,traverseexp->data);	
			}
			else
			{
				if(traverseexp->data==0)
					printf("%d",traversecoeff->data);		
				else
					printf("%dx^%d",traversecoeff->data,traverseexp->data);
			}
			flag=1;
		}
		else if(traversecoeff->data>0&&flag==1)				//flag==1 means its not first term
		{
			if(traverseexp->data==0)
				printf(" + %d",traversecoeff->data);	
			else
				printf(" + %dx^%d",traversecoeff->data,traverseexp->data);
		}
		else if(traversecoeff->data<0&&flag==1)
		{
			if(traverseexp->data==0)
				printf(" - %d",-traversecoeff->data);	
			else
				printf(" - %dx^%d",-traversecoeff->data,traverseexp->data);
		}
		traversecoeff=traversecoeff->next;
		traverseexp=traverseexp->next;	
	}
	printf(" \n");
}

/*Multiply two polynomials and return the result*/
Polynomial multiply(Polynomial poly1, Polynomial poly2)
{
	Polynomial multi;
	multi.exponents=llist_new();
	multi.coeffs=llist_new();
	multi.exponents->head=node_new(0);
	multi.coeffs->head=node_new(0);
	Node* exp1=poly1.exponents->head;
	Node* coeff1=poly1.coeffs->head;	
	Node* exp2=poly2.exponents->head;
	Node* coeff2=poly2.coeffs->head;	
	Node* expmulti=multi.exponents->head;
	Node* coeffmulti=multi.coeffs->head;
	while(exp2!=NULL)							//We execute the loop once to initialise multi with 
	{											//(element1 of poly1)*poly2
			if(exp2->next!=NULL)							
			{
			expmulti->next=node_new(0);
			coeffmulti->next=node_new(0);
			expmulti->data=exp1->data+exp2->data;			
			coeffmulti->data=coeff1->data*coeff2->data;
			expmulti=expmulti->next;
			coeffmulti=coeffmulti->next;
			exp2=exp2->next;
			coeff2=coeff2->next;
			}
			else							//for last element
			{
				expmulti->data=exp1->data+exp2->data;
				coeffmulti->data=coeff1->data*coeff2->data;
				expmulti=expmulti->next;
				coeffmulti=coeffmulti->next;
				exp2=exp2->next;
				coeff2=coeff2->next;
			}

	}
	exp2=poly2.exponents->head;
	coeff2=poly2.coeffs->head;	
	exp1=exp1->next;
	coeff1=coeff1->next;
	while(exp1!=NULL)				//from 2nd element of poly1
	{
		exp2=poly2.exponents->head;
		coeff2=poly2.coeffs->head;
		Polynomial poly3;				//poly3 is to store (one element of poly1)*poly2 each time
		poly3.exponents=llist_new();
		poly3.coeffs=llist_new();
		poly3.exponents->head=node_new(0);
		poly3.coeffs->head=node_new(0);
		Node* exppoly3=poly3.exponents->head;
		Node* coeffpoly3=poly3.coeffs->head;
		while(exp2!=NULL)						
		{
			if(exp2->next!=NULL)
			{
				exppoly3->next=node_new(0);
				coeffpoly3->next=node_new(0);
				exppoly3->data=exp1->data+exp2->data;
				coeffpoly3->data=coeff1->data*coeff2->data;  
				exppoly3=exppoly3->next;
				coeffpoly3=coeffpoly3->next;
				exp2=exp2->next;
				coeff2=coeff2->next;
			}
			else
			{
				exppoly3->data=exp1->data+exp2->data;
				coeffpoly3->data=coeff1->data*coeff2->data;
				exppoly3=exppoly3->next;
				coeffpoly3=coeffpoly3->next;
				exp2=exp2->next;
				coeff2=coeff2->next;
			}
		}
		multi=add(multi,poly3);				//we add that polynomial to the result
		exp1=exp1->next;
		coeff1=coeff1->next;
	}
	return multi;
}
/*Add two polynomials and return the result*/
Polynomial add(Polynomial poly1, Polynomial poly2)
{
	Polynomial addn;
	addn.exponents=llist_new();
	addn.coeffs=llist_new();
	Node* exp1=poly1.exponents->head;
	Node* coeff1=poly1.coeffs->head;	
	Node* exp2=poly2.exponents->head;
	Node* coeff2=poly2.coeffs->head;	
	Node* expadd=addn.exponents->head;
	Node* coeffadd=addn.coeffs->head;
	while(exp1!=NULL||exp2!=NULL)
	{	if(exp1==NULL)					//If 1st polynomial traversal finishes first only poly2 needs to be used
		{
			llist_append(addn.exponents,exp2->data);
			llist_append(addn.coeffs,coeff2->data);
			exp2=exp2->next;
			coeff2=coeff2->next;
		}
		else if(exp2==NULL)				//If 2nd polynomial traversal finishes first only poly1 needs to be used
		{
			llist_append(addn.exponents,exp1->data);
			llist_append(addn.coeffs,coeff1->data);
			exp1=exp1->next;
			coeff1=coeff1->next;
		}
		else if(exp1->data==exp2->data) 	//If the exponents are equal we add both coeffs
		{
			if((coeff1->data+coeff2->data)!=0)	//if coeff sum is 0, ignore the term.
			{
				llist_append(addn.exponents,exp1->data);
				llist_append(addn.coeffs,coeff1->data+coeff2->data);
			}
			exp1=exp1->next;
			coeff1=coeff1->next;
			exp2=exp2->next;
			coeff2=coeff2->next;
		
		}
		
		else if(exp1->data<exp2->data)		//exp1 is lesser we append term from poly1 then increment exp1
		{
			llist_append(addn.exponents,exp1->data);
			llist_append(addn.coeffs,coeff1->data);
			exp1=exp1->next;
			coeff1=coeff1->next;			
		}
		else if(exp2->data<exp1->data)		//exp2 is lesser we append term from poly2 then increment exp2
		{
			llist_append(addn.exponents,exp2->data);
			llist_append(addn.coeffs,coeff2->data);
			exp2=exp2->next;
			coeff2=coeff2->next;
		}
		
	}
	return addn;
}

/*Subtract second Polynomial from first*/
Polynomial subtract(Polynomial p1, Polynomial p2)
{
	Node* npc=p2.coeffs->head;
	Node* npe=p2.exponents->head;
	Polynomial p3;
	p3.exponents=llist_new();
	p3.coeffs=llist_new();
	while(npe!=NULL)							//We make a copy of p2 with negated coeffs.
	{
		llist_append(p3.exponents,npe->data);
		llist_append(p3.coeffs,-npc->data);
		npc=npc->next;
		npe=npe->next;
	}
	return add(p1,p3);							//we add p1 with the negated p2
}
/*Evaluate Polynomial at var=k and return the result*/
long long evaluate(Polynomial poly1, int k)
{
	
	Node* exp1=poly1.exponents->head;
	Node* coeff1=poly1.coeffs->head;
	long long result=0;						//initialization
	int power=0;						
	long long kp=1;							//kp is to store pow(k)
	int prevexp=0;							//To store the value of previous exponent
	while(exp1!=NULL)
	{
		power=exp1->data-prevexp;			//to reduce no. of iteration we only need currexp-prevexp
		prevexp=exp1->data;
		int i;
		for(i=0;i<power;i++)
			kp*=k;							//at end of this, kp=k^currexp
		result+=(kp*coeff1->data);			
		exp1=exp1->next;
		coeff1=coeff1->next;
	}
	return result;
	 
}
