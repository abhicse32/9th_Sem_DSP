#include<stdio.h>
#include<stdlib.h>
#include "Polynomial.h"
int main(void)
{
	int option=0;
	while(option!=-1)						//Menu
	{
		scanf("%d",&option);
		switch(option)
		{
			case 1:							//To print a polynomial
				{
					int t;
					scanf("%d",&t);
					int i;
					Polynomial p;
					p.exponents=llist_new();			
					for(i=0;i<t;i++)						//For creating exponent list
					{
						int exp;
						scanf("%d",&exp);
						llist_append(p.exponents,exp);
					}
					p.coeffs=llist_new();
					for(i=0;i<t;i++)						//For creating coefficient list
					{
						int coeff;
						scanf("%d",&coeff);
						llist_append(p.coeffs,coeff);
					}
					print_polynomial(p);
					break;
				}
			case 2:
				{
					int t;
					scanf("%d",&t);
					int i;
					Polynomial p;
					p.exponents=llist_new();
					for(i=0;i<t;i++)
					{
						int exp;
						scanf("%d",&exp);
						llist_append(p.exponents,exp);
					}
					p.coeffs=llist_new();
					for(i=0;i<t;i++)
					{
						int coeff;
						scanf("%d",&coeff);
						llist_append(p.coeffs,coeff);
					}
					int deg=get_degree(p);
					printf("%d\n",deg);
					break;
				}
			case 3:
				{
					int t1;
					scanf("%d",&t1);
					int i;
					Polynomial p1;
					p1.exponents=llist_new();	
					for(i=0;i<t1;i++)
					{
						int exp1;
						scanf("%d",&exp1);
						llist_append(p1.exponents,exp1);
					}
					p1.coeffs=llist_new();
					for(i=0;i<t1;i++)
					{
						int coeff1;
						scanf("%d",&coeff1);
						llist_append(p1.coeffs,coeff1);
					}
					int t2;
					scanf("%d",&t2);
					Polynomial p2;
					p2.exponents=llist_new();
					for(i=0;i<t2;i++)
					{
						int exp2;
						scanf("%d",&exp2);
						llist_append(p2.exponents,exp2);
					}
					p2.coeffs=llist_new();
					for(i=0;i<t2;i++)
					{
						int coeff2;
						scanf("%d",&coeff2);
						llist_append(p2.coeffs,coeff2);
					}
					if(add(p1,p2).exponents->head==NULL)
						printf("0\n");
					else
						print_polynomial(add(p1,p2));
					break;
				}

			case 4:
				{
					int t1;
					scanf("%d",&t1);
					int i;
					Polynomial p1;
					p1.exponents=llist_new();
					for(i=0;i<t1;i++)
					{
						int exp1;
						scanf("%d",&exp1);
						llist_append(p1.exponents,exp1);
					}
					p1.coeffs=llist_new();
					for(i=0;i<t1;i++)
					{
						int coeff1;
						scanf("%d",&coeff1);
						llist_append(p1.coeffs,coeff1);
					}
					int t2;
					scanf("%d",&t2);
					Polynomial p2;
					p2.exponents=llist_new();
					for(i=0;i<t2;i++)
					{
						int exp2;
						scanf("%d",&exp2);
						llist_append(p2.exponents,exp2);
					}
					p2.coeffs=llist_new();
					for(i=0;i<t2;i++)
					{
						int coeff2;
						scanf("%d",&coeff2);
						llist_append(p2.coeffs,coeff2);
					}
					if(subtract(p1,p2).exponents->head==NULL)
						printf("0\n");
					else
						print_polynomial(subtract(p1,p2));
					break;
				}
			case 5:
				{
					int t1;
					scanf("%d",&t1);
					int i;
					Polynomial p1;
					p1.exponents=llist_new();
					for(i=0;i<t1;i++)
					{
						int exp1;
						scanf("%d",&exp1);
						llist_append(p1.exponents,exp1);
					}
					p1.coeffs=llist_new();
					for(i=0;i<t1;i++)
					{
						int coeff1;
						scanf("%d",&coeff1);
						llist_append(p1.coeffs,coeff1);
					}
					int t2;
					scanf("%d",&t2);
					Polynomial p2;
					p2.exponents=llist_new();
					for(i=0;i<t2;i++)
					{
						int exp2;
						scanf("%d",&exp2);
						llist_append(p2.exponents,exp2);
					}
					p2.coeffs=llist_new();
					for(i=0;i<t2;i++)
					{
						int coeff2;
						scanf("%d",&coeff2);
						llist_append(p2.coeffs,coeff2);
					}
					if(multiply(p1,p2).exponents->head==NULL)
						printf("0\n");
					else
						print_polynomial(multiply(p1,p2));
					break;
				}
			case 6:
				{
					int t;
					scanf("%d",&t);
					int i;
					Polynomial p;
					p.exponents=llist_new();
					for(i=0;i<t;i++)
					{
						int exp;
						scanf("%d",&exp);
						llist_append(p.exponents,exp);
					}
					p.coeffs=llist_new();
					for(i=0;i<t;i++)
					{
						int coeff;
						scanf("%d",&coeff);
						llist_append(p.coeffs,coeff);
					}
					int k;
					scanf("%d",&k);
					printf("%lld\n",evaluate(p,k));
					break;
				}
		}
	}
}