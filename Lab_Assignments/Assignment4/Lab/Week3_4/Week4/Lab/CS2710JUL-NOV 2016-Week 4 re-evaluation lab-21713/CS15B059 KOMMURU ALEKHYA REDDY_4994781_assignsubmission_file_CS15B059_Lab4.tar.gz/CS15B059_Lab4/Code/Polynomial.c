/*  KOMMURU ALEKHYA REDDY
    CS15B059
    30AUG2016
    TO FUNCTION OPERATIONS ON TWO POLYNOMIALS USING LISTS
    */
#include "Polynomial.h"
#include<stdio.h>
#include<stdlib.h>

//used to get the degree of the polynomial
int get_degree(Polynomial Poly)
{
	int degree;
	Node *temp=(Poly.exponents)->head;
	while(temp->next!=NULL)
		temp=temp->next;//increment the pointer till the next of it is NULL
	degree=temp->data;//the value stored is the degree
	return(degree);
}

//to print the polynomial
void print_polynomial(Polynomial Poly)
{
	Node *tempexp=(Poly.exponents)->head;
	Node *tempcoe=(Poly.coeffs)->head;//make temporary pointers
	if(tempexp!=NULL)
	{
	if(tempexp->data==0)
	printf("%d ",tempcoe->data);
	else{
	printf("%dx^%d ",tempcoe->data,tempexp->data);
	}
	tempcoe=tempcoe->next;
	tempexp=tempexp->next;//increment the pointers
	
	}
	while(tempexp!=NULL)//continue the process till the pointer points to NULL
	{
	        
		if(tempcoe->data>0)
		{
		if(tempexp->data==0)
		        printf("+ %d ",tempcoe->data);
		else
		printf("+ %dx^%d ",tempcoe->data,tempexp->data);
		tempcoe=tempcoe->next;
		tempexp=tempexp->next;
		
		}
		else if(tempcoe->data<0)
		{
	        int d=-1*tempcoe->data;
	        if(tempexp->data==0)
	                printf("- %d ",d);
	        else
		printf("- %dx^%d ",d,tempexp->data);
		tempcoe=tempcoe->next;
		tempexp=tempexp->next;
		
		}//printing it according to the given format
		else
		{
		tempcoe=tempcoe->next;
		tempexp=tempexp->next;
		}
	}
	printf("\n");
}

//to multiply two polynomials by taking one term at a time
Polynomial multiply(Polynomial Poly1, Polynomial Poly2)
{
         int coef,exp;
         
        Polynomial mult;
        Polynomial temp;//temporary polynomial which stores the value after the multiplication of each term
	mult.exponents=llist_new();
	mult.coeffs=llist_new();
        Node *tempexp1=(Poly1.exponents)->head;
	Node *tempcoe1=(Poly1.coeffs)->head;
	Node *tempexp2=(Poly2.exponents)->head;
	Node *tempcoe2=(Poly2.coeffs)->head;//temporary pointers
	
	while(tempexp1!=NULL)
	{       
		temp.exponents=llist_new();
	        temp.coeffs=llist_new();//initialising the two lists
	        while(tempexp2!=NULL)
	        {
	        llist_append(temp.coeffs,(tempcoe1->data) * (tempcoe2->data));//the coefficient term
	        llist_append( temp.exponents,(tempexp1->data) + (tempexp2->data));//exponent term
	        tempexp2=tempexp2->next;
	        tempcoe2=tempcoe2->next;//increment pointer 2
	        }
	        tempexp2=(Poly2.exponents)->head;//initialise pointer 2 
	        tempcoe2=(Poly2.coeffs)->head;
	        tempexp1=tempexp1->next;
	        tempcoe1=tempcoe1->next;//increment pointer 1
	        mult=add(mult,temp);//add it everytime to get the final multiplication matrix
	        
	}
	return mult;
	
	
}



//to add two polynomials
Polynomial add(Polynomial Poly1, Polynomial Poly2)
{
	Polynomial addn;
	addn.exponents=llist_new();
	addn.coeffs=llist_new();
	Node *tempexp1=(Poly1.exponents)->head;
	Node *tempcoe1=(Poly1.coeffs)->head;
	Node *tempexp2=(Poly2.exponents)->head;
	Node *tempcoe2=(Poly2.coeffs)->head;//temporary pointers
	while(tempexp1!=NULL && tempexp2!=NULL)
	{
	        if((tempexp1->data) < (tempexp2->data))//checking the exponents
	        {
	        llist_append(addn.coeffs,tempcoe1->data);
	        llist_append(addn.exponents,tempexp1->data);
	        tempexp1=tempexp1->next;
	        tempcoe1=tempcoe1->next;
	        }
	        
	        else if(tempexp1->data == tempexp2->data)//if the exponents have equal value then add the coefficients
	        {
	        llist_append(addn.coeffs,(tempcoe1->data)+(tempcoe2->data));
	        llist_append(addn.exponents,tempexp1->data);
	        tempexp1=tempexp1->next;
	        tempcoe1=tempcoe1->next;
	        tempexp2=tempexp2->next;
	        tempcoe2=tempcoe2->next;
	        }
	        
	        else
	        {
	        llist_append(addn.coeffs,tempcoe2->data);
	        llist_append(addn.exponents,tempexp2->data);
	        tempexp2=tempexp2->next;
	        tempcoe2=tempcoe2->next;//increment the necessary pointer
	        }
	}
	
	while(tempexp1!=NULL)//if some elements of one list are left then print them 
	{
	        llist_append(addn.coeffs,tempcoe1->data);
	        llist_append(addn.exponents,tempexp1->data);//append the elements into the add list
	        tempexp1=tempexp1->next;
	        tempcoe1=tempcoe1->next;
	}
	
	while(tempexp2!=NULL)//exhaustively do the same for the second list as well
	{
	        llist_append(addn.coeffs,tempcoe2->data);
	        llist_append(addn.exponents,tempexp2->data);
	        tempexp2=tempexp2->next;
	        tempcoe2=tempcoe2->next;
	}
	return addn;
}

//to subtract the second number from the first
Polynomial subtract(Polynomial Poly1, Polynomial Poly2)
{
        Polynomial sub;
	sub.exponents=llist_new();
	sub.coeffs=llist_new();
	Node *tempexp1=(Poly1.exponents)->head;
	Node *tempcoe1=(Poly1.coeffs)->head;
	Node *tempexp2=(Poly2.exponents)->head;
	Node *tempcoe2=(Poly2.coeffs)->head;  //temporary pointers      

        while(tempexp1!=NULL && tempexp2!=NULL)
	{
	        if((tempexp1->data) < (tempexp2->data))
	        {
	        llist_append(sub.coeffs,tempcoe1->data);
	        llist_append(sub.exponents,tempexp1->data);
	        tempexp1=tempexp1->next;
	        tempcoe1=tempcoe1->next;//to increment the pointers till one of them becomes null
	        }
	        
	        else if(tempexp1->data == tempexp2->data)
	        {
	        llist_append(sub.coeffs,(tempcoe1->data)-(tempcoe2->data));
	        llist_append(sub.exponents,tempexp1->data);
	        tempexp1=tempexp1->next;
	        tempcoe1=tempcoe1->next;
	        tempexp2=tempexp2->next;
	        tempcoe2=tempcoe2->next;
	        }//subtract the coefficients
	        
	        else
	        {
	        llist_append(sub.coeffs,-1*tempcoe2->data);
	        llist_append(sub.exponents,tempexp2->data);
	        tempexp2=tempexp2->next;
	        tempcoe2=tempcoe2->next;
	        }
	}
        
        while(tempexp1!=NULL)//continue to do so till we reach the end of the list
	{
	        llist_append(sub.coeffs,tempcoe1->data);
	        llist_append(sub.exponents,tempexp1->data);
	        tempexp1=tempexp1->next;
	        tempcoe1=tempcoe1->next;
	}
	
	while(tempexp2!=NULL)
	{
	        llist_append(sub.coeffs,-1*tempcoe2->data);
	        llist_append(sub.exponents,tempexp2->data);
	        tempexp2=tempexp2->next;
	        tempcoe2=tempcoe2->next;
	}
	return sub;//returns the polynomial

}

//function to evaluate the value of the polynomial at a given integer
long long int evaluate(Polynomial Poly, int k)
{
       
        long long int value=0;
        int i,power=0;
        long long int a=1;
        Node *tempexp=(Poly.exponents)->head;
	Node *tempcoe=(Poly.coeffs)->head;
        while(tempexp!=NULL)
        {
          power=tempexp->data;
          for(i=0;i<power;i++)
          {
                a=a*k;
          }      
          value=value+(tempcoe->data)*a; //calculates the power     
          tempcoe=tempcoe->next;
          tempexp=tempexp->next;//increments the power
          a=1;
        }
        return(value);
}






