/*KOMMURU ALEKHYA REDDY
        CS15B059
        30AUG2016
        BASED ON THE INPUT TO PERFORM THE OPERATIONS ON POLYNOMIALS
        */
#include<stdio.h>
#include<math.h>
#include"Polynomial.h"
void main()
{
	int option;
	scanf("%d",&option);//inputs the option
	int n,i,n1,n2;
	Polynomial poly,poly1,poly2;
	
	while(option!=-1)//terminates if the value of option is 1
	{
	        if(option==1)
	        {
	               poly.exponents=llist_new();
                       poly.coeffs=llist_new();
         
                       poly1.exponents=llist_new();
                       poly1.coeffs=llist_new();
                        
                       poly2.exponents=llist_new();
                       poly2.coeffs=llist_new();//has 3 polynomials
	                                i=0;
	               scanf("%d",&n);
	               int a[n];
	               while(i<n)
	               {
	                        scanf("%d",&a[i]);
	                        llist_append(poly.exponents,a[i]);
	                         i++;
	               }
	               i=0;
	               while(i<n)
	               {
	                          scanf("%d",&a[i]);
	                          llist_append(poly.coeffs,a[i]);
	                         i++;
	               }//inputs them by appending
	               print_polynomial(poly);//function to print the polynomial
	               scanf("%d",&option);
	               
	          }     
	        else if(option ==2)//to get the degree of the polynomial
	            {
	               poly.exponents=llist_new();
                       poly.coeffs=llist_new();
         
                       poly1.exponents=llist_new();
                       poly1.coeffs=llist_new();
                        
                       poly2.exponents=llist_new();
                       poly2.coeffs=llist_new();
	               i=0;
	               int degree;
	               scanf("%d",&n);
	               int b[n];
	               while(i<n)
	               {
	                        scanf("%d",&b[i]);
	                         llist_append(poly.exponents, b[i]);
	                         i++;
	               }
	               i=0;
	               while(i<n)
	               {
	                        scanf("%d",&b[i]);
	                         llist_append(poly.coeffs,b[i]);
	                         i++;
	               }
	               degree=get_degree(poly);
	               printf("%d\n",degree);//prints the degree
	               scanf("%d",&option);
	             }       
	               
	        else if(option ==3)//to add two polynomials
	        {
	              poly.exponents=llist_new();
                      poly.coeffs=llist_new();
         
                      poly1.exponents=llist_new();
                      poly1.coeffs=llist_new();
                        
                      poly2.exponents=llist_new();
                       poly2.coeffs=llist_new();//defines the polynomials
	                i=0;
	               scanf("%d",&n1);
	               int c[n1];
	               while(i<n1)
	               {
	                         scanf("%d",&c[i]);
	                         llist_append(poly1.exponents, c[i]);
	                         i++;
	               }
	               i=0;
	               while(i<n1)
	               {        
	                        scanf("%d",&c[i]);
	                        llist_append(poly1.coeffs, c[i]);
	                        i++;
	               }  
	               
	               //inputs polynomial 1
	               i=0;
	              
	               scanf("%d",&n2);
	               int d[n2];
	               while(i<n2)
	               {
	                         scanf("%d",&d[i]);
	                         llist_append(poly2.exponents, d[i] );
	                          i++;
	               }
	               i=0;
	               while(i<n2)
	               {
	                          scanf("%d",&d[i]);
	                          llist_append(poly2.coeffs,d[i] );
	                          i++;
	               }
	               //inputs polynomial 2
	               
                       Polynomial poly_addition=add(poly1,poly2);
                       print_polynomial(poly_addition);//performs the addition on two polynomials
                       scanf("%d",&option);
	               
	          }     
	               
                else if(option ==4)//to subtract one polynomial from the other
                       {i=0;
	               poly.exponents=llist_new();
                       poly.coeffs=llist_new();
         
                       poly1.exponents=llist_new();
                       poly1.coeffs=llist_new();
                        
                       poly2.exponents=llist_new();
                       poly2.coeffs=llist_new();
	               scanf("%d",&n1);//inputs the values
	               int e[n1];
	               while(i<n1)
	               {
	                        scanf("%d",&e[i]);
	                        llist_append(poly1.exponents, e[i]);
	                        i++;
	               }
	               i=0;
	               while(i<n1)
	               {
	                        scanf("%d",&e[i]);
	                        llist_append(poly1.coeffs,e[i]);
	                        i++;
	               }//inputs polynomial 1  
	               
	               
	               i=0;
	              
	               scanf("%d",&n2);
	               int f[n2];
	               while(i<n2)
	               {
	                scanf("%d",&f[i]);
	               llist_append(poly2.exponents,f[i]);
	               i++;
	               }
	               i=0;
	               while(i<n2)
	               {
	                scanf("%d",&f[i]);
	               llist_append(poly2.coeffs, f[i]);
	               i++;
	               }//inputs polynomial 2
	               
	               
                       Polynomial poly_sub=subtract(poly1,poly2);
                       print_polynomial(poly_sub);//performs subtraction and prints the nw polynomial
                        scanf("%d",&option);
	               
	               }
	              
	       else if(option==5)//to multiply two polynomials
	       {
	                poly.exponents=llist_new();
                        poly.coeffs=llist_new();
         
                        poly1.exponents=llist_new();
                        poly1.coeffs=llist_new();
                        
                        poly2.exponents=llist_new();
                        poly2.coeffs=llist_new();//initialises the polynomials
	                i=0;
	               scanf("%d",&n1);
	               int g[n1];
	               while(i<n1)
	               {
	                         scanf("%d",&g[i]);
	                         llist_append(poly1.exponents, g[i] );
	                         i++;
	               }
	               i=0;
	               while(i<n1)
	               {
	                          scanf("%d",&g[i]);
	                         llist_append(poly1.coeffs, g[i]);
	                         i++;
	               }  
	               //inputs polynomial 1
	               int n2;
	               i=0;
	               scanf("%d",&n2);
	               int h[n2];
	               while(i<n2)
	               {
	                        scanf("%d",&h[i]);
	                        llist_append(poly2.exponents, h[i]);
	                        i++;
	               }
	               i=0;
	               while(i<n2)
	               {
	                        scanf("%d",&h[i]);
	                        llist_append(poly2.coeffs, h[i] );
	                         i++;
	               }
	               //inputs polynomial
                       Polynomial poly_mult=multiply(poly1,poly2);
                       print_polynomial(poly_mult);//multiplies and  prints the polynomia
                        scanf("%d",&option);
	               }
	               
	       else if(option==6)//to evaluate a polynomial at that particular value
	       {
	                poly.exponents=llist_new();
                        poly.coeffs=llist_new();
         
                        poly1.exponents=llist_new();
                        poly1.coeffs=llist_new();
                        
                        poly2.exponents=llist_new();
                        poly2.coeffs=llist_new();
	                i=0;
	               scanf("%d",&n);
	               int l[n];
	               while(i<n)
	               {
	                scanf("%d",&l[i]);
	               llist_append(poly.exponents, l[i] );
	               i++;
	               }
	               i=0;
	               while(i<n)
	               {
	                scanf("%d",&l[i]);
	               llist_append(poly.coeffs, l[i]);
	               i++;
	               }//inputs the polynomial
	               int k;
	               scanf("%d",&k);//the value at which to be evaluated
	               long long int ans=evaluate(poly,k);
                       printf("%lld\n",ans);//the answer
                       scanf("%d",&option);
	             
	          }
	          else      
	               
	        {printf("Wrong input,enter -1 to terminate else enter 1 to 6 to perform operations");
	         scanf("%d",&option);
	         }        
	               
	        }

	}

