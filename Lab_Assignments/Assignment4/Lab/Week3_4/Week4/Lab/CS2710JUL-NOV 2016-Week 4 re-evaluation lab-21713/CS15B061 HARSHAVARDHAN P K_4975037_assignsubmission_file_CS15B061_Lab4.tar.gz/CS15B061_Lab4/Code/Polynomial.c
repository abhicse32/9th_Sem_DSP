
/*-----------------------------------------------------------------------------
 *  Title: Program to implement Polynomial ADT with functions to print, add, subtract
 *  	   multiply and evaluate for given value.
 *  Author: Harshavardhan.P.K.
 *  Roll No.: CS15B061
 *  Date: 30 August, 2016.	   
 *-----------------------------------------------------------------------------*/
#include "Polynomial.h"
#define INT_MIN -1
#include <stdio.h>
#include <stdlib.h>


/*-----------------------------------------------------------------------------
 *  Function: get_degree - to find degree of polynomial
 *  Input: Polynomial ADT
 *  Output: degree of polynomial
 *-----------------------------------------------------------------------------*/
int get_degree(Polynomial p){
	int t;
	t=llist_size(p.exponents);
	return (llist_get(p.exponents,t-1));
}


/*-----------------------------------------------------------------------------
 *  Function: print_polynomial - to print Polynomial ADT in readable form
 *  Input: Polynomial ADT p
 *  Output: prints polynomial and returns void.
 *-----------------------------------------------------------------------------*/
void print_polynomial(Polynomial p){
	int t,i;
	t=llist_size(p.exponents);
	if(t<=0) {printf("0 \n");return;}
	int n=llist_get(p.exponents,0);
	int coef=llist_get(p.coeffs,0);
	//Printing first term
	if(n>0){
			
		if(coef>0)
			printf("%dx^%d ",coef,n);
		else if(coef<0)
			printf("-%dx^%d ",-coef,n);
	}
	else{
		if(coef>0)
			printf("%d ",coef);
		else if(coef<0)
			printf("-%d ",-coef);
	}
	//If only one term returns
	if(t==1) {putchar('\n'); return;}

	//Prints rest of the terms except last term
	for(i=1;i<t-1;i++){
		
		n=llist_get(p.exponents,i);
		coef=llist_get(p.coeffs,i);
		if(coef>0)
			printf("+ %dx^%d ",coef,n);
		else if(coef<0)
			printf("- %dx^%d ",-coef,n);
	}
	//prints last term
	n=llist_get(p.exponents,t-1);
	coef=llist_get(p.coeffs,t-1);
	if(n>0){
			
		if(coef>0)
			printf("+ %dx^%d \n",coef,n);
		else if(coef<0)
			printf("- %dx^%d \n",-coef,n);
	}
	else{
		if(coef>0)
			printf("+ %d \n",coef);
		else if(coef<0)
			printf("- %d \n",-coef);
	}

}


/*-----------------------------------------------------------------------------
 *  Function: add - adds two polynomials
 *  Input: Polynamial p1,p2: the two polynomials to add.
 *  Output: returns a Polynomial ADT with sum.
 *-----------------------------------------------------------------------------*/
Polynomial add(Polynomial p1, Polynomial p2){

	int t1,t2;
	t1=llist_size(p1.exponents);
	t2=llist_size(p2.exponents);
/*	scanf("%d",&t1);
	Polynomial p1;
	p1.exponents=llist_new();
	p1.coeffs=list_new();
	int n1;
	for(i=0;i<t1;i++){
		scanf("%d",&n);
		llist_prepend(p.exponents,n);
	}int coef1;
	for(i=0;i<t1;i++){
		scanf("%d",&coef);
		llist_prepend(p1.coeffs,n);
	}

	scanf("%d",&t2);
	Polynomial p2;
	p2.exponents=llist_new();
	p2.coeffs=list_new();
	int n2;
	for(i=0;i<t2;i++){
		scanf("%d",&n);
		llist_prepend(p2.exponents,n);
	}int coef2;
	for(i=0;i<t2;i++){
		scanf("%d",&coef);
		llist_prepend(p2.coeffs,n);
	}*/
	int ind1=t1-1,ind2=t2-1;
	Polynomial p3;
	p3.exponents=llist_new();
	p3.coeffs=llist_new();
	int n1=llist_get(p1.exponents,ind1);
	int n2=llist_get(p2.exponents,ind2);
	int coef1=llist_get(p1.coeffs,ind1);
	int coef2=llist_get(p2.coeffs,ind2);
	while(ind1>=0 && ind2>=0){
		//If the next exponents are equal add the coefficients.
		if(n1==n2){if(coef1!=(-coef2)){llist_prepend(p3.exponents,n1); llist_prepend(p3.coeffs,coef1+coef2);}
			ind1--; ind2--;
				
			n1=llist_get(p1.exponents,ind1);
			n2=llist_get(p2.exponents,ind2);
			coef1=llist_get(p1.coeffs,ind1);
			coef2=llist_get(p2.coeffs,ind2);
		}//Else print the term with next largest exponent.
		else if(n1>n2){
			llist_prepend(p3.exponents,n1);
			llist_prepend(p3.coeffs,coef1);
			ind1--;
				
		n1=llist_get(p1.exponents,ind1);
		coef1=llist_get(p1.coeffs,ind1);
		} 
		
		else {
			llist_prepend(p3.exponents,n2);
			llist_prepend(p3.coeffs,coef2);
			ind2--;
				
		n2=llist_get(p2.exponents,ind2);
		coef2=llist_get(p2.coeffs,ind2);
		}
		
	}//If p1 has some terms left add it.
	if(ind1>=0) while(ind1>=0){
			llist_prepend(p3.exponents,n1);
			llist_prepend(p3.coeffs,coef1);
			ind1--;
				
		n1=llist_get(p1.exponents,ind1);
		coef1=llist_get(p1.coeffs,ind1);
		} 
	if(ind2>=0) while(ind2>=0) {//If p2 has some terms left add it.
			llist_prepend(p3.exponents,n2);
			llist_prepend(p3.coeffs,coef2);
			ind2--;
				
		n2=llist_get(p2.exponents,ind2);
		coef2=llist_get(p2.coeffs,ind2);
		}

	return p3;
}



/*-----------------------------------------------------------------------------
 *  Function: subtract - subtracts two polynomials
 *  Inputs: Polynomial p1,p2: to find p1-p2
 *  Output: A Polynomial ADT with anser of difference
 *-----------------------------------------------------------------------------*/
Polynomial subtract(Polynomial p1, Polynomial p2){

	int t1,t2;
	t1=llist_size(p1.exponents);
	t2=llist_size(p2.exponents);
	int ind1=t1-1,ind2=t2-1;
	Polynomial p3;
	p3.exponents=llist_new();
	p3.coeffs=llist_new();
	int n1=llist_get(p1.exponents,ind1);
	int n2=llist_get(p2.exponents,ind2);
	int coef1=llist_get(p1.coeffs,ind1);
	int coef2=llist_get(p2.coeffs,ind2);
	while(ind1>=0 && ind2>=0){
		//If exponents are eual subract coefficients
		if(n1==n2){if(coef1!=coef2){llist_prepend(p3.exponents,n1); llist_prepend(p3.coeffs,coef1-coef2);}
			ind1--; ind2--;
				
			n1=llist_get(p1.exponents,ind1);
			n2=llist_get(p2.exponents,ind2);
			coef1=llist_get(p1.coeffs,ind1);
			coef2=llist_get(p2.coeffs,ind2);
		}
		//If exponents arnt equal append the coeff and exp of next largest exponent.
		else if(n1>n2){
			llist_prepend(p3.exponents,n1);
			llist_prepend(p3.coeffs,coef1);
			ind1--;
				
		n1=llist_get(p1.exponents,ind1);
		coef1=llist_get(p1.coeffs,ind1);
		} 
		
		else {
			llist_prepend(p3.exponents,n2);
			llist_prepend(p3.coeffs,-coef2);
			ind2--;
				
		n2=llist_get(p2.exponents,ind2);
		coef2=llist_get(p2.coeffs,ind2);
		}
		
	}
	//If some elements of p1 are left add to p3
	if(ind1>=0) while(ind1>=0){
			llist_prepend(p3.exponents,n1);
			llist_prepend(p3.coeffs,coef1);
			ind1--;
				
		n1=llist_get(p1.exponents,ind1);
		coef1=llist_get(p1.coeffs,ind1);
		} 
	//If some elements of p2 are left add to p3
	if(ind2>=0) while(ind2>=0) {
			llist_prepend(p3.exponents,n2);
			llist_prepend(p3.coeffs,-coef2);
			ind2--;
				
		n2=llist_get(p2.exponents,ind2);
		coef2=llist_get(p2.coeffs,ind2);
		}

	return p3;

}


/*-----------------------------------------------------------------------------
 *  Function: evaluate - evalute Polynomial for integer value k
 *  Input: Polynomial p - polynomial to evaluate
 *  	   int k: the value for evaluating p(k)
 *
 *  Outpot: ans: the value of p(x)	   
 *-----------------------------------------------------------------------------*/
long long evaluate(Polynomial p, int k){

	int t,i;
	t=llist_size(p.exponents);
	long long ans=llist_get(p.coeffs,t-1);
	int exp1=llist_get(p.exponents,t-1);
	int exp2=llist_get(p.exponents,t-2);
	long long next=ans;
	int index=t-1;
	//evaluating from greatest term by HORNER's METHOD
	while(exp2!=INT_MIN){

		for(i=0;i<exp1-exp2;i++)
			ans*=k;
		index--;	
		next=llist_get(p.coeffs,index); t--;
		
		if(!t) break;
		ans+=next;
		exp1=llist_get(p.exponents,index);
		exp2=llist_get(p.exponents,index-1);
	}
	//If last term is not constant
	for(i=0;i<exp1-0;i++) ans*=k;
	return ans;

}



/*-----------------------------------------------------------------------------
 *  FUnction : multiply - multiply p1, p2.
 *  Input: Polynomial p1,p2 - the polunomials to multiply
 *  pt - Termporary polynomial to store (each term of p1) * p2
 *
 *  Output: Polynomial ADT ans that contains the product.
 *-----------------------------------------------------------------------------*/
Polynomial multiply(Polynomial p1, Polynomial p2){
	Polynomial  ans;
	ans.exponents=llist_new();
	ans.coeffs=llist_new();
	
	int t1,t2,i;
	t1=llist_size(p1.exponents);
	t2=llist_size(p2.exponents);
	int coef1,exp1,ind1=0;
	//Using Distributive law over addition to compute product
	coef1=llist_get(p1.coeffs,ind1);
	exp1=llist_get(p1.exponents,ind1);
	while(exp1!=INT_MIN){
		Polynomial pt;
		pt.exponents=llist_new();
		pt.coeffs=llist_new();
		//Make the next term * p2 in pt
		for(i=0;i<t2;i++){
		llist_append(pt.exponents,exp1+llist_get(p2.exponents,i));
		llist_append(pt.coeffs,coef1*llist_get(p2.coeffs,i));
		}
		//Add p2+ans 
		ans=add(ans ,pt);
		ind1++;

		coef1=llist_get(p1.coeffs,ind1);
		exp1=llist_get(p1.exponents,ind1);
	}
	return ans;
}
