/*
 * =====================================================================================
 *
 *       Filename:  q2.c
 *
 *    Description:  To implement Polynomial.c functions
 *
 *        Created:  Tuesday 30 August 2016 11:53:27  IST
 *       Compiler:  gcc
 *
 *         Author:  Harshavardhan.P.K. 
 *   	   RollNo:  CS15B061
 *
 * =====================================================================================
 */

#include "Polynomial.h"
#include <stdio.h>

void getPolynomial(Polynomial);

/*-----------------------------------------------------------------------------
 *  Function - getPolynomial() - to input the terms for Polynomial from stdin
 *
 *  Input: Polynomial p- the polynomial whose terms are to be inputted.
 *  Output: returns void after putting appropritely the exponents and corresponding
 *  terms.
 *-----------------------------------------------------------------------------*/
void getPolynomial(Polynomial p){
	int t,i,temp;
	scanf("%d",&t);
	for(i=0;i<t;i++){
		scanf("%d",&temp);
		llist_append(p.exponents,temp);
	}
	for(i=0;i<t;i++){
		scanf("%d",&temp);
		llist_append(p.coeffs,temp);
	}
}

/*-----------------------------------------------------------------------------
 *  Function - main : the driver function to test functionality of Polynomial.h
 						It execute relevant operations for opt=[1 .. 6] and terminates
 						for opt=-1
 *
 *  User input: opt : options to test Polynomial operations.
 *  deg; stores degree of polynomial
 *  Polynomial p1,p2,p3: to perform the operations
 *-----------------------------------------------------------------------------*/
int main(void){
	int opt,deg,k;

	do{	//Get users option
		scanf("%d",&opt);
		//Create new Polynomials
		Polynomial p1,p2,p3;
		p1.exponents=llist_new();
		p1.coeffs=llist_new();
		p2.exponents=llist_new();
		p2.coeffs=llist_new();
		//Switch user options
		switch(opt){
			case 1: getPolynomial(p1); print_polynomial(p1); break;
			case 2: getPolynomial(p1); deg=get_degree(p1); printf("%d\n",deg);break;
			case 3: getPolynomial(p1); getPolynomial(p2);
			       	p3=add(p1,p2);print_polynomial(p3); break;
			case 4: getPolynomial(p1); getPolynomial(p2);
			       	p3=subtract(p1,p2); print_polynomial(p3); break;
			case 5: getPolynomial(p1); getPolynomial(p2);
			       	p3=multiply(p1,p2); print_polynomial(p3); break;
			case 6: getPolynomial(p1); scanf("%d",&k);
			       	printf("%lld\n",evaluate(p1,k)); break;	
		}
	}while(opt!=-1);//If user types -1 loop terminates

	return 0;
}
