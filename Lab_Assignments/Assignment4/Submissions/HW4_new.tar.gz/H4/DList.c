#include "DList.h"
#include<stdio.h>
#include<stdlib.h>


DNode* dnode_new( int data)              //fn for creating new node in double linked list
{DNode *node=(DNode*)malloc(sizeof(DNode));
  node->prev=NULL;
  node->next=NULL;
  node->data=data;
  return node;
  }
  
  DList* dlist_new()                     //new list creation
  {DList *lst=(DList*)malloc(sizeof(DList));
   lst->head=NULL;
   return lst;
   }
   
   int dlist_size( DList* lst )          //returns size of list
   {DNode *curr;int i=0;
     
     for(curr=lst->head;curr!=NULL;curr=curr->next)
       i++;
       return i;
       }
       
       void dlist_print( DList* lst )    //printing the list completely
       {DNode *curr;
     
     for(curr=lst->head;curr!=NULL;curr=curr->next)
           printf("%d ",curr->data);
           
           }
           
           
           int dlist_get( DList* lst, int idx )
           {  DNode *curr=lst->head;int i=0;
              if(idx>= dlist_size(  lst ))
               return -1;
           
                for(i=0;i<idx;i++)
                curr=curr->next;
                return curr->data;
                }
                
             void dlist_append( DList* lst, int data )     //adding elements at the end
             {  DNode *curr,*i;
                 curr=dnode_new( data);
                 if(lst->head==NULL)
                 lst->head=curr;
                 else
                 { for(i=lst->head;i->next!=NULL;i=i->next);
                     i->next=curr;
                     curr->next=NULL;
                     curr->prev=i;
                     }
                     
                     }
                   void dlist_prepend( DList* lst, int data )   //adding elements in front
                   { DNode *curr,*i;
                 curr=dnode_new( data);
                 if(lst->head==NULL)
                 lst->head=curr;
                 else
                 { curr->next=lst->head;
                   lst->head->prev=curr;
                   lst->head=curr;
                   }
                   }
                   
                   void dlist_insert( DList* lst, int idx, int data ) //inserting at index posn
                   { DNode *curr,*i;int j=0;
                     DNode *cur=lst->head;
                 curr=dnode_new( data);
                 
                 if(idx> dlist_size(  lst ))
               return ;
                   if(lst->head==NULL || idx==0)
                   dlist_prepend(lst,data);
                   else if(idx==dlist_size(lst))
                   dlist_append(lst,data);
                   else
                   {for(j=0;j<idx-1;j++)
                     cur=cur->next;
                     curr->next=cur->next;
                     cur->next->prev=curr;
                     cur->next=curr;
                     curr->prev=cur;
                     }
                     
                     }
                     
                     
                     void dlist_remove_last( DList* lst )
                     {  DNode *curr,*i;
                       if(lst->head==NULL)
                       return;
                       else if(dlist_size(lst)==1)
                       lst->head=NULL;
                       
                       else{
                        for(i=lst->head;i->next->next!=NULL;i=i->next);
                         i->next->prev=NULL;
                         i->next=NULL;
                         }
                         }


                    void dlist_remove_first( DList* lst )
                    {
                       DNode *curr,*i;
                       if(lst->head==NULL)
                       return;
                       else if(dlist_size(lst)==1)
                       lst->head=NULL;
                       else
                       {  lst->head=lst->head->next;
                          lst->head->prev=NULL;
                          }
                          
                          }
                          
                     void dlist_remove( DList* lst, int idx )
                     {    DNode *curr,*i;int j=0;curr=lst->head;
                           if(lst->head==NULL)
                       return;
                        else if(idx<dlist_size( lst ))
                        {if(idx==0)
                         dlist_remove_first(lst );
                         else if(idx==dlist_size(lst)-1)
                         dlist_remove_last(lst);
                         else 
                         {for(j=0;j<idx-1;j++)
                           curr=curr->next;
                           curr->next=curr->next->next;
                           curr->next->prev=curr;
                          }
                          }
                          
                          }
                          
                          
                          
                          void dlist_reverse(DList* lst)   //reversing DLL non recursively
                          { DNode *tail,*curr,*i;
                            curr=lst->head;
                            for(i=lst->head;i->next!=NULL;i=i->next);
                            tail=i;
                            curr=tail;
                            if(lst->head==NULL ||lst->head->next==NULL)
                             return;
                            
                            while(lst->head->next!=tail)
                            { for(i=lst->head;i->next!=tail;i=i->next);
                                tail->next=i;
                                i->next=NULL;
                                i->prev=tail;
                                tail->prev=NULL;
                                tail=i;
                                }
                                tail->next=lst->head;
                                lst->head->next=NULL;
                                lst->head->prev=tail;
                                tail=lst->head;
                                lst->head=curr;
                                }
                                
                             
                          
                          
                          
                          
                          
                          
                          
                          
                          
                          
                          
                 
             
             
             
                



