#include"SparseMatrix.h"
#include<stdio.h>
#include<stdlib.h>

void main()
{int m,n,c,i,j,x,pt[100000],prn[1000000];
 for(i=0;i<100;i++)
 {prn[i]=pt[i]=0;}
while(1)
{
 Matrix a,b;

 scanf("%d",&c);
 
  if(c==1)
  {
   
     scanf("%d",&a.n_rows);
     b.n_rows= m=a.n_rows;
     scanf("%d",&n);
     a.row_lst=(LList**)malloc(a.n_rows*sizeof(LList*));
     b.row_lst=(LList**)malloc(b.n_rows*sizeof(LList*));
      for(i=0;i<a.n_rows;i++)
   {a.row_lst[i]=llist_new();
     b.row_lst[i]=llist_new();
   }  
     
     
     
     
     
     for(i=0;i<m;i++)
    { 
      for(j=0;j<n;j++)
       {scanf("%d",&x);pt[i]++;
         if(x!=0)
          {llist_append(a.row_lst[i],j,x);prn[i]=pt[i];}
        }

    }  
    /* for(i=0;i<m;i++)
     {llist_print(a.row_lst[i]);
    
     
     while(prn[i]!=pt[i])
     {printf("0 ");prn[i]++;}
       printf("\n");
       } */ 
    
    /*  for(i=0;i<m;i++)
    { 
      for(j=0;j<n;j++)
       {scanf("%d",&x);
         if(x!=0)
          llist_append(b.row_lst[i],j,x);
        }

    }
      for(i=0;i<m;i++)
     llist_print(b.row_lst[i]);*/
     
      for(i=0;i<100;i++)
 {prn[i]=pt[i]=0;}
     
     
     
      for(i=0;i<m;i++)
    { 
      for(j=0;j<n;j++)
       {scanf("%d",&x);pt[i]++;
         if(x!=0)
          {llist_append(b.row_lst[i],j,x);prn[i]=pt[i];}
        }

    }  
     /*for(i=0;i<m;i++)
     {
       llist_print(b.row_lst[i]);
    
     
     while(prn[i]!=pt[i])
     {printf("0 ");prn[i]++;}
       printf("\n");
       } */ 
    
    
    Matrix c=add(a,b);
     
 
    
    
    int total;
   /*for(i=0;i<m;i++)
    { total=llist_print(c.row_lst[i]);
       while(total<n)
       {printf("0 ");total++;}
        
      printf("\n");}*/
      
      for(i=0;i<m;i++)
       { if(c.row_lst[i]->head!=NULL &&c.row_lst[i]->head->val!=0)
         {llist_print(c.row_lst[i]);
          printf("\n");}
         }
     
     }
     
     
    else if(c==2)
  {
   
     scanf("%d",&a.n_rows);
     b.n_rows= m=a.n_rows;
     scanf("%d",&n);
     a.row_lst=(LList**)malloc(a.n_rows*sizeof(LList*));
     b.row_lst=(LList**)malloc(b.n_rows*sizeof(LList*));
      for(i=0;i<a.n_rows;i++)
   {a.row_lst[i]=llist_new();
     b.row_lst[i]=llist_new();
   }  
     
     
     
     
     
     for(i=0;i<m;i++)
    { 
      for(j=0;j<n;j++)
       {scanf("%d",&x);pt[i]++;
         if(x!=0)
          {llist_append(a.row_lst[i],j,x);prn[i]=pt[i];}
        }

    }  
    /* for(i=0;i<m;i++)
     {llist_print(a.row_lst[i]);
    
     
     while(prn[i]!=pt[i])
     {printf("0 ");prn[i]++;}
       printf("\n");
       } */ 
    
    /*  for(i=0;i<m;i++)
    { 
      for(j=0;j<n;j++)
       {scanf("%d",&x);
         if(x!=0)
          llist_append(b.row_lst[i],j,x);
        }

    }
      for(i=0;i<m;i++)
     llist_print(b.row_lst[i]);*/
     
      for(i=0;i<100;i++)
 {prn[i]=pt[i]=0;}
     
     
     
      for(i=0;i<m;i++)
    { 
      for(j=0;j<n;j++)
       {scanf("%d",&x);pt[i]++;
         if(x!=0)
          {llist_append(b.row_lst[i],j,x);prn[i]=pt[i];}
        }

    }  
     /*for(i=0;i<m;i++)
     {
       llist_print(b.row_lst[i]);
    
     
     while(prn[i]!=pt[i])
     {printf("0 ");prn[i]++;}
       printf("\n");
       } */ 
    
    
    Matrix c=subtract(a,b);
     
 
    
    
    int total;
   /*for(i=0;i<m;i++)
    { total=llist_print(c.row_lst[i]);
       while(total<n)
       {printf("0 ");total++;}
        
      printf("\n");}*/
      
      for(i=0;i<m;i++)
       { if(c.row_lst[i]->head!=NULL &&c.row_lst[i]->head->val!=0)
         {llist_print(c.row_lst[i]);
         printf("\n");
         }
        }
     
     }
     
     
     
     else if(c==3)
     {    scanf("%d",&a.n_rows);
      m=a.n_rows;
      
     scanf("%d",&n);
     b.n_rows=n;
     a.row_lst=(LList**)malloc(a.n_rows*sizeof(LList*));
     b.row_lst=(LList**)malloc(b.n_rows*sizeof(LList*));
      for(i=0;i<a.n_rows;i++)
   a.row_lst[i]=llist_new();
     for(i=0;i<n;i++)
     b.row_lst[i]=llist_new();
     
     
     
     
     
     
     for(i=0;i<m;i++)
    { 
      for(j=0;j<n;j++)
       {scanf("%d",&x);pt[i]++;
         if(x!=0)
          {llist_append(a.row_lst[i],j,x);prn[i]=pt[i];}
        }

    }  
    /* for(i=0;i<m;i++)
     {llist_print(a.row_lst[i]);
    
     
     while(prn[i]!=pt[i])
     {printf("0 ");prn[i]++;}
       printf("\n");
       } */ 
    
    /*  for(i=0;i<m;i++)
    { 
      for(j=0;j<n;j++)
       {scanf("%d",&x);
         if(x!=0)
          llist_append(b.row_lst[i],j,x);
        }

    }
      for(i=0;i<m;i++)
     llist_print(b.row_lst[i]);*/
     
      for(i=0;i<100;i++)
 {prn[i]=pt[i]=0;}
     
     
     
      for(i=0;i<n;i++)
    { 
      scanf("%d",&x);pt[i]++;
         if(x!=0)
          {llist_append(b.row_lst[i],0,x);prn[i]=pt[i];}
        }
      /*   for(i=0;i<n;i++)
       { llist_print(b.row_lst[i]);
          printf("\n");} */
        
        
        
        
       Matrix c =matrix_vect_multiply(a,b);
       
        int ko;
      for(i=0;i<m;i++)
       { ko=llist_print(c.row_lst[i]);
          if(ko==0)
          printf("0");
          printf("\n");
          } 
       
       
       
       
       
        
        

    }
    
     else
      break;
      
      }
     
    
      
     
     }
     
     
     
