#include "queue_a.h"
#include <stdio.h>
int main(){
	queue_a* que= queuea_new();
	printf("%d\n",queuea_is_full(que));
	queuea_push(que,12);
	queuea_push(que,15);
	printf("%d\n",queuea_is_full(que));
}