#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "queue_a.h"
#include "queue.h"
#define BUFF_SIZE 20
int main(int* argc, char* argv[]){
	char str[BUFF_SIZE];
	queue *que= queue_new();
	queue_a* que_a= queuea_new();
	while(fgets(str,BUFF_SIZE,stdin)!=NULL){
		str[strlen(str)-1]='\0';
		char* temp= strtok(str," ");
		if(!strcmp(temp,"push")){
			int data=atoi(strtok(NULL," "));
			queuea_push(que_a,data);
			queue_push(que,data);
			queue_print(que);
			printf(": ");
			queuea_print(que_a);

		}else if(!strcmp(temp,"size"))
			printf("%d : %d",queue_size(que),queuea_size(que_a));
		else if(!strcmp(temp,"is_full"))
			printf("%d",queuea_is_full(que_a));
		else if(!strcmp(temp,"is_empty"))
			printf("%d : %d",queue_is_empty(que),queuea_is_empty(que_a));
		else if(!strcmp(temp,"pop"))
			printf("%d : %d", queue_pop(que),queuea_pop(que_a));
		printf("\n");
	}
}	