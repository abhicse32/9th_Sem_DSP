#include "queue_a.h"
#include <stdio.h>
#include <stdlib.h>
#define size 1000

// create a new queue
queue_a* queuea_new(){
	queue_a* que= (queue_a*)malloc(sizeof(queue_a));
	que->arr= (int*)malloc(sizeof(int)*size);
	que->front=0;
	que->rear= 0;
	return que;
}

// push an element on the queue
void queuea_push(queue_a* que, int data){
	if(!queuea_is_full(que)){
		que->arr[que->rear]=data;
		++(que->rear);
	}
}

// pop the top element from the queue
int queuea_pop(queue_a* que){
	int retVal= -1;
	if(que->front != que->rear){
		retVal= que->arr[que->front];
		++(que->front);
	}
	return retVal;
}

// Check if queue is empty
bool queuea_is_empty(queue_a* que){
	return (que->front == que->rear) ? true: false;
}

// bool check if queue is full
bool queuea_is_full(queue_a* que){
	return que->rear >= size ? true: false;
}

// find the size of the queue
int queuea_size(queue_a* que){
	return que->rear;
}

// print queue element
void queuea_print(queue_a* que){
	int i;
	for(i= que->front; i < que->rear; i++)
		printf("%d ",que->arr[i]);
}