#ifndef QUEUE_A
#define QUEUE_A
#include <stdbool.h>

typedef struct Queue_a{
	int *arr;
	int front;
	int rear;
}queue_a;

// create a new queue
queue_a* queuea_new();

// push an element on the queue
void queuea_push(queue_a*, int);

// pop the top element from the queue
int queuea_pop(queue_a*);

// Check if queue is empty
bool queuea_is_empty(queue_a*);

// bool check if queue is full
bool queuea_is_full(queue_a*);

// find the size of the queue
int queuea_size(queue_a*);

// print queue element
void queuea_print(queue_a*);

#endif