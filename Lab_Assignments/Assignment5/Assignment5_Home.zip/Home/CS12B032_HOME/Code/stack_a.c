#include "stack_a.h"
#include <stdio.h>
#include <stdlib.h>
#define size 1000

// create new stack
stack_a* stacka_new(){
	stack_a* st=(stack_a*)malloc(sizeof(stack_a));
	st->arr=(int*)malloc(sizeof(int)*size);
	st->top= 0;
	return st;
}

// push an element on the stack
void stacka_push(stack_a* st, int data){
	if(!stacka_is_full(st)){
		st->arr[st->top]= data;
		++(st->top);
	}
}

// pop the top element from the stack
int stacka_pop(stack_a* st){
	int retVal=-1;
	if(!stacka_is_empty(st)){
		retVal=st->arr[(st->top)-1];
		--(st->top);
	}
	return retVal;
}

// Check if stack is empty
bool stacka_is_empty(stack_a* st){
	return st->top?false:true;
}

// bool check if stack is full
bool stacka_is_full(stack_a* st){
	return st->top >= size?true:false;
}

// find the size of the stack
int stacka_size(stack_a* st){
	return st->top;
}

// print stack element
void stacka_print(stack_a* st){
	int i;
	for(i=st->top-1;i>=0;i--)
		printf("%d ",st->arr[i]);
}