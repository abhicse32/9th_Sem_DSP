#ifndef STACK_A
#define STACK_A
#include <stdbool.h>

typedef struct Stack_a{
	int *arr;
	int top;
}stack_a;

// create a new stack
stack_a* stacka_new();

// push an element on the stack
void stacka_push(stack_a*, int);

// pop the top element from the stack
int stacka_pop(stack_a*);

// Check if stack is empty
bool stacka_is_empty(stack_a*);

// bool check if stack is full
bool stacka_is_full(stack_a*);

// find the size of the stack
int stacka_size(stack_a*);

// print stack element
void stacka_print(stack_a*);

#endif