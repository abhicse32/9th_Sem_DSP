#ifndef STACK_USING_QUEUE_H
#define STACK_USING_QUEUE_H
#include "queue.h"
#include "List.h"
#include <stdio.h>
#include <stdlib.h>
#include<string.h>
void push(queue* q,int n);
void pop(queue* q);
void size(queue* q);
void empty(queue* q);
#endif

