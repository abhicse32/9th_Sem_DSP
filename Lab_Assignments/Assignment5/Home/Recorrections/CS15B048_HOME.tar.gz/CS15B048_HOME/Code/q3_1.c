/* Program to convert an infix expression to postfix form
 * Author : G.Kavya
 * Date: 10.09.2016
*/

#include<stdio.h>
#include<stdlib.h>
#include<ctype.h>
#include "stack.h"

// Max buffer size for fgets
const int size = 1000;

// Returns the preference order for the elements
int prefOfElem(char c){
  // Sentinel character to be ignored till end of string
  if(c == '#')
	return -1;
  if(c == '(')
	return 0;
  if(c == '|')
	return 1;
  if(c == '^')
	return 2;
  if(c == '&')
	return 3;
  if(c == '+' || c == '-')
	return 4;
  if(c == '/' || c == '*' || c == '%')
	return 5;
}

void printPostfix(char* string){
  int i = 0;
  stack *postfix = stack_new();

  // Push sentinel character to detect end of stack
  stack_push(postfix, '#');

  while(string[i] != '\n'){
	if(isalnum(string[i]) || (string[i] == '-' && string[i+1] != ' ')){
	  // Variables and constants are printed as such
	  // Extra code to print multi-digit constants and multi-character alphabets 
	  if(string[i] == '-' && string[i+1] != ' '){
		printf("%c", string[i]);
		i++;
	  }
	  while(isalnum(string[i])){
		printf("%c", string[i++]);
	  }
	  printf(" ");
	  continue;
	}
	else if(string[i] == '('){
	  // Opening paranthesis are pushed into stack
	  stack_push(postfix, (int) string[i]);
	}
	else if(string[i] != ')' && string[i] != ' '){
	  // This is an operator
	  char prev = (char) stack_pop(postfix);
	  // We pop operators that are of more precedence than this one
	  while(prev != '#' && prefOfElem(prev) >= prefOfElem(string[i])){
		printf("%c ", prev);
		prev = (char) stack_pop(postfix);
	  }
	  stack_push(postfix, (int) prev);
	  // And then push this operator
	  stack_push(postfix, (int) string[i]);
	}
	else if(string[i] == ')'){
	  // It is a closing brace
	  // We pop all elements till the opening brace and throw the opening brace
	  
	  char prev = (char) stack_pop(postfix);
	  while(prev != '('){
		printf("%c ", prev);
		prev = (char) stack_pop(postfix);
	  }
	}
	i++;

  }
  // String is completed
  // Now pop all remaining elements in stack
  char leftover = (char) stack_pop(postfix);
  while(leftover != '#'){
	printf("%c ", leftover);
	leftover = (char) stack_pop(postfix);
  }
}

int main(){
  char *input = (char*) malloc(size * sizeof(char*));
  while(fgets(input, size, stdin)){
	printPostfix(input);
	fflush(stdin);
	printf("\n");
  }
  return 0;
}
