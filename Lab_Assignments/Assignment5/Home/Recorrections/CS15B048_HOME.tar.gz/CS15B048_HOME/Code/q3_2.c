/* Program to evaluate a given postfix expression and print output
 * Author : G.Kavya CS15B048
 * Date : 13.09.2016
*/

#include<stdio.h>
#include<stdlib.h>
#include<ctype.h>
#include "stack.h"

// For max buffer length for fgets
const int size = 1000;

// To perform operations when character of operation is given
int resultOfOperation(char c, int n1, int n2){
  if(c == '+')
	return n1 + n2;
  if(c == '-')
	return n1 - n2;
  if(c == '*')
	return n1 * n2;
  if(c == '/')
	return n1 / n2;
  if(c == '%'){
	/* Code in case modulus of negative number is calculated by adding number to make it positive
	if(n1 < 0)
	  return (n2 + n1) % n2;
	*/
	return n1 % n2;
  }
  if(c == '&')// Bitwise and
	return n1 & n2;
  if(c == '|')// Bitwise or
	return n1 | n2;
  if(c == '^')// Bitwise XOR
	return n1 ^ n2;
}

int evaluatePostfix(char *string){
  stack *result = stack_new();
  // Pushing sentinel character to detect end of stack
  stack_push(result, '#');

  int i = 0;
  while(string[i] != '\n'){
	// To input numbers, special condition to input negative numbers
	if(isdigit(string[i]) || (string[i] == '-' && string[i+1] != ' ')){
	  int num = 0, pre = 1;
	  if(string[i] == '-' && string[i+1] != ' '){
		pre = -1;
		i++;
	  }
	  // Calculating value for multi-digit number inputs
	  while(isdigit(string[i])){
		num *= 10;
		num += string[i] - '0';
		i++;
	  }
	  stack_push(result, pre*num);
	  if(string[i] == '\n')
		break;
	}
	else if(string[i] != ' '){
	  // This is an operator
	  int num1 = stack_pop(result);
	  int num2 = stack_pop(result);
	  //printf("Pop %d %d\n", num1, num2);
	  stack_push(result, resultOfOperation(string[i], num2, num1));
	}
	i++;
  }
  // Final value stored in stack is result
  return stack_pop(result);
}

int main(){
  char *input = (char*) malloc(1000 * sizeof(char));
  while(fgets(input, size, stdin)){
	printf("%d\n", evaluatePostfix(input));
  }
  return 0;
}
