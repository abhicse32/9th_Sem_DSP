/* Program to implement queue data structure using existing stack data structure and its functions
 * Author : G.Kavya CS15B048
 * Date : 13.09.2016
*/

#include<stdio.h>
#include "queue_using_stack.h"
#include <stdlib.h>
#include <string.h>
#define BUFF_SIZE 20

// Note: qus stands for queue using stack
int main(int argc, char* argv[]){
	char str[BUFF_SIZE];
	stack *my_stack= stack_new();

	while(fgets(str,BUFF_SIZE,stdin)!=NULL){
		str[strlen(str)-1]='\0';
		char* temp= strtok(str," ");
		if(!strcmp(temp,"enqueue")){
			int data=atoi(strtok(NULL," "));
			qus_enqueue(my_stack, data);
			qus_print(my_stack);
		}
		else if(!strcmp(temp,"size"))
			printf("%d",qus_size(my_stack));
		else if(!strcmp(temp,"is_empty"))
			printf("%d",qus_is_empty(my_stack));
		else if(!strcmp(temp,"dequeue"))
			printf("%d", qus_dequeue(my_stack));
		printf("\n");
	}
}	
