/* Program to implement stack using existing queue data structure and its functions
 * Author : G.Kavya CS15B048
 * Date : 13.09.2016
 */

#include<stdio.h>
#include <stdlib.h>
#include <string.h>
#include "stack_using_queue.h"
#define BUFF_SIZE 20

// Note : suq stands for stack using queue
int main(int argc, char* argv[]){
  char str[BUFF_SIZE];
  queue* my_queue = queue_new();
  while(fgets(str,BUFF_SIZE,stdin)!=NULL){
	str[strlen(str)-1]='\0';
	char* temp= strtok(str," ");
	if(!strcmp(temp,"push")){
	  int data=atoi(strtok(NULL," "));
	  suq_push(my_queue,data);
	  suq_print(my_queue);
	}
	else if(!strcmp(temp,"size"))
	  printf("%d",suq_size(my_queue));
	else if(!strcmp(temp,"is_empty"))
	  printf("%d",suq_is_empty(my_queue));
	else if(!strcmp(temp,"pop"))
	  printf("%d",suq_pop(my_queue));
	printf("\n");
  }
}	
