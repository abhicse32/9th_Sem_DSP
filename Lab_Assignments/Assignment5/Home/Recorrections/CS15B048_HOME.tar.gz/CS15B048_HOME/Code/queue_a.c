#include "queue_a.h"
#include <stdio.h>
#include <stdlib.h>
#define size 1000

// create a new queue
queue* queue_new(){
  queue* new = (queue*) malloc(sizeof(queue));
  new->arr = (int*) malloc(sizeof(int)*size);
  // -1 signifies no elements in queue
  new->front = -1;
  new->rear = -1;
  return new;
}

// add an element in the queue
void enqueue(queue* my_queue, int value){
  if(my_queue->front == -1){
	// Case of no elements in queue
	my_queue->arr[++my_queue->front] = value;
	my_queue->rear++;
	return;
  }
  my_queue->arr[(++my_queue->rear) % size] = value;
}

// remove the first element from the queue
int dequeue(queue* my_queue){
  // Have not handled empty queue case
  if(my_queue->front == my_queue->rear){
	// Case of only one element
	int value = my_queue->arr[my_queue->front];
	my_queue->front = my_queue->rear = -1;
	return value;
  }
  int value = my_queue->arr[my_queue->front];
  my_queue->front = (my_queue->front + 1) % size;
  return value;
}

// Check if queue is empty
bool queue_is_empty(queue* my_queue){
	// Note: Both front and rear will hold value -1 in that case by my implementation
	return (my_queue->front == -1);
}

// check if queue is full
bool queue_is_full(queue* my_queue){
  // Normally front is 0 and rear is end
  // But in wrapping around cases front is one in front of rear
  return ((my_queue->front == 0 && my_queue->rear == size-1) || (my_queue->front == my_queue->rear + 1));
}

// find the size of the queue
int queue_size(queue* my_queue){
  if(queue_is_empty(my_queue))
	return 0;
  if(queue_is_full(my_queue))
	return (size);
  int front = my_queue->front;
  int rear = my_queue->rear;
  if(front == rear)
	return 1;
  if(front > rear)
	// Implies that queue wrapped around itself once
	// Total minus occupied elements
	return (size - (front - 0 + 1) - (size - 1 - rear + 1));
  else
	// Implies queue is still maintaining order
	return ( rear - front + 1);
}

// print queue element
void queue_print(queue* my_queue){
  if(queue_is_empty(my_queue))
	return;
  int front = my_queue->front;
  int rear = my_queue->rear;
  if(rear >= front){
	// Queue did not wrap around
	int i = front;
	while(i != rear+1){
	  printf("%d ", my_queue->arr[i++]);
	}
  }
  // Queue wrapped around once and is thus in 2 pieces
  else {
	int i = front;
	while(i < size){
	  printf("%d ", my_queue->arr[i++]);
	}
	i = 0;
	while(i <= rear){
	  printf("%d ", my_queue->arr[i++]);
	}
  }
}
