/* Program with functions to implement queue data structure using existing stack data structure and its functions
 * Author : G.Kavya CS15B048
 * Date : 13.09.2016
*/

#include "queue_using_stack.h"
#include "stack.h"

// Recursively removes elements till the last element and then pushes given element and then pushes back previously popped elements
void qus_enqueue(stack* my_stack, int data){
  if(stack_is_empty(my_stack)){
	stack_push(my_stack, data);
	// Thus given element is at the bottom of the stack 
	return;
  }
  int value = stack_pop(my_stack);
  qus_enqueue(my_stack, data);
  stack_push(my_stack, value);
}

// Print elements of queue
void qus_print(stack* my_stack){
  stack_print(my_stack);
}

// Print size of queue
int qus_size(stack* my_stack){
  return stack_size(my_stack);
}

// Print if queue is empty
bool qus_is_empty(stack* my_stack){
  return stack_is_empty(my_stack);
}

// Dequeue the first entered element from queue
// Since first entered elements are on the top to dequeue just pop
int qus_dequeue(stack* my_stack){
  return stack_pop(my_stack);
}
