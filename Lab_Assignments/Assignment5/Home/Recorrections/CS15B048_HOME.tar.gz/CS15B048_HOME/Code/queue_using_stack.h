#ifndef QUEUE_USING_STACK_H
#define QUEUE_USING_STACK_H
#include "stack.h"
#include <stdbool.h>

// Add an element to queue
void qus_enqueue(stack* my_stack, int data);

// Print queue
void qus_print(stack* my_stack);

// Print queue size
int qus_size(stack* my_stack);

// Print if queue is empty
bool qus_is_empty(stack* my_stack);

// Dequeue an element from queue
int qus_dequeue(stack* my_stack);

#endif
