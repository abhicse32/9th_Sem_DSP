#include "stack_a.h"
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#define size 1000
//#define size 1 // To check working of is_full

// create a new stack
stack* stack_new(){
  stack* new = (stack*) malloc(sizeof(stack));
  new->arr = (int*) malloc(size*sizeof(int));
  new->top = -1;// Points to the current top most element in this case nothing
  return new;
}

// push an element on the stack
void stack_push(stack* my_stack, int value){
  my_stack->arr[++my_stack->top] = value;
}

// pop the top element from the stack
int stack_pop(stack* my_stack){
  if(my_stack->top == -1){
	return INT_MIN;
  }
  return my_stack->arr[my_stack->top--];
}

// Check if stack is empty
bool stack_is_empty(stack* my_stack){
  return (my_stack->top == -1);
}

// bool check if stack is full
bool stack_is_full(stack* my_stack){
  return (my_stack->top == size - 1);
}

// find the size of the stack
int stack_size(stack* my_stack){
  return my_stack->top + 1;
}

// print stack element
void stack_print(stack* my_stack){
  int i;
  for(i = my_stack->top; i >= 0; i--){
	printf("%d ", my_stack->arr[i]);
  }
  printf("\n");
}

