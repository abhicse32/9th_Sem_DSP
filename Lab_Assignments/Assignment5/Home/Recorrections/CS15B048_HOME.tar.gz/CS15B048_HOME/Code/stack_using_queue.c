/* Program with functions to implement stack using existing queue data structure and its functions
 * Author : G.Kavya CS15B048
 * Date : 13.09.2016
 */

#include "stack_using_queue.h"
#include "queue.h"

// Inserts a sentinel element and then data element, then dequeues each element and inserts it again till it rreaches the sentinel element
// Thus element entered last appears like the element entered first
void suq_push(queue* my_queue, int data){
  if(queue_is_empty(my_queue)){
	enqueue(my_queue, data);
	return;
  }
  enqueue(my_queue, '#');
  enqueue(my_queue, data);
  int x = dequeue(my_queue);
  while(x != '#'){
	enqueue(my_queue, x);
	x = dequeue(my_queue);
  }
}

// Print elements of stack
void suq_print(queue* my_queue){
  queue_print(my_queue);
}

// Print size of stack
int suq_size(queue* my_queue){
  queue_size(my_queue);
}

// Print if stack is empty
bool suq_is_empty(queue* my_queue){
  queue_is_empty(my_queue);
}

// Pop topmost element from stack
int suq_pop(queue* my_queue){
  // Since last entered element appears first in the queue to pop just dequeue
  return dequeue(my_queue);
}
