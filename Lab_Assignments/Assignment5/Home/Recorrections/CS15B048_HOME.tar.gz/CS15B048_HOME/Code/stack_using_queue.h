#ifndef STACK_USING_QUEUE_H
#define STACK_USING_QUEUE_H
#include "queue.h"
#include <stdbool.h>

// Push an element to stack
void suq_push(queue* my_queue, int data);

// Print the stack elements
void suq_print(queue* my_queue);

// Print size of stack
int suq_size(queue* my_queue);

// Print whether stack is empty
bool suq_is_empty(queue* my_queue);

// Pop topmost element out of stack
int suq_pop(queue* my_queue);

#endif
