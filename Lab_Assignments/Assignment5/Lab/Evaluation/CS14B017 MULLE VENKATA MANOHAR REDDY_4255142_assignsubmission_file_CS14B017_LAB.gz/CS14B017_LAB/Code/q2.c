#include<stdio.h>
#include "stack.h"
#include "List.h"
#include<string.h>
//#include "stack.c"
//#include "List.c"
int main(){
	int n,N,i,j,ans=1,b,s,c;
	scanf("%d",&N);
	int B[N];
	for(j=0;j<N;j++){
		c=0;
//		ans=1;
		char S[1024];
		scanf("%s",S);
		n=strlen(S);
		int A[n];
	//	printf("flag0\n");
		for(i=0;i<n;i++){
			if(S[i]=='{'){
				A[i]=3;
			}
			else if(S[i]=='}'){
				A[i]=-3;
			}
/*			else if(S[i]=='['){
				A[i]=2;
			}
			else if(S[i]==']'){
				A[i]=-2;
			}
			else if(S[i]=='('){
				A[i]=1;
			}
			else if(S[i]==')'){
				A[i]=-1;
			}*/
		}
	//	printf("flag1\n");
		stack* st=stack_new();
//printf("....%d.....\n",stack_size(st));
		for(i=0;i<n;i++){
			if(A[i]==/*1||A[i]==2||A[i]==*/3){
				stack_push(st,A[i]);
			}
			else if((A[i]==/*-1||A[i]==-2||A[i]==*/-3)&&(stack_size(st)!=0)){
				if(stack_pop(st)==-1*A[i]){
//					ans=0;
//					break;
				}
				else{
					stack_push(st,-1*A[i]);
					stack_push(st,A[i]);
				}
			}	
			else{
//				ans=0;
				stack_push(st,-1*A[i]);
				c++;
			}
		}
		s=stack_size(st);
/*		while(stack_size(st)>0){
			if(stack_pop(st)==3){
				c++;
			}
		}*/
		if(s%2==0){
			B[j]=c+s/2;
		}
		else{
			B[j]=-1;
		}
//		if(ans==0){
//			printf("0");
//			B[j]=0;
//		}

//		else if(stack_size(st)!=0){
//			printf("0");
//			B[j]=0;
//		}
//		else{
//			printf("1");
//			B[j]=1;
//		}
//		while(stack_size(st)!=0){
//			b=stack_pop(st);
//		}
	}
	for(i=0;i<N;i++){
		printf("%d\n",B[i]);
	}
}
