#include<stdio.h>
#include "stack.h"
#include "List.h"
#include<string.h>
//#include "stack.c"
//#include "List.c"
int main(){
	int n,N,i,j/*,ans=1*/,b,a,k;
	scanf("%d",&N);
	int B[N][10001];
//printf("flag0\n");
	for(j=0;j<N;j++){
//printf("entered for loop\n");
//		ans=1;
		int p;
		scanf("%d",&p);
		int A[p];
		scanf("%d",&A[0]);
		a=A[0];
		for(i=1;i<p;i++){
			scanf("%d",&A[i]);
			if(A[i]>A[i-1]){
				a=A[i];
			}
		}
//		n=strlen(S);
		n=p;
		int C[a];
		for(i=0;i<n;i++){
//			C[A[i]][0]=i;
			C[A[i]]=-1;
		}
/*		int A[n];
	//	printf("flag0\n");
		for(i=0;i<n;i++){
			if(S[i]=='{'){
				A[i]=3;
			}
			else if(S[i]=='}'){
				A[i]=-3;
			}
			else if(S[i]=='['){
				A[i]=2;
			}
			else if(S[i]==']'){
				A[i]=-2;
			}
			else if(S[i]=='('){
				A[i]=1;
			}
			else if(S[i]==')'){
				A[i]=-1;
			}
		}*/
	//	printf("flag1\n");
//printf("initialized stack\n");
		stack* st=stack_new();
//printf("....%d.....\n",stack_size(st));
/*		for(i=0;i<n;i++){
			if(A[i]==1||A[i]==2||A[i]==3){
				stack_push(st,A[i]);
			}
			else if((A[i]==-1||A[i]==-2||A[i]==-3)&&(stack_size(st)!=0)){
				if(stack_pop(st)!=-1*A[i]){
					ans=0;
					break;
				}
			}	
			else{
				ans=0;
			}
		}
		if(ans==0){
//			printf("0");
			B[j]=0;
		}
		else if(stack_size(st)!=0){
//			printf("0");
			B[j]=0;
		}
		else{
//			printf("1");
			B[j]=1;
		}
		while(stack_size(st)!=0){
			b=stack_pop(st);
		}
	}
	for(i=0;i<N;i++){
		printf("%d\n",B[i]);
						*/
//			stack_push(st,S[i]);
//			while(A[i]=B)
//printf("process started\n");
			b=A[0];
			stack_push(st,A[0]);
			if(n>1){
				i=1;
				while(i<n){
					if(b>A[i]){
						stack_push(st,A[i]);
						i++;
					}
				
					else if(b<A[i]){
						while(1){
							a=stack_pop(st);
							C[a]=A[i];
							if(a==b){
								break;
							}
						}
						b=A[i];
						stack_push(st,A[i]);
						i++;
					}
				}
			}
			B[j][0]=n;
			for(k=1;k<=n;k++){
				B[j][k]=C[A[k-1]];
			}
//			B[N][n]=-2;
//			B[j][k]
//printf("process ended\n");
	}
//printf("came out\n");
//printf("%d\n",B[0][0]);
	for(i=0;i<N;i++){
//		while(B[i][j]!=-2){
		for(j=0;j<B[i][0];j++){
			printf("%d ",B[i][j+1]);
//			j++;
		}
		printf("\n");
	}
}
