/* Program to find next greater element in an array in order of appearance
 * Author : G.Kavya CS15B048
 * Date : 16.09.2016
 */

#include "stack.h"
#include "queue.h"

#include<stdio.h>

/*
int main(){
  int t;
  while(t-- > 0){
	queue *my_queue = queue_new();
	stack* my_stack = stack_new();
	// Number of entries
	int n;
	scanf("%d", &n);
	int i = 0;
	int waiting;
	//for(; i < n; i++){
	while(i == 0 || !queue_is_empty(my_queue)){
	  if(i < n){
		int num;
		scanf("%d", &num);
		enqueue(my_queue, num);
		i++;
	  }

	  waiting = my_queue->front->head->data;

	  if(stack_is_empty(my_stack)){
		//waiting = stack_pop(my_stack);
		if(num > waiting){
		  stack_push(my_stack, num);
		  dequeue(my_queue);
		  printf("%d ", num);
		}
	  }
	  else {
		// Current maximum number
		int comp = stack_pop(my_stack);
		// Use that and push it back into stack
		if(comp > waiting){
		  printf("%d ", comp);
		  stack_push(my_stack, comp);
		}
		// Else it is no longer useful to be compared so thrown away
	  }
	}
*/

int main(){
  int t;
  scanf("%d", &t);

  while(t-- > 0){
	int n;
	scanf("%d", &n);
	int array[n];
	int i;

	for(i = 0; i < n; i++){
	  scanf("%d", &array[i]);
	}

	stack*  = stack_new();
	int index = 0;
	stack_push(my_stack, array[0]);
	i = 1;
	int numprinted = 0;
	while(i < n){
	  int existed = stack_pop(my_stack);
	  if(array[i] > existed){
		int j = i - 1;
		for(; j >= index; j--){
		  printf("%d ", array[i]);
		  numprinted++;
		}
		stack_push(my_stack, array[i]);
		index = i;
		i++;
	  }
	  else{
		stack_push(my_stack, existed);
	  }
	}
	while(numprinted < n){
	  printf("-1 ");
	  numprinted++;
	}
  }
}
