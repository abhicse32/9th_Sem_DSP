#include "queue_a.h"
#include <stdio.h>
#include <stdlib.h>
#define size 1000
