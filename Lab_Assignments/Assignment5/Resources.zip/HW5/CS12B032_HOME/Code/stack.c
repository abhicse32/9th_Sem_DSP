#include "stack.h"
#include "List.h"
#include <stdio.h>
#include <stdlib.h>
