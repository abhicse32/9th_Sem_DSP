#include <stdio.h>
#include <stdlib.h>
#include"bst.h"
#include"queue.h"
 
void correct( Node_BST* root, Node_BST** f,Node_BST** m, Node_BST** l, Node_BST** prev )
{
    if( root!=NULL )
    {
        correct( root->left, f, m, l, prev );
        if (*prev!=NULL && root->data < (*prev)->data)
        {
            if ( *f!=NULL )
            {
                *l = root;
            }
            else
            {
                 *f = *prev;
                *m = root;
             }
        }
        *prev = root;
        correct( root->right, f, m, l, prev );
    }
}
 
void correct_bst( Node_BST* root )
{
    Node_BST *f=NULL;
    Node_BST *m=NULL;
    Node_BST *l=NULL;
    Node_BST *prev=NULL;
 
    // Set the poiters to find out two nodes
    correct( root, &f, &m, &l, &prev );
 
    // Fix (or correct) the tree
    if( f!=NULL && l!=NULL )
       {
            int temp = f->data;
            f->data = l->data;
            l->data = temp;       
       }
    else if( f!=NULL && m!=NULL ) // Adjacent nodes swapped
        {
            int temp1;
            temp1 = f->data;
            f->data = m->data;
            m->data = temp1;
        }
 
    // else nodes have not been swapped, passed tree is really BST.
}

int main()
{
  int n;
  scanf("%d",&n);
  //printf("1");
  Node_BST* node[n];// node = (Node_BST**)malloc(n*sizeof(Node_BST*));
 //printf("2");
  int index[n],d[n],value[n];
   int i;
  for(i=0;i<n;i++) scanf("%d",&index[i]); //printf("1");
  for(i=0;i<n;i++) scanf("%d",&d[i]);// printf("1");
  for(i=0;i<n;i++) scanf("%d",&value[i]);
  node[0]=new_node(value[0]);
  Node_BST * root = node[0];
   for(i=1;i<n;i++)
  {
  node[i]=new_node(value[i]);
  if (d[i]==1)
  node[index[i]]->right=node[i];
  else 
  node[index[i]]->left=node[i];
  }
 // print_level_wise(root);
   correct_bst(root);
   print_level_wise(root);
  
  
}

/*int main()
{
  int n;
  scanf("%d",&n);
  int a[n],b[n],value[n];
  int i;
  for(i=0;i<n;i++) scanf("%d",&a[i]);
  for(i=0;i<n;i++) scanf("%d",&b[i]);
  for(i=0;i<n;i++) scanf("%d",&value[i]);
  
  Node_BST* one=new_node(value[0]);
  queue *q=queue_new();
  enqueue(q,one);
  int j;
  for(i=1;i<n;)
  {
     Node_BST* p=new_node(a[i]);
     j=a[i];
     while(j==a[i]&&i<n)
      {
            Node_BST *r=new_node(value[i]);
            if(b[i]==0){
             p->left=r;
             i++;
             }
            else{
            p->right=r;
            i++;
             }
      }
     enqueue(q,p);
    }
   Node_BST* root;
    root=dequeue(q);
   print_level_wise(root);
   correct_bst(root);
   print_level_wise(root);   
}
*/
