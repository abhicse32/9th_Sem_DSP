#include<stdio.h>
#include<stdlib.h>
#include"bst.h"
Node_BST* insert_new(Node_BST *node,int value)
{
  if(node==NULL)
  return new_node(value);
  if(value<node->data)
  node->left=insert_new(node->left,value);
  else if(value>node->data)
  node->right=insert_new(node->right,value);
  return node;
}
int main()
{
  int n;
  scanf("%d",&n);
  int i,value[n];
  Node_BST* node[n];
  for(i=0;i<n;i++)
  {
    scanf("%d",&value[i]);
  }
  Node_BST * root=(Node_BST*)malloc(sizeof(Node_BST));
  root->data=value[n-1];
   for(i=n-2;i>=0;i--)
   {
      insert_new(root,value[i]);
      //print_level_wise(root);
      //printf("3");
   }
   //printf("1");
   print_level_wise(root);
  //printf("2");

}
