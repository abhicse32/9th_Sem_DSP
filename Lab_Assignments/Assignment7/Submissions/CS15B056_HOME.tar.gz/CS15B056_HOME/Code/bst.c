#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "bst.h"
#include "queue.h"

Node_BST* new_node(int data)           //initialisation
{
	Node_BST *new;
	new=(Node_BST *)malloc(sizeof(Node_BST));
	new->left=NULL;
	new->right=NULL;
	new->data=data;
	return new;
}

Node_BST* insert(Node_BST* T, int data)      //inserts the element at its correct location
{
	if (T==NULL)
		T=new_node(data);
	else if (T->data==data)
		;
	else if (data<T->data)
	{
		if (T->left==NULL)
			T->left=new_node(data);            
		else
			insert(T->left,data);              //moves left if left is not free
	}
	else if (data>T->data)
	{
		if (T->right==NULL)
			T->right=new_node(data);
		else
			insert(T->right,data);
	}
	return T;
}

int find_max(Node_BST* T )				//finds max
{
	Node_BST *curr;
	curr=T;
	for (;curr->right!=NULL;curr=curr->right)
		;
	return (curr->data);
}

int find_min(Node_BST* T )				//finds min
{
	Node_BST *curr;
	curr=T;
	for (;curr->left!=NULL;curr=curr->left)
		;
	return (curr->data);
}

void print_level_wise(Node_BST* t)                     //prints level wise
{
	if (t!=NULL)
	{
	queue *q=queue_new();
	Node_BST *curr,*sen;
	sen=new_node(-1);                             //sen=sentinel value (used to print spaces)
	enqueue (q,t);
	enqueue (q,sen);
	
	for (;queue_size(q)!=0;)
	{
		curr=dequeue (q);
		if (curr->data!=-1)
			printf ("%d ",curr->data);
		else 
		{
			printf ("\n");			//new line if sentinel value seen
			if (queue_size(q)!=0)
				enqueue (q,sen);
		}
			
			
		
		if (curr->left!=NULL)
		{      
			enqueue (q,curr->left);
		}
		if (curr->right!=NULL)
		{
			enqueue (q,curr->right);
		}
	}
	}
}

Node_BST* search(Node_BST* T, int data)
{
	if (T==NULL)
		return NULL;
	if (T->data==data)
		return T;
	if (data>T->data)
		return (search (T->right,data));		//searches for an element
	else 
		return (search(T->left,data));
}

Node_BST* delete(Node_BST* T, int data )			//recursively finds the node and deletes it
{
	if (T->data==data)
	{
		if (T->left==NULL&&T->right==NULL)	
			return NULL;
		else if (T->right!=NULL)
		{
			Node_BST *T2=T->right;
			for (;T2->left!=NULL;T2=T2->left)
				;
			T->data=T2->data;	//replaces  with next value in inorder traversal
			T->right=delete(T->right,T2->data);
		}
		
		else
		{
			Node_BST *T1=T->left;			//if right null,goes to left
			for (;T1->right!=NULL;T1=T1->right)	
				;
			T->data=T1->data;
			T->left=delete (T->left,T1->data);
		}
	}
	
	else if (T->data<data)
	{
		T->right=delete(T->right,data);
	}
	else
	{
		T->left=delete (T->left,data);
	}
	return T;
	
	
}
void inorder_traversal(Node_BST* T)
{
	if (T->left!=NULL)
		inorder_traversal (T->left);
	printf ("%d ",T->data);                         //inorder traversal
	
	if (T->right!=NULL)
		inorder_traversal(T->right);
}













	

