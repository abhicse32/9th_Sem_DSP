#include <stdio.h>
#include <stdlib.h>
#include "bst.h"
int idx=0;
Node_BST *make_tree (int n);
void inorder(Node_BST * T,int n ,Node_BST *a[n]);
int main()
{
	int n,b[4],i,k=0,temp;
	scanf ("%d",&n);			//gets the number of nodes
	Node_BST *T=make_tree(n);
	Node_BST *a[n];
	inorder (T,n,a);
	for ( i = 0; i < n-1; i++)
	{
		if (a[i]->data>a[i+1]->data)
		{
			b[k]=i;
			b[k+1]=i+1;                                 //finds the indices where there is discontinuity in ascending order
			k=k+2;
		}
	}
	if (k==4)
	{
		temp=a[b[0]]->data;
		a[b[0]]->data=a[b[3]]->data;                         //exchanges the values stored in those indices
		a[b[3]]->data=temp;
	}

	else
	{
		temp=a[b[0]]->data;
		a[b[0]]->data=a[b[1]]->data;
		a[b[1]]->data=temp;
	}

	print_level_wise(T);                                      //prints level wise

}


void inorder(Node_BST * T,int n ,Node_BST *a[n])
{
	if (T->left!=NULL)
		inorder (T->left, n, a);
	a[idx]=T;
	idx++;                               //inorder traversal and updation of 'a'
	
	if (T->right!=NULL)
		inorder(T->right,n,a);
}

Node_BST *make_tree (int n)
{
	int i,k;
	int parent[n],lr[n],val[n];
	for (i=0;i<n;i++)
		scanf ("%d",&parent[i]);                      //takes input parent,left or right, and value of node
	for (i=0;i<n;i++)
		scanf ("%d",&lr[i]);
	for (i=0;i<n;i++)
		scanf ("%d",&val[i]);
	
	Node_BST *root,*nd[n];
	for (i=0;i<n;i++)
		nd[i]=new_node(val[i]);				//makes an array of nodes
	root=nd[0];
	for (i=0;i<n;i++)
	{
		if (parent[i]==-1)
			;
		else 
		{
			k=parent[i];
			if (lr[i]==0)
			nd[k]->left=nd[i];                    //constructs the tree
			else if (lr[i]==1)
			nd[k]->right=nd[i];
		}
	}
	return root;						//returns root
	
}
