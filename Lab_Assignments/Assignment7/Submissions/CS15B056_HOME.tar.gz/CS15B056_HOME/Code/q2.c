#include <stdio.h>
#include <stdlib.h>
#include "bst.h"
int main ()
{
	int n,i;
	scanf("%d",&n);
	int a[n];
	Node_BST *T;
	for ( i = 0; i < n; ++i)
	{
		scanf ("%d",&a[i]);
	}
	for ( i = n-1; i >= 0; i--)
	{
		T=insert (T,a[i]);                  //if the nodes are inserted in reverse order , the resulting tree is the tree obtained by updating in each step 
	}
	print_level_wise(T);                    //prints tree in level order

}