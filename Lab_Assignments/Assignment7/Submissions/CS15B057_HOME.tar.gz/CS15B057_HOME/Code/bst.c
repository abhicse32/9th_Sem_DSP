/*
	Author: G.Kavitha
	Roll No. CS15B057
	Date: 03/10/2016
*/
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "bst.h"
#include "queue.h"
// create a new Node_BST
Node_BST* new_node(int data){
	Node_BST* temp=(Node_BST*)malloc(sizeof(Node_BST));
	temp->left=NULL;
	temp->right=NULL;
	temp->data=data;//setting the corresponding values for temp
	return temp;
}

//insert data in bst
Node_BST* insert(Node_BST* root, int data){
	if(root==NULL) return new_node(data); //creating new_node if the root bacame NULL
	if(root->data>data) {
		root->left=insert(root->left,data); //Updating root->left
		return root;
	}
	else if(root->data<data){
		root->right=insert(root->right,data); //updating root->right
		return root;
	}
	return root;//Return root
}

//find the node with the maximum value and return the key(-1 if root is null)
int find_max(Node_BST* root){//max is the rightmost node
	if(root==NULL) return -1;
	while(root->right!=NULL){
		root=root->right;
	}
	return root->data;
}

//find the node with the minimum value and return the key(-1 if root is null)
int find_min(Node_BST* root){//min  is the leftmost node
	if(root==NULL) return -1;
	while(root->left!=NULL){
		root=root->left;
	}
	return root->data;
}

// print level-wise traversal of the tree
void print_level_wise(Node_BST* root){
	if(root==NULL) return;
	queue* q=queue_new();
	Node_BST* sentinel=new_node(-1);//sentinel node holds -1
	enqueue(q,root);//enqueue the root
	enqueue(q,sentinel);//enqueue the sentinel
	while(queue_size(q)>1){
		Node_BST* temp=dequeue(q);
		if(temp->data==-1) printf("\n");//new line in case it was sentinel
		else printf("%d ",temp->data);//else print the data in the node
		//Enqueue the left and right if they are not NULL	
		if(temp->left!=NULL) enqueue(q,temp->left);
		if(temp->right!=NULL) enqueue(q,temp->right);
		if(temp->data==-1) enqueue(q,sentinel);//enqueue sentinel again
	}
	printf("\n");
}

// search for the given key in the bst and return 1 if found 0 otherwise
Node_BST* search(Node_BST* root, int data){
	if(root==NULL) return NULL;
	if(root->data==data) return root;
	if(root->data>data) return search(root->left,data);
	else return search(root->right,data);
}

//delete the node with the given key
Node_BST* delete(Node_BST* root, int data){
	Node_BST* temp=search(root,data);
	if(temp==NULL) return root; //node not found
	if(temp->right==NULL&&temp->left==NULL) {//node to be deleted has no children
		if(temp==root) return NULL;
		Node_BST* par=root;
		Node_BST* save;
		int tt=0;
		if(par->data<data) save=par->right;
		else {save=par->left; tt=1;}
		while(save!=NULL&&save->data!=temp->data){
			par=save;
			if(par->data<data) {save=par->right; tt=0;}
			else {save=par->left; tt=1;}
		}
		if(save==NULL) return root;
		if(tt==0) par->right=NULL;
		else par->left=NULL;
		free(temp);
		return root;
	}
	if(temp->right==NULL){//Node to be deleted has only the left child
		if(temp==root) return temp->left;
		Node_BST* par=root;
		Node_BST* save;
		int tt=0;
		if(par->data<data) save=par->right;
		else {save=par->left; tt=1;}
		while(save!=NULL&&save->data!=temp->data){
			par=save;
			if(par->data<data) {save=par->right; tt=0;}
			else {save=par->left; tt=1;}
		}
		if(save==NULL) return root;
		if(tt==0) par->right=save->left;
		else par->left=save->left;
		free(temp);
		return root;
	}
	if(temp->left==NULL){//Node to be deleted has only right child
		if(temp==root) return temp->right;
		Node_BST* par=root;
		Node_BST* save;
		int tt=0;
		if(par->data<data) save=par->right;
		else {save=par->left; tt=1;}
		while(save!=NULL&&save->data!=temp->data){
			par=save;
			if(par->data<data) {save=par->right; tt=0;}
			else {save=par->left; tt=1;}
		}
		if(save==NULL) return root;
		if(tt==0) par->right=save->right;
		else par->left=save->right;
		free(temp);
		return root;
	}
	//Node to be deleted has both children
	Node_BST* save;
	save=temp->right; //save will finally hold the successor of temp
	Node_BST* par;//par will hold the parent of save
	par=temp;	
	while(save->left!=NULL){
		par=save;		
		save=save->left;
	}
	if(par->data==temp->data) {//the successor was the right child of temp
		temp->data=save->data;
		par->right=save->right;
		free(save);				
	}
	else{
		temp->data=save->data;
		par->left=save->right;
		free(save);	
	}
	return root;
}

// print the inorder travesal of the tree
void inorder_traversal(Node_BST* root){
	if(root==NULL) return;
	inorder_traversal(root->left);//recusive call
	printf("%d ",root->data);//printing
	inorder_traversal(root->right);//recursive call
}
