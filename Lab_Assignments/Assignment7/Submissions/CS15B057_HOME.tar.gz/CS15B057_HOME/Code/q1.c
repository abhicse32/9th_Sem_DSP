/*
	Author: G.Kavitha
	Roll No. CS15B057
	Date: 05/10/2016
	Program to correct BST where two elements are swapped
*/
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <stdbool.h>
#include "bst.h"
# define size 1005
const int INF=INT_MAX;//INF is the maximum value that key in the node can take

void BSTcorrect(Node_BST* root, Node_BST** st, Node_BST** mid, Node_BST** en, Node_BST** pr){
	if(root==NULL) return;
	BSTcorrect(root->left,st,mid,en,pr);//left sub tree
	if(pr!=NULL&&(*pr)!=NULL){
		if((*pr)->data>(root)->data){//wrong order
			if((*st)==NULL){//update st and mid
				*st=*pr;
				*mid=root;
			}
			else{//update en
				*en=root;
			}
		}
	}
	(*pr)=root;
	BSTcorrect(root->right,st,mid,en,pr);//right subtree
}

//Main function
int main(){
	int n;
	scanf("%d",&n);//Read in n

	int i;
	int p[size],l[size],b[size];//arrays to hold the inputs given

	for(i=0;i<n;i++) scanf("%d",&p[i]);//Reading in array elements of p
	for(i=0;i<n;i++) scanf("%d",&l[i]);//Reading in array elements of l

	int mini=INF,maxi=-INF;

	for(i=0;i<n;i++) {
		scanf("%d",&b[i]);//Reading in array elements of b
		if(b[i]<mini) mini=b[i];
		if(b[i]>maxi) maxi=b[i];
	}

	Node_BST** arr=(Node_BST**)malloc(n*sizeof(Node_BST*));//Array of Nodes
	for(i=0;i<n;i++){
		arr[i]=new_node(b[i]);
	}
	
	Node_BST* root=NULL;

	//Building the tree
	for(i=0;i<n;i++){
		if(p[i]==-1) root=arr[i];//Marking the root
		else{//Setting the parent to point to the child
			if(l[i]==0)
				arr[p[i]]->left=arr[i];
			else
				arr[p[i]]->right=arr[i];
		}
	}
	
	Node_BST *st,*mid,*en,*pred;
	st=NULL; mid=NULL; en=NULL; pred=NULL;
	BSTcorrect(root,&st,&mid,&en,&pred);
	int temp;
	if(en==NULL) {//swap st and mid
		temp=(st->data);
		(st->data)=(mid->data);
		(mid->data)=temp;
	}
	else{//swap st and en
		temp=(st->data);
		(st->data)=(en->data);
		(en->data)=temp;
	}
	print_level_wise(root);//print answer
	return 0;
}
