/*
	Author: G.Kavitha
	Roll No. CS15B057
	Date: 05/10/2016
	Program to insert into BST while rotating
*/

#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <stdbool.h>
#include "bst.h"
# define size 1005
const int INF=INT_MAX;//INF is the maximum value that key in the node can take

//Main function
int main(){
	int n;
	scanf("%d",&n);//Read in n

	int i;
	Node_BST* root=NULL;

	for(i=0;i<n;i++){
		int v;
		scanf("%d",&v);
		root=insert(root,v); //insert v into bst
		if(root->data==v) { //if v is already at root
		//	print_level_wise(root);printf("\n");
			continue;
		}
		Node_BST* save=NULL;
		while(root->data!=v){ //While v is not at root
			Node_BST* temp=root;//temp holds parent of v
			save=NULL; //save holds parent of temp
			while(temp!=NULL&&temp->data!=v){ //setting temp and save
				if(temp->left!=NULL&&temp->left->data==v) break;
				if(temp->right!=NULL&&temp->right->data==v) break;
				save=temp;
				if(temp->data>v) temp=temp->left;
				else temp=temp->right;
			}
			if(temp->left!=NULL&&temp->left->data==v){//if temp's left child is v
				if(save==NULL){ //if temp is root
					root=temp->left; //setting root to v
					temp->left=root->right; 
					root->right=temp;
				}
				else{//rotating and bringing v one level up the bst
					if(save->left==temp){
						save->left=temp->left;
						temp->left=save->left->right;
						save->left->right=temp;
					}
					else{
						save->right=temp->left;
						temp->left=save->right->right;
						save->right->right=temp;
					}
				}	
			}
			else{//if temp's right child is v
				if(save==NULL){ //if temp is root
					root=temp->right; //setting root to v
					temp->right=root->left;
					root->left=temp;
				}
				else{//rotating and bringing v one level up
					if(save->left==temp){
						save->left=temp->right;
						temp->right=save->left->left;
						save->left->left=temp;
					}
					else{
						save->right=temp->right;
						temp->right=save->right->left;
						save->right->left=temp;
					}
				}	
			}
		}
	//	print_level_wise(root); printf("\n");
	}
	print_level_wise(root);
	return 0;
}