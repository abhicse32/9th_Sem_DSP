#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#include "set.h"
#include "graph.h"

//TO CREATE A NEW GRAPH
Graph* createGraph1(int numNodes, int numEdges )
{
	SIZE = numNodes;
	int* arr = (int*)malloc(SIZE*sizeof(int));
	int i;
	for (i = 0; i < SIZE; ++i)
	{
		arr[i] = i+1;
	}
	initializeMap(arr);
	Graph *g = (Graph *)malloc(sizeof(Graph));
	g->numNodes = numNodes;
	g->numEdges = numEdges;
	g->edge = (Edge *)malloc(numEdges*sizeof(Edge));
	for(i = 0; i < numEdges; ++i)
	{
		scanf("%d %d",&(g->edge[i].src),&(g->edge[i].dest));
	}
	return g;
}

//TO FIND MIN NO. OF FRIENDS TO BE INVITED
int min_friends(Graph* graph , int numNodes, int numEdges)
{
	int i = 0;
	while(i < numEdges)
	{
		Union(graph->edge[i].src,graph->edge[i].dest);
		i++;
	}
	int min = numNodes;
	i = 0;
	int j = 0;
	while(i < numNodes)
	{
		j = cardinality(map->node[i]->value);
		if(j < min)
			min = j;
		i++;
	}
	return min;
}

int main(int argc, char const *argv[])
{
	int test;
	scanf("%d", &test);
	while(test--)
	{
		int v;
		int e;
		scanf("%d %d", &v,&e);                          //TAKING INPUT
		Graph *g;
		g = createGraph1(v,e);
		printf("%d\n",min_friends(g,v,e));		//PRINTING OUTPUT
	}
	return 0;
}
