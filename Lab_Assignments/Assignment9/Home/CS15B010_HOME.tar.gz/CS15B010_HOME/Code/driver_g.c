#include <stdio.h>
#include <stdbool.h>

#include "set.h"
#include "graph.h"

int main(int argc, char const *argv[])
{
	int test;
	scanf("%d", &test);
	while(test--)
	{
		int v;
		int e;
		scanf("%d %d", &v,&e);
		Graph *g;
		g = createGraph(v,e);
		if(isCycle(g,v,e))
			printf("true\n");
		else
			printf("false\n");
	}
	return 0;
}
