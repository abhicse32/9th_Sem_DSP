#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#include "set.h"
#include "graph.h"

//TO CREATE A NEW GRAPH
Graph* createGraph(int numNodes, int numEdges )
{
	SIZE = numNodes;
	int* arr = (int*)malloc(SIZE*sizeof(int));
	int i;
	for (i = 0; i < SIZE; ++i)
	{
		arr[i] = i;
	}
	initializeMap(arr);
	Graph *g = (Graph *)malloc(sizeof(Graph));
	g->numNodes = numNodes;
	g->numEdges = numEdges;
	g->edge = (Edge *)malloc(numEdges*sizeof(Edge));
	for(i = 0; i < numEdges; ++i)
	{
		scanf("%d %d",&(g->edge[i].src),&(g->edge[i].dest));
	}
	return g;
}

//TO FIND IF THERE IS A CYCLE
bool isCycle( Graph* graph , int numNodes, int numEdges)
{
	int i = 0;
	while(i < numEdges)
	{
		if(find(graph->edge[i].src) == find(graph->edge[i].dest))
			return true;
		Union(graph->edge[i].src,graph->edge[i].dest);
		i++;
	}
	return false;
}
