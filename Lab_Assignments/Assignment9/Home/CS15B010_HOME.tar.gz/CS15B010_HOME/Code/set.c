#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#include "set.h"

//create a new Set of given element
Node* makeSet (int value)
{
	Node *set = (Node *)malloc(sizeof(Node));
	set->value = value;
	set->rank = 1;
	set->parent = NULL;
	return set;
}	

//initialize the Map. Map is just an array of Node pointers
//i.e it stores the pointers to sets
void initializeMap ( int* arr)
{
	map = (Map *)malloc(sizeof(Map *));
	map->node = (Node **)malloc(SIZE*sizeof(Node *));
	int i = 0;
	while(i < SIZE)
	{
		map->node[i] = makeSet(arr[i]);
		i++;
	}
}

//get Set from the Map. i.e get pointer to the node having value=value 
Node* getNode(int value)
{
	int i = 0;
	while(i < SIZE)
	{
		if(value == map->node[i]->value)
			break;
		i++;
	}
	return map->node[i];
}

//find an element x ( return the representative/root of the set which x belongs to ) 
Node* find(int value)
{
	Node *temp = getNode(value);
	while(temp->parent)
	{
		temp = temp->parent;
	}
	return temp;
}

//find an element x ( return the representative/root of the set which x belongs to ) 
//along with the path compression
Node* findWithPathCompression(int value)
{
	Node *temp1 = getNode(value);
	Node *temp2 = temp1->parent;
	if(temp2 == NULL)
		return temp1;
	Node *temp3 = find(value);
	if(temp3 == temp2)
		return temp3;
	temp1->parent = temp3;
	return (findWithPathCompression(temp2->value));
}

//implement union of two sets by "union by rank algorithm"
//i.e (xVal, yVal) these may not represent the root nodes, 
//so you should first get the representatives of these nodes and then take union of them 
Node* Union (int xVal , int yVal)
{
	Node *temp1 = find(xVal);
	Node *temp2 = find(yVal);
	if(temp1 == temp2)
		return temp1;
	if(temp1->rank < temp2->rank)
	{
		temp1->parent = temp2;
		return temp2;
	}
	else if(temp1->rank > temp2->rank)
	{
		temp2->parent = temp1;
		return temp1;
	}
	else
	{
		temp2->parent = temp1;
		(temp1->rank)++;
		return temp1;		
	}
}

//Membership. i.e Do (xVal, yVal) belongs to same set 
bool isMember ( int xVal, int yVal)
{
	Node *temp1 = find(xVal);
	Node *temp2 = find(yVal);
	if(temp1 == temp2)
		return true;
	return false;	
}

//cardinality of set containing given value/node
int cardinality (int value)
{
	int i = 0;
	Node *temp = find(value);
	int count = 0;
	while(i < SIZE)
	{
		if(temp == find(map->node[i]->value))
			count++;
		i++;
	}
	return count;
}

//Print the path from this node to it's representative
void printNode ( Node* node)
{
	while(node)
	{
		printf("%d ",node->value);
		node = node->parent;
	}
	printf("\n");
}

//This will print path from each node to it's representative
//make use of printNode function
void printMap ()
{
	int i = 0;
	while(i < SIZE)
	{
		printf("%d ",map->node[i]->value);
		i++;
	}
	printf("\n");
}
