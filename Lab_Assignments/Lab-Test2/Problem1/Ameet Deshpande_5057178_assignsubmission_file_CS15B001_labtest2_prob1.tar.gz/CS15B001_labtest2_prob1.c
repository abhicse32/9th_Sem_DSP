#include <stdio.h>
#include <string.h>
#include<stdlib.h>

#define MAX_SIZE 100

typedef struct _node {
   char label;
   struct _node *L;
   struct _node *R;
} node;

// COMPLETE THE FOLLOWING gentree FUNCTION
node *gentree ( char *inlist , char *prelist )
{
   node *root;
   root = (node*) malloc(sizeof(node));
   root->R = NULL;
   root->L = NULL;
   root->label = prelist[0];
   
   int size = strlen(inlist);	//Stores the number of nodes
   
   char *inlist_new,*prelist_new;
   
   int i=0;
   for(i=0;i<size;++i)
   {
   		if(inlist[i] == prelist[0])
   		{
   			break;
   		}
   }
   
   if(i == 0)	//Constructing left tree
   {
   	root->L = NULL;
   }
   else
   {
	   	inlist_new = (char*) malloc(sizeof(char)*(i+1));
	   	prelist_new = (char*) malloc(sizeof(char)*(i+1));
	   	
	   	int j=0;
	   	for(j=0;j<i;++j)
	   	{
	   		inlist_new[j] = inlist[j];
	   	}
	   	inlist_new[j] = '\0';
	   	
	   	j=0;
	   	
	   	for(j=0;j<i;++j)
	   	{
	   		prelist_new[j] = prelist[j+1];
	   	}
	   	prelist_new[j] = '\0';
	   	
	   	root->L = gentree(inlist_new,prelist_new);
	   	
	   	free(inlist_new);
	   	free(prelist_new);
   	
   }
   
   
   if(i == size-1)
   {
   		root->R = NULL;
   }
   
   else
   {
	   	inlist_new = (char*) malloc(sizeof(char)*(size-i));
		prelist_new = (char*) malloc(sizeof(char)*(size-i));
	
		int j=0;
		for(j=i+1;j<size;++j)
		{
			inlist_new[j-i-1] = inlist[j];
		}
	
		inlist_new[j-i-1] = '\0';
	
		j=0;
	
		for(j=i+1;j<size;++j)
		{
			prelist_new[j-i-1] = prelist[j];
		}
	
		prelist_new[j-i-1] = '\0';
	
		root->R = gentree(inlist_new,prelist_new);
	
		free(inlist_new);
		free(prelist_new);
		
	}
	
	
	return root;
	
	
}

void printtree ( node *root )
{
   if (root == NULL) return;
   printf("Node : %c, ",root->label);
   printf("Left child : ");
   if (root->L == NULL) printf("NULL, ");
   else printf("   %c, ",root->L->label);
   printf("Right child : ");
   if (root->R == NULL) printf("NULL.\n");
   else printf("   %c.\n",root->R->label);
   printtree(root->L);
   printtree(root->R);
}

int main ()
{
   char inlist[MAX_SIZE], prelist[MAX_SIZE];
   node *root;

   printf("Inorder listing  : "); scanf("%s",inlist);
   printf("Preorder listing : "); scanf("%s",prelist);
   root = gentree(inlist,prelist);
   printtree(root);
   return(0);
}
