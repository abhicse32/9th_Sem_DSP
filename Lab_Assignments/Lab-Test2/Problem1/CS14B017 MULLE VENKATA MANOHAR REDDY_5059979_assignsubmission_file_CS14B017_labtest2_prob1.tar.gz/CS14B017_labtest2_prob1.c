#include <stdio.h>
#include <string.h>
#include<stdlib.h>

#define MAX_SIZE 100

typedef struct _node {
   char label;
   struct _node *L;
   struct _node *R;
} node;

// COMPLETE THE FOLLOWING gentree FUNCTION
node *gentree ( char *inlist , char *prelist )
{

   // Write C-code Here


	node *nd=(node *)malloc(sizeof(node));


	int n=strlen(inlist);
	if(n==0){
//printf("NULL\n");
		return NULL;
	}
	else
	{
		nd->label=prelist[0];
		int i,j=0;
		char m=prelist[0];
/*printf("\nNOde\n");
printf("\n%d\n",n);
for(i=0;i<n;i++){
//printf("%d\n",n);
printf("%c ",inlist[i]);
}
printf("\n");
for(i=0;i<n;i++){
printf("%c ",prelist[i]);
}
printf("\n");*/

		for(i=0;m!=inlist[i];i++){
			j++;
		}
//printf("\nposition of middle=%d\n",j);
		char linlist[MAX_SIZE], lprelist[MAX_SIZE];
		char rinlist[MAX_SIZE], rprelist[MAX_SIZE];
		for(i=j+1;i<n;i++){
			rinlist[i-j-1]=inlist[i];
			rprelist[i-j-1]=prelist[i];
		}
		rinlist[i-j-1]='\0';
//printf("\n.....%d.....\n",i-j-1);
		rprelist[i-j-1]='\0';
		
		for(i=0;i<j;i++){
			linlist[i]=inlist[i];
			lprelist[i]=prelist[i+1];
		}
		linlist[i]='\0';
		lprelist[i]='\0';


//printf("left\n");


/*int n0=strlen(linlist);
printf("%d\n",n0);
for(i=0;i<n0;i++){
//printf("%d\n",n);
printf("%c ",linlist[i]);
}
printf("\n");
for(i=0;i<n0;i++){
printf("%c ",lprelist[i]);
}

printf("\nright\n");


int nr=strlen(rinlist);
printf("%d\n",nr);
for(i=0;i<nr;i++){
//printf("%d\n",n);
printf("%c ",rinlist[i]);
}
printf("\n");
for(i=0;i<nr;i++){
printf("%c ",rprelist[i]);
}
printf("\n");
*/

		nd->L=gentree(linlist,lprelist);
		nd->R=gentree(rinlist,rprelist);
		return nd;
}

}

void printtree ( node *root )
{
   if (root == NULL) return;
   printf("Node : %c, ",root->label);
   printf("Left child : ");
   if (root->L == NULL) printf("NULL, ");
   else printf("   %c, ",root->L->label);
   printf("Right child : ");
   if (root->R == NULL) printf("NULL.\n");
   else printf("   %c.\n",root->R->label);
   printtree(root->L);
   printtree(root->R);
}

int main ()
{
   char inlist[MAX_SIZE], prelist[MAX_SIZE];
   node *root;

   printf("Inorder listing  : "); scanf("%s",inlist);
   printf("Preorder listing : "); scanf("%s",prelist);
   root = gentree(inlist,prelist);
   printtree(root);
   return(0);
}
