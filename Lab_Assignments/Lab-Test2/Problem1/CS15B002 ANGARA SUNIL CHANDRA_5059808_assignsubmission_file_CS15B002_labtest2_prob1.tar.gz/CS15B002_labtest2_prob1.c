#include <stdio.h>
#include <string.h>
#include<stdlib.h>

#define MAX_SIZE 100
typedef struct _node {
   char label;
   struct _node *L;
   struct _node *R;
} node;
int check(char a, char b, char* in,int x)
{
	int i;
	for(i=0;i<x;i++)
	{
		if(in[i]==a) return 1;
		if(in[i]==b) return 0;
	}
}
// COMPLETE THE FOLLOWING gentree FUNCTION
node *gentree ( char *inlist , char *prelist )
{
   // Write C-code Here
   int x = strlen(inlist),i,ro;
   char a;
   int* comp = malloc(sizeof(int)*x);
   a = prelist[0];
   for(i=0;i<x;i++)
   {
		if(inlist[i] == a){ro = i;break;}
   }
   node* root;
   root = malloc(sizeof(node*));
   root->label = inlist[ro];
   root->L=NULL;
   root->R=NULL;
   node** narr = malloc(sizeof(node*)*x);
   for(i=0;i<x;i++)
   {
   		narr[i] = malloc(sizeof(node*));
   		narr[i]->label = prelist[i];
   		narr[i]->L = NULL;
  		narr[i]->R = NULL; 
   }      
//   root->label = narr[0]->label;
	 node* curr = root;
   int z =0,y=0,end=ro-1;
   for(i=1;i<=ro;i++)
   {
   		if(check(prelist[i],curr->label,inlist,x)==1){if(inlist[end]==curr->label)comp[i]=1; curr->L = narr[i];z=0;}
   		else if(check(prelist[i],curr->label,inlist,x)==0) 
   		{
	   		if((z>0)&&(i!=0))
	   		{
	   			int l=z;
	   			node* curr1=curr;
   				while(z>=1)
   				{
   					curr1 =curr1->R;
   					z--;
   				}
   				curr1->R = narr[i];
   				z=l;
   				//printf("%c is curr1->R ",curr1->R->label);
   			}
	   		else curr->R = narr[i];
	   		z++;comp[i]=1;}	
   		if(i==1) curr = narr[i];
   		if(comp[i]==1) {curr = narr[i];end--;}
   }
   curr = root;
   y=0;
   for(i=ro+1;i<x;i++)
   {
//   		printf("%c curr",curr->label);
   		if(check(prelist[i],curr->label,inlist,x)==1) 
   		{
   			if(inlist[x-1]==curr->label)comp[i]=1;
   			if((y>=1)&&(i!=x-1))
   			{	
   				int k=y;
   		//		printf("in %d",y);
   				node* curr1=curr;
   				while(y>=1)
   				{
   					curr1 =curr1->L;
   					y--;
   				}
   				curr1->L = narr[i];
			//	printf("%c is curr1->L ",curr1->L->label);
   			//	printf("%c is curr->l",curr1->label);
   				y=k;
   			}
   			else curr->L = narr[i];
   			y++;
   		}
   		else if(check(prelist[i],curr->label,inlist,x)==0) {curr->R = narr[i];comp[i]=1;y=0;}	
   		if(i==ro+1) curr = narr[i];
   		if(comp[i]==1) curr = narr[i];		
   }
//   printf("complete");
   return root;
}

void printtree ( node *root )
{
   if (root == NULL) return;
   printf("Node : %c, ",root->label);
   printf("Left child : ");
   if (root->L == NULL) printf("NULL, ");
   else printf("   %c, ",root->L->label);
   printf("Right child : ");
   if (root->R == NULL) printf("NULL.\n");
   else printf("   %c.\n",root->R->label);
   printtree(root->L);
   printtree(root->R);
}

int main ()
{
   char inlist[MAX_SIZE], prelist[MAX_SIZE];
   node *root;

   printf("Inorder listing  : "); scanf("%s",inlist);
   printf("Preorder listing : "); scanf("%s",prelist);
   root = gentree(inlist,prelist);
   printtree(root);
   return(0);
}
