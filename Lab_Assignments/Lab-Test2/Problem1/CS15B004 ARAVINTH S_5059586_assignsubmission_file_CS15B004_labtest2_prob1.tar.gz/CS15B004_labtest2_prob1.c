#include <stdio.h>
#include <string.h>
#include<stdlib.h>

#define MAX_SIZE 100

typedef struct _node {
   char label;
   struct _node *L;
   struct _node *R;
} node;

int idx = -1;

// RECURSIVELY BUILDS THE TREE
node* buildtree(char *inlist , char *prelist, int lower, int higher)
   { 
   	  if(lower+1 == higher)
   	     return NULL;
   	     
   	  idx++;   
      node* root = (node*) malloc (sizeof(node));
      root->label = prelist[idx];
      
  	  int inpos, i;
      for(i = lower + 1; i< higher; i++)
      	if(prelist[idx] == inlist[i])
      	  { inpos = i; break; }
      	 
      root->L= buildtree(inlist, prelist, lower, inpos); 	  
      root->R= buildtree(inlist, prelist, inpos, higher);
      	  
      return root;
   }

// COMPLETE THE FOLLOWING gentree FUNCTION
node *gentree ( char *inlist , char *prelist )
{
   int n = strlen(inlist);
   	
   node* root = buildtree(inlist,prelist,-1,n);
   return root;
}

void printtree ( node *root )
{
   if (root == NULL) return;
   printf("Node : %c, ",root->label);
   printf("Left child : ");
   if (root->L == NULL) printf("NULL, ");
   else printf("   %c, ",root->L->label);
   printf("Right child : ");
   if (root->R == NULL) printf("NULL.\n");
   else printf("   %c.\n",root->R->label);
   printtree(root->L);
   printtree(root->R);
}

int main ()
{
   char inlist[MAX_SIZE], prelist[MAX_SIZE];
   node *root;

   printf("Inorder listing  : "); scanf("%s",inlist);
   printf("Preorder listing : "); scanf("%s",prelist);
   root = gentree(inlist,prelist);
   printtree(root);
   return(0);
}
