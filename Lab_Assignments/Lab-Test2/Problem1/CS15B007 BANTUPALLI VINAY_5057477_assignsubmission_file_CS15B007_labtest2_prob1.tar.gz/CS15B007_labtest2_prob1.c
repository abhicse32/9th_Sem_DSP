#include <stdio.h>
#include <string.h>
#include<stdlib.h>

#define MAX_SIZE 100

typedef struct _node {
   char label;
   struct _node *L;
   struct _node *R;
} node;

// COMPLETE THE FOLLOWING gentree FUNCTION
node *gentree ( char *inlist , char *prelist )
{	
	int size = strlen(inlist);
	if( size < 1 ) return NULL;
	int i,j;
	char k = prelist[0];
	node * root;
	root = (node *)malloc(sizeof(node));	
	root->label = k; 	
	root->L = NULL;
	root->R = NULL;
	char subin[MAX_SIZE],subpre[MAX_SIZE];
	for( i = 0 ; i < size ; i++){
		if(inlist[i] == k){
			break;	
		}
	}
	for( j = 0 ; j < i ; j++){
		subin[j] = inlist[j];
	}
	subin[j] = '\0';
	for( j = 0 ; j < i ; j++){
		subpre[j] = prelist[j+1];
	}
	subpre[j]= '\0';
	if(i > 0){
		root->L = gentree(subin,subpre);
	}
	for( j = 0 ; j < (size - i -1) ; j++){
		subin[j] = inlist[j+i+1];
	}
	subin[j] = '\0';
	for( j = 0 ; j < (size - i -1)  ; j++){
		subpre[j] = prelist[j+i+1];
	}
	subpre[j]= '\0';
	if((size - i -1) > 0 ){
		root->R = gentree(subin,subpre);
	}
	return root;
}

void printtree ( node *root )
{
   if (root == NULL) return;
   printf("Node : %c, ",root->label);
   printf("Left child : ");
   if (root->L == NULL) printf("NULL, ");
   else printf("   %c, ",root->L->label);
   printf("Right child : ");
   if (root->R == NULL) printf("NULL.\n");
   else printf("   %c.\n",root->R->label);
   printtree(root->L);
   printtree(root->R);
}

int main ()
{
   char inlist[MAX_SIZE], prelist[MAX_SIZE];
   node *root;

   printf("Inorder listing  : "); scanf("%s",inlist);
   printf("Preorder listing : "); scanf("%s",prelist);
   root = gentree(inlist,prelist);
   printtree(root);
   return(0);
}
