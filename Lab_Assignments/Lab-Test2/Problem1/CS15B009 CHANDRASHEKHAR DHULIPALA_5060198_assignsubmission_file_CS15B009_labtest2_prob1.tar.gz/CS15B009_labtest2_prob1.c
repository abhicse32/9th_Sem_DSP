#include <stdio.h>
#include <string.h>
#include<stdlib.h>

#define MAX_SIZE 100

typedef struct _node {
   char label;
   struct _node *L;
   struct _node *R;
} node;

// COMPLETE THE FOLLOWING gentree FUNCTION
node *gentree ( char *inlist , char *prelist )
{
   // Write C-code Here
      
   int l = strlen(inlist);
   if (l==0)
   		return NULL;
   char curr_root = prelist[0];
   char left_inlist[MAX_SIZE],left_prelist[MAX_SIZE];
   char right_inlist[MAX_SIZE],right_prelist[MAX_SIZE];
   
   int i,j;
   for (i = 0; i < l; i++)
   {
   		if(inlist[i] == curr_root)
   			break;
   		else
   			left_inlist[i] = inlist[i];
   }
   left_inlist[i] = '\0';
   
   int flag = i;
   i = i+1;
   for (j = 0; j < l; j++)
   {
   		if (i == l)
   			break;
   		right_inlist[j] = inlist[i];
   		i = i+1;
   }
   right_inlist[j] = '\0';
   
   for (i = 0; i < flag; i++)
   		left_prelist[i] = prelist[i+1];
   left_prelist[i] = '\0';
   
   for (j = 0; j < l-flag-1; j++)
   		right_prelist[j] = prelist[j+flag+1];
   right_prelist[j] = '\0';
   
   node* root = (node*)malloc(sizeof(node));
   root->label = curr_root;
   root->L = gentree(left_inlist,left_prelist);
   root->R = gentree(right_inlist,right_prelist);
   return root;
}

void printtree ( node *root )
{
   if (root == NULL) return;
   printf("Node : %c, ",root->label);
   printf("Left child : ");
   if (root->L == NULL) printf("NULL, ");
   else printf("   %c, ",root->L->label);
   printf("Right child : ");
   if (root->R == NULL) printf("NULL.\n");
   else printf("   %c.\n",root->R->label);
   printtree(root->L);
   printtree(root->R);
}

int main ()
{
   char inlist[MAX_SIZE], prelist[MAX_SIZE];
   node *root;

   printf("Inorder listing  : "); scanf("%s",inlist);
   printf("Preorder listing : "); scanf("%s",prelist);
   root = gentree(inlist,prelist);
   printtree(root);
   return(0);
}
