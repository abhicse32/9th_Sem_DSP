#include <stdio.h>
#include <string.h>
#include<stdlib.h>

#define MAX_SIZE 100

typedef struct _node {
   char label;
   struct _node *L;
   struct _node *R;
} node;

// COMPLETE THE FOLLOWING gentree FUNCTION
node *gentree ( char *inlist , char *prelist )
{
   // Write C-code Here
   int size = strlen(inlist);
   int lst[size];
   	node *stk[size];
	int i,j,temp1,i1,top=0;
	int left,right;
	//initializing
	for(i=0;i<size;i++){
		lst[i]=-1;
	}
	
	//assigning the root
	temp1=prelist[0];
	i1=0;
	while(inlist[i1]!=temp1) i1++;
	lst[i1]=i1;
	node * root=(node *)malloc(sizeof(node));
	root->label=temp1;
	top++;
	stk[top]=root;
	
	for(i=1;i<size;i++){
		temp1=prelist[i];
		i1=0;
		while(inlist[i1]!=temp1) i1++;
		//check in btw which nodes
			left=right=-1;
			for(j=i1;j>=0;j--){
				if(lst[j]>=0){ left=j; break; }
			}
			for(j=i1;j<size;j++){
				if(lst[j]>=0){ right=j; break; }
			}
		//check for children of root
		if(left==-1){
			node *new=(node *)malloc(sizeof(node));
			new->L=NULL;
			new->R=NULL;
			new->label=prelist[i];
			root->L=new;
			lst[i1]=i;
			top++;
			stk[top]=new;
		}else if(right==-1){
			node *new=(node *)malloc(sizeof(node));
			new->L=NULL;
			new->R=NULL;
			new->label=prelist[i];
			root->R=new;
			lst[i1]=i;
			top=1;
			stk[top]=new;
		}
		//for any node
		else{
			for(j=top;j>=0;j--){
				if(stk[j]->label==inlist[left]){
					node *new=(node *)malloc(sizeof(node));
					new->L=NULL;
					new->R=NULL;
					new->label=prelist[i];
					stk[j]->R=new;
					lst[i1]=i;
					top=j+1;
					stk[top]=new;
					break;
				}
				else if(stk[j]->label==inlist[right]){
					node *new=(node *)malloc(sizeof(node));
					new->L=NULL;
					new->R=NULL;
					new->label=prelist[i];
					stk[j]->L=new;
					lst[i1]=i;
					top++;
					stk[top]=new;
					break;
				}
			}
		}
	}
	return root;
}

void printtree ( node *root )
{
   if (root == NULL) return;
   printf("Node : %c, ",root->label);
   printf("Left child : ");
   if (root->L == NULL) printf("NULL, ");
   else printf("   %c, ",root->L->label);
   printf("Right child : ");
   if (root->R == NULL) printf("NULL.\n");
   else printf("   %c.\n",root->R->label);
   printtree(root->L);
   printtree(root->R);
}

int main ()
{
   char inlist[MAX_SIZE], prelist[MAX_SIZE];
   node *root;

   printf("Inorder listing  : "); scanf("%s",inlist);
   printf("Preorder listing : "); scanf("%s",prelist);
   root = gentree(inlist,prelist);
   printtree(root);
   return(0);
}
