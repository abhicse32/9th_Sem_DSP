#include <stdio.h>
#include <string.h>
#include<stdlib.h>

#define MAX_SIZE 100

typedef struct _node {
   char label;
   struct _node *L;
   struct _node *R;
} node;

node* maketree(char *inlist , char *prelist ,int start ,int end)
{
	if(start > end) return;
	int i,j;
	node* root;
	char a = prelist[start];
	for(i = start; i <= end; i++) if(inlist[i] == a) break;	
	root = (node*) malloc(sizeof(node));
	root->L = NULL;
	root->R = NULL;
	root->label = inlist[i];
	char in1[i];
	char in2[end-i];
	char pre1[i];
	char pre2[end-i];
	for(j=0;j<i;j++) in1[j] = inlist[i];
	for(j=0;j<(end-i);j++) 
	{
		in2[j] = inlist[i+1+j];
		pre2[j] = prelist[i+1+j];
	}
	for(j=0;j<i;j++) pre1[j] = prelist[i+1];
	root->L = maketree(in1,pre1,0,i-1);
	root->R = maketree(in2,pre2,i+1,end);
	return root;
}

// COMPLETE THE FOLLOWING gentree FUNCTION
node *gentree ( char *inlist , char *prelist )
{
   // Write C-code Here
	int len = strlen(inlist);
	node* root = maketree(inlist , prelist ,0 ,len-1);
	
}

void printtree ( node *root )
{
   if (root == NULL) return;
   printf("Node : %c, ",root->label);
   printf("Left child : ");
   if (root->L == NULL) printf("NULL, ");
   else printf("   %c, ",root->L->label);
   printf("Right child : ");
   if (root->R == NULL) printf("NULL.\n");
   else printf("   %c.\n",root->R->label);
   printtree(root->L);
   printtree(root->R);
}

int main ()
{
   char inlist[MAX_SIZE], prelist[MAX_SIZE];
   node *root;

   printf("Inorder listing  : "); scanf("%s",inlist);
   printf("Preorder listing : "); scanf("%s",prelist);
   root = gentree(inlist,prelist);
   printtree(root);
   return(0);
}
