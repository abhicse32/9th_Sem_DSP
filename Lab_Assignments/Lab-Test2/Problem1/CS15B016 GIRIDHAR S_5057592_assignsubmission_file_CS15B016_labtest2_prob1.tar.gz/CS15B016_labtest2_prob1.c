#include <stdio.h>
#include <string.h>
#include<stdlib.h>

#define MAX_SIZE 100

typedef struct _node {
   char label;
   struct _node *L;
   struct _node *R;
} node;

// COMPLETE THE FOLLOWING gentree FUNCTION
node *gentree ( char *inlist , char *prelist )
{
   // Write C-code Here
	int lenin=strlen(inlist);
	int lenpre=strlen(prelist);
	if(lenin==0) return NULL;

	char root_c=prelist[0];
	int i;
	for(i=0;i<lenin;i++){
		if(root_c==inlist[i]) break;
	}
	int root_pos=i;
	int len_left=root_pos;
	int len_right=lenin-(root_pos+1);
	
	node* root=(node*)malloc(sizeof(node));
	root->label=root_c;
	root->L=NULL;
	root->R=NULL;

	if(len_left==0&&len_right==0) 
		return root;

	else if(len_left==0){
		char *right_in=(char*)malloc(sizeof(char)*len_right);
		char *right_pre=(char*)malloc(sizeof(char)*len_right);
		for(i=0;i<len_right;i++){
			right_in[i]=inlist[root_pos+1+i];
			right_pre[i]=prelist[root_pos+1+i];
		}
		root->R=gentree(right_in, right_pre);
		return root;	
	}

	else if(len_right==0){
		char *left_in=(char*)malloc(sizeof(char)*len_left);
		char *left_pre=(char*)malloc(sizeof(char)*len_left);
		for(i=0;i<len_left;i++){
			left_in[i]=inlist[i];
			left_pre[i]=prelist[1+i];
		}
		root->L=gentree(left_in, left_pre);
		return root;	
	}
	
	else{
		char *left_in=(char*)malloc(sizeof(char)*len_left);
		char *left_pre=(char*)malloc(sizeof(char)*len_left);
		char *right_in=(char*)malloc(sizeof(char)*len_right);
		char *right_pre=(char*)malloc(sizeof(char)*len_right);
		for(i=0;i<len_left;i++){
			left_in[i]=inlist[i];
			left_pre[i]=prelist[i+1];
		}
		for(i=0;i<len_right;i++){
			right_in[i]=inlist[root_pos+1+i];
			right_pre[i]=prelist[root_pos+1+i];
		}	
		root->R=gentree(right_in, right_pre);
		root->L=gentree(left_in, left_pre);
		return root;
	}	
}

void printtree ( node *root )
{
   if (root == NULL) return;
   printf("Node : %c, ",root->label);
   printf("Left child : ");
   if (root->L == NULL) printf("NULL, ");
   else printf("   %c, ",root->L->label);
   printf("Right child : ");
   if (root->R == NULL) printf("NULL.\n");
   else printf("   %c.\n",root->R->label);
   printtree(root->L);
   printtree(root->R);
}

int main ()
{
   char inlist[MAX_SIZE], prelist[MAX_SIZE];
   node *root;

   printf("Inorder listing  : "); scanf("%s",inlist);
   printf("Preorder listing : "); scanf("%s",prelist);
   root = gentree(inlist,prelist);
   printtree(root);
   return(0);
}
