#include <stdio.h>
#include <string.h>
#include<stdlib.h>

#define MAX_SIZE 100

typedef struct _node {
   char label;
   struct _node *L;
   struct _node *R;
} node;

int i = 0;
node *gentree ( char *inlist , char *prelist )
{
  	node* root = (node*)malloc(sizeof(char)*1);
	int j, x, y, z;
	
	int l = sizeof(inlist)/sizeof(char);

	root -> label = prelist[i];
	
	
	
	if(i + 1 < l)
	{
		for(j = 0; j < l; j++)
		{
			if(inlist[j] == prelist[i])
			{
				x = j;
				break;
			}
		}
		for(j = 0; j < l; j++)
		{
			if(inlist[j] == prelist[i + 1])
			{
				y = j;
				break;
			}
		}
		
		if(i + 2 < l)	
		{
			for(j = 0; j < l; j++)
			{
				if(inlist[j] == prelist[i])
				{
					z = j;
					break;
				}
			}
		}
		i++;	
		if(x > y)
		{
			if(x < z)
			{
				i++;
				root -> R = gentree(inlist, prelist);
			}
			root -> L = gentree(inlist, prelist);
		}	
		if(x < y)
		{
			if(x > z)
			{
				i++;
				root -> L = gentree(inlist, prelist);
			}
			root -> R = gentree(inlist, prelist);
		}
		return root;	
	}
}

void printtree ( node *root )
{
   if (root == NULL) return;
   printf("Node : %c, ",root->label);
   printf("Left child : ");
   if (root->L == NULL) printf("NULL, ");
   else printf("   %c, ",root->L->label);
   printf("Right child : ");
   if (root->R == NULL) printf("NULL.\n");
   else printf("   %c.\n",root->R->label);
   printtree(root->L);
   printtree(root->R);
}

int main ()
{
   char inlist[MAX_SIZE], prelist[MAX_SIZE];
   node *root;

   printf("Inorder listing  : "); scanf("%s",inlist);
   printf("Preorder listing : "); scanf("%s",prelist);
   root = gentree(inlist,prelist);
   printtree(root);
   return(0);
}
