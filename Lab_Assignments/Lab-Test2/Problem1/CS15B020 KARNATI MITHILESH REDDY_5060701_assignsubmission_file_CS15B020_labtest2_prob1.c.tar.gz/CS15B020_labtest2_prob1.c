#include <stdio.h>
#include <string.h>
#include<stdlib.h>

#define MAX_SIZE 100

typedef struct _node {
   char label;
   struct _node *L;
   struct _node *R;
} node;

// COMPLETE THE FOLLOWING gentree FUNCTION
node *gentree ( char *inlist , char *prelist )
{
	int i,j,k,pre,right,left;
	right=0;
	left=0;
	char c;
	c=prelist[0];
	for(i=0;i<MAX_SIZE;i++)
	{
		if(inlist[i]==c) j=i;
		if(inlist[i]=='\0') break;
	}
	if(j==0) left=1;
	if(j==i-1) right=1;
	char inlistnewleft[j+1];
	char inlistnewright[i-j];
	char prelistnewleft[j+1];
	char prelistnewright[i-j];
	for(k=0;k<j;k++)
	{
		inlistnewleft[k]=inlist[k];
		prelistnewleft[k]=prelist[k+1];
	}
	inlistnewleft[j]='\0';
	prelistnewleft[j]='\0';
	for(k=j+1;k<=i;k++)
	{
		inlistnewright[k-j-1]=inlist[k];
		prelistnewright[k-j-1]=prelist[k];
	}
	node* root;
	root=(node*)malloc(1*sizeof(node));
	root->label=c;
	if(left==1) root->L=NULL;
	else root->L=gentree(inlistnewleft,prelistnewleft);
	if(right==1)root->R=NULL;
	else root->R=gentree(inlistnewright,prelistnewright);
	return root;	
   // Write C-code Here
}

void printtree ( node *root )
{
   if (root == NULL) return;
   printf("Node : %c, ",root->label);
   printf("Left child : ");
   if (root->L == NULL) printf("NULL, ");
   else printf("   %c, ",root->L->label);
   printf("Right child : ");
   if (root->R == NULL) printf("NULL.\n");
   else printf("   %c.\n",root->R->label);
   printtree(root->L);
   printtree(root->R);
}

int main ()
{
   char inlist[MAX_SIZE], prelist[MAX_SIZE];
   node *root;

   printf("Inorder listing  : "); scanf("%s",inlist);
   printf("Preorder listing : "); scanf("%s",prelist);
   root=gentree(inlist,prelist);
   printtree(root);
   return(0);
}
