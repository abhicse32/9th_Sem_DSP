#include <stdio.h>
#include <string.h>
#include<stdlib.h>

#define MAX_SIZE 100

typedef struct _node {
   char label;
   struct _node *L;
   struct _node *R;
} node;

// COMPLETE THE FOLLOWING gentree FUNCTION
node *gentree ( char *inlist , char *prelist )
{
    
    node *root = (node*)malloc(sizeof(node));
    root -> label = prelist[0];
   char t = prelist[0];
   int i = 0;
   while(inlist[i] != t)
   {
        i++;
   }
   int k1 = sizeof(inlist);
   if(k1 - i - 1 != 0)
   {
        char array1[k1 - i -1];
        char array2[k1 - i - 1];
        int j = i + 1;
        for(j = i + 1;j<k1;j++)
        {
            array1[j - i - 1] = inlist[j];
        }
        for(j = i+1;j<k1;j++)
        {
            array2[j - i -1] = prelist[j];
        }
        root -> R = gentree(array1,array2);
        
   }
   else if(k1 - i - 1 == 0)
   {
        root -> R = NULL;
    }
   if(i != 0)
   {
        char array3[i];
        char array4[i];
        int m = 0;
        for(m = 0;m<i;m++)
        {
            array3[m] = inlist[m];
        }
        for(m = 0;m<i;m++)
        {
            array4[m] = prelist[m + 1];
         }
         root -> L = gentree(array3,array4);
     }
     else if(i == 0)
     {
        root -> L = NULL;
     }
     return root;
   
}

void printtree ( node *root )
{
   if (root == NULL) return;
   printf("Node : %c, ",root->label);
   printf("Left child : ");
   if (root->L == NULL) printf("NULL, ");
   else printf("   %c, ",root->L->label);
   printf("Right child : ");
   if (root->R == NULL) printf("NULL.\n");
   else printf("   %c.\n",root->R->label);
   printtree(root->L);
   printtree(root->R);
}

int main ()
{
   char inlist[MAX_SIZE], prelist[MAX_SIZE];
   node *root;

   printf("Inorder listing  : "); scanf("%s",inlist);
   printf("Preorder listing : "); scanf("%s",prelist);
   root = gentree(inlist,prelist);
   printtree(root);
   return(0);
}
