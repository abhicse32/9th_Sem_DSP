#include <stdio.h>
#include <string.h>
#include<stdlib.h>

#define MAX_SIZE 100

typedef struct _node {
   char label;
   struct _node *L;
   struct _node *R;
} node;


int find(char *inlist,char x,int size)
{
   int i;

   for(i=0;i<size;i++)
   {
      if(inlist[i]==x)
      {
         return i;
      }
   }
}
node* join(char *inlist,char* prelist,int str,int end,int size)
{
   int i,mid=str;

   if(str>end)
      return NULL;

   node* Node=malloc(sizeof(node));
   Node->label=prelist[str];

   for(i=str+1;i<=end;i++)
   {
      if(find(inlist,prelist[i],size)<find(inlist,prelist[str],size))
      {
         mid=i;
      }
   }

   

   Node->L=join(inlist,prelist,str+1,mid,size);
   Node->R=join(inlist,prelist,mid+1,end,size);

   return Node;
}
// COMPLETE THE FOLLOWING gentree FUNCTION
node *gentree ( char *inlist , char *prelist )
{

   // Write C-code Here
	int size=strlen(inlist);
	
   node* root1=join(inlist,prelist,0,size-1,size);

   return root1;

}

void printtree ( node *root )
{
   if (root == NULL) return;
   printf("Node : %c, ",root->label);
   printf("Left child : ");
   if (root->L == NULL) printf("NULL, ");
   else printf("   %c, ",root->L->label);
   printf("Right child : ");
   if (root->R == NULL) printf("NULL.\n");
   else printf("   %c.\n",root->R->label);
   printtree(root->L);
   printtree(root->R);
}

int main ()
{
   char inlist[MAX_SIZE], prelist[MAX_SIZE];
   node *root;

   printf("Inorder listing  : "); scanf("%s",inlist);
   printf("Preorder listing : "); scanf("%s",prelist);
   root = gentree(inlist,prelist);
   printtree(root);
   return(0);
}
