#include <stdio.h>
#include <string.h>
#include<stdlib.h>

#define MAX_SIZE 100

typedef struct _node {
   char label;
   struct _node *L;
   struct _node *R;
} node;

// COMPLETE THE FOLLOWING gentree FUNCTION
node *gentree ( char *inlist , char *prelist )
{
   // Write C-code Here
   int i = 0;
   int j = 0;
   int l1 = strlen(inlist);
   int l2 = strlen(prelist);
   if((l1 == 0) || (l2 == 0))
      return NULL;
   char a = prelist[0];
   while(1)
   {
      if(inlist[i] == a)
         break;
      i++;
   }
   char *inlist1 = (char *)malloc(i * sizeof(char));
   char *prelist1 = (char *)malloc(i * sizeof(char));
   while(j < i)
   {
   	inlist1[j] = inlist[j];
   	prelist1[j] = prelist[j+1];
   	j++;
   }

   char *inlist2 = (char *)malloc((l1-i-1) * sizeof(char));
   char *prelist2 = (char *)malloc((l2-i-1) * sizeof(char));
   while(j < l1)
   {
   	inlist2[j-i] = inlist[j+1];
   	prelist2[j-i] = prelist[j+1];
   	j++;
   }
   
   node *root = (node *)malloc(sizeof(node));
   root->label = a;
   root->L = gentree(inlist1,prelist1);
   root->R = gentree(inlist2,prelist2);
   return root;
}

void printtree ( node *root )
{
   if (root == NULL) return;
   printf("Node : %c, ",root->label);
   printf("Left child : ");
   if (root->L == NULL) printf("NULL, ");
   else printf("   %c, ",root->L->label);
   printf("Right child : ");
   if (root->R == NULL) printf("NULL.\n");
   else printf("   %c.\n",root->R->label);
   printtree(root->L);
   printtree(root->R);
}

int main ()
{
   char inlist[MAX_SIZE], prelist[MAX_SIZE];
   node *root;

   printf("Inorder listing  : "); scanf("%s",inlist);
   printf("Preorder listing : "); scanf("%s",prelist);
   root = gentree(inlist,prelist);
   printtree(root);
   return(0);
}
