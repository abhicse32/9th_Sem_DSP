#include <stdio.h>
#include <string.h>
#include<stdlib.h>

#define MAX_SIZE 100

typedef struct _node {
   char label;
   struct _node *L;
   struct _node *R;
} node;

// COMPLETE THE FOLLOWING gentree FUNCTION
node *gentree ( char *inlist , char *prelist )
{
    // Write C-code Here
    int n = strlen(inlist);
    int i,j;
    node *a1[n],*a2[n];
	for(i = 0;i < n; i++)  
	{
		node *new = (node*)malloc(sizeof(node));
		new->L = new->R = NULL;
		new->label = prelist[i];
		a1[i] = new;
	}
	for(i = 0;i < n; i++)
	{
		for(j = 0;j < n; j++)
		{
			if(inlist[j] == a1[i]->label)
			a2[j] = a1[i];
			break;
		}
	} 
	j = 0;
	for(i = 0;i < n; i++)
	{
		if(prelist[i + 1] == inlist[j])
		{
			a1[i]->L = a2[j]; 
			j++;
		}
		else if(prelist[i + 1] != inlist[j]) 
		{
			a1[i]->R = a2[j];
		}
	}
}

void printtree ( node *root )
{
   if (root == NULL) return;
   printf("Node : %c, ",root->label);
   printf("Left child : ");
   if (root->L == NULL) printf("NULL, ");
   else printf("   %c, ",root->L->label);
   printf("Right child : ");
   if (root->R == NULL) printf("NULL.\n");
   else printf("   %c.\n",root->R->label);
   printtree(root->L);
   printtree(root->R);
}

int main ()
{
   char inlist[MAX_SIZE], prelist[MAX_SIZE];
   node *root;

   printf("Inorder listing  : "); scanf("%s",inlist);
   printf("Preorder listing : "); scanf("%s",prelist);
   root = gentree(inlist,prelist);
   printtree(root);
   return(0);
}
