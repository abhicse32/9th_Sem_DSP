#include <stdio.h>
#include <string.h>
#include<stdlib.h>

#define MAX_SIZE 100

typedef struct _node {
   char label;
   struct _node *L;
   struct _node *R;
} node;

// COMPLETE THE FOLLOWING gentree FUNCTION
node *gentree ( char *inlist , char *prelist )
{
   // Write C-code Here
   static int si = 0, ei = MAX_SIZE;
   static int sp = 0, ep = MAX_SIZE;
   if(ei == MAX_SIZE){
        ei = strlen(inlist) - 1;
        ep = strlen(prelist) - 1;
   }
   
   if(si > ei || sp > ep) return NULL;
   node* root = (node*)malloc(sizeof(node));
   root->label = prelist[sp];
   int i,ind = 0;
   for(i = si; i <= ei; i++){
        if(inlist[i] == prelist[sp]){
            ind = i;
            break;
        }
   }
   int pei = ei;
   int pep = ep;
   si = si; ei = ind - 1;
   sp = sp + 1; ep = sp -si + ind;
   int nsp = ep; 
   root->L  = gentree(inlist, prelist);
   si = ind + 1; ei = pei;
   sp = nsp; ep = pep;
   root->R = gentree(inlist, prelist);
   return root;
}

void printtree ( node *root )
{
   if (root == NULL) return;
   printf("Node : %c, ",root->label);
   printf("Left child : ");
   if (root->L == NULL) printf("NULL, ");
   else printf("   %c, ",root->L->label);
   printf("Right child : ");
   if (root->R == NULL) printf("NULL.\n");
   else printf("   %c.\n",root->R->label);
   printtree(root->L);
   printtree(root->R);
}

int main ()
{
   char inlist[MAX_SIZE], prelist[MAX_SIZE];
   node *root;

   printf("Inorder listing  : "); scanf("%s",inlist);
   printf("Preorder listing : "); scanf("%s",prelist);
   root = gentree(inlist,prelist);
   printtree(root);
   
   return(0);
}
