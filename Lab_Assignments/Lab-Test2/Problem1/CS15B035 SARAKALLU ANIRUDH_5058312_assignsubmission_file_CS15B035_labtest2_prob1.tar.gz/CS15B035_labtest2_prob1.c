#include <stdio.h>
#include <string.h>
#include<stdlib.h>

#define MAX_SIZE 100

typedef struct _node {
   char label;
   struct _node *L;
   struct _node *R;
} node;

// COMPLETE THE FOLLOWING gentree FUNCTION

node *newNode(char data){
    node *new = malloc(sizeof(node));
    new->label = data;
    new ->L = NULL;
    new->R = NULL;
    return new;
}

int search(char *inlist,int instart,int inend,char key){
    int i;
    for(i = instart;i<=inend ;i++){
        if(inlist[i] == key) return i;
    }
}

node *gettree(char *inlist,char * prelist ,int instart,int inend){
    if(instart>inend) return NULL;
    static int preidx = 0;
    node* tnode;
    tnode = newNode(prelist[preidx++]);
    if(instart == inend) 
        return tnode;
    int i = search(inlist,instart,inend,tnode->label);
        tnode->L = gettree(inlist,prelist,instart,i-1);
        tnode->R = gettree(inlist,prelist,i+1,inend);    
}


node *gentree ( char *inlist , char *prelist )
{   
    strcat(inlist,"\0");
    strcat(prelist,"\0");
    int size = strlen(inlist);
    node* root = gettree(inlist,prelist,0,size-1);
    return root;   
}

void printtree ( node *root )
{
   if (root == NULL) return;
   printf("Node : %c, ",root->label);
   printf("Left child : ");
   if (root->L == NULL) printf("NULL, ");
   else printf("   %c, ",root->L->label);
   printf("Right child : ");
   if (root->R == NULL) printf("NULL.\n");
   else printf("   %c.\n",root->R->label);
   printtree(root->L);
   printtree(root->R);
}

int main ()
{
   char inlist[MAX_SIZE], prelist[MAX_SIZE];
   node *root;

   printf("Inorder listing  : "); scanf("%s",inlist);
   printf("Preorder listing : "); scanf("%s",prelist);
   root = gentree(inlist,prelist);
   printtree(root);
   return(0);
}
