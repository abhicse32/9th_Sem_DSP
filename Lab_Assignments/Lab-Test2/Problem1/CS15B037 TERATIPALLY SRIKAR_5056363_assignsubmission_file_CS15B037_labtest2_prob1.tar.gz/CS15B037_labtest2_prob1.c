/*
 *On 31st Oct 2016
 *Written by Teratipally Srikar, CS15B037
 *This program generates a tree for a given
 *preorder and inorder traversal
 */

#include <stdio.h>
#include <string.h>
#include<stdlib.h>

#define MAX_SIZE 100

typedef struct _node {
   char label;
   struct _node *L;
   struct _node *R;
} node;

// COMPLETE THE FOLLOWING gentree FUNCTION
node *gentree ( char *inlist , char *prelist )
{
    int len1 = strlen(inlist);  /*No.of nodes*/
    int len2 = strlen(prelist);

    if(len1 > 0)
    {
        node* root = (node*) malloc(sizeof(node));  /*Allocating space for the node*/
        root->L = NULL;
        root->R = NULL;
        root->label = prelist[0];

        int i;  /*Counter*/
        for( i = 0; i < len1; i++)  /*Finding the index of root in inrder*/
        {
            if(inlist[i] == prelist[0]) break;
        }

        int index = i;      /*Index of root in inorder*/

        char leftinlist[index+1];   /*Array for storing the inorder of left tree*/
        char leftprelist[index+1];  /*Array for storing the preorder of left tree*/

        for(i = 0; i!=(index); i++) /*Coping the preoder and iorder of left subtree into the new array*/
        {
            leftinlist[i] = inlist[i];
            leftprelist[i] = prelist[i+1];
        }

        leftinlist[i] = '\0';
        leftprelist[i] = '\0';

        char rightinlist[len1 - index];  /*Array for storing the inorder of right tree*/
        char rightprelist[len1 - index];     /*Array for storing the preorder of right tree*/

        for( i = 0; i!=(len1 - index - 1); i++) /*Coping the preoder and iorder of left subtree into the new array*/
        {
            rightinlist[i] = inlist[index+1+i];
            rightprelist[i] = prelist[index+1+i];
        }

        rightinlist[i] = '\0';
        rightprelist[i] = '\0';

        root->L = gentree(leftinlist, leftprelist);     /*For generating the left subtree*/
        root->R = gentree(rightinlist, rightprelist);   /*For generating the right subtree*/

        return root;
    }

    else return NULL;
    
}

void printtree ( node *root )
{
   if (root == NULL) return;
   printf("Node : %c, ",root->label);
   printf("Left child : ");
   if (root->L == NULL) printf("NULL, ");
   else printf("   %c, ",root->L->label);
   printf("Right child : ");
   if (root->R == NULL) printf("NULL.\n");
   else printf("   %c.\n",root->R->label);
   printtree(root->L);
   printtree(root->R);
}

int main ()
{
   char inlist[MAX_SIZE], prelist[MAX_SIZE];
   node *root;

   printf("Inorder listing  : "); scanf("%s",inlist);
   printf("Preorder listing : "); scanf("%s",prelist);
   root = gentree(inlist,prelist);
   printtree(root);
   return(0);
}
