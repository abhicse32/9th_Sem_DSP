#include <stdio.h>
#include <string.h>
#include<stdlib.h>

#define MAX_SIZE 100

typedef struct _node {
   char label;
   struct _node *L;
   struct _node *R;
} node;

// COMPLETE THE FOLLOWING gentree FUNCTION
node *gentree ( char *inlist , char *prelist )
{
   // Write C-code Here
   if(strlen(prelist) == 0)
   	return NULL;
   	
   int loc, i, N, l, r;
   char top;
   char *left_str_pre, *right_str_pre, *left_str_in, *right_str_in;
   node *root;
   
   top = prelist[0];
   root = (node *)malloc(sizeof(node));
   root->label = top;
   N = strlen(prelist);
   
   for(i=0;i<strlen(inlist);i++)
   {
   	if(inlist[i] == top)
   	{
   		loc = i;
   		break;
   	}
   }
   
   left_str_pre = (char *)malloc(loc * sizeof(char));
   right_str_pre = (char *)malloc((strlen(inlist)-loc-1) * sizeof(char));
   left_str_in = (char *)malloc(loc * sizeof(char));
   right_str_in = (char *)malloc((strlen(inlist)-loc-1) * sizeof(char));
   
   for(i=0; i<loc; i++)
   {
   	left_str_pre[i] = prelist[i+1];
   	left_str_in[i] = inlist[i];
   }
   
   for(i=loc+1; i<N; i++)
   {
   	right_str_pre[i-(loc+1)] = prelist[i];
   	right_str_in[i-(loc+1)] = inlist[i];
   }
   	
   if(strlen(left_str_pre) != 0)
   	root->L = gentree(left_str_in, left_str_pre);
   else
   	root->L = NULL;
   	
   if(strlen(right_str_pre) != 0)
   	root->R = gentree(right_str_in, right_str_pre);
   else
   	root->R = NULL;
   	
   return root;
}

void printtree ( node *root )
{
   if (root == NULL) return;
   printf("Node : %c, ",root->label);
   printf("Left child : ");
   if (root->L == NULL) printf("NULL, ");
   else printf("   %c, ",root->L->label);
   printf("Right child : ");
   if (root->R == NULL) printf("NULL.\n");
   else printf("   %c.\n",root->R->label);
   printtree(root->L);
   printtree(root->R);
}

int main ()
{
   char inlist[MAX_SIZE], prelist[MAX_SIZE];
   node *root;

   printf("Inorder listing  : "); scanf("%s",inlist);
   printf("Preorder listing : "); scanf("%s",prelist);
   root = gentree(inlist,prelist);
   printtree(root);
   return(0);
}
