#include <stdio.h>
#include <string.h>
#include<stdlib.h>

#define MAX_SIZE 100

typedef struct _node {
   char label;
   struct _node *L;
   struct _node *R;
} node;


void printtree ( node *root )
{
   if (root == NULL) return;
   printf("Node : %c, ",root->label);
   printf("Left child : ");
   if (root->L == NULL) printf("NULL, ");
   else printf("   %c, ",root->L->label);
   printf("Right child : ");
   if (root->R == NULL) printf("NULL.\n");
   else printf("   %c.\n",root->R->label);
   printtree(root->L);
   printtree(root->R);
}

node* new_node(char data){

	node* p=(node*)malloc(sizeof(node));
	p->label=data;
	p->L=NULL;
	p->R=NULL;
	return p;
}
node* gen_helper(node* root,char* inlist,char* prelist){

	char *s1,*s2,*s3,*s4;
	int i=0,j=0;
	
	int length=strlen(inlist);
	char c=prelist[0];

	   for(i=0;i<length;i++){
	   
	   	if(inlist[i]==c){
	   		for(j=0;j<i;j++){
	   			s1[j]=inlist[j];
	   		}
	   		s1[j]='\0';
	   		for(j=i+1;j<length;j++){
	   			s2[j]=inlist[j];
	   		}
	   		s2[j]='\0';
	   		
	   	}
	   }
	int l1=strlen(s1);
	int l2=strlen(s2);
	
	for(i=0;i<l1;i++){
		s3[i]=prelist[i+1];
	}
	s3[i]='\0';
	
	for(i=0;i<l2;i++){
		s4[i]=prelist[l1+1];
	}
	s4[i]='\0';

	root->L=gen_helper(root->L,s1,s3);
	root->R=gen_helper(root->R,s2,s4);
	return root;
}

// COMPLETE THE FOLLOWING gentree FUNCTION
node *gentree ( char *inlist , char *prelist )
{	
   	node* root=(node*)malloc(sizeof(node));
	if(strlen(prelist)==0){
		return root;
	}
   
   	char *s1,*s2,*s3,*s4;
	int i=0,j=0;
	
	int length=strlen(inlist);
	char c=prelist[0];
	root=new_node(c);
	gen_helper(root,inlist,prelist);

	/*   for(i=0;i<length;i++){
	   
	   	if(inlist[i]==c){
	   		for(j=0;j<i;j++){
	   			inlist[j]=inlist[j];		
	   			
	   		}
	   		inlist[j]='\0';
	   		root->L=gentree(inlist,s3);
	   		
	   		for(j=i+1;j<length;j++){
	   			s2[j]=inlist[j];
	   		}
	   		s2[j]='\0';
	   		
	   	}
	   }
	int l1=strlen(s1);
	int l2=strlen(s2);
	
	for(i=0;i<l1;i++){
		s3[i]=prelist[i+1];
	}
	s3[i]='\0';
	
	for(i=0;i<l2;i++){
		s4[i]=prelist[l1+1];
	}
	s4[i]='\0';
	root->R=gentree(s2,s4);*/
   		
}


int main ()
{
   char inlist[MAX_SIZE], prelist[MAX_SIZE];
   node *root;

   printf("Inorder listing  : "); scanf("%s",inlist);
   printf("Preorder listing : "); scanf("%s",prelist);
   root = gentree(inlist,prelist);
   printtree(root);
   return(0);
}
