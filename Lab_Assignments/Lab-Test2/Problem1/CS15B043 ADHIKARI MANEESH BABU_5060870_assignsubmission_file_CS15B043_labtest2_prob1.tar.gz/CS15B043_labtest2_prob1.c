#include <stdio.h>
#include <string.h>
#include<stdlib.h>

#define MAX_SIZE 100

 int Count = 0;
 int CheckLeft( char *inlist , char *prelist , int Present );
 int CheckRight( char *inlist , char *prelist , int Present );

typedef struct _node {
   char label;
   struct _node *L;
   struct _node *R;
} node;

// COMPLETE THE FOLLOWING gentree FUNCTION
node *gentree ( char *inlist , char *prelist )
{
  int Present = Count; 

      if( Count == 0 )
     { 
       node *root = ( node* )malloc( sizeof( node ) ); 
       root->label = prelist[Count++];

          if( Count < MAX_SIZE && CheckLeft( inlist , prelist , Present ) )     
           root->L = gentree( inlist , prelist );
          else
           root->L = NULL;

          if( Count < MAX_SIZE && CheckRight( inlist , prelist , Present )
           root->R = gentree( inlist , prelist );
          else
           root->R = NULL;	   
     } 
      else
     {
       
     }
 
  return root;  
}

 int CheckLeft( char *inlist , char *prelist , int Present )
{
  int i , index1 , index2;

     if( Count < MAX_SIZE )
    {
         for( i = 0 ; i < MAX_SIZE ; i++ )
        {
             if( inlist[i] == prelist[Present] )
              index1 = i;

             if( inlist[i] == prelist[Count] )
              index2 = i;
        }
    }

     if( index2 < index1 )
      return 1;

  return 0; 
} 

 int CheckRight( char *inlist , char *prelist , int Present )
{
  int index1 , index2 , index3 , i;

     for( i = 0 ; i < MAX_SIZE ; i++ )
    {
         //if( inlist[i] == prelist[Present - 1] )
          //index1 = i;

         if( inlist[i] == prelist[Present] )
          index2 = i; 

         if( inlist[i] == prelist[Count] )
          index3 = i;  
    }  

     if( index3 > index2 /* && index1 > index2 */ )
      return 1;

  return 0; 
}

void printtree ( node *root )
{
   if (root == NULL) return;
   printf("Node : %c, ",root->label);
   printf("Left child : ");
   if (root->L == NULL) printf("NULL, ");
   else printf("   %c, ",root->L->label);
   printf("Right child : ");
   if (root->R == NULL) printf("NULL.\n");
   else printf("   %c.\n",root->R->label);
   printtree(root->L);
   printtree(root->R);
}

int main ()
{
   char inlist[MAX_SIZE], prelist[MAX_SIZE];
   node *root;

   printf("Inorder listing  : "); scanf("%s",inlist);
   printf("Preorder listing : "); scanf("%s",prelist);
   root = gentree(inlist,prelist);
   printtree(root);
   return(0);
}
