#include <stdio.h>
#include <string.h>
#include<stdlib.h>

#define MAX_SIZE 100

typedef struct _node {
   char label;
   struct _node *L;
   struct _node *R;
} node;

// COMPLETE THE FOLLOWING gentree FUNCTION
node *gentree ( char *inlist , char *prelist )
{
	
   // Write C-code Here
    int len=strlen(prelist);
   node *root;
   root=(node*)malloc(sizeof(node*));
   if(len==1)
   {
   	root->label=prelist[0];
   	root->R=NULL;
   	root->L=NULL;
   	return root;
   }
   /*node *temp;
   temp=root;
   int len=strlen(prelist);
   int count=0;
   while(count<len)
   {
		int index1=-1,index2=-1,i;
		char temp1,temp2;
		temp1=prelist[count];
		temp2=prelist[count+1];
		root->label=temp1;
		for(i=0;i<count;i++)
		{
			if(inlist[i]==temp1)
			{
				index1=i;
			}
			if(inlist[i]==temp2)
			{
				index2=i;
			}
		}
		if(index1>index2)
		{
			temp->L->label=temp2;
		}	
   }*/
  
   
   int index,i;
   for(i=0;i<len;i++)
	{
		if(inlist[i]==prelist[0])
		{
			index=i;
			break;
		}
	}
	root->label=prelist[0];
	

	if(index==0)
		root->L=NULL;
	else
	{
		char inL[index],preL[index];
		for(i=0;i<index;i++)
		{
			inL[i]=inlist[i];
			preL[i]=prelist[i+1];
		}
		root->L=gentree(inL,preL);
	}
	if(index==len-1)
		root->R=NULL;
	else
	{
		char inR[len-index-1],preR[len-index-1];
		for(i=index+1;i<len;i++)
		{
			inR[i-index-1]=inlist[i];
			preR[i-index-1]=prelist[i];
		}
		root->R=gentree(inR,preR);
	}
	return root;
}

void printtree ( node *root )
{
   if (root == NULL) return;
   printf("Node : %c, ",root->label);
   printf("Left child : ");
   if (root->L == NULL) printf("NULL, ");
   else printf("   %c, ",root->L->label);
   printf("Right child : ");
   if (root->R == NULL) printf("NULL.\n");
   else printf("   %c.\n",root->R->label);
   printtree(root->L);
   printtree(root->R);
}

int main ()
{
   char inlist[MAX_SIZE], prelist[MAX_SIZE];
   node *root;

   printf("Inorder listing  : "); scanf("%s",inlist);
   printf("Preorder listing : "); scanf("%s",prelist);
   root = gentree(inlist,prelist);
   printtree(root);
   return(0);
}
