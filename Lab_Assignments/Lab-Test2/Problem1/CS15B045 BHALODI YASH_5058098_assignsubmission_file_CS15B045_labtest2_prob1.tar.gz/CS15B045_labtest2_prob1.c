#include <stdio.h>
#include <string.h>
#include<stdlib.h>

#define MAX_SIZE 100

typedef struct _node {
   char label;
   struct _node *L;
   struct _node *R;
} node;

int findchar(char a[],char key)
{
	int idx = -1;
	int i;
	
	for(i=0;i<stringsize(a);i++)
	{
		if(a[i] == key)
		{
			idx = i;
		}
	}
	return idx;
}

int stringsize(char a[])
{
	int n,i;
	n=0;
	while(a[i] != '\0')
	{
		n++;
		i++;
	}
	return n;
}
	
// COMPLETE THE FOLLOWING gentree FUNCTION
node *gentree ( char *inlist , char *prelist )
{

  node *root;
  int k,j,i;
  i = 0; 
	char leftprelist[MAX_SIZE],rightprelist[MAX_SIZE];
	char leftinlist[MAX_SIZE],rightinlist[MAX_SIZE];
	
	k = findchar(inlist,prelist[0]);
	for(j=0;j<k;j++)
	{
		leftinlist[j] = inlist[j];
		leftprelist[j] = prelist[j+1];
	}
	
	for(j=k+1;j<=stringsize(prelist);i++,j++)
	{
		rightinlist[i] = inlist[j];
		rightprelist[i] = prelist[j];
	}
	
	root->label = prelist[0];
	root->L = gentree(leftinlist,leftprelist);
	root->R = gentree(rightinlist,rightprelist);
	
	return root;
}

void printtree ( node *root )
{
   if (root == NULL) return;
   printf("Node : %c, ",root->label);
   printf("Left child : ");
   if (root->L == NULL) printf("NULL, ");
   else printf("   %c, ",root->L->label);
   printf("Right child : ");
   if (root->R == NULL) printf("NULL.\n");
   else printf("   %c.\n",root->R->label);
   printtree(root->L);
   printtree(root->R);
}

int main ()
{
   char inlist[MAX_SIZE], prelist[MAX_SIZE];
   node *root;

   printf("Inorder listing  : "); scanf("%s",inlist);
   printf("Preorder listing : "); scanf("%s",prelist);
   
   root = gentree(inlist,prelist);
   
   printtree(root);
   return(0);
}
