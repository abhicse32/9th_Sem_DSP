#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define MAX_SIZE 100
int curr=0;

typedef struct _node {
   char label;
   struct _node *L;
   struct _node *R;
} node;

node* node_new(char val)
{
   node* newNode=(node*)malloc(sizeof(node));
   newNode->label=val;
   newNode->L=NULL;
   newNode->R=NULL;
   return newNode;
}

node* createTree(char* inlist,char* prelist, int start,int end)
{
   if(start>end)
      return NULL;
   node* temp=node_new(prelist[curr++]);
   if(start==end)
      return temp;
   int index=0;
   int i;
   for(i=start;i<=end;i++)
      if(inlist[i]==temp->label)
         {
            index=i;
            break;
         }
   temp->L=createTree(inlist,prelist,start,index-1);
   temp->R=createTree(inlist,prelist,index+1,end);
   return temp;

}

// COMPLETE THE FOLLOWING gentree FUNCTION
node *gentree ( char *inlist , char *prelist )
{
   // Write C-code Here
   return createTree(inlist,prelist,0,strlen(inlist)-1);
}

void printtree ( node *root )
{
   if (root == NULL) return;
   printf("Node : %c, ",root->label);
   printf("Left child : ");
   if (root->L == NULL) printf("NULL, ");
   else printf("   %c, ",root->L->label);
   printf("Right child : ");
   if (root->R == NULL) printf("NULL.\n");
   else printf("   %c.\n",root->R->label);
   printtree(root->L);
   printtree(root->R);
}

int main ()
{
   char inlist[MAX_SIZE], prelist[MAX_SIZE];
   node *root;

   printf("Inorder listing  : "); scanf("%s",inlist);
   printf("Preorder listing : "); scanf("%s",prelist);
   root = gentree(inlist,prelist);
   printtree(root);
   return(0);
}
