#include <stdio.h>
#include <string.h>
#include<stdlib.h>

#define MAX_SIZE 100

typedef struct _node {
   char label;
   struct _node *L;
   struct _node *R;
} node;

// COMPLETE THE FOLLOWING gentree FUNCTION
node *gentree ( char *inlist , char *prelist )
{	
	if(strlen(inlist) == 0)
		return NULL ;	

	int l = strlen(inlist) ;
	node* root = (node*)malloc(sizeof(node)) ;
	root->label = prelist[0] ;
	root->L = NULL ;
	root->R = NULL ;
	
	if(l == 1)
		return root ;
	
	char rt = prelist[0] ;
	int i=0,j,k;
	while(inlist[i] != rt)
	{
		i++ ;
	}
	char *in1 = (char*)malloc(sizeof(char)*(l+1)) ;
	char *pre1 = (char*)malloc(sizeof(char)*(l+1)) ;
	for(j=0;j<i;j++)
	{
		in1[j] = inlist[j] ;
	}
	in1[j] = '\0' ;
	for(j=1;j<=i;j++)
	{
		pre1[j-1] = prelist[j] ; 
	}
	pre1[j-1] = '\0' ;	
	if (j==0)
	root->L =NULL ;
	else
	root->L = gentree(in1,pre1) ;
	
	char *in2 = (char*)malloc(sizeof(char)*(l+1)) ;
	char *pre2 = (char*)malloc(sizeof(char)*(l+1)) ;
	
	for(j=i+1,k=0;j<l;j++,k++)
	{
		in2[k] = inlist[j] ;
	}
	in2[k] = '\0' ;
	for(j=i+1,k=0;j<l;j++,k++)
	{
		pre2[k] = prelist[j] ;
	}
	pre2[k] = '\0' ;
	if(k ==0)
	root->R = NULL ;
	else
	root->R = gentree(in2,pre2) ;
	
	return root ;
}

void printtree ( node *root )
{
   if (root == NULL) return;
   printf("Node : %c, ",root->label);
   printf("Left child : ");
   if (root->L == NULL) printf("NULL, ");
   else printf("   %c, ",root->L->label);
   printf("Right child : ");
   if (root->R == NULL) printf("NULL.\n");
   else printf("   %c.\n",root->R->label);
   printtree(root->L);
   printtree(root->R);
}

int main ()
{
   char inlist[MAX_SIZE], prelist[MAX_SIZE];
   node *root;

   printf("Inorder listing  : "); scanf("%s",inlist);
   printf("Preorder listing : "); scanf("%s",prelist);
   root = gentree(inlist,prelist);
   printtree(root);
   return(0);
}
