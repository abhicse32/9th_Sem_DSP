#include <stdio.h>
#include <string.h>
#include<stdlib.h>

#define MAX_SIZE 100

typedef struct _node {
   char label;
   struct _node *L;
   struct _node *R;
} node;

int findInString(char* list, char inp){
  int len = strlen(list);
  int i;
  for(i = 0; i < len; i++){
	if(list[i] == inp)
	  return i;
  }
}

int start = 0, end = MAX_SIZE, pointer = 0;
int tempstart = 0;
// COMPLETE THE FOLLOWING gentree FUNCTION
node *gentree ( char *inlist , char *prelist )
{
   // Write C-code Here
   // Base cases
   if(pointer >= strlen(prelist))
	 return NULL;

   int position = findInString(inlist, prelist[pointer]);
   if(position >= end || position < start){
	 return NULL;
   }

   node* new = (node*) malloc(sizeof(node));
   new->L = NULL;
   new->R = NULL;
   new->label = prelist[pointer];

   int tempend = end;
   end = findInString(inlist, prelist[pointer]);
   tempstart = findInString(inlist, prelist[pointer])+1;

   pointer++;
   new->L = gentree(inlist, prelist);

   end = tempend;

   int temp = start;
   start = tempstart;
   new->R = gentree(inlist, prelist);

   start = temp;

   return new;
}

void printtree ( node *root )
{
   if (root == NULL) return;
   printf("Node : %c, ",root->label);
   printf("Left child : ");
   if (root->L == NULL) printf("NULL, ");
   else printf("   %c, ",root->L->label);
   printf("Right child : ");
   if (root->R == NULL) printf("NULL.\n");
   else printf("   %c.\n",root->R->label);
   printtree(root->L);
   printtree(root->R);
}

int main ()
{
   char inlist[MAX_SIZE], prelist[MAX_SIZE];
   node *root;

   printf("Inorder listing  : "); scanf("%s",inlist);
   printf("Preorder listing : "); scanf("%s",prelist);
   root = gentree(inlist,prelist);
   printtree(root);
   return(0);
}
