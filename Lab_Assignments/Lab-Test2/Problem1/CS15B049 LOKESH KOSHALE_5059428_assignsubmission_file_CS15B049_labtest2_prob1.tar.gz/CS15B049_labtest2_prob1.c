#include <stdio.h>
#include <string.h>
#include<stdlib.h>

#define MAX_SIZE 100

typedef struct _node {
   char label;
   struct _node *L;
   struct _node *R;
} node;


node* new_node(char ch)
{
	node* ptr = (node*)malloc(sizeof(node));
	if(ptr != NULL)
	{
		ptr->label = ch;
		ptr->L = NULL;
		ptr->R = NULL;
	}

	return ptr;
}

char* copy(char* in,int start,int end)
{
	
	int size = end - start + 1;
	int i,j=0;
	
	char* str = (char*)malloc(sizeof(char)*size);

	for(i=start;i<=end;i++)
	{
		str[j] = in[i];
		j++;
	}

	return str;
}

// COMPLETE THE FOLLOWING gentree FUNCTION
node *gentree ( char *inlist , char *prelist )
{
   // Write C-code Here


	static int idx =0;

	char a = prelist[idx];

	int i;
	int in = -1;
	int size = strlen(inlist);

	for(i=0;i<size;i++)
	{
		if(a == inlist[i])
		{
			in = i;
			break;
		}
	}

	if(in == -1)
		return NULL;
	
	node* root = new_node(a);

	if(size>1)
	{
		if(in-1 >= 0)
		{
			char* lsub = copy(inlist,0,in-1);
			idx++;
			root->L = gentree(lsub,prelist);
		}
		
		if(in+1 <= size-1)
		{
			char* rsub = copy(inlist,in+1,size-1);
			idx++;
			root->R = gentree(rsub,prelist);
		}
	}
	
	return root;
}

void printtree ( node *root )
{
   if (root == NULL) return;
   printf("Node : %c, ",root->label);
   printf("Left child : ");
   if (root->L == NULL) printf("NULL, ");
   else printf("   %c, ",root->L->label);
   printf("Right child : ");
   if (root->R == NULL) printf("NULL.\n");
   else printf("   %c.\n",root->R->label);
   printtree(root->L);
   printtree(root->R);
}

int main ()
{
   char inlist[MAX_SIZE], prelist[MAX_SIZE];
   node *root;

   printf("Inorder listing  : "); scanf("%s",inlist);
   printf("Preorder listing : "); scanf("%s",prelist);
   root = gentree(inlist,prelist);
   printtree(root);
   return(0);
}
