#include <stdio.h>
#include <string.h>
#include<stdlib.h>

#define MAX_SIZE 100

typedef struct _node {
   char label;
   struct _node *L;
   struct _node *R;
} node;

node* new_node(char ch)
{
	node* new;
	new=(node*)malloc(sizeof(node));
	new->label=ch;
	new->R=NULL;
	new->L=NULL;
	return new;
}

// COMPLETE THE FOLLOWING gentree FUNCTION
node *gentree ( char *inlist , char *prelist )
{
   int flag,i;
   for(i=0;i<strlen(inlist);i++) 
   {
   		if(inlist[i]!='1')
   		{
   			flag=0;
   			break;
   		}
   }
   if(flag) return NULL;
   node* root=new_node(prelist[0]);
   for(i=1;i<strlen(prelist);i++) prelist[i-1]=prelist[i];
   if(strlen(prelist)==1) prelist[0]='\0';
   else prelist[i]='\0';
   for(i=0;i<strlen(inlist);i++) 
   {
   		if(inlist[i]==root->label)
   		{
   			inlist[i]='1';
   			break;
   		}
   }
   root->L=gentree(inlist,prelist);
   root->R=gentree(inlist,prelist);   
   
   return root;
}

void printtree ( node *root )
{
   if (root == NULL) return;
   printf("Node : %c, ",root->label);
   printf("Left child : ");
   if (root->L == NULL) printf("NULL, ");
   else printf("   %c, ",root->L->label);
   printf("Right child : ");
   if (root->R == NULL) printf("NULL.\n");
   else printf("   %c.\n",root->R->label);
   printtree(root->L);
   printtree(root->R);
}

int main ()
{
   char inlist[MAX_SIZE], prelist[MAX_SIZE];
   node *root;

   printf("Inorder listing  : "); scanf("%s",inlist);
   printf("Preorder listing : "); scanf("%s",prelist);
   root = gentree(inlist,prelist);
   printtree(root);
   return(0);
}
